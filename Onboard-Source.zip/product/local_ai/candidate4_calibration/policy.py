"""Pure, owner-authorized one-attempt policy. No inference imports or execution."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[3]
B=ROOT/'product/local_ai'
E=ROOT/'docs/sprint3a/evidence/candidate4-calibration-01'
PREFLIGHT=ROOT/'docs/sprint3a/evidence/candidate4-preflight-01'
LABEL='ENGINEERING_CALIBRATION_ONLY'
IDENT='2ac1559f0e7d0e8848242f5db55226b23715ca9a8b12968242065b01965b3547'
GiB=1024**3
POLICY={'label':LABEL,'planningWorkingAllowanceBytes':int(4.5*GiB),'planningAdmissionBytes':int(6.5*GiB),
 'planningPolicyAdopted':False,'calibrationBypass':'Only the unmeasured 4.5 GiB pre-load working allowance',
 'reserveBytes':2*GiB,'abortAvailableBytes':int(2.25*GiB),'workerFootprintUpperBytes':int(4.5*GiB),
 'maxCompressorGrowthBytes':512*1024**2,'maxSwapGrowthBytes':0,'sampleIntervalSeconds':.25,
 'monitorStaleSeconds':1.5,'wallTimeoutSeconds':180,'loadTimeoutSeconds':90,'generationTimeoutSeconds':60,
 'maxTotalContext':512,'maxNewTokens':128,'prefillStepSize':128,'batch':1,'loadRequests':1,'generationRequests':1,
 'tools':[],'recoverySeconds':3}

def save(name,data):
    with (E/name).open('x') as f:json.dump(dict(data,label=LABEL),f,indent=2);f.write('\n')

def violation(row,baseline):
    required=['availableEstimateBytes','pressure','swapUsedBytes','compressorBytes','thermal','workerFootprintBytes']
    if any(k not in row for k in required):return 'MONITOR: missing field'
    if row['availableEstimateBytes']<=POLICY['abortAvailableBytes']:return 'RESOURCE: protected reserve approached'
    if row['pressure']!=1:return 'RESOURCE: non-normal or unknown pressure'
    if row['swapUsedBytes']>baseline['swapUsedBytes']:return 'RESOURCE: swap grew'
    if row['compressorBytes']-baseline['compressorBytes']>=POLICY['maxCompressorGrowthBytes']:return 'RESOURCE: compressor growth >=512 MiB'
    if row['thermal'] not in [0,1]:return 'RESOURCE: unsafe or unknown thermal'
    if row['workerFootprintBytes'] is not None and row['workerFootprintBytes']>POLICY['workerFootprintUpperBytes']:return 'RESOURCE: worker footprint >4.5 GiB'
    return None

def deadline_violation(now,started,last_sample,phase,phase_started):
    if now-last_sample>POLICY['monitorStaleSeconds']:return 'MONITOR: stale >1.5 seconds'
    if now-started>POLICY['wallTimeoutSeconds']:return 'RUNTIME: overall wall timeout'
    if phase=='load' and now-phase_started>POLICY['loadTimeoutSeconds']:return 'RUNTIME: load timeout'
    if phase=='generate' and now-phase_started>POLICY['generationTimeoutSeconds']:return 'RUNTIME: generation timeout'
    return None

def classify(success,aborts,events):
    if success:return 'LOCAL_GENERATION_SUCCESS'
    kinds={x.get('classification') for x in events if x.get('event')=='fatal'}
    loaded=any(x.get('event')=='MODEL_LOADED' for x in events)
    reason=aborts[0] if aborts else ''
    if 'NETWORK' in kinds or reason.startswith('NETWORK:'):return 'NETWORK_BOUNDARY_FAILED'
    if 'ACTIVATION' in kinds or reason.startswith('ACTIVATION:'):return 'ACTIVATION_VERIFICATION_FAILED'
    if reason.startswith('RESOURCE:'):return 'LOCAL_GENERATION_ABORTED_RESOURCE_GUARD' if loaded else 'MODEL_LOAD_ABORTED_RESOURCE_GUARD'
    if 'COMPATIBILITY' in kinds:return 'RUNTIME_COMPATIBILITY_FAILED'
    return 'LOCAL_GENERATION_FAILED' if loaded else 'MODEL_LOAD_FAILED'

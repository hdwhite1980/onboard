"""Pure guard/protocol checks; never imports MLX or launches the worker."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p

class Guards(unittest.TestCase):
    def setUp(self):
        self.base={'availableEstimateBytes':4*p.GiB,'pressure':1,'swapUsedBytes':0,
           'compressorBytes':3*p.GiB,'thermal':0,'workerFootprintBytes':None}
    def test_only_planning_admission_bypassed(self):
        self.assertIsNone(p.violation(self.base,self.base))
        self.assertLess(self.base['availableEstimateBytes'],p.POLICY['planningAdmissionBytes'])
        self.assertEqual(p.POLICY['reserveBytes'],2*p.GiB)
        self.assertFalse(p.POLICY['planningPolicyAdopted'])
    def test_reserve_equal_stops(self):
        self.assertTrue(p.violation(dict(self.base,availableEstimateBytes=int(2.25*p.GiB)),self.base))
    def test_compression_equal_stops(self):
        self.assertTrue(p.violation(dict(self.base,compressorBytes=self.base['compressorBytes']+512*1024**2),self.base))
    def test_swap_any_increase(self):
        self.assertTrue(p.violation(dict(self.base,swapUsedBytes=1),self.base))
    def test_pressure_unknown_or_abnormal(self):
        for v in [None,0,2]:self.assertTrue(p.violation(dict(self.base,pressure=v),self.base))
    def test_thermal_unknown_or_serious(self):
        for v in [None,2,3]:self.assertTrue(p.violation(dict(self.base,thermal=v),self.base))
    def test_worker_hard_upper(self):
        self.assertIsNone(p.violation(dict(self.base,workerFootprintBytes=int(4.5*p.GiB)),self.base))
        self.assertTrue(p.violation(dict(self.base,workerFootprintBytes=int(4.5*p.GiB)+1),self.base))
    def test_missing_monitor_field(self):
        row=dict(self.base);del row['pressure'];self.assertTrue(p.violation(row,self.base))
    def test_stale_watchdog(self):self.assertTrue(p.deadline_violation(2,0,0,'load',0).startswith('MONITOR:'))
    def test_load_deadline(self):self.assertIn('load timeout',p.deadline_violation(91,0,91,'load',0))
    def test_generation_deadline(self):self.assertIn('generation timeout',p.deadline_violation(61,0,61,'generate',0))
    def test_wall_deadline(self):self.assertIn('wall timeout',p.deadline_violation(181,0,181,'unload',180))
    def test_classifications(self):
        self.assertEqual(p.classify(False,['RESOURCE: compressor'],[]),'MODEL_LOAD_ABORTED_RESOURCE_GUARD')
        self.assertEqual(p.classify(False,['RESOURCE: compressor'],[{'event':'MODEL_LOADED'}]),'LOCAL_GENERATION_ABORTED_RESOURCE_GUARD')
        self.assertEqual(p.classify(False,['ACTIVATION: metadata'],[]),'ACTIVATION_VERIFICATION_FAILED')
        self.assertEqual(p.classify(False,['NETWORK: denied control failed'],[]),'NETWORK_BOUNDARY_FAILED')
        self.assertEqual(p.classify(False,['COMPATIBILITY: cache'],[{'event':'fatal','classification':'COMPATIBILITY'}]),'RUNTIME_COMPATIBILITY_FAILED')
    def test_frozen_prompt(self):
        a=json.loads((p.PREFLIGHT/'future-first-prompt.json').read_text())
        self.assertEqual(a['promptTokens'],len(a['tokenIDs']))
        self.assertEqual(a['promptTokens'],110)
        self.assertEqual(a['promptTokens']+p.POLICY['maxNewTokens'],238)
        self.assertEqual(a['templateSHA256'],'fed2756d2d24e127b951dcf139d0b03ab7db8ef23a456128ebc9c2db4901d476')
    def test_no_static_runtime_change(self):
        preflight=json.loads((p.PREFLIGHT/'EVIDENCE_MANIFEST.json').read_text())
        for row in preflight['files']:
            if row['path'].startswith('product/local_ai/candidate4/'):
                self.assertEqual(hashlib.sha256((p.ROOT/row['path']).read_bytes()).hexdigest(),row['sha256'])
        for file in Path(__file__).parent.glob('*.py'):ast.parse(file.read_text())

if __name__=='__main__':unittest.main()

"""One-use supervisor with independent pre-worker monitor/watchdog and no retry path."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import signal
import subprocess
import sys
import threading
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p

def run(argv):
    result=subprocess.run(list(map(str,argv)),capture_output=True,text=True,timeout=1,check=True)
    return result.stdout

def sample(pid=None):
    vm=run(['/usr/bin/vm_stat']);page=int(re.search(r'page size of (\d+)',vm)[1])
    counts={k:int(v) for k,v in re.findall(r'^(Pages [\w ]+):\s+(\d+)',vm,re.M)}
    pressure=int(run(['/usr/sbin/sysctl','-n','kern.memorystatus_vm_pressure_level']))
    raw=run(['/usr/sbin/sysctl','vm.swapusage']);sw=re.search(r'used\s*=\s*([\d.]+)([MG])',raw);assert sw
    native=json.loads(run([p.B/'.artifacts/build/resource-probe',str(pid or os.getpid())]))
    assert native['error']==0 and native['phys_footprint'] is not None
    return {'label':p.LABEL,'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonic':time.monotonic(),
       'pageSizeBytes':page,'pages':{k:counts[k] for k in ['Pages free','Pages inactive','Pages speculative','Pages wired down','Pages occupied by compressor']},
       'availableEstimateBytes':page*sum(counts[k] for k in ['Pages free','Pages inactive','Pages speculative']),
       'wiredBytes':page*counts['Pages wired down'],'compressorBytes':page*counts['Pages occupied by compressor'],
       'swapUsedBytes':int(float(sw[1])*{'M':1024**2,'G':p.GiB}[sw[2]]),'pressure':pressure,'thermal':native['thermal_state'],
       'workerFootprintBytes':native['phys_footprint'] if pid else None,'native':native}

def main():
    # Code is frozen after pure tests, before this unique execution marker.
    for row in json.loads((p.E/'tested-source.json').read_text())['files']:
        assert hashlib.sha256((p.ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
    p.save('ATTEMPT_STARTED.json',{'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'retryAllowed':False})
    p.save('policy.json',p.POLICY)
    prepare=subprocess.run([sys.executable,'-I','-B',str(Path(__file__).with_name('prepare.py'))],capture_output=True,text=True)
    p.save('verification-exit.json',{'exitCode':prepare.returncode,'stdout':prepare.stdout,'stderr':prepare.stderr,
       'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonic':time.monotonic()})
    if prepare.returncode:
        failure=json.loads((p.E/'preparation-failure.json').read_text()) if (p.E/'preparation-failure.json').exists() else {'status':'ACTIVATION_VERIFICATION_FAILED'}
        p.save('result.json',{'status':failure['status'],'success':False,'preparationFailed':True,'loadRequests':0,'generationRequests':0,'retryAllowed':False})
        print(failure['status']);return
    settling=time.monotonic();time.sleep(10)
    p.save('settling.json',{'seconds':time.monotonic()-settling,'verifierExited':True,'naturalOnly':True})
    scratch=p.B/'.artifacts/state/candidate4-calibration-01';scratch.mkdir(parents=True,exist_ok=False)
    # Do not repurpose HOME; caches/tmp are explicitly redirected through task-specific settings.
    env=dict(os.environ)
    env.update(PATH='/usr/bin:/bin',TMPDIR=str(scratch),HF_HOME=str(scratch/'hf'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
       HF_HUB_DISABLE_TELEMETRY='1',HF_HUB_DISABLE_XET='1',DO_NOT_TRACK='1',TOKENIZERS_PARALLELISM='false',
       PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1',USE_TORCH='0',USE_TF='0',USE_FLAX='0')
    cmd=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)',sys.executable,'-I','-B',str(Path(__file__).with_name('worker.py'))]
    p.save('launch.json',{'command':cmd,'offlineFlags':{k:env[k] for k in ['HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_HUB_DISABLE_TELEMETRY','USE_TORCH','USE_TF','USE_FLAX']},
       'appleFoundationBackend':'DISABLED_UNREGISTERED','externalFallbacks':[],'tools':[]})
    host={'physicalMemoryBytes':int(run(['/usr/sbin/sysctl','-n','hw.memsize'])),'power':run(['/usr/bin/pmset','-g','batt'])}
    events=[];samples=[];aborts=[];q=queue.Queue();proc=[None];baseline=[None];stage=['pre_worker'];phase_start=[time.monotonic()]
    stop=threading.Event();baseline_ready=threading.Event();abort_lock=threading.Lock();start=time.monotonic();last_sample=[start]
    err=(p.E/'worker.stderr').open('x');raw=(p.E/'worker-events.jsonl').open('x');metrics=(p.E/'resources.jsonl').open('x')
    def abort(why):
        with abort_lock:
            if not aborts:aborts.append(why)
            if proc[0] is not None and proc[0].poll() is None:
                try:os.killpg(proc[0].pid,signal.SIGKILL)
                except ProcessLookupError:pass
    def monitor():
        while not stop.is_set():
            sample_started=time.monotonic()
            try:
                worker=proc[0];pid=worker.pid if worker is not None and worker.poll() is None else None
                try:row=sample(pid)
                except BaseException:
                    if worker is not None and worker.poll() is not None:row=sample()
                    else:raise
                row['stage']=stage[0];samples.append(row);metrics.write(json.dumps(row)+'\n');metrics.flush();last_sample[0]=time.monotonic()
                if baseline[0] is None:
                    baseline[0]=row;p.save('baseline.json',dict(host,sample=row,availableMethod='free + inactive + speculative; not guaranteed allocatable',
                      planningShortfallBytes=max(0,p.POLICY['planningAdmissionBytes']-row['availableEstimateBytes']),
                      calibrationBypass=p.POLICY['calibrationBypass']))
                why=p.violation(row,baseline[0])
                if why:abort(why)
                baseline_ready.set()
            except BaseException as error:
                abort('MONITOR: unavailable '+repr(error));baseline_ready.set();break
            stop.wait(max(0,p.POLICY['sampleIntervalSeconds']-(time.monotonic()-sample_started)))
    def watchdog():
        last_process_check=0
        while not stop.wait(.1):
            now=time.monotonic();reason=p.deadline_violation(now,start,last_sample[0],stage[0],phase_start[0])
            if reason:abort(reason);break
            if proc[0] is not None and proc[0].poll() is None and now-last_process_check>=1:
                try:
                    # Names only: no unrelated process arguments or environment are retained.
                    listing=run(['/bin/ps','-axo','pid=,pgid=,comm='])
                    children=[]
                    for line in listing.splitlines():
                        fields=line.strip().split(None,2)
                        if len(fields)>=2 and int(fields[1])==proc[0].pid and int(fields[0])!=proc[0].pid:children.append(fields)
                    if children:abort('SECURITY: unexpected worker-group process '+repr(children));break
                    last_process_check=now
                except BaseException as error:abort('MONITOR: process check unavailable '+repr(error));break
    def reader():
        for line in proc[0].stdout:
            try:
                event=json.loads(line);assert event['label']==p.LABEL;event['receivedMonotonic']=time.monotonic()
                raw.write(json.dumps(event)+'\n');raw.flush();events.append(event);q.put(event)
                if event['event']=='fatal':abort(event.get('classification','RUNTIME')+': '+event.get('error','Worker fatal'))
            except BaseException as error:abort('RUNTIME: malformed worker event '+repr(error))
        q.put({'event':'terminated'})
    def wait(wanted,limit=30):
        until=time.monotonic()+limit
        while not aborts:
            if time.monotonic()>until:abort('RUNTIME: timeout awaiting '+wanted);break
            try:event=q.get(timeout=.1)
            except queue.Empty:continue
            if event['event']==wanted:return event
            if event['event']=='terminated':raise RuntimeError('Worker terminated before '+wanted)
        raise RuntimeError(str(aborts))
    sent=[]
    def send(name):
        assert not aborts
        assert name not in sent,'Repeated command prohibited'
        sent.append(name);stage[0]=name;phase_start[0]=time.monotonic()
        proc[0].stdin.write(json.dumps({'command':name})+'\n');proc[0].stdin.flush()
    threads=[threading.Thread(target=f,daemon=True) for f in [monitor,watchdog]]
    for t in threads:t.start()
    success=False
    try:
        assert baseline_ready.wait(3) and baseline[0] is not None,'Baseline unavailable'
        assert not aborts,aborts
        stage[0]='startup'
        with abort_lock:
            assert not aborts
            proc[0]=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,env=env,start_new_session=True)
        p.save('worker-start.json',{'pid':proc[0].pid,'monotonic':time.monotonic(),'baselineMonotonic':baseline[0]['monotonic'],'monitorStartedBeforeWorker':True})
        t=threading.Thread(target=reader,daemon=True);threads.append(t);t.start()
        wait('started');send('initialize');wait('runtime_ready')
        assert any(e['event']=='network_negative_control' and e['denied'] for e in events),'NETWORK_DENIAL_NOT_ESTABLISHED'
        send('load');wait('MODEL_LOADED',90);stage[0]='loaded_steady';time.sleep(1)
        send('generate');wait('generated',60);stage[0]='post_generation';time.sleep(.5)
        send('unload');wait('unloaded');stage[0]='unloaded_steady';time.sleep(1)
        send('exit');proc[0].wait(timeout=5);success=proc[0].returncode==0 and not aborts
    except BaseException as error:abort(('NETWORK' if 'NETWORK_' in str(error) else 'RUNTIME')+': '+repr(error))
    finally:
        if proc[0] is not None:
            if proc[0].poll() is None:abort('RUNTIME: worker failed to terminate')
            proc[0].wait(timeout=5)
        stage[0]='recovery';time.sleep(p.POLICY['recoverySeconds']);stop.set()
        for t in threads:t.join(timeout=2)
        raw.close();metrics.close();err.close()
    success=success and not aborts
    result={'status':p.classify(success,aborts,events),'success':success,'abort':aborts,'exit':proc[0].returncode if proc[0] else None,
      'loadRequests':sum(e['event']=='load_begin' for e in events),'generationRequests':sum(e['event']=='generation_begin' for e in events),
      'modelLoadCompleted':any(e['event']=='MODEL_LOADED' for e in events),'generationCompleted':any(e['event']=='generated' for e in events),
      'networkNegativeControlDenied':any(e['event']=='network_negative_control' and e.get('denied') for e in events),
      'gracefulUnloadCompleted':any(e['event']=='unloaded' for e in events),'workerTerminated':proc[0] is None or proc[0].poll() is not None,
      'normalAdmissionChanged':False,'modelManifestSHA256':p.IDENT,'sampleCount':len(samples),'commandsSent':sent,'retryAllowed':False}
    p.save('recovery.json',{'samples':[s for s in samples if s['stage']=='recovery']})
    p.save('result.json',result)
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()

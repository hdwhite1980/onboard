"""Post-failure observation ONLY: never loads, generates, retries, or signals a process."""
import datetime
import json
import subprocess
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p
from run_once import sample

def main():
    start=json.loads((p.E/'worker-start.json').read_text());pid=start['pid'];assert pid==74548
    raw=subprocess.run(['/bin/ps','-axo','pid=,pgid=,comm='],capture_output=True,text=True,check=True,timeout=3).stdout
    matches=[]
    for line in raw.splitlines():
        fields=line.strip().split(None,2)
        if len(fields)>=2 and (int(fields[0])==pid or int(fields[1])==pid):matches.append(fields)
    assert not matches,'Worker/group still exists; no retry or silent continuation'
    rows=[]
    for _ in range(12):rows.append(sample());time.sleep(.25)
    power=subprocess.run(['/usr/bin/pmset','-g','batt'],capture_output=True,text=True,check=True,timeout=3).stdout
    p.save('recovery-observation.json',{'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'workerPID':pid,'workerAndGroupAbsent':True,'matchingProcesses':matches,'samples':rows,'power':power,
       'limitation':'Delayed observation after supervisor finalization failure. Does not reconstruct the unsampled interval or certify initial signal delivery/exit status.',
       'modelLoads':0,'generationRequests':0,'processSignalsSent':0})
    print(json.dumps({'workerAndGroupAbsent':True,'samples':len(rows),'first':rows[0],'last':rows[-1]},indent=2))

if __name__=='__main__':main()

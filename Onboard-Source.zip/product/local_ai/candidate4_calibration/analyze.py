"""Offline reconstruction after terminated calibration. No model/runtime execution."""
import collections
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p

def main():
    events=[json.loads(s) for s in (p.E/'worker-events.jsonl').read_text().splitlines()]
    rows=[json.loads(s) for s in (p.E/'resources.jsonl').read_text().splitlines()]
    baseline=json.loads((p.E/'baseline.json').read_text())['sample']
    recovery=json.loads((p.E/'recovery-observation.json').read_text())
    load=next(e for e in events if e['event']=='load_begin')
    first_stop=next(r for r in rows if p.violation(r,baseline))
    memory=[e['memory'] for e in events if e.get('memory')]
    growth=max(r['compressorBytes'] for r in rows)-baseline['compressorBytes']
    assert p.violation(first_stop,baseline)=='RESOURCE: compressor growth >=512 MiB'
    assert sum(e['event']=='load_begin' for e in events)==1
    assert not any(e['event'] in ['MODEL_LOADED','generation_begin','generated','unloaded'] for e in events)
    assert recovery['workerAndGroupAbsent']
    images=[v for e in events for v in e.get('images',[])]
    metrics={'baseline':baseline,'resourceSamples':len(rows),'workerPeakBytes':max(r['workerFootprintBytes'] or 0 for r in rows),
       'mlxMaximaBytes':{k:max(x[k] for x in memory) for k in ['active','cache','peak']},
       'minimumAvailableBytes':min(r['availableEstimateBytes'] for r in rows),'maximumCompressorBytes':max(r['compressorBytes'] for r in rows),
       'maximumCompressorGrowthBytes':growth,'compressionTriggerBytes':p.POLICY['maxCompressorGrowthBytes'],
       'observedCompressionOvershootBytes':growth-p.POLICY['maxCompressorGrowthBytes'],
       'swapMaximumBytes':max(r['swapUsedBytes'] for r in rows),'pressureStates':sorted({r['pressure'] for r in rows}),
       'thermalStates':sorted({r['thermal'] for r in rows}),'firstGuardSample':first_stop,
       'observedLoadToGuardSeconds':first_stop['monotonic']-load['monotonic'],
       'completedLoadSeconds':None,'workerExitStatus':None,
       'sampleIntervalSeconds':{'min':min(b['monotonic']-a['monotonic'] for a,b in zip(rows,rows[1:])),
                               'max':max(b['monotonic']-a['monotonic'] for a,b in zip(rows,rows[1:]))},
       'recoveryObservationGapSeconds':recovery['samples'][0]['monotonic']-rows[-1]['monotonic'],
       'lastRecoverySample':recovery['samples'][-1],
       'networkNegativeControl':next(e for e in events if e['event']=='network_negative_control'),
       'foundationModelsInRecordedImageSnapshots':any('foundationmodels' in n.lower() for n in images),
       'generationMeasurements':None,'hybridCacheMeasurements':None,
       'limits':['Incomplete load: worker/MLX maxima are sampled lower bounds, not final safe requirements',
                 'Supervisor finalization failed; continuous recovery and terminal peak were not captured',
                 'Delayed recovery does not reconstruct the intervening interval','No output or inference independence demonstrated']}
    p.save('measurements.json',metrics)
    p.save('result.json',{'status':'MODEL_LOAD_ABORTED_RESOURCE_GUARD','success':False,
       'recordOrigin':'Post-execution reconstruction from preserved raw worker/resources, command failure and follow-up observations; not the missing normal supervisor result.',
       'secondaryFinding':'SUPERVISOR_TERMINATION_FINALIZATION_FAILED','abort':['RESOURCE: compressor growth >=512 MiB'],
       'modelManifestSHA256':p.IDENT,'loadRequests':1,'modelLoadCompletedCheckpoint':False,'generationRequests':0,
       'generationCompleted':False,'gracefulUnloadCompleted':False,'workerExitStatus':None,
       'workerAndGroupConfirmedAbsent':True,'immediateTerminationCertified':False,
       'networkNegativeControlDenied':metrics['networkNegativeControl']['denied'],'normalAdmissionChanged':False,
       'lifecycle':'EXPERIMENTAL','qualifiedTasks':[],'retryExecuted':False})
    print(json.dumps({k:metrics[k] for k in ['workerPeakBytes','mlxMaximaBytes','maximumCompressorGrowthBytes','observedCompressionOvershootBytes','observedLoadToGuardSeconds','recoveryObservationGapSeconds']}))

if __name__=='__main__':main()

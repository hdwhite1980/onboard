"""Seal failure evidence and verify historical references; no runtime/model invocation."""
import datetime
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def record(path):return {'path':str(path.relative_to(p.ROOT)),'bytes':path.stat().st_size,'sha256':digest(path)}

def main():
    frozen=[]
    for name in ['calibration-01','candidate2-01','candidate2-clean-01','candidate2-calibration-01',
       'candidate2-quality-01','candidate3-tokenizer-provenance-01','candidate4-research-01','candidate4-preflight-01']:
        manifest=p.ROOT/'docs/sprint3a/evidence'/name/'EVIDENCE_MANIFEST.json'
        old=json.loads(manifest.read_text());mapped=[]
        for row in old['files']:
            path=p.ROOT/row['path']
            if name=='candidate3-tokenizer-provenance-01' and row['path'].endswith('CANDIDATE3_PUBLISHER_CLARIFICATION_DRAFT.md'):
                path=p.ROOT/'docs/sprint3a/evidence/candidate4-research-01/candidate3-draft-before.md'
            elif name=='candidate4-research-01' and row['path'].endswith('LOCAL_MODEL_COMPARISON.md'):
                path=p.PREFLIGHT/'local-model-comparison-before.md'
            elif name=='candidate4-preflight-01' and row['path'].endswith('LOCAL_MODEL_COMPARISON.md'):
                path=p.E/'local-model-comparison-before.md'
            assert digest(path)==row['sha256'] and path.stat().st_size==row['bytes'],path
            if path!=p.ROOT/row['path']:mapped.append({'originalPath':row['path'],'archivedPath':str(path.relative_to(p.ROOT))})
        frozen.append(dict(**record(manifest),referencesVerified=len(old['files']),explicitArchivedSupersessions=mapped))
    for row in json.loads((p.E/'tested-source.json').read_text())['files']:
        assert digest(p.ROOT/row['path'])==row['sha256'],row['path']
    p.save('preservation-check.json',{'status':'PASS','manifests':frozen,
      'historicalReferencesVerified':sum(r['referencesVerified'] for r in frozen),
      'executedSourcesUnchangedAfterAttempt':True,'candidate1And2Reruns':0,'candidate4Retries':0})
    files=sorted({x for x in p.E.rglob('*') if x.is_file() and x.name!='EVIDENCE_MANIFEST.json'} |
       set(Path(__file__).parent.glob('*.py')) |
       {p.ROOT/'docs/sprint3a/CANDIDATE4_GRANITE_CALIBRATION.md',p.ROOT/'docs/sprint3a/LOCAL_MODEL_COMPARISON.md'})
    p.save('EVIDENCE_MANIFEST.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'scope':'One Granite engineering calibration attempt; raw failure evidence, explicitly reconstructed result and delayed recovery. No retry. Excludes this manifest.',
       'files':[record(x) for x in files], 'packageManifestSHA256':p.IDENT,
       'activationSnapshot':json.loads((p.E/'activation.json').read_text())['snapshot'],
       'artifactVerificationReference':'verification.json plus activation_verified worker event; no fresh model execution for sealing'})
    print(json.dumps({'status':'SEALED','files':len(files),'historicalReferencesVerified':sum(r['referencesVerified'] for r in frozen),
       'manifestSHA256':digest(p.E/'EVIDENCE_MANIFEST.json')}))

if __name__=='__main__':main()

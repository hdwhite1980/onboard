"""Helper-only normal shutdown. Historical worker Supervisor remains unchanged."""
import signal, subprocess, sys, time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'resource_harness_v2'))
from supervisor import Supervisor, atomic_json, stamp
TERM_WINDOW=.1
SANDBOX=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)']
HELPER=Path(__file__).resolve().parents[1]/'candidate4_policy_v2/resource-probe'

def group_present(pgid):
    r=subprocess.run(['/bin/ps','-axo','pgid='],capture_output=True,text=True,check=True,timeout=1)
    return any(int(line.strip())==pgid for line in r.stdout.splitlines() if line.strip())

def launch_helper(duration=210,stderr=subprocess.PIPE):
    return subprocess.Popen(SANDBOX+[str(HELPER),'0','.1',str(duration)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1,start_new_session=True)

class HelperSupervisor(Supervisor):
    def __init__(self,*args,**kwargs):
        kwargs.setdefault('term_wait',TERM_WINDOW)
        super().__init__(*args,**kwargs)
    def _present(self):
        try:
            value=self.group_present()
            return value if type(value) is bool else None
        except ProcessLookupError:
            self.events.append({**stamp(),'event':'GROUP_OBSERVATION','result':'PROCESS_NOT_FOUND'})
            return False
        except BaseException as error:
            self.errors.append({**stamp(),'stage':'group_observation','exception':repr(error)})
            return None
    def _terminate(self):
        self.transition('STOP_REQUESTED')
        if self.proc is None:
            self.transition('ALREADY_EXITED');return
        exited,present=self._poll(),self._present()
        if exited is None and present is not False:
            self._signal(signal.SIGTERM)
            began=time.monotonic()
            try:self.proc.wait(timeout=self.term_wait)
            except subprocess.TimeoutExpired:pass  # Observation expiry is a decision point, not signal failure.
            except BaseException as error:
                self._error('term_observation',lambda:(_ for _ in ()).throw(error))
            self.events.append({**stamp(),'event':'TERM_OBSERVATION','seconds':time.monotonic()-began,'limit':self.term_wait})
        # Both observations are mandatory immediately before escalation. UNKNOWN is not alive.
        exited,present=self._poll(),self._present()
        self.events.append({**stamp(),'event':'PRE_KILL_RECHECK','childExit':exited,'groupPresent':present})
        if exited is None and present is True:
            self._signal(signal.SIGKILL)
        else:
            self.transition('NO_KILL_REAPED_OR_ABSENT' if exited is not None or present is False else 'NO_KILL_STATE_UNKNOWN')
        self.transition('REAP')
        self._error('reap',lambda:self.proc.wait(timeout=self.kill_wait))
        self.events.append({**stamp(),'event':'FINAL_GROUP_OBSERVATION','groupPresent':self._present()})


def join_threads(threads,timeout=2):
    """Always attempt every join; return evidence for failures without raising."""
    rows=[]
    for thread in threads:
        row={**stamp(),'name':thread.name,'requested':True,'completed':False,'timedOut':False,'stillAlive':None,'exception':None}
        try:
            thread.join(timeout=timeout);row['stillAlive']=thread.is_alive()
            row['timedOut']=row['stillAlive'];row['completed']=not row['stillAlive']
        except BaseException as error:row['exception']=repr(error)
        rows.append(row)
    return rows


def cleanup_and_join(life,threads,stop,timeout=2):
    stop.set()
    try:
        result=life.finish('NATIVE_MONITOR_STOPPED',recovery=lambda:{'bounded':True})
    except BaseException as error:
        result={'supervisor':'CLEANUP_OR_EVIDENCE_ERROR','exception':repr(error)}
    joins=join_threads(threads,timeout)
    return {'helper':result,'joins':joins,'clean':result['supervisor']=='TERMINATION_CONFIRMED' and all(r['completed'] for r in joins)}

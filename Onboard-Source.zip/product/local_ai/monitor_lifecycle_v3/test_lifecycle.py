"""Deterministic harmless fault tests. No AI imports or model launch path."""
import errno,json,signal,subprocess,sys,tempfile,threading,time,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from lifecycle import HelperSupervisor,Supervisor,join_threads,cleanup_and_join
class Fake:
    pid=2147483000
    def __init__(self,mode='normal'):self.mode=mode;self.status=None;self.present=True;self.calls=[];self.waits=[];self.observations=0
    def poll(self):return self.status
    def group(self):
        self.observations+=1
        if self.mode=='unknown':return None
        if self.mode=='lookup' and self.calls:self.status=-15;raise ProcessLookupError(errno.ESRCH,'synthetic')
        if self.mode=='disappears' and self.calls:self.status=-15;self.present=False
        return self.present
    def send(self,pid,sig):
        self.calls.append(sig)
        if self.mode=='term_permission' and sig==signal.SIGTERM:self.status=-15;self.present=False;raise PermissionError(errno.EPERM,'synthetic')
        if self.mode=='kill_permission' and sig==signal.SIGKILL:self.status=-15;self.present=False;raise PermissionError(errno.EPERM,'synthetic')
        if sig==signal.SIGKILL and self.mode!='timeout':self.status=-9;self.present=False
        if sig==signal.SIGTERM and self.mode=='normal':self.status=-15;self.present=False
    def wait(self,timeout):
        self.waits.append(timeout)
        if self.mode=='boundary' and self.calls and timeout==.1:self.status=-15;self.present=False
        if self.status is None:raise subprocess.TimeoutExpired('fake',timeout)
        return self.status
class Tests(unittest.TestCase):
    def run_case(self,mode='normal',exit=None,recovery=lambda:{'complete':True}):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        p=Fake(mode)
        if exit is not None:p.status=exit;p.present=False
        s=HelperSupervisor(Path(self.tmp.name)/'case',p,p.pid,signal_group=p.send,group_present=p.group)
        r=s.finish('HARMLESS',recovery=recovery)
        self.assertTrue((s.directory/'manifest.json').exists());return p,s,r
    def test_normal_term(self):
        p,s,r=self.run_case();self.assertEqual(p.calls,[signal.SIGTERM]);self.assertEqual(r['supervisor'],'TERMINATION_CONFIRMED')
    def test_boundary_exit(self):
        p,s,r=self.run_case('boundary');self.assertEqual(p.calls,[signal.SIGTERM]);self.assertEqual(p.waits[0],.1)
    def test_ignored_term_kill(self):
        p,s,r=self.run_case('ignore');self.assertEqual(p.calls,[signal.SIGTERM,signal.SIGKILL]);self.assertEqual(r['supervisor'],'TERMINATION_CONFIRMED')
    def test_already_exited(self):self.assertEqual(self.run_case(exit=0)[0].calls,[])
    def test_disappears(self):self.assertEqual(self.run_case('disappears')[0].calls,[signal.SIGTERM])
    def test_lookup(self):self.assertEqual(self.run_case('lookup')[0].calls,[signal.SIGTERM])
    def test_term_permission(self):self.assertEqual(self.run_case('term_permission')[2]['supervisor'],'TERMINATION_PERMISSION_ERROR')
    def test_kill_permission(self):self.assertEqual(self.run_case('kill_permission')[2]['supervisor'],'TERMINATION_PERMISSION_ERROR')
    def test_unknown(self):
        p,s,r=self.run_case('unknown');self.assertNotIn(signal.SIGKILL,p.calls);self.assertEqual(r['supervisor'],'TERMINATION_UNCONFIRMED')
    def test_reader_normal(self):
        t=threading.Thread(target=lambda:None);t.start();self.assertTrue(join_threads([t])[0]['completed'])
    def test_reader_delayed(self):
        t=threading.Thread(target=lambda:time.sleep(.02));t.start();self.assertTrue(join_threads([t],.2)[0]['completed'])
    def test_reader_timeout(self):
        stop=threading.Event();t=threading.Thread(target=stop.wait);t.start()
        try:self.assertTrue(join_threads([t],.001)[0]['timedOut'])
        finally:stop.set();t.join()
    def test_double_cleanup(self):
        p,s,r=self.run_case();self.assertIs(s.finish('SECOND'),r);self.assertEqual(len(p.calls),1)
    def test_crash(self):self.assertEqual(self.run_case(exit=-11)[0].calls,[])
    def test_eof(self):
        # Reader EOF must join even while the sampler itself still needs TERM.
        t=threading.Thread(target=lambda:list(iter(())));t.start()
        p,s,r=self.run_case();self.assertTrue(cleanup_and_join(s,[t],threading.Event())['clean'])
    def test_cleanup_timeout(self):self.assertEqual(self.run_case('timeout')[2]['supervisor'],'TERMINATION_UNCONFIRMED')
    def test_recovery_failure(self):
        def fail():raise RuntimeError('synthetic recovery failure')
        self.assertEqual(self.run_case(recovery=fail)[2]['supervisor'],'CLEANUP_OR_EVIDENCE_ERROR')
    def test_join_despite_helper_error(self):
        p,s,r=self.run_case('term_permission');t=threading.Thread(target=lambda:None);t.start()
        row=cleanup_and_join(s,[t],threading.Event());self.assertFalse(row['clean']);self.assertTrue(row['joins'][0]['completed'])
    def test_model_abort_remains_immediate(self):
        with tempfile.TemporaryDirectory() as d:
            p=Fake('ignore');s=Supervisor(Path(d)/'worker',p,p.pid,signal_group=p.send,group_present=p.group,term_wait=0)
            s.finish('HARD_STOP');self.assertEqual(p.waits[0],0);self.assertEqual(p.calls,[signal.SIGTERM,signal.SIGKILL])
if __name__=='__main__':unittest.main(verbosity=2)

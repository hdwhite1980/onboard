"""Ten sequential real helper cycles at the exact intended quality boundary; no AI imports."""
import hashlib,json,os,platform,subprocess,sys,threading,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from lifecycle import HelperSupervisor,atomic_json,stamp,group_present,launch_helper,cleanup_and_join,HELPER,SANDBOX,TERM_WINDOW
ROOT=Path(__file__).resolve().parents[3];E=ROOT/'docs/sprint3a/evidence/monitor-lifecycle-v3-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def seal(d):
    atomic_json(d/'manifest.json',{'files':[{'path':str(p.relative_to(d)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(d.rglob('*')) if p.is_file() and p!=d/'manifest.json']})
def valid_manifest(d):
    return all(sha(d/r['path'])==r['sha256'] for r in json.loads((d/'manifest.json').read_text())['files'])
def main():
    (E/'ATTEMPT_STARTED.json').open('x').write(json.dumps(stamp()))
    files=[Path(__file__),Path(__file__).with_name('lifecycle.py'),Path(__file__).with_name('test_lifecycle.py'),HELPER,ROOT/'product/local_ai/resource_harness_v2/supervisor.py']
    atomic_json(E/'tested-source.json',{'files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in files]})
    atomic_json(E/'context.json',{'uid':os.getuid(),'interpreter':sys.executable,'interpreterSHA256':sha(Path(sys.executable).resolve()),'python':platform.python_version(),'machine':platform.machine(),'sandbox':SANDBOX,'helper':str(HELPER),'startNewSession':True,'helperTermWindowSeconds':TERM_WINDOW,'workerTermWindowSeconds':0})
    test=subprocess.run([sys.executable,'-I','-B',str(Path(__file__).with_name('test_lifecycle.py'))],capture_output=True,text=True,timeout=30)
    (E/'pure-tests.txt').write_text(test.stdout+test.stderr)
    rows=[]
    if test.returncode==0:
      for index in range(10):
        d=E/f'cycle-{index+1:02}';life=HelperSupervisor(d/'lifecycle',group_present=lambda:False)
        stop=threading.Event();ready=threading.Event();samples=[];events=[];reader_errors=[];recovery=[]
        proc=None;row={'index':index+1,'pass':False};threads=[]
        try:
          proc=launch_helper();life.proc=proc;life.pgid=proc.pid;life.group_present=lambda:group_present(proc.pid)
          def reader():
            try:
              for line in proc.stdout:
                event=json.loads(line);events.append(event)
                if event['event']=='sample':samples.append(event)
                if len(samples)>=3 and any(e['event']=='pressure_subscription_ready' for e in events):ready.set()
            except BaseException as error:reader_errors.append(repr(error))
          def watchdog():
            while not stop.wait(.05):
              if samples and time.monotonic()-samples[-1]['monotonic']>1.5:reader_errors.append('stale native telemetry');return
          threads=[threading.Thread(target=reader,name='monitor-reader',daemon=True),threading.Thread(target=watchdog,name='watchdog',daemon=True)]
          for t in threads:t.start()
          assert ready.wait(3),'helper readiness timeout'
          began=time.monotonic();cleanup=cleanup_and_join(life,threads,stop)
          elapsed=time.monotonic()-began
          for i in range(4):
            deadline=time.monotonic()+.25
            result=subprocess.run(SANDBOX+[str(HELPER),'0','.25','0'],capture_output=True,text=True,check=True,timeout=1)
            sample=json.loads(result.stdout);sample['helperGroupPresent']=group_present(proc.pid);recovery.append(sample)
            time.sleep(max(0,deadline-time.monotonic()))
          signals=[e for e in life.events if e['event']=='SIGNAL']
          term=next(e for e in signals if e['signal']=='SIGTERM')
          recheck=next(e for e in life.events if e['event']=='PRE_KILL_RECHECK')
          absent=next(e for e in life.events if e['event']=='FINAL_GROUP_OBSERVATION')
          row.update(pid=proc.pid,exitCode=proc.returncode,cleanup=cleanup,cleanupSeconds=elapsed,termToReapedObservationSeconds=recheck['monotonic']-term['monotonic'],termToGroupAbsenceSeconds=absent['monotonic']-term['monotonic'],samples=len(samples),readerErrors=reader_errors)
          assert cleanup['clean'] and proc.returncode==-15 and not group_present(proc.pid)
          assert len(signals)==1 and term['result']=='SENT' and not reader_errors
          assert all(s['helperGroupPresent'] is False for s in recovery)
          assert valid_manifest(d/'lifecycle')
          row['pass']=True
        except BaseException as error:
          row['error']=repr(error)
          if proc and life.result is None:row['cleanup']=cleanup_and_join(life,threads,stop)
        finally:
          if proc:
            for f in (proc.stdin,proc.stdout,proc.stderr):
              if f:f.close()
          atomic_json(d/'observations.json',{'events':events,'recovery':recovery})
          atomic_json(d/'result.json',row);seal(d);row['manifestValid']=valid_manifest(d);rows.append(row)
        print(json.dumps({'cycle':index+1,'pass':row['pass'],'manifestValid':row['manifestValid']}),flush=True)
        if not row['pass'] or not row['manifestValid']:break
    passed=test.returncode==0 and len(rows)==10 and all(r['pass'] and r['manifestValid'] for r in rows)
    latencies=[r['termToReapedObservationSeconds'] for r in rows if 'termToReapedObservationSeconds' in r]
    # 100 ms is the smallest suggested starting window; require at least 2x observed margin.
    margin=bool(latencies) and max(latencies)<TERM_WINDOW/2
    passed=passed and margin
    result={'status':'MONITOR_LIFECYCLE_QUALIFIED_FOR_TESTED_CONTEXT' if passed else 'MONITOR_LIFECYCLE_NOT_QUALIFIED','pureTestsPassed':test.returncode==0,'realCycles':len(rows),'realPassed':sum(r['pass'] for r in rows),'allManifestsValid':all(r['manifestValid'] for r in rows),'observationWindowSeconds':TERM_WINDOW,'worstTermToReapedObservationSeconds':max(latencies) if latencies else None,'atLeastTwofoldMargin':margin,'modelLoads':0,'generationRequests':0,'scope':'Same UID, interpreter, sandbox/network-denied helper boundary, native helper and supervisor revision only; context changes require requalification.'}
    atomic_json(E/'result.json',result);seal(E);print(json.dumps(result),flush=True)
if __name__=='__main__':main()

"""Owned single-worker hard abort: immediate KILL, no cooperative grace.
Historical supervisor and helper are unchanged. EPERM is never downgraded.
"""
import errno,os,signal,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import Supervisor,atomic_json,stamp
class WorkerSupervisor(Supervisor):
 def __init__(self,*args,identity=None,**kwargs):
  kwargs['term_wait']=0
  super().__init__(*args,**kwargs)
  self.identity=identity or (lambda pid:(os.getpgid(pid),os.getsid(pid)))
 def _signal(self,sig):
  if sig in self.sent:return
  self.sent.add(sig)
  row={**stamp(),'event':'SIGNAL','targetPID':self.proc.pid if self.proc else None,'targetPGID':self.pgid,'signal':signal.Signals(sig).name,'errno':None,'exception':None,'result':'PENDING'}
  self.events.append(dict(row,event='SIGNAL_INTENT'))
  self._error('journal',lambda:atomic_json(self.directory/'termination.json',self.events))
  try:
   if self.proc is None or type(self.pgid)is not int or self.pgid<=1 or self.pgid!=self.proc.pid or self.pgid==os.getpgrp():raise ValueError('Invalid/unowned group')
   # Do not reap between identity validation and killpg: an unreaped owned child
   # keeps its PID unavailable for reuse. Exiting transitions can still cause EPERM.
   pgid,sid=self.identity(self.proc.pid)
   row['identity']={'pgid':pgid,'sid':sid}
   if pgid!=self.pgid or sid!=self.pgid:raise ValueError('Session/group identity changed')
   row['syscallStart']=time.monotonic()
   try:self.signal_group(self.pgid,sig)
   finally:row['syscallEnd']=time.monotonic()
   row['result']='SENT'
  except ProcessLookupError as error:row.update(result='PROCESS_NOT_FOUND',errno=error.errno,exception=repr(error))
  except PermissionError as error:row.update(result='PERMISSION_DENIED',errno=error.errno,exception=repr(error))
  except BaseException as error:row.update(result='OTHER_ERROR',errno=getattr(error,'errno',None),exception=repr(error))
  self.events.append(row)
  self.transition('KILL_SENT' if row['result']=='SENT' else 'ALREADY_EXITED' if row['result']=='PROCESS_NOT_FOUND' else 'SIGNAL_FAILED')
 def _terminate(self):
  self.events.append({**stamp(),'event':'HARD_ABORT_BEGIN','strategy':'IMMEDIATE_KILL','cooperativeGraceSeconds':0})
  if self.proc is None:self.transition('ALREADY_EXITED');return
  if self._poll() is None:self._signal(signal.SIGKILL)
  else:self.transition('ALREADY_EXITED')
  self.transition('REAP')
  start=time.monotonic();code=self._error('reap',lambda:self.proc.wait(timeout=self.kill_wait))
  self.events.append({**stamp(),'event':'REAP_OBSERVED','exitCode':code,'waitSeconds':time.monotonic()-start})
  present=self._present()
  self.events.append({**stamp(),'event':'GROUP_OBSERVED','present':present})

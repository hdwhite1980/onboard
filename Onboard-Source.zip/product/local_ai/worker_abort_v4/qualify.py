"""Exact hard-abort component/boundary qualification. Harmless processes only."""
import json,os,platform,signal,subprocess,sys,threading,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c
from common import atomic_json,stamp
from worker_lifecycle import WorkerSupervisor

def main():
 E=c.E/'qualification-v2';E.mkdir();atomic_json(E/'STARTED.json',stamp())
 files=list(Path(__file__).parent.glob('*.py'))+[c.B/'resource_harness_v2/supervisor.py',c.B/'monitor_lifecycle_v3/lifecycle.py',c.HELPER]
 atomic_json(E/'tested-source.json',{'files':[{'path':str(p.relative_to(c.ROOT)),'sha256':c.sha(p)} for p in files]})
 atomic_json(E/'context.json',{'uid':os.getuid(),'interpreter':sys.executable,'interpreterSHA256':c.sha(Path(sys.executable).resolve()),'python':platform.python_version(),'machine':platform.machine(),'sandbox':c.SANDBOX,'startNewSession':True,'workerTermGraceSeconds':0,'workerStrategy':'IMMEDIATE_KILL','helperTermWindowSeconds':.1,'ownedSingleWorkerOnly':True,'modelLoads':0})
 tests=subprocess.run([sys.executable,'-I','-B',str(Path(__file__).with_name('test_lifecycle.py'))],capture_output=True,text=True,timeout=20)
 (E/'pure-tests.txt').write_text(tests.stdout+tests.stderr);assert tests.returncode==0
 # Predetermined limits on tested signal actuation/exit observation, no grace interval.
 atomic_json(E/'criteria.json',{'requestToSignalSecondsMax':.05,'signalToReapSecondsMax':.1,'noUnexpectedEPERM':True,'allWorkersReapedGroupsAbsentRecoveryExecutedSealed':True,'pureTests':18,'realCases':40,'scope':'Measured same-boundary harmless-worker qualification, not a hard real-time kernel guarantee or proof of GPU teardown latency.'})
 rows=[]
 for mode in ('sleep','cpu','memory','ignore','exit','crash','double','monitor','timeout','disappears'):
  for i in range(4):
   d=E/f'{mode}-{i}';d.mkdir();base=c.native();assert c.safe(base),'Unsafe host baseline'
   proc=None;life=None;triggered=threading.Event();terminate=threading.Event();trigger={};thread=None;result=None;passed=False
   try:
    proc,ready=c.launch({'double':'sleep','monitor':'cpu','timeout':'cpu','disappears':'on_command_exit'}.get(mode,mode))
    life=WorkerSupervisor(d/'lifecycle',proc,proc.pid,group_present=lambda:c.present(proc.pid),kill_wait=1)
    if mode in ('exit','crash'):proc.wait(timeout=1)
    if mode=='disappears':
     proc.stdin.write('exit\n');proc.stdin.flush();proc.wait(timeout=1)
    def abort_now(reason):
     trigger.update(monotonic=time.monotonic(),reason=reason)
     with life.lock:
      life.request_abort(reason)
      life._error('termination',life._terminate)
     triggered.set()
    if mode=='monitor':
     def monitor():
      row=c.native();trigger['nativeSample']=row
      # Logical hard-stop injection. No host pressure or memory exhaustion induced.
      trigger['injectedCondition']='RESOURCE: pressure WARN'
      abort_now('MONITOR_SYNTHETIC_POLICY_WARN')
     thread=threading.Thread(target=monitor,name='monitor-trigger');thread.start()
    elif mode=='timeout':
     def timeout():
      terminate.wait(.02);abort_now('SYNTHETIC_WALL_TIMEOUT')
     thread=threading.Thread(target=timeout,name='timeout-trigger');thread.start()
    else:abort_now('HARMLESS_HARD_STOP')
    if thread:
     assert triggered.wait(2),'Abort thread did not complete';thread.join(timeout=1);assert not thread.is_alive()
    if mode=='double':life.request_abort('DUPLICATE_HARD_STOP');life._terminate()
    def recovery():return {'samples':[dict(c.native(),groupMembers=c.members(proc.pid),workerExit=proc.poll()) for _ in range(2)]}
    final_begin=time.monotonic();result=life.finish('HARMLESS_HARD_STOP',recovery=recovery);final_end=time.monotonic()
    signals=[e for e in result['events'] if e['event']=='SIGNAL'];reaps=[e for e in result['events'] if e['event']=='REAP_OBSERVED'];groups=[e for e in result['events'] if e['event']=='GROUP_OBSERVED' and e['present'] is False]
    latency={'requestToSyscallSeconds':signals[0]['syscallStart']-trigger['monotonic'] if signals and 'syscallStart' in signals[0] else None,'syscallSeconds':signals[0]['syscallEnd']-signals[0]['syscallStart'] if signals and 'syscallStart' in signals[0] else None,'signalToReapSeconds':reaps[0]['monotonic']-signals[0]['syscallEnd'] if signals and 'syscallEnd' in signals[0] else None,'signalToGroupAbsenceSeconds':groups[0]['monotonic']-signals[0]['syscallEnd'] if groups and signals and 'syscallEnd' in signals[0] else None,'finalizationSeconds':final_end-final_begin}
    passed=result['supervisor']=='TERMINATION_CONFIRMED' and result['evidenceCompleteness']=='COMPLETE' and result['workerExitCode'] is not None and result['processGroupPresent'] is False and c.verify(d/'lifecycle')
    passed=passed and all(s['result']=='SENT' and s['signal']=='SIGKILL' for s in signals) and len(signals)<=1
    passed=passed and (latency['requestToSyscallSeconds'] is None or latency['requestToSyscallSeconds']<.05) and (latency['signalToReapSeconds'] is None or latency['signalToReapSeconds']<.1)
    passed=passed and all(not x['groupMembers'] and x['workerExit'] is not None for x in result['recovery']['samples'])
    atomic_json(d/'observations.json',{'ready':ready,'baseline':base,'trigger':trigger,'latency':latency,'pass':passed})
   finally:
    if thread and thread.is_alive():thread.join(timeout=2)
    if life and life.result is None:result=life.finish('HARNESS_ERROR',recovery=lambda:{'attempted':True})
    if proc:
     if proc.poll() is None:
      # Last resort is still only the bound owned harmless child; never qualifies.
      try:os.killpg(proc.pid,signal.SIGKILL)
      except OSError:pass
      proc.wait(timeout=5);passed=False
     for f in (proc.stdin,proc.stdout,proc.stderr):f.close()
    c.seal(d)
   row={'case':d.name,'pass':passed,'latency':latency,'supervisor':result['supervisor']};rows.append(row);print(json.dumps(row),flush=True)
   if not passed:break
  if not passed:break
 passed=len(rows)==40 and all(x['pass'] for x in rows)
 atomic_json(E/'result.json',{'status':'MODEL_WORKER_ABORT_QUALIFIED_FOR_TESTED_CONTEXT' if passed else 'MODEL_WORKER_ABORT_NOT_QUALIFIED','pureTestsPassed':18,'realCases':len(rows),'realPassed':sum(x['pass'] for x in rows),'strategy':'IMMEDIATE_KILL','cooperativeGraceSeconds':0,'cases':rows,'modelLoads':0,'generationRequests':0,'scope':'Exact retained Python, UID, session, seatbelt boundary and source hashes; owned single worker. No hard real-time or arbitrary descendant guarantee.'});c.seal(E)
 print('QUALIFICATION',passed,flush=True)
if __name__=='__main__':main()

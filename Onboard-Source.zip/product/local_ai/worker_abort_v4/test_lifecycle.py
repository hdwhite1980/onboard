"""Synthetic fault tests: no real process signalling, no AI."""
import errno,json,signal,subprocess,sys,tempfile,threading,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
from worker_lifecycle import WorkerSupervisor
import common as c
class Fake:
 pid=2147483000
 def __init__(self):self.exit=None;self.present=True;self.signals=[]
 def poll(self):return self.exit
 def wait(self,timeout):
  if self.exit is None:raise subprocess.TimeoutExpired('fake',timeout)
  return self.exit
 def killpg(self,pid,sig):self.signals.append(sig);self.exit=-sig;self.present=False
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.proc=Fake();self.path=Path(self.tmp.name)/'life'
 def make(self,**kw):return WorkerSupervisor(self.path,self.proc,kw.pop('pgid',self.proc.pid),identity=kw.pop('identity',lambda pid:(pid,pid)),signal_group=kw.pop('signal_group',self.proc.killpg),group_present=kw.pop('group_present',lambda:self.proc.present),**kw)
 def finish(self,s,**kw):
  r=s.finish('SYNTHETIC_HARD_STOP',recovery=kw.pop('recovery',lambda:{'executed':True}),**kw)
  self.assertTrue((self.path/'result.json').exists());self.assertTrue((self.path/'recovery.json').exists());self.assertTrue(c.verify(self.path));return r
 def test_immediate(self):
  r=self.finish(self.make());self.assertEqual(self.proc.signals,[signal.SIGKILL]);self.assertEqual(r['supervisor'],'TERMINATION_CONFIRMED')
 def test_double_abort(self):
  s=self.make();s.request_abort('first');s.request_abort('second');r=self.finish(s);self.assertIs(s.finish('duplicate'),r);self.assertEqual(len(self.proc.signals),1)
 def test_concurrent_abort(self):
  s=self.make();ts=[threading.Thread(target=s.request_abort,args=('guard',)) for _ in range(8)]
  for t in ts:t.start()
  for t in ts:t.join()
  self.finish(s);self.assertEqual(self.proc.signals,[signal.SIGKILL])
 def test_already_exit(self):
  self.proc.exit=0;self.proc.present=False;self.finish(self.make());self.assertEqual(self.proc.signals,[])
 def test_crash(self):
  self.proc.exit=7;self.proc.present=False;r=self.finish(self.make());self.assertEqual(r['workerExitCode'],7)
 def test_lookup(self):
  def gone(*a):self.proc.exit=0;self.proc.present=False;raise ProcessLookupError(errno.ESRCH,'gone')
  r=self.finish(self.make(signal_group=gone));self.assertEqual(r['supervisor'],'TERMINATION_CONFIRMED');self.assertIn('PROCESS_NOT_FOUND',str(r['events']))
 def test_identity_disappears(self):
  def gone(*a):self.proc.exit=0;self.proc.present=False;raise ProcessLookupError(errno.ESRCH,'gone')
  self.finish(self.make(identity=gone));self.assertEqual(self.proc.signals,[])
 def test_permission_then_absent_stays_error(self):
  def denied(*a):self.proc.exit=0;self.proc.present=False;raise PermissionError(errno.EPERM,'denied')
  r=self.finish(self.make(signal_group=denied));self.assertEqual(r['supervisor'],'TERMINATION_PERMISSION_ERROR');self.assertEqual(r['evidenceCompleteness'],'PARTIAL')
 def test_permission_alive(self):
  def denied(*a):raise PermissionError(errno.EPERM,'denied')
  r=self.finish(self.make(signal_group=denied));self.assertEqual(r['supervisor'],'TERMINATION_PERMISSION_ERROR');self.assertTrue(r['workerPresent'])
 def test_invalid_group(self):
  r=self.finish(self.make(pgid=0));self.assertEqual(r['supervisor'],'TERMINATION_SIGNAL_ERROR');self.assertEqual(self.proc.signals,[])
 def test_changed_identity(self):
  r=self.finish(self.make(identity=lambda p:(p+1,p)));self.assertEqual(r['supervisor'],'TERMINATION_SIGNAL_ERROR');self.assertEqual(self.proc.signals,[])
 def test_unknown_group(self):
  r=self.finish(self.make(group_present=lambda:None));self.assertEqual(r['supervisor'],'TERMINATION_UNCONFIRMED')
 def test_extra_group_member(self):
  r=self.finish(self.make(group_present=lambda:True));self.assertEqual(r['supervisor'],'TERMINATION_UNCONFIRMED')
 def test_cleanup_failure_still_recovery(self):
  def fail():raise RuntimeError('cleanup')
  r=self.finish(self.make(),cleanup=fail);self.assertTrue(r['recovery']['executed']);self.assertEqual(r['evidenceCompleteness'],'PARTIAL')
 def test_evidence_failure_still_final(self):
  def fail():raise OSError(errno.EIO,'evidence')
  r=self.finish(self.make(),evidence=fail);self.assertEqual(r['evidenceCompleteness'],'PARTIAL')
 def test_recovery_failure_still_seal(self):
  def fail():raise RuntimeError('recovery')
  r=self.finish(self.make(),recovery=fail);self.assertEqual(r['evidenceCompleteness'],'PARTIAL')
 def test_journal_failure_still_signal_and_cleanup(self):
  import supervisor
  original=supervisor.atomic_json
  def fail(path,data):
   if Path(path).name=='termination.json':raise OSError(errno.EIO,'journal')
   return original(path,data)
  s=self.make()
  with patch('supervisor.atomic_json',side_effect=fail):r=s.finish('STOP',recovery=lambda:{'executed':True})
  self.assertEqual(self.proc.signals,[signal.SIGKILL]);self.assertEqual(r['evidenceCompleteness'],'PARTIAL');self.assertTrue(r['recovery']['executed'])
 def test_unexpected_signal_error(self):
  def fail(*a):raise RuntimeError('signal')
  r=self.finish(self.make(signal_group=fail));self.assertEqual(r['supervisor'],'TERMINATION_SIGNAL_ERROR')
if __name__=='__main__':unittest.main(verbosity=2)

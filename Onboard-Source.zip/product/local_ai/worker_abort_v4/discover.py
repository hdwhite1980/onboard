"""Compare signal strategies on owned harmless workers; never launches AI."""
import errno,json,os,platform,signal,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c
from common import Supervisor,atomic_json,stamp
class Recheck(Supervisor):
 def _terminate(self):
  if self.proc is None:return
  if self._poll() is None:
   self._signal(signal.SIGTERM)
   # Read-only immediate recheck, no artificial observation sleep or grace.
   exited=self._poll();group=self._present()
   self.events.append({**stamp(),'event':'PRE_KILL_RECHECK','exit':exited,'present':group})
   if exited is None and group is True and self._poll() is None:self._signal(signal.SIGKILL)
  self._error('reap',lambda:self.proc.wait(timeout=1))
class Immediate(Supervisor):
 def _terminate(self):
  if self.proc is None:return
  if self._poll() is None:self._signal(signal.SIGKILL)
  self._error('reap',lambda:self.proc.wait(timeout=1))
def main():
 E=c.E/'discovery';E.mkdir();atomic_json(E/'STARTED.json',stamp())
 atomic_json(E/'context.json',{'uid':os.getuid(),'interpreter':sys.executable,'interpreterSHA256':c.sha(Path(sys.executable).resolve()),'machine':platform.machine(),'python':platform.python_version(),'uname':list(os.uname()),'sandbox':c.SANDBOX,'startNewSession':True,'boundedAllocationBytes':16*1024**2,'modelLoads':0})
 atomic_json(E/'source.json',{'files':[{'path':str(p.relative_to(c.ROOT)),'sha256':c.sha(p)} for p in [Path(__file__),Path(__file__).with_name('common.py'),Path(__file__).with_name('harmless_worker.py'),c.B/'resource_harness_v2/supervisor.py']]})
 rows=[]
 cases=[(strategy,mode,i) for strategy in ('original','recheck','immediate') for mode in ('sleep','cpu','memory','ignore','exit','crash') for i in range(3)]
 for strategy,mode,i in cases:
  d=E/f'{strategy}-{mode}-{i}';d.mkdir();base=c.native();assert c.safe(base),'Unsafe baseline; stop harmless tests'
  proc=None;life=None;signals=[];recovery=[];started=time.monotonic();details={}
  try:
   proc,ready=c.launch(mode);details['ready']=ready;details['before']=c.members(proc.pid)
   def send(pgid,sig):
    row={'signal':signal.Signals(sig).name,'pid':proc.pid,'pgid':pgid,'start':time.monotonic()}
    try:os.killpg(pgid,sig);row['syscallEnd']=time.monotonic();row['result']='SENT'
    except OSError as error:
     row.update(result=type(error).__name__,errno=error.errno,syscallEnd=time.monotonic())
     # Inspect only after error, never reap before this group/process observation.
     row['afterErrorMembers']=c.members(pgid)
     for name,fn in [('getpgid',lambda:os.getpgid(proc.pid)),('getsid',lambda:os.getsid(proc.pid)),('kill0',lambda:os.kill(proc.pid,0))]:
      try:row[name]=fn()
      except OSError as e:row[name]={'errno':e.errno}
     raise
    finally:row['end']=time.monotonic();signals.append(row)
   cls={'original':Supervisor,'recheck':Recheck,'immediate':Immediate}[strategy]
   life=cls(d/'lifecycle',proc,proc.pid,signal_group=send,group_present=lambda:c.present(proc.pid),term_wait=0,kill_wait=1)
   request=time.monotonic();life.request_abort('HARMLESS_STRATEGY_COMPARISON')
   def recover():
    for j in range(2):recovery.append(dict(c.native(),groupMembers=c.members(proc.pid)))
    return {'samples':recovery}
   result=life.finish('HARMLESS_ABORT',recovery=recover)
   details.update(strategy=strategy,mode=mode,iteration=i,result=result,signals=signals,requestMonotonic=request,endMonotonic=time.monotonic(),exit=proc.returncode,groupAbsent=not c.present(proc.pid),baseline=base)
   assert proc.returncode is not None and details['groupAbsent'],'Orphan or unreaped worker'
   assert c.verify(d/'lifecycle'),'Seal invalid'
  finally:
   if proc:
    if proc.poll() is None:
     try:os.killpg(proc.pid,signal.SIGKILL)
     except OSError:pass
     proc.wait(timeout=5)
    for f in (proc.stdin,proc.stdout,proc.stderr):f.close()
   atomic_json(d/'observations.json',details);c.seal(d)
  rows.append({'case':d.name,'strategy':strategy,'mode':mode,'status':result['supervisor'],'exit':proc.returncode,'signals':[{'signal':s['signal'],'result':s['result'],'errno':s.get('errno'),'syscallSeconds':s['syscallEnd']-s['start']} for s in signals]})
  print(json.dumps(rows[-1]),flush=True)
 atomic_json(E/'results.json',{'cases':rows,'modelLoads':0});c.seal(E)
if __name__=='__main__':main()

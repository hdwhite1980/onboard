"""Seal Stage 1; cannot advance unless corrected exact qualification passed."""
import collections,json,shutil
from pathlib import Path
import common as c
E=c.E;Q=E/'qualification-v2';r=json.loads((Q/'result.json').read_text());assert r['status']=='MODEL_WORKER_ABORT_QUALIFIED_FOR_TESTED_CONTEXT' and r['realPassed']==40
for row in json.loads((Q/'tested-source.json').read_text())['files']:
 assert c.sha(c.ROOT/row['path'])==row['sha256'];dst=E/'qualified-source'/row['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(c.ROOT/row['path'],dst)
old=json.loads((E/'historical-before.json').read_text())
for row in old:assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path']
lat={k:max(x['latency'][k] for x in r['cases'] if x['latency'][k] is not None) for k in r['cases'][0]['latency']}
dis=json.loads((E/'discovery/results.json').read_text())['cases'];zombie=[]
for f in (E/'discovery').glob('*/observations.json'):
 d=json.loads(f.read_text())
 for sig in d['signals']:
  if sig.get('errno')==1:zombie.append({'case':f.parent.name,'members':sig['afterErrorMembers'],'exit':d['exit'],'kill0':sig['kill0']})
assert len(zombie)==9 and all(x['exit']==-15 and all(m['state'].startswith('Z') for m in x['members']) for x in zombie)
c.atomic_json(E/'analysis.json',{'status':r['status'],'currentQualification':'qualification-v2','strategy':'IMMEDIATE_KILL','historicalFilesAndSourcesUnchanged':len(old),'latencyMaxima':lat,'reproducedEPERM':zombie,'discoveryCases':54,'firstQualificationSupersededForTimestampOrder':True,'modelLoads':0,'historicalCandidate6StatusUnchanged':True,'historicalCause':'Exit-transition/zombie mechanism is consistent and reproduced; exact past syscall state was not captured and remains unproven.'})
c.atomic_json(E/'SOURCE_REGISTER.json',{'sources':[{'url':'https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/kern/kern_sig.c','localFile':'xnu-kern-sig-main.c','sha256':c.sha(E/'xnu-kern-sig-main.c'),'scope':'Published Apple source explains group zombie filtering and zero eligible members -> EPERM; main snapshot is not attested byte-identical to this installed kernel.'},{'url':'https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man2/killpg.2.html','scope':'Apple documented process-group signal interface and error semantics'}]})
doc=f'''# Candidate 6B — model-worker hard-abort qualification

**{r['status']}**. Stage 1 passed before any text-only artifact research or acquisition.

The historical Candidate 6 result remains CANDIDATE6_RESOURCE_CALIBRATION_FAILED / MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2 / TERMINATION_PERMISSION_ERROR / PARTIAL, with no generation. Neither that evidence nor the old supervisor/helper implementation was changed.

## Findings and strategy

Fifty-four same-boundary harmless discovery cases compared original zero-grace TERM→KILL, TERM followed by immediate state recheck, and immediate KILL. Original behavior produced 9 EPERM outcomes: all three sleep, active-CPU and 16 MiB memory trials. Each showed a zombie after the error with unchanged PID/PGID/UID; it reaped at -15. The ignore-TERM controls accepted KILL and reaped -9. Both alternative strategies completed all 18 comparison cases.

Apple's published [XNU signal implementation](https://github.com/apple-oss-distributions/xnu/blob/main/bsd/kern/kern_sig.c) filters zombie processes from explicit group signalling and can return EPERM when no eligible member is found. This provides a mechanism consistent with the reproduced results. The reviewed source snapshot is not attested as byte-identical to the installed kernel. It does not prove the historical Candidate 6 worker's state at the failed call. EPERM is never converted into successful KILL delivery or relabeled harmless.

A. Historical exact cause remains unproven; the TERM exit-transition/zombie mechanism is reproduced in harmless same-boundary workers.
B. The reproduced target was a zombie when observed after EPERM. Successful PID signal-0 is not proof that a zombie can execute or receive a group KILL.
C. Pre/post PID, PGID and UID observations remained stable; no group substitution was observed.
D. TERM caused exit -15 in those cases; subsequent observation found zombie state. The past Candidate 6 syscall state cannot be recovered.
E. Same seatbelt/session boundary permitted immediate KILL and KILL against ignored-TERM workers. No general sandbox prohibition on KILL was demonstrated.
F. State recheck avoided EPERM in this sample, but a process-table scan adds observation latency and cannot remove all exit races.
G. Select **immediate SIGKILL for hard stops**, with **zero cooperative grace**. Validate the still-owned, unreaped child's PGID/SID before signalling. Do not add the helper's 100 ms TERM window. Retain signal errors and require reaping/group absence/recovery/final sealing.

## Current qualification

Eighteen synthetic fault tests passed: immediate abort, double/concurrent abort, already exited/crash, disappearing identity/group, ESRCH, EPERM both alive and subsequently absent, invalid/changed identity, unknown/nonempty group, cleanup/evidence/recovery/journal failures and unexpected signal exceptions. These never signal a real process.

Forty real harmless cases passed with the exact corrected source: four each of sleep, active CPU, bounded 16 MiB allocation, ignored TERM, already exited, crash, double abort, monitor-triggered synthetic WARN, timeout-triggered abort and commanded group disappearance. All workers were reaped, all groups absent, recovery ran, manifests verified, no unexpected EPERM and no orphan. Triggered WARN was a logical test condition; no system pressure was induced. An independent 4-second worker alarm bounded abnormal harness failures.

Boundary: UID 501; retained Python 3.12.14 arm64; exact interpreter hash; `start_new_session=True`; same `(version 1)(allow default)(deny network*)` worker boundary; deliberate network-negative control denied. Qualified code is `product/local_ai/worker_abort_v4/worker_lifecycle.py`, reusing the historical error-isolating finalizer. The helper continues using its separately qualified 100 ms lifecycle.

Observed maxima in the corrected qualification:

| Measurement | Maximum |
|---|---:|
| Hard-stop request → KILL syscall start | {lat['requestToSyscallSeconds']*1000:.3f} ms |
| KILL syscall duration | {lat['syscallSeconds']*1000:.3f} ms |
| KILL return → reaped exit observation | {lat['signalToReapSeconds']*1000:.3f} ms |
| KILL return → completed group-absence observation | {lat['signalToGroupAbsenceSeconds']*1000:.3f} ms |
| Finalization including recovery and evidence | {lat['finalizationSeconds']*1000:.3f} ms |

Discovery signal-call durations, conditional-KILL timing, state transitions, recovery and seals are retained per case. The first qualification's group-event timestamp was taken before its observation; it was retained and superseded by `qualification-v2`, which timestamps after observation. No model ran during either qualification.

No extra grace is introduced into the 100 ms load-monitor cadence or 250 ms generation cadence. Immediate actuation minimizes intentional reserve consumption after detection; the 2 GiB reserve, 2.25 GiB early trigger and pressure stops remain unchanged. Neither these samples nor any finite grace choice can establish a hard real-time OS/GPU memory-release guarantee. Qualification is limited to the tested boundary and an owned single worker; unexpected group members/unknown absence prevent clean termination qualification. Future execution must preserve all guards and stop on any signal/identity/evidence failure.

Evidence: [Stage 1 analysis](evidence/candidate6b-worker-abort-01/analysis.json), [current qualification](evidence/candidate6b-worker-abort-01/qualification-v2/result.json), [source/context freeze](evidence/candidate6b-worker-abort-01/qualification-v2/tested-source.json). {len(old)} historical evidence/source files verified unchanged.
'''
(c.ROOT/'docs/sprint3a/CANDIDATE6B_WORKER_ABORT_QUALIFICATION.md').open('x').write(doc)
shutil.copyfile(c.ROOT/'docs/sprint3a/CANDIDATE6B_WORKER_ABORT_QUALIFICATION.md',E/'report.md');shutil.copyfile(Path(__file__),E/'seal_stage1.py')
c.seal(E);print(json.dumps({'status':r['status'],'manifestSHA256':c.sha(E/'manifest.json'),'historicalPreserved':len(old),'modelLoads':0}))

"""Harmless worker qualification context; no ML imports."""
import hashlib,json,os,select,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];B=ROOT/'product/local_ai';E=ROOT/'docs/sprint3a/evidence/candidate6b-worker-abort-01'
SANDBOX=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)']
HELPER=B/'candidate4_policy_v2/resource-probe'
sys.path.insert(0,str(B/'resource_harness_v2'))
from supervisor import Supervisor,atomic_json,stamp

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def members(pgid):
 r=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid=,uid=,stat=,comm='],capture_output=True,text=True,check=True,timeout=1)
 return [dict(pid=int(f[0]),ppid=int(f[1]),pgid=int(f[2]),uid=int(f[3]),state=f[4],command=f[5]) for s in r.stdout.splitlines() if len(f:=s.strip().split(None,5))==6 and int(f[2])==pgid]
def present(pgid):return bool(members(pgid))
def native():
 r=subprocess.run(SANDBOX+[str(HELPER),'0','.1','0'],capture_output=True,text=True,check=True,timeout=1);return json.loads(r.stdout)
def safe(r):
 return r.get('memoryPressure')=='NORMAL' and r.get('swapUsedBytes')==0 and r.get('thermalState') in (0,1) and r.get('availableEstimateLegacyBytes',0)>2.25*1024**3 and 0<=time.monotonic()-r['monotonic']<1.5

def launch(mode):
 proc=subprocess.Popen(SANDBOX+[sys.executable,'-I','-B',str(Path(__file__).with_name('harmless_worker.py')),mode],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,start_new_session=True)
 try:
  if not select.select([proc.stdout],[],[],2)[0]:raise RuntimeError('Readiness timeout')
  row=json.loads(proc.stdout.readline());assert row['pid']==row['pgid']==proc.pid and row['uid']==os.getuid() and row['networkDenied'],row
  return proc,row
 except BaseException:
  try:os.killpg(proc.pid,signal.SIGKILL)
  except OSError:pass
  proc.wait(timeout=5)
  for f in (proc.stdin,proc.stdout,proc.stderr):f.close()
  raise

def seal(d):
 atomic_json(d/'manifest.json',{'files':[{'path':str(f.relative_to(d)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(d.rglob('*')) if f.is_file() and f!=d/'manifest.json']})
def verify(d):return all(sha(d/r['path'])==r['sha256'] for r in json.loads((d/'manifest.json').read_text())['files'])

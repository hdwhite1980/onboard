"""Fixed, inert, bounded worker. No model, user data, native extension or child process."""
import errno,json,os,signal,socket,sys,time
mode=sys.argv[1];assert mode in ('sleep','cpu','memory','ignore','exit','crash','on_command_exit')
signal.alarm(4)
if mode=='ignore':signal.signal(signal.SIGTERM,signal.SIG_IGN)
with socket.socket() as s:
 s.settimeout(.2);code=s.connect_ex(('127.0.0.1',9))
buf=bytearray(16*1024**2) if mode=='memory' else None
print(json.dumps({'event':'ready','pid':os.getpid(),'pgid':os.getpgrp(),'sid':os.getsid(0),'uid':os.getuid(),'mode':mode,'networkDenied':code in (errno.EPERM,errno.EACCES),'errno':code,'maxAllocationBytes':len(buf) if buf else 0,'selfExpirySeconds':4,'modelLoads':0}),flush=True)
if mode=='exit':sys.exit(0)
if mode=='crash':os._exit(7)
if mode=='on_command_exit':sys.stdin.readline();sys.exit(0)
x=0
while True:
 if mode in ('cpu','memory'):
  x=(x+1)%1000003
  if buf is not None:buf[(x*4096)%len(buf)]=x%256
 else:time.sleep(.01)

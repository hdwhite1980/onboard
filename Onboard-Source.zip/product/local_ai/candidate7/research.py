"""Candidate 7 metadata-only research. No model/runtime imports or weight access."""
import argparse, datetime, hashlib, json, subprocess
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[3]
E = ROOT / 'docs/sprint3a/evidence/candidate7-research-01'
S = E / 'sources'
ALLOW = {'README.md','LICENSE','LICENSE.txt','NOTICE','NOTICE.txt','.gitattributes',
         'config.json','generation_config.json','model.safetensors.index.json',
         'tokenizer.json','tokenizer_config.json','tokenizer.model','special_tokens_map.json',
         'chat_template.jinja','processor_config.json','preprocessor_config.json',
         'video_preprocessor_config.json','preprocessor_config.json'}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, obj):
    with p.open('x') as f: json.dump(obj,f,indent=2); f.write('\n')

def fetch(url, name):
    # Safetensors index JSON is allowed; tensor payloads and binary runtime code are not.
    assert not any(x in url.split('?')[0].lower() for x in ('.safetensors/', '.gguf', '.bin', '.whl'))
    assert not url.split('?')[0].endswith('.safetensors')
    p=S/name
    if p.exists(): raise RuntimeError('Refusing overwrite: '+str(p))
    p.parent.mkdir(parents=True, exist_ok=True)
    r=subprocess.run(['curl','--fail','--location','--silent','--show-error','--proto','=https','--proto-redir','=https','--max-filesize','67108864','--connect-timeout','20','--max-time','90',url,'-o',str(p)],capture_output=True,text=True)
    rec={'url':url,'path':str(p.relative_to(E)),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'error':r.stderr}
    if p.exists():rec.update(bytes=p.stat().st_size,sha256=sha(p))
    with (E/'source-register.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
    if r.returncode: print(json.dumps(rec),flush=True); return None
    return p

def snapshot():
    out={}
    for base in ('docs/sprint3a','product/local_ai'):
        for p in (ROOT/base).rglob('*'):
            if not p.is_file() or p.is_symlink(): continue
            rel=p.relative_to(ROOT)
            if any(x in rel.parts for x in ('.artifacts','__pycache__','candidate7','candidate7-research-01')): continue
            out[str(rel)]=sha(p)
    write(E/'historical-baseline.json',out)
    print('BASELINE',len(out))

def repo(repo):
    key=repo.replace('/','__')
    h=fetch('https://huggingface.co/api/models/'+repo+'?blobs=true',key+'.head.json')
    if not h:return
    head=json.loads(h.read_text()); rev=head['sha']
    p=fetch(f'https://huggingface.co/api/models/{repo}/revision/{rev}?blobs=true',key+'.pinned.json')
    data=json.loads(p.read_text()); assert data['sha']==rev
    rows=[]
    for row in data['siblings']:
        n=row['rfilename']; row=dict(row);row['acquired']=False
        if n in ALLOW:
            dest=fetch(f'https://huggingface.co/{repo}/resolve/{rev}/{n}',key+'/'+n)
            if dest:
                b=dest.read_bytes();assert len(b)==row['size']
                assert sha(dest)==row['lfs']['sha256'] if 'lfs' in row else hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['blobId']
                row.update(acquired=True,sha256=sha(dest))
        rows.append(row)
    fetch(f'https://huggingface.co/api/models/{repo}/commits/{rev}',key+'.history.json')
    result={'repository':repo,'revision':rev,'weightBytes':sum(r['size'] for r in rows if r['rfilename'].endswith('.safetensors')),'repositoryBytes':sum(r['size'] for r in rows),'files':rows}
    write(E/(key+'.verified.json'),result)
    print(json.dumps({k:v for k,v in result.items() if k!='files'}),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['snapshot','discover','repo','url']);p.add_argument('args',nargs='*');a=p.parse_args()
    if a.action=='snapshot':snapshot()
    elif a.action=='repo':
        for r in a.args:repo(r)
    elif a.action=='url':fetch(a.args[0],a.args[1])
    else:
        for q in a.args:fetch('https://huggingface.co/api/models?search='+quote(q)+'&limit=100&full=true', 'search-'+q.replace('/','__')+'.json')

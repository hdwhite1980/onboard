"""Static metadata arithmetic only; never imports ML runtimes or loads tensors."""
import collections, hashlib, json, re, shutil
from pathlib import Path
from research import ROOT, E, S, sha, write

REPOS=['mlx-community/gemma-4-e4b-it-4bit','lmstudio-community/gemma-4-E4B-it-MLX-4bit','k5p5/gemma-4-E4B-it-text-MLX-4bit']
site=ROOT/'product/local_ai/.artifacts/runtime/venv/lib/python3.12/site-packages'
runtime_files=['mlx_lm/models/gemma4.py','mlx_lm/models/gemma4_text.py','mlx_lm/models/cache.py','mlx_lm/utils.py','mlx_lm/tokenizer_utils.py','mlx/nn/layers/quantized.py','transformers/models/gemma/tokenization_gemma.py','transformers/models/gemma4/configuration_gemma4.py','transformers/models/gemma4/modeling_gemma4.py']
records=[]
for name in runtime_files:
    src=site/name; dst=S/'retained-runtime'/name; dst.parent.mkdir(parents=True,exist_ok=True)
    assert not dst.exists();shutil.copyfile(src,dst)
    records.append({'source':str(src),'snapshot':str(dst.relative_to(E)),'sha256':sha(src)})
for p in site.glob('*.dist-info/METADATA'):
    if p.parent.name.split('-')[0] in ('mlx','mlx_metal','mlx_lm','transformers','tokenizers'):
        dst=S/'retained-runtime'/p.parent.name/'METADATA';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
        records.append({'source':str(p),'snapshot':str(dst.relative_to(E)),'sha256':sha(p)})
write(E/'retained-runtime-source-record.json',records)

c=json.loads((S/'google__gemma-4-E4B-it/config.json').read_text())['text_config']
h=c['hidden_size'];v=c['vocab_size'];n=c['num_hidden_layers'];p=c['hidden_size_per_layer_input'];m=n-c['num_kv_shared_layers'];inter=c['intermediate_size']
shapes={};groups={}
def add(name,shape,group):shapes['language_model.model.'+name]=shape;groups['language_model.model.'+name]=group
add('embed_tokens.weight',[v,h],'mainEmbedding')
add('embed_tokens_per_layer.weight',[v,n*p],'perLayerEmbedding')
add('per_layer_model_projection.weight',[n*p,h],'perLayerProjection')
add('per_layer_projection_norm.weight',[p],'normsAndScalars')
add('norm.weight',[h],'normsAndScalars')
for i,t in enumerate(c['layer_types']):
    root=f'layers.{i}.';d=c['head_dim'] if t=='sliding_attention' else c['global_head_dim']
    for proj,shape in [('q_proj',[c['num_attention_heads']*d,h]),('o_proj',[h,c['num_attention_heads']*d])]:add(root+'self_attn.'+proj+'.weight',shape,'attention')
    add(root+'self_attn.q_norm.weight',[d],'normsAndScalars')
    if i<m:
        for proj in ('k_proj','v_proj'):add(root+'self_attn.'+proj+'.weight',[c['num_key_value_heads']*d,h],'attention')
        add(root+'self_attn.k_norm.weight',[d],'normsAndScalars')
    for proj,shape in [('gate_proj',[inter,h]),('up_proj',[inter,h]),('down_proj',[h,inter])]:add(root+'mlp.'+proj+'.weight',shape,'MLP')
    for proj,shape in [('per_layer_input_gate',[p,h]),('per_layer_projection',[h,p])]:add(root+proj+'.weight',shape,'perLayerGates')
    for norm in ('input_layernorm','post_attention_layernorm','pre_feedforward_layernorm','post_feedforward_layernorm','post_per_layer_input_norm'):add(root+norm+'.weight',[h],'normsAndScalars')
    add(root+'layer_scalar',[1],'normsAndScalars')
def prod(shape):
    out=1
    for x in shape:out*=x
    return out
params=collections.Counter()
for k,shape in shapes.items():params[groups[k]]+=prod(shape)
rows=[]
for repo in REPOS:
    key=repo.replace('/','__');base=S/key
    verified=json.loads((E/(key+'.verified.json')).read_text());cfg=json.loads((base/'config.json').read_text());idx=json.loads((base/'model.safetensors.index.json').read_text());names=set(idx['weight_map']);q=cfg['quantization'];expected=set();bytegroups=collections.Counter();tensors=[]
    for name,shape in shapes.items():
        expected.add(name);count=prod(shape);quant=name.endswith('.weight') and name[:-7]+'.scales' in names
        if quant:
            policy=q.get(name[:-7],q);bits=policy['bits'];gs=policy['group_size']
            # Config-derived nominal payload including BF16 scales and biases.
            assert shape[-1]%gs==0
            weightbytes=count*bits//8; sidebytes=count//gs*2
            expected.update((name[:-7]+'.scales',name[:-7]+'.biases'))
            nb=weightbytes+2*sidebytes
        else:nb=count*2;bits=16;gs=None
        bytegroups[groups[name]]+=nb;tensors.append({'name':name,'expectedShape':shape,'logicalParameters':count,'bits':bits,'groupSize':gs,'estimatedBytes':nb})
    language={k for k in names if k.startswith('language_model.')}
    extras=sorted(language-expected);missing=sorted(expected-language)
    token=json.loads((base/'tokenizer.json').read_text());up=json.loads((S/'google__gemma-4-E4B-it/tokenizer.json').read_text())
    rows.append({'repository':repo,'revision':verified['revision'],'weightBytes':verified['weightBytes'],'repositoryBytes':verified['repositoryBytes'],'indexTensorBytes':idx['metadata']['total_size'],'indexEntries':len(names),'languageEntries':len(language),'nonLanguageEntries':len(names-language),'expectedTextParameters':sum(params.values()),'expectedTextBytesByComponent':dict(bytegroups),'expectedTextBytes':sum(bytegroups.values()),'extraLanguageKeys':extras,'missingLanguageKeys':missing,'tokenizerIdenticalOfficial':token==up,'tokenizerSHA256':sha(base/'tokenizer.json'),'templateSHA256':sha(base/'chat_template.jinja'),'templateIdenticalOfficialCurrent':sha(base/'chat_template.jinja')==sha(S/'google__gemma-4-E4B-it/chat_template.jinja'),'templateIdenticalDeclaredInput':sha(base/'chat_template.jinja')==sha(S/'official-conversion-input-template.jinja'),'quantizedTensorPlan':tensors,'remoteCodeKeys':[x for x in ('auto_map','model_file') if x in cfg]})
kv={}
for precision,by in [('BF16',2),('FP32',4)]:
    kv[precision]=sum(2*512*c['num_key_value_heads']*(c['head_dim'] if t=='sliding_attention' else c['global_head_dim'])*by for t in c['layer_types'][:m])
out={'method':'Configuration and installed-source arithmetic, not downloaded weight headers or measured memory','config':c,'textParametersByComponent':dict(params),'textParameters':sum(params.values()),'cache512Bytes':kv,'cacheLayers':m,'cacheSlidingLayers':c['layer_types'][:m].count('sliding_attention'),'cacheGlobalLayers':c['layer_types'][:m].count('full_attention'),'allLayerTypes':dict(collections.Counter(c['layer_types'])),'artifacts':rows}
write(E/'static-analysis.json',out)
print(json.dumps({'params':params,'totalText':sum(params.values()),'cache':kv,'rows':[{k:v for k,v in r.items() if k not in ('quantizedTensorPlan','extraLanguageKeys')}|{'extraLanguageKeyCount':len(r['extraLanguageKeys'])} for r in rows]},indent=2))

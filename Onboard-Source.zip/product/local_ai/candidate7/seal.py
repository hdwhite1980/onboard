"""Verify read-only scope/preservation and seal Candidate 7 research artifacts."""
import ast, hashlib, json, re, shutil
from pathlib import Path
from research import ROOT, E, S, sha, write

baseline=json.loads((E/'historical-baseline.json').read_text())
comparison='docs/sprint3a/LOCAL_MODEL_COMPARISON.md'
changed=[p for p,h in baseline.items() if p!=comparison and (not (ROOT/p).exists() or sha(ROOT/p)!=h)]
assert not changed,changed
prefix=json.loads((E/'comparison-prefix.json').read_text())
current=(ROOT/comparison).read_bytes()
assert hashlib.sha256(current[:prefix['bytes']]).hexdigest()==prefix['sha256']==baseline[comparison]
assert current.count(b'## Candidate 7 ')==1
runtime=json.loads((E/'retained-runtime-source-record.json').read_text())
assert all(sha(Path(r['source']))==r['sha256'] for r in runtime)
register=[json.loads(l) for l in (E/'source-register.jsonl').read_text().splitlines()]
for r in register:
    if r['exitCode']==0:
        assert sha(E/r['path'])==r['sha256'],r['path']
    assert not r['url'].split('?')[0].endswith(('.safetensors','.gguf','.bin','.whl'))
assert not list(E.rglob('*.safetensors'))
reports=sorted((ROOT/'docs/sprint3a').glob('CANDIDATE7*.md'))
assert len(reports)==7
for p in reports:
    text=p.read_text()
    for href in re.findall(r'\]\(([^)]+)\)',text):
        if href.startswith(('https://','http://','#')):continue
        assert (p.parent/href.split('#')[0]).exists(),(p,href)
    assert '\x00' not in text
analysis=json.loads((E/'static-analysis.json').read_text())
best=analysis['artifacts'][0]
assert not best['missingLanguageKeys'] and not best['extraLanguageKeys']
assert len(analysis['artifacts'][1]['extraLanguageKeys'])==126
assert analysis['artifacts'][2]['nonLanguageEntries']==0
assert all(r['tokenizerIdenticalOfficial'] for r in analysis['artifacts'])
assert best['templateIdenticalDeclaredInput']
budget=json.loads((E/'resource-hypothesis.json').read_text())
assert sum(budget['componentsBytes'].values())==budget['sumBytes']<budget['workerCeilingBytes']==7*2**30
assert budget['normalAdmissionStrictlyGreaterThanBytes']==7*2**30+int(2.25*2**30)
decision=json.loads((E/'research-decision.json').read_text())
assert decision['status']=='GEMMA4_LICENSE_REVIEW_REQUIRED'
assert all(decision[k]==0 for k in ['modelWeightBytesAcquired','modelLoads','generations','dynamicTokenizerRuns','runtimeInstalls','policyChanges'])
for p in (ROOT/'product/local_ai/candidate7').glob('*.py'):ast.parse(p.read_text())
owner=Path('/Users/donwhite/.codex/attachments/575b9d02-538a-4dca-8a51-e2bb3952c089/Pasted text.txt')
shutil.copyfile(owner,E/'OWNER_REQUEST.txt')
for name in ['reports','research-tools']:(E/name).mkdir()
for p in reports+[ROOT/comparison]:shutil.copyfile(p,E/'reports'/p.name)
for p in (ROOT/'product/local_ai/candidate7').glob('*.py'):shutil.copyfile(p,E/'research-tools'/p.name)
out={'status':'RESEARCH_COMPLETE_PRESERVATION_VERIFIED','decision':decision['status'],'historicalFilesUnchanged':len(baseline)-1,'comparisonHistoricalPrefixUnchanged':True,'retainedRuntimeSourceFilesUnchanged':len(runtime),'reports':len(reports),'successfulSourceRetrievals':sum(r['exitCode']==0 for r in register),'failedSourceRetrievals':sum(r['exitCode']!=0 for r in register),'modelWeightBytesAcquired':0,'modelLoads':0,'generations':0,'dynamicTokenizerRuns':0,'runtimeInstalls':0,'policyChanges':0,'sourceHashesVerified':True,'localReportLinksVerified':True,'staticArithmeticAndKeyChecksVerified':True}
write(E/'final-verification.json',out)
files=[{'path':str(p.relative_to(E)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(E.rglob('*')) if p.is_file()]
write(E/'EVIDENCE_MANIFEST.json',{'scope':'Candidate 7 metadata-only research','decision':decision['status'],'files':files})
print(json.dumps(dict(out,evidenceFiles=len(files),manifestSHA256=sha(E/'EVIDENCE_MANIFEST.json')),indent=2))

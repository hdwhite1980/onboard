"""Write research reports from captured metadata. No model/tokenizer execution."""
import datetime, hashlib, json
from pathlib import Path
from research import ROOT, E, S, write, sha

D=ROOT/'docs/sprint3a'
A=json.loads((E/'static-analysis.json').read_text())
R=A['artifacts'];best=R[0]
OFF='ee0ef6023621cff504d758262d4e04895a5af4a2'
INPUT='fee6332c1abaafb77f6f9624236c63aa2f1d0187'
REV=best['revision'];REPO=best['repository']
DECISION='GEMMA4_LICENSE_REVIEW_REQUIRED'
SELECTION='SELECT_mlx-community/gemma-4-e4b-it-4bit@'+REV
stamp='Research only • 2026-09-23 • Apple M3 / 16 GiB / macOS • no acquisition or execution authorization\n\n'
def put(name,text):
    p=D/name
    with p.open('x') as f:f.write(text.rstrip()+'\n')
def link(repo,rev,file=''):return f'https://huggingface.co/{repo}/'+('blob/' if file else 'tree/')+rev+('/'+file if file else '')
official=link('google/gemma-4-E4B-it',OFF)
selected=link(REPO,REV)
config=link('google/gemma-4-E4B-it',OFF,'config.json')
paper='https://arxiv.org/html/2607.02770v1'
card='https://ai.google.dev/gemma/docs/core/model_card_4'
license_url='https://ai.google.dev/gemma/apache_2'
gib=lambda n:n/(1024**3)
budget={'fullPublishedWeightsIncludingUnusedModalities':best['weightBytes'],'runtimeProcess':int(.375*2**30),'tokenizer':int(.1875*2**30),'loadTemporaries':int(.375*2**30),'prefillTemporaries':int(.5*2**30),'cache512FP32UpperPlanningAllowance':A['cache512Bytes']['FP32'],'allocatorCache':int(.25*2**30),'uncertainty':int(.375*2**30)}
write(E/'resource-hypothesis.json',{'status':'PROPOSED_UNMEASURED_NOT_AUTHORIZED','artifact':REPO,'revision':REV,'componentsBytes':budget,'sumBytes':sum(budget.values()),'sumGiB':gib(sum(budget.values())),'workerCeilingBytes':7*2**30,'normalAdmissionStrictlyGreaterThanBytes':int(9.25*2**30),'policyModified':False,'hostAdmissionMeasured':False})
write(E/'research-decision.json',{'status':DECISION,'selection':SELECTION,'selectionScope':'Conditional research recommendation for owner/legal review only; no clean acquisition clearance','modelWeightBytesAcquired':0,'modelLoads':0,'generations':0,'dynamicTokenizerRuns':0,'runtimeInstalls':0,'policyChanges':0,'quality':'UNMEASURED','resource':'UNMEASURED','qualifiedTasks':[],'blockers':['Derivative card license gemma conflicts with pinned Google Apache-2.0 declaration','Converter local checkout revision, command and dependencies unattested','Weight/header verification deferred until authorized acquisition','Offline tokenizer preflight and runtime/resource calibration not performed']})

put('CANDIDATE7_GEMMA4_ARCHITECTURE.md',f'''# Candidate 7 — Gemma 4 E4B architecture

{stamp}E4B is **dense**, with **effective**, not expert/active-expert, naming. It has no MoE router, expert count, selected experts, shared experts or expert routing state. Those fields are not applicable. Google currently lists E2B, E4B, 12B Unified, 26B A4B and 31B; the 26B A4B is the separate MoE design. The E4B assistant target is the instruction-tuned `google/gemma-4-E4B-it`, not its pretrained sibling and not the `-it-assistant` MTP drafter. [Official family card]({card}); [draft-model card](evidence/candidate7-research-01/sources/official-draft-assistant-card.md).

## Identity and counts

| Field | Evidence-backed value |
|---|---|
| Publisher / release | Google / Google DeepMind; family launch April 2, 2026 ([launch](https://blog.google/innovation-and-ai/technology/developers-tools/gemma-4/)) |
| Official current repository revision | `google/gemma-4-E4B-it@{OFF}` |
| Conversion's declared official input | Same repository, `{INPUT}`; distinct from current head |
| Model class | `Gemma4ForConditionalGeneration`, nested `gemma4_text` |
| Published total | About 8B; official Hub safetensors metadata reports **7,996,156,490 BF16 elements**; no local header verification |
| Effective designation | About 4.5B; not an exact count of weights touched per text token |
| Stored embedding tables | Main 671,088,640 + per-layer 2,818,572,288 parameters |
| Derived text module parameters | **7,463,013,418** for the installed inference architecture, with tied output projection and unused tail K/V projections omitted |
| Derived official text layout | **7,518,069,034**, including 55,055,616 redundant tail K/V/norm parameters; architecture arithmetic, not downloaded-header measurement |
| Multimodal remainder | 478,087,456 aggregate parameters by subtraction; includes encoders/projections/auxiliary tensors, not solely vision |
| Vision / audio published sizes | Approximately 150M / 305M respectively; exact separated stored counts not independently established without tensor shapes |
| Output / input | Text output; text, image, audio, video-as-frames input in the full model |
| Context | 131,072 positions; future project experiment limited to 512 total tokens |

The exact official total is publisher metadata. The text figures come from enumerating shapes implied by the [pinned config]({config}) and the installed MLX-LM source. Their calculation is preserved in `static-analysis.json`. Removing both embedding tables from the official total yields about 4.5065B, illustrating the effective designation; it does not establish an execution-level active-parameter metric. In particular, the tied vocabulary output projection still uses the main embedding matrix. Google's technical report reports rounded component counts, not a precise E4B active-expert count. [Report, Table 1]({paper}#S1.T1).

## Configuration that determines memory

| Component | E4B setting |
|---|---|
| Decoder layers / hidden size | 42 / 2,560 |
| MLP width | 10,240; three GELU-gated projections; `use_double_wide_mlp=false` |
| Attention pattern | Five sliding layers then one global, repeated seven times: 35 sliding / 7 global |
| Sliding window | 512 tokens |
| Query heads / KV heads | 8 / 2 |
| Head dimensions | Sliding 256; global 512 |
| KV sharing | Last 18 layers reuse prior same-type K/V; only first 24 own cache: 20 sliding / 4 global |
| Keys equal values | **False** for E4B; do not apply the larger-family K=V optimization to it |
| RoPE | Sliding theta 10,000; global proportional RoPE theta 1,000,000, rotary fraction 0.25 |
| Vocabulary | 262,144; main embeddings `[262144,2560]`, tied output |
| PLE | 256 dimensions per layer; table `[262144,10752]`; projection `[10752,2560]` plus per-layer gates/projections |
| Normalization / logits | RMSNorm and query/key normalization; final logit softcap 30 |
| Recurrent/state-space | None in text decoder; no recurrent cache budget |
| Vision configuration | 16 layers, hidden 768, MLP 3,072, 12 attention/KV heads, head dimension 64, patches 16, pooling 3 |
| Audio configuration | 12 layers, hidden 1,024, 8 attention heads; convolution/subsampling components; not used by text wrapper |

All values above are config/source facts, not performance measurements. The family overview's broad K=V language is superseded for this exact candidate by `attention_k_eq_v=false`.

## Compute is not resident memory

There are **no experts to stream or page**. PLE performs sparse row lookup, which reduces embedding lookup work; it does not mean that the full table can be removed from the package or its memory budget. Installed `QuantizedEmbedding.__call__` gathers the needed packed rows before dequantization. Its tied-output `as_linear` uses quantized matrix multiplication. These are actual compute differences from a dense 9B transformer, but not proof of a four-billion-parameter resident working set.

The installed loader opens all published safetensors files with `mx.load`, then constructs only the language model, filters vision/audio/projector tensors, binds packed language weights, and by default calls `mx.eval(model.parameters())`. It has no E4B-specific disk offload, expert streaming, selective PLE paging or measured lazy-mmap residency contract. Generic MLX lazy evaluation does not prove lazy file-backed residency. Budget every language weight; also charge the entire published multimodal file in the conservative initial plan because transient cost of discarded tensors is unmeasured.

No vision/audio module is constructed by the MLX-LM `gemma4` wrapper. The reviewed community package still contains 1,415 non-language index entries. Unused is not equivalent to zero transient memory. A separately published k5p5 text artifact has zero non-language index entries but larger mixed-precision weights; see comparison.

## Cache arithmetic at the proposed test length

For BF16 caches: `2(K,V) × 512 × 2(KV heads) × (20×256 + 4×512) × 2(bytes)` = **29,360,128 bytes (28 MiB)**. FP32 doubles this to **56 MiB**, used as the planning allowance. Cross-layer references must not be counted as 18 new caches; kernel temporaries and allocation padding remain separate. Beyond 512 tokens, sliding caches saturate while the four independent global caches grow; the model's 128K capacity is not an endpoint deployment promise.

## Static compatibility finding

Retained Python 3.12.14 arm64, MLX/Metal 0.32.2, MLX-LM 0.31.3, Transformers 5.17.0 and tokenizers 0.23.2 have the required native text architecture and tokenizer implementation. No MLX-VLM installation is needed for the proposed text path. The preferred conversion's **1,355 language index keys exactly match** the independently enumerated installed-model keys; shapes/dtypes still require later header verification. No `auto_map`, `model_file` or repository Python file is present in that package manifest. Static compatibility is not a completed load test.

LM Studio retains 126 redundant trailing K/V keys which the current sanitizer does not remove. Its strict-load path is therefore statically incompatible without an explicitly reviewed loader/artifact change. The mobile-QAT discovery uses `quant_method=gemma`, unsupported by this installed generic quantization dispatch. Neither finding justifies changing the retained runtime during research.

Source snapshots and hashes: [runtime source record](evidence/candidate7-research-01/retained-runtime-source-record.json), [shape and index analysis](evidence/candidate7-research-01/static-analysis.json).
''')

put('CANDIDATE7_GEMMA4_LICENSE.md',f'''# Candidate 7 — license and product gate

{stamp}**{DECISION}.** Official Gemma 4 uses **Apache License 2.0**, a permissive open-source license, rather than the custom terms used for listed older Gemma models. However, the preferred exact community conversion declares `license: gemma`. This is a concrete conflict requiring clarification or an explicit, narrow owner-approved experimental exception before acquisition; research does not silently relabel the derivative.

## Exact controlling-source evidence

- [Google's pinned instruction model]({official}) declares `apache-2.0` and links to Google's Gemma 4 license. The conversion's [declared source revision]({link('google/gemma-4-E4B-it',INPUT,'README.md')}) makes the same declaration.
- The repository license link redirects to [Google's Apache 2.0 text]({license_url}). No separate LICENSE or NOTICE file exists in the captured official repository inventory; the license is provided through the model card link.
- The [legacy Gemma Terms](https://ai.google.dev/gemma/terms), modified April 1, 2026, explicitly direct Gemma 4 readers to its separate license. Their appendix lists older models, not Gemma 4.
- [Preferred conversion card]({link(REPO,REV,'README.md')}): `license: gemma`, with no local LICENSE/NOTICE and no explanation reconciling it with its Apache upstream. This could be erroneous metadata, but that explanation is not attested.
- [LM Studio card]({link(R[1]['repository'],R[1]['revision'],'README.md')}) declares Apache 2.0 and links to Google. Its independent runtime mismatch prevents using it as a drop-in alternative.
- [k5p5 card]({link(R[2]['repository'],R[2]['revision'],'README.md')}) expressly says legacy Gemma terms govern its derivative. This is stronger than a bare tag and is not overridden by this research.

## Apache 2.0 obligations for an authorized package

Sections 2–4 permit commercial use, modification, sublicensing and redistribution, including paid/offline packaging. Recipients must receive the license; modified files need change notices; relevant attribution notices must be preserved, including applicable upstream NOTICE material if supplied. Terms for additions cannot negate upstream requirements. Section 3 ends its patent grant if the recipient initiates specified patent litigation. The text does not add a field-of-use ban, recurring online acceptance, hosted-service reporting or a general Google discretionary revocation clause. Sections 6–9 limit trademark permission, disclaim warranty/liability and place voluntarily offered support obligations on their provider. These conclusions apply to the Apache-licensed work, not automatically to separate services or third-party additions. [Exact license]({license_url}).

## Custom legacy terms: reviewed, not silently applied to Gemma 4

The older agreement covers hosted access within distribution, requires downstream use restrictions, agreement copies and change notices, and a Notice file for non-hosted distribution. It incorporates the prohibited-use policy and provides breach termination with deletion/cessation duties. Those requirements are materially different from Apache 2.0. [Legacy terms](https://ai.google.dev/gemma/terms).

The [legacy prohibited-use policy](https://ai.google.dev/gemma/prohibited_use_policy) restricts harmful/illegal activities, some personal-data uses and automated consequential decisions, among other uses. It does not itself establish a blanket government or defense-customer ban. We do not attach it to the official Apache Gemma 4 release merely because the family name is shared. Whether a derivative publisher intended additional restrictions is the unresolved issue here.

## Commercial, government and defense assessment

| Scope | Classification | Reason |
|---|---|---|
| Official Apache Gemma 4 copyright-license identity | CLEAR | Exact publisher declaration and linked text agree |
| Paid/offline redistribution based on that official license | ACCEPTABLE_WITH_REVIEW | Normal notice/attribution, modification and component-rights review; no model-specific offline distribution prohibition found |
| Preferred community derivative in a shipped product | MATERIAL_LEGAL_REVIEW_REQUIRED | Conflicting custom-license tag; conversion provenance not fully reproducible |
| Government procurement / deployment / contractors | ACCEPTABLE_WITH_REVIEW for official license; MATERIAL_LEGAL_REVIEW_REQUIRED for preferred derivative | No official evidence of special government approval or categorical prohibition; procurement and operating authorization are separate |
| Defense customers | Same distinction | A customer category is not proof of a prohibited use, and a model license is not a mission-use authorization |
| Public / Internal / FCI / CUI | Product deployment NOT AUTHORIZED | No resource/quality/security qualification or agency authorization follows from licensing; classified use remains outside V1 |

These are engineering gate classifications for owner/legal review, not a legal opinion or certification. No claims of FedRAMP, CMMC, FIPS, CUI approval, government endorsement or defense prohibition are made. No specific jurisdiction/contract approval is inferred.

## Resolution needed

Request publisher clarification tied to the exact revision, or obtain counsel/owner acceptance of a narrowly defined local evaluation exception identifying the contradictory tag, upstream terms and conversion uncertainty. No message has been sent to a publisher. A resolved license alone is not acquisition permission. Any future experimental approval must exclude redistribution/customer/government/CUI/FCI use, specify artifact/revision and synthetic inputs, and leave production review pending. The prior Qwen exceptions do not carry forward.

All source texts are archived with timestamps and SHA-256 values in [source register](evidence/candidate7-research-01/source-register.jsonl). Website footer licenses were not substituted for the model license.
''')

put('CANDIDATE7_GEMMA4_TOKENIZER_PROVENANCE.md',f'''# Candidate 7 — tokenizer provenance and native assistant format

{stamp}**Official origin identified; immediate byte lineage verified; derivative license conflict unresolved. No dynamic tokenizer execution.** This is substantially stronger immediate provenance evidence than an unnamed tokenizer lineage, but is not a warranty about every training-data right.

## Identity and lineage

Google publishes the tokenizer with `google/gemma-4-E4B-it@{OFF}`. The technical report identifies the tokenizer as the Gemini Team (2025) tokenizer: SentencePiece lineage, digit splitting, preserved whitespace and byte-level encoding. [Technical report, tokenizer paragraph]({paper}#S3).

The actual downloaded JSON is a **tokenizers BPE serialization with byte fallback**: 262,144 vocabulary entries, 514,906 merges, `<unk>` fallback, space-to-`▁` normalization, and reverse-space/ByteFallback/Fuse decoding. SentencePiece lineage and BPE are compatible descriptions; do not call this JSON a Unigram model or claim a tokenizer.model file was obtained. No separate SentencePiece model/vocab/merges files are in the official inventory. Underlying tokenizer-training corpus and a granular third-party vocabulary rights ledger were not published in the inspected sources.

All three shortlisted conversions have byte-identical `tokenizer.json` to Google's current pinned file:

`cc8d3a0ce36466ccc1278bf987df5f71db1719b9ca6b4118264f45cb627bfe0f`

Size **32,169,626 bytes**. The preferred conversion's declared Google input API also supplies the same file identity. Downloaded metadata bytes were checked against publisher Git blob/LFS identities; no model weight identity was locally verified.

The preferred native chat template equals the declared Google input `{INPUT}` byte-for-byte:

`2f1b4d75d067bae3fe44e676721c7f077d243bc007156cb9c2f8b5836613d082` (17,336 bytes).

It differs from current official head's 18,569-byte template, SHA-256 `0a2c8073c878ab1da004bee933a998606537bbb62016310352c7285c3f01c5b5`. Preserve the selected artifact's native template; do not silently update it. LM Studio and k5p5 have different templates; full hashes appear in the comparison evidence. Their tokenizer byte identity does not make their templates identical.

## Rights and software distinction

The official repository makes a package-level Apache-2.0 declaration, with no tokenizer-specific contrary notice in the inspected inventory. This supports coverage of the published tokenizer artifacts; no independent tokenizer-only grant or complete training-data-rights attestation was found. Google's linked license supplies the model/package grant. The derivative's contradictory `gemma` declaration therefore remains relevant to the tokenizer package too.

Installed Transformers' `GemmaTokenizer` source has its own Apache-2.0 software license and consumes tokenizer JSON through the installed tokenizers backend. That software license does not independently confer rights to vocabulary, merges or training data. No executable code from a model repository is needed for this class. Third-party software notices belong in the product SBOM; none establishes artifact/data rights by itself. See [license review](CANDIDATE7_GEMMA4_LICENSE.md).

## Exact native mode proposed for a later test

The selected Jinja template supports initial `system` or `developer`, `user`, and `assistant` (rendered as `model`). It emits BOS, opens turns with `<|turn>role` plus newline, and closes completed turns with `<turn|>` plus newline. With `add_generation_prompt=true`, it opens `<|turn>model` plus newline. `enable_thinking=false` omits the `<|think|>` injection; E4B's routine format does not need an invented empty thought block. No tools are passed. [Pinned template]({link(REPO,REV,'chat_template.jinja')}).

Tool definitions, when used, have native tool delimiters and function serialization; tool calls use IDs 48/49, responses 50/51, and string escaping uses ID 52. They are documented here but are outside the one-request design. Do not enable repository code, template evaluation side effects, tool dispatch or network fallback.

| Token | ID / treatment |
|---|---|
| `<pad>` / `<eos>` / `<bos>` / `<unk>` | 0 / 1 / 2 / 3 |
| `<|think|>` | 98; absent in routine input |
| `<|channel>` / `<channel|>` | 100 / 101 |
| `<|turn>` / `<turn|>` | 105 / 106 |
| `<|tool_response>` | 50; generation stop as specified by selected generation config |
| Image/audio/video markers | 255999, 256000, 258880–258884; unused for text |
| Effective generation stops | `[1,106,50]` from selected generation_config; do not use nested text-config EOS 1 alone |

The JSON postprocessor does not add BOS automatically in the reviewed serialization; the native template emits it. Later preflight must verify one-BOS rendering, stop behavior, role boundaries, special-token round trips and every frozen fixture's actual token count. No prompt token count is asserted now. Google's sampling recommendation differs from the owner's fixed greedy evaluation; the future experiment must explicitly record that difference while preserving the native format.

## Remaining provenance gates

1. Resolve/explicitly accept the derivative's license conflict for the approved use.
2. Keep exact Google input, conversion, tokenizer and template identities in the future package manifest.
3. Preserve converter reproducibility uncertainty: the card identifies a local `mlx-vlm` checkout but not its commit/version or full command/dependencies.
4. Perform offline dynamic tokenizer checks only in a later authorized phase. No tokenizer or model was instantiated in this research.
''')

table='| Artifact | Exact revision | Weight bytes | Repository bytes | Finding |\n|---|---|---:|---:|---|\n'
findings=['Conditional preferred research candidate; license conflict','126 unexpected language keys; larger mixed precision','True text-only; larger mixed precision and express legacy terms']
for r,why in zip(R,findings):table+=f"| `{r['repository']}` | `{r['revision']}` | {r['weightBytes']:,} | {r['repositoryBytes']:,} | {why} |\n"
put('CANDIDATE7_GEMMA4_ARTIFACT_COMPARISON.md',f'''# Candidate 7 — artifact comparison

{stamp}Exactly three serious artifacts are shortlisted. The sole **conditional research recommendation** is:

`{SELECTION}`

This selects an artifact for owner/legal review, **not acquisition clearance**. Final gate: **{DECISION}**. No weighted scoring was used. Legal/product viability remains ahead of fit; the license conflict prevents progressing today. This is not a claim that an unconditionally acceptable package already exists.

{table}

Sizes are fresh pinned Hub file metadata, excluding Git history; weight bytes include safetensors headers, and repository bytes include all published files. No range request or model weight payload was downloaded. All fetched non-weight files were checked against Git blob/LFS identities.

## 1. Preferred: MLX Community standard instruction 4-bit

Publisher `mlx-community`; [exact repository]({selected}). Declared upstream is `google/gemma-4-E4B-it@{INPUT}`. The current official head is different, so it is not substituted. Current conversion commit re-uploads from that declared input; converter is `mlx_vlm.convert` from a local checkout, with exact version/commit/command/dependency build unreported. Full reproducibility remains pending.

Affine 4-bit, group 64. Index has 2,770 entries: **1,355 language / 1,415 non-language**; current-language expected keys match exactly. The declared converted logical parameter metadata is 7,941,100,874, below the official 7,996,156,490 because the 55,055,616 unused tail K/V/norm parameters are absent. Actual header/shapes not acquired. Effective naming remains roughly 4.5B, with no MoE active count.

Both embedding matrices/tied output, MLP, attention and per-layer projection/gates have packed weight/scale/bias index families. Norms/scalars stay floating; metadata reports BF16 and U32. Audio/vision/projector payload is retained. Exact per-tensor dtype attribution awaits header review; config-derived language bytes are **4,198,750,292**. Full-file budget remains **5,146,800,534** bytes.

Native text execution is statically supported by retained MLX-LM; full modality use advertised by the publisher uses MLX-VLM. No remote-code keys or repository executables. `processor_config.json` includes Gemma4 image/audio processing, unused by the text path. Tokenizer bytes match Google; template matches declared source. License tag is `gemma`, conflicting with that source's Apache declaration. No LICENSE/NOTICE in inventory.

Weight SHA-256 (publisher LFS, **not locally verified**): `932b8271fc3fe65adcc78b96c10c6268bbfb13e8f67d1358727c0d6ee97e1eff`.

Reason to prefer conditionally: direct pinned Google source; native source template; compatible tensor names; standard quantization; lower all-file charge than alternatives. Reason not to acquire yet: unresolved license tag and unattested converter build; later shape/runtime/resource checks still required.

## 2. LM Studio Community 4-bit

[Exact repository]({link(R[1]['repository'],R[1]['revision'])}); publisher `lmstudio-community`; declared Google instruction model, no exact upstream revision. Converter `mlx_vlm`, version/commit/command not attested. Apache-2.0 card/link; no repository LICENSE/NOTICE. Official ~8B architecture; metadata total 7,996,156,490; no experts.

Affine group 64, 4-bit default with **126 MLP projections at 8-bit** (all three projections in all 42 layers). Other linear/embedding modules follow 4-bit defaults where indexed; norms/scalars remain floating. Two shards retain vision/audio/processor metadata. Tokenizer matches Google; template SHA `781d10940fbc44be40064b5d43a056fc486c84ceaa55538226368b57314132bf` differs from both reviewed official templates. No remote-code keys.

There are **126 extra language tensor keys** from trailing shared-KV layers. Installed `Model.sanitize` does not delete these. Strict loading would reject unexpected keys by source inspection; no test was run. A generic framework upgrade is not assumed to fix it. It is not recommended unchanged, and the 6.36 GiB all-file weight floor also leaves less host margin.

## 3. k5p5 text-only mixed precision

[Exact repository]({link(R[2]['repository'],R[2]['revision'])}); publisher `k5p5`; declared source `unsloth/gemma-4-E4B-it-UD-MLX-4bit`, upstream revision unreported. Card links an extraction script in `k5p5/personai`, without a pinned script/converter/environment. It claims tensor-copy stripping and output equivalence; those claims were not independently verified.

Config and index support **text-only**: 1,353 language / zero non-language entries, no audio/vision configs/processor file in fetched inventory, retained modality token IDs. Derived language logical parameters 7,463,013,418, not a 4B-total model. Quantization is affine group 64 with mixed 4/5/6/8-bit modules; main and PLE embeddings are 6-bit, attention/gates 8-bit, MLP mixed 4/5/6-bit, global per-layer projection floating. The config-derived payload **5,559,654,484** matches index total exactly, supporting this arithmetic without proving tensor content.

Tokenizer matches Google. Template SHA `241c50d86bdfe5e43307da87f559cd2416aacd67a8de46c15acc0105ef2200b7`; no match to either reviewed official template. No remote-code keys; expected key names match retained runtime. Its card expressly applies legacy Gemma terms, contradicting official Gemma 4 licensing. Larger weights and added lineage/terms uncertainty outweigh removal of modalities for this first experiment.

## Quantization discovery outside the shortlist

These are scoped format checks, not additional recommendations:

- **3-bit exists:** `salohcin714/gemma-4-E4B-it-3bit-mlx@4e36ab66c9ef31a66c1a60af891354ca074bebfe`, published weights **3,266,118,857** bytes. Its card declares Apache-2.0, direct Google input and MLX-LM 0.31.3; input commit is not given. Affine/group64, round-to-nearest with no calibration. No compelling retained-quality evidence was found. Do not choose it solely to force fit; metadata-only discovery is not full package qualification.
- **MXFP4 exists:** `mlx-community/gemma-4-e4b-it-mxfp4@509e9e4be41533a283aa07fedfe27fd4fa08f9c2`, **4,913,368,671** bytes, group32/mxfp4. Installed MLX has this quantization format, but no exact M3 kernel/quality qualification was performed; the same `gemma` tag conflict persists. It is not the preferred standard affine experiment.
- **QAT mobile exists:** `mlx-community/gemma-4-E4B-it-qat-mobile@659820526b0c35dc548eca973741b3efe8ae8a35`, **3,455,955,670** bytes; 2/4/8-bit module policies and activation scales, `quant_method=gemma`. Its sparse card omits license/upstream/build detail, and the installed loader does not dispatch that method. No inference, runtime change or automatic mapping to generic affine is justified.
- A separate community QAT-4bit card/config was screened: mixed 4/8-bit, sparse provenance/license description; not a safer drop-in on the inspected evidence.
- Google publishes QAT/mobile formats; that is not an official Google MLX package attestation. No official Apple/Google-published MLX E4B conversion was established by the captured searches. MLX Community affiliation is not a Google artifact signature. Publisher-scoped searches included LM Studio and MLX Community, plus text-only/3-bit discovery; this is bounded discovery, not proof that no other conversion exists.

All selected-format weight content, exact dtype/shape and quantization fidelity checks remain deferred. No full-precision expansion or performance result is asserted. [Static analysis](evidence/candidate7-research-01/static-analysis.json), [source register](evidence/candidate7-research-01/source-register.jsonl).
''')

bt='| Budget item | GiB | Basis |\n|---|---:|---|\n'
basis=['Full file, including unmeasured transient modality cost','Provisional interpreter/runtime overhead','32.17 MB JSON plus in-memory tokenizer structures','Bounded packed load workspace, no full BF16 copy assumed','128-token prefill chunks; logits/softcap/MLP/PLE temporaries','All 24 independent caches at FP32; BF16 would be half','Provisional bounded allocator allowance','Explicit unmeasured allowance']
for (k,v),b in zip(budget.items(),basis):bt+=f'| {k} | {gib(v):.6f} | {b} |\n'
components='| Text component | Logical parameters | Config-derived 4-bit payload bytes |\n|---|---:|---:|\n'
for k,v in A['textParametersByComponent'].items():components+=f"| {k} | {v:,} | {best['expectedTextBytesByComponent'][k]:,} |\n"
put('CANDIDATE7_GEMMA4_RESOURCE_PLAN.md',f'''# Candidate 7 — unmeasured resource hypothesis

{stamp}A **technically defensible but high-risk bounded experiment exists**, conditional on the license/provenance gate and later owner authorization. This is not a current admission pass. No fresh host telemetry, tokenizer execution, model load, header reads or performance test occurred.

The candidate for this proposal is `{REPO}@{REV}`. The proposal does not authorize acquiring its 5,146,800,534 weight bytes, switching artifacts, stripping weights or altering the loader.

## Weight and execution budget

{components}

Sum of language payload estimate: **4,198,750,292 bytes / 3.910391 GiB**, including affine scale/bias overhead and assumed BF16 floating tensors. This is static shape arithmetic, not a verified safetensors header or resident measurement. The published index total exceeds it by **947,698,048 bytes** attributable by subtraction to non-language payload, pending header verification. Header overhead is another 352,194 bytes. Router, experts, expert-routing state and recurrent caches: **zero/not applicable**. Shared dense layers, attention, embeddings and per-layer gates are separately counted above and must not be added twice.

{bt}

Sum: **{gib(sum(budget.values())):.6f} GiB**. Round upward to independently proposed **GEMMA4_INITIAL_WORKER_CEILING = 7.0 GiB = 7,516,192,768 bytes** of measured worker physical footprint. This is a stop boundary, not an allocation target or safe-host guarantee. It is not copied from the previous Qwen or Granite ceilings. These overheads are explicitly unmeasured planning allowances; their adequacy must be observed, not presumed.

At batch 1 / prefill chunk 128, an FP32 `[128,262144]` logits buffer is 128 MiB. The 512 MiB temporary allowance covers several logits/softcap buffers plus MLP/PLE work as a hypothesis. KV is 28 MiB BF16 or 56 MiB FP32 at 512 tokens. A full BF16 text expansion would approach 13.9 GiB and is outside this plan; unexpected expansion/allocation behavior must abort. The plan does not depend on expert paging, CPU offload, mmap, TurboQuant, purging, app closure or modified Metal limits.

## Admission concepts — neither authorized here

**Normal conservative admission:** fresh healthy host observations, zero initial swap, plus legacy-equivalent headroom **strictly greater than 9.25 GiB** (7.0 GiB ceiling + 2.25 GiB early reserve). This scalar test is necessary, not sufficient; NORMAL pressure and all other gates also apply. Historical C6/C6B starting headroom around 4.65–5.00 GiB would fail it. No assertion about today's headroom is made.

**Possible owner-authorized unmeasured-profile calibration:** permit only one attempt despite failure of the *unmeasured working-allowance admission calculation*. Require an otherwise healthy starting host and retain every hard guard. It is technically plausible because the bound language estimate is about 0.78 GiB below C6B's language tensor payload, PLE changes compute behavior, and cache sharing keeps the small test cache modest. It remains high risk: C6B reached WARN at only 3.443 GiB observed worker footprint, so neither the 7 GiB ceiling nor available-headroom arithmetic predicts reaching MODEL_LOADED.

The experiment can fail below the proposed ceiling; it may not raise the ceiling or weaken pressure policy. No arbitrary claimed safe lower allowance is substituted. An owner exception is **not granted by this document**.

## Unchanged Policy V2 and safety controls

- NORMAL pressure only; WARN/CRITICAL/UNKNOWN immediately stop.
- Protected reserve 2 GiB; early stop at headroom **≤2.25 GiB**.
- Initial swap zero; no growth and no positive swap-in/out activity.
- Nominal/fair thermal states only; unknown/serious/critical stop.
- Finite 7.0 GiB proposed physical-footprint limit; native and MLX telemetry fresh within 1.5 seconds.
- Load 90 s, generation including prefill 60 s, wall 180 s limits; 100 ms load / 250 ms generation sampling and recovery observations.
- Compression is diagnostic and may latch degraded status; never a replacement for the pressure hard stop.
- Existing network-denied boundary, negative control, exact package/runtime identities, no Foundation Models, remote provider, fallback, repo code or Hub access during execution.
- Use Candidate6B-qualified immediate-KILL worker lifecycle without changing historical files; retain separately corrected helper cleanup. Harmless qualification latency is not a guarantee of GPU teardown latency.

## Future one-attempt design — design only

After a separate exact acquisition authorization, obtain the pinned weight file into quarantine, verify size/SHA, inspect every tensor shape/dtype/offset against config/index and runtime expectations, and create a signed/verified experimental package under the existing process. Record conversion/license limitations. No local stripping or requantization.

Only after later authorization: offline tokenizer-only preflight for the unchanged frozen Candidate2 fixtures; `trust_remote_code=False`, `local_files_only=True`, no Hub fallback. Verify actual total tokens, native template hash, stop IDs, nonthinking mode and one-BOS rendering. Preserve the exact substantive `professional-1` system and user messages from `product/local_ai/quality/fixtures.py`; do not shorten or improve them. This research has not rendered/tokenized them.

Then, if explicitly authorized, **one load → one generation only if safely loaded → one cooperative unload if reached**, with no retry. Batch 1, **512 total tokens including 128 reserved output**, greedy decoding, prefill chunks 128, native routine mode (`enable_thinking=false`), no tools. Stop IDs `[1,106,50]`. Capture raw output without repairing it. Evaluate Sarah, encryption, October 3, deployment, impact uncertainty, professional tone, and absence of invented progress/approval/facts or impact-to-blocking narrowing.

On any hard stop, terminate/reap the worker, verify owned process group absence, perform bounded helper cleanup and recovery observations, seal complete/partial evidence honestly, and stop. Do not retry, switch derivative, change loader or reinterpret prior results. A clean one-request resource result is not a quality pass or a sustained qualification.

## TurboQuant

**TURBOQUANT_NOT_APPLICABLE_OR_UNVERIFIED** for the exact retained candidate/runtime. Google's research addresses KV/vector compression, not a demonstrated reduction of this artifact's static weight payload. Third-party projects advertise Gemma 4 E4B support, including TurboMLX at commit `e123f0ce0f187b47ba84614c425be556f827bf30`; their tests use different artifacts/additional code. The inspected project API supplies no license and its LICENSE URL returned 404. Its README includes a small logit-comparison test, not this project's frozen quality/security/resource qualification. No implementation or patent/license grant is inferred from the paper. Retained MLX-LM has no TurboQuant symbol/path. [Google research](https://research.google/blog/turboquant-redefining-ai-efficiency-with-extreme-compression/), [publisher source](https://github.com/Smilefounder/TurboMLX/tree/e123f0ce0f187b47ba84614c425be556f827bf30).

Even an ideal cache reduction could only recover tens of MiB at this 512-token profile; it would not solve multi-GiB model load pressure. No TurboQuant adoption or runtime installation is proposed.
''')

put('CANDIDATE7_16GB_DECISION_FRAMEWORK.md',f'''# Candidate 7 — 16 GiB architecture decision framework

{stamp}**Do not pivot merely because research found a package license/runtime issue.** This investigation has not tested Gemma resource fit or quality. It identifies a plausibly stronger dense/PLE model and a material derivative license gate. The current research status is **{DECISION}**, not a measured model failure.

## Preserved evidence baseline

| Candidate | Existing finding, unchanged |
|---|---|
| Qwen3 1.7B | Resource pass; general assistant quality fail |
| Granite 4.0 H Micro | Policy V2 resource pass; general assistant quality fail |
| Qwen3.5 2B | Resource pass; 8/16 semantic passes, 2/7 complete capabilities; basic-quality fail |
| Qwen3.5 9B multimodal | WARN during incomplete eager load, before generation |
| Qwen3.5 9B text-only | WARN during incomplete eager load, before generation; removal of ~0.85 GiB published vision payload did not yield safe load |

Historical Qwen3.5 9B decision remains `QWEN35_9B_NOT_SUPPORTED_FOR_CURRENT_M3_16GIB_EXPERIMENTAL_PROFILE`. No prior candidate was rerun, regraded or promoted by this research.

## Why Gemma warrants consideration

The [official report]({paper}) reports E4B IFEval 96.7, IFBench 44.0, MMLU-Pro 69.4, GPQA Diamond 58.6 and MRCR-v2 eight-needle 128K 25.4. These are published **thinking-mode** evaluations unless otherwise stated, not this routine-mode quantized artifact's scores. Native system instructions and structured-output support justify testing, but no retrieved evidence directly establishes preservation of our names, numbers, owners, versions or approval states.

The product-specific tests remain necessary: unsupported rewrite assumptions, ownership loss, exact-number changes, approval mutation, impact-to-blocking narrowing, length violations, payroll classification, output schema, missing versions and owner mutation. Published reasoning strength cannot replace those checks. Native long context is not proof of grounded QA/RAG, and summarization/writing use cases in a model card are not per-task validation scores. No retrieved official benchmark supplies a direct calibrated guarantee for the frozen enterprise fixtures.

## Decision sequence

1. Resolve or explicitly accept exact derivative terms and provenance for local experimentation; authorize acquisition separately. A procurement/license impasse is not proof that the architecture cannot fit.
2. Verify artifact/header/runtime/tokenizer compatibility; if that fails, classify the integration result, not a semantic/resource failure. Do not invent a passing baseline from inability to test.
3. Perform only an explicitly authorized one-load/one-request calibration. A Policy V2 hard stop ends it; no retries to find a favorable workstation state.
4. Only after resource success and separate authorization, run the **same frozen 16 cases**. At least **four of seven capabilities must pass both fixtures**, including at least one writing or summarization capability. The two dedicated fact-preservation cases remain separate evidence, never extra capability credits. No easier prompt, truncation, output repair or relaxed semantic rubric.
5. A basic-quality pass still requires separately authorized RAG, meeting, adversarial and sustained validation before any primary-assistant promotion.

## If a properly selected Gemma candidate fails

If this materially different, appropriately licensed and integrated E4B candidate either cannot safely load under unchanged Policy V2 or safely runs but fails the frozen basic-quality gate, **recommend ending the current open-ended search for a universal full-assistant model on the M3/16 GiB baseline**. The accumulated engineering evidence would justify a product architecture decision, not a mathematical claim that no future model can work. A runtime bug or telemetry fault alone would instead require an integration conclusion, not an unsupported model-quality claim.

The proposed product split is:

- **16 GiB endpoints:** capability-qualified local utility AI, deterministic processing, permission-aware retrieval, authoritative classification/policy enforcement outside the model, and policy-controlled escalation to an approved government/enterprise service when allowed. Existing small-model failures mean even utility tasks require explicit task qualification; no blanket deployment pass is granted.
- **Higher-memory endpoints:** evaluate stronger primary local assistants with their own resource, quality and security gates. More RAM does not guarantee accuracy or policy compliance.

Local-only requests that exceed a qualified capability must be withheld or handled deterministically when escalation is prohibited; the architecture cannot silently send data elsewhere. Public/Internal/FCI/CUI policies and exact service approvals remain product gates. Classified content remains outside V1.

Do not abandon the overall product. Preserve the calendar → authorized Graph/relevant content → grounded retrieval → classification/policy → local processing → permitted escalation → personalized briefing objective. The pivot changes which endpoint capabilities can be promised, not the need for centrally governed processing.

Reopen 16 GiB full-assistant research only for a concrete new architecture/runtime/artifact with credible new evidence and a bounded owner decision, rather than repeated quantization or pressure-policy relaxation. No pivot is implemented, escalation enabled or Sprint 3B started here.
''')

put('CANDIDATE7_GEMMA4_RESEARCH.md',f'''# Candidate 7 — Gemma 4 E4B research decision

{stamp}**Final decision: {DECISION}**

**Sole conditional artifact recommendation: `{SELECTION}`.** This is the preferred artifact for owner/legal review; it is not a statement of clean acquisition readiness. The official Google release is Apache-2.0, while this exact conversion uses a contradictory `gemma` license tag. No weight acquisition, execution or exception was authorized or performed.

## Answers to the owner's 30 questions

| # | Question | Answer |
|---:|---|---|
| 1 | What E4B means | Effective parameters; dense decoder with large per-layer embedding tables, not MoE |
| 2 | Official identity/revision | `google/gemma-4-E4B-it@{OFF}`, Google DeepMind; launched April 2, 2026 |
| 3 | Total parameters | About 8B; official Hub metadata 7,996,156,490 BF16 elements; not locally header-verified |
| 4 | Active parameters/token | About 4.5B is an effective designation, not a verified per-token active-parameter count; exact count is not asserted |
| 5 | Expert architecture | None; dense attention/MLP plus PLE; separate 26B A4B is MoE |
| 6 | All experts resident? | Not applicable; all language weights must remain available and are eagerly evaluated by retained loader; no expert offload |
| 7 | Text/vision | Full package is text/image/audio/video-frame input → text output; language wrapper constructs no encoders, but opens full weights before filtering |
| 8 | Current MLX artifacts | Three-item shortlist below; standard affine, mixed precision and text-only options exist |
| 9 | Exact revisions | Full pinned revisions in table below and archived APIs |
| 10 | Quantization | 4-bit/group64 preferred technically; 3-bit/group64, mixed 4–8-bit, mxfp4/group32 and mobile QAT discovered, not automatic substitutes |
| 11 | Exact sizes | 5,146,800,534; 6,829,300,498; 5,559,828,972 weight bytes, respectively |
| 12 | Retained runtime | Preferred artifact has static architecture/tokenizer/key support in retained MLX-LM 0.31.3 / MLX 0.32.2; dynamic compatibility untested |
| 13 | Runtime change | None identified for preferred text path; LM Studio strict-key mismatch and mobile-QAT method need changes/review if chosen instead |
| 14 | Remote code | Not required by preferred metadata/installed source; no repo executable files or model_file/auto_map; enforce local-only and trust_remote_code=False later |
| 15 | Model license | Official Apache-2.0; preferred derivative declares gemma — unresolved inconsistency |
| 16 | Commercial redistribution | Official license permits it with obligations; preferred derivative cannot be cleared for product redistribution yet |
| 17 | Government/defense | No categorical approval/ban found; official license ACCEPTABLE_WITH_REVIEW; preferred derivative MATERIAL_LEGAL_REVIEW_REQUIRED |
| 18 | Tokenizer | Google/Gemini SentencePiece lineage; BPE JSON, 262,144 vocab/514,906 merges; three shortlisted tokenizer files byte-match Google; package rights declaration identified, no tokenizer-only corpus-rights attestation |
| 19 | Native assistant mode | System/user/model turns; enable_thinking=false, native generation prefix, stop IDs 1/106/50; no dynamic rendering/token counts asserted |
| 20 | Quality evidence | Official IFEval/IFBench and reasoning/long-context results justify consideration, mostly thinking mode; no product pass or exact-artifact routine quality claim |
| 21 | Expected M3 memory | 3.910391 GiB config-derived bound language payload; conservatively budget full 4.793332 GiB file plus overhead; pressure risk substantial |
| 22 | Compute vs residency | Sparse PLE row lookup saves work, not automatic residency; output tied embedding and eager language-weight evaluation still matter |
| 23 | Worker ceiling | Proposed independently: 7.0 GiB from 6.910519 GiB component budget; unmeasured, not authorized |
| 24 | Bounded Policy V2 experiment | Technically justified conditionally; normal headroom >9.25 GiB, or a separately authorized allowance-only exception with every hard guard retained |
| 25 | TurboQuant | TURBOQUANT_NOT_APPLICABLE_OR_UNVERIFIED for exact retained path; no integration/weight-saving claim |
| 26 | Shortlist | Exactly three serious artifacts; see table |
| 27 | Selection | Exact conditional recommendation above; legal review required before acquisition |
| 28 | Blockers | License conflict; unattested converter build; deferred weight/header verification; unperformed offline tokenizer/resource/quality tests |
| 29 | Next authorization | Resolve/accept exact local experimental terms/provenance, then explicitly authorize pinned acquisition; calibration exception/execution require their own explicit scope |
| 30 | Failure/pivot | After a properly integrated candidate's Policy V2 resource or frozen quality failure, recommend the 16 GiB utility/deterministic/escalation split; not a business shutdown or universal impossibility claim |

{table}

## Most consequential findings

The preferred artifact has a stronger immediate lineage than its name alone suggests: its current card identifies exact Google input `{INPUT}`, and the tokenizer/template match that input. Its conversion build remains unattested. It omits unused trailing K/V keys that are still present in LM Studio's package; this is a concrete compatibility advantage, not just a smaller download. The true text-only alternative remains larger because of mixed precision. These findings do not resolve the license conflict or prove 16 GiB fit.

The model is materially different enough to justify a conditional experiment: around 2.82B parameters belong to a lookup table rather than dense layer multiplication, 18 layers share caches, and the bound text payload estimate is below the failed 9B candidate's language payload. Nevertheless, pressure WARN can stop far below a worker ceiling. Nothing in this research changes the Qwen3.5-9B outcome or Policy V2.

## Deliverables and evidence

- [Architecture and exact runtime analysis](CANDIDATE7_GEMMA4_ARCHITECTURE.md)
- [License and commercial/government review](CANDIDATE7_GEMMA4_LICENSE.md)
- [Tokenizer provenance and native template](CANDIDATE7_GEMMA4_TOKENIZER_PROVENANCE.md)
- [Three-artifact comparison and other quantization checks](CANDIDATE7_GEMMA4_ARTIFACT_COMPARISON.md)
- [Independent memory budget and future one-attempt design](CANDIDATE7_GEMMA4_RESOURCE_PLAN.md)
- [16 GiB decision framework and unchanged quality gate](CANDIDATE7_16GB_DECISION_FRAMEWORK.md)
- [Machine-readable decision](evidence/candidate7-research-01/research-decision.json), [source register](evidence/candidate7-research-01/source-register.jsonl), [static analysis](evidence/candidate7-research-01/static-analysis.json)

Research used official Google documentation/model metadata first, then pinned publisher configs/indexes/templates and installed framework source. Website/model-card instructions were treated as source material, not commands. Some exploratory URLs returned 401/404; these are preserved as failed retrievals, not proof of nonexistence. Initial sandbox DNS failures were followed by the approved metadata-only network retry. Search listings may be bounded; publisher-scoped searches reduce but do not eliminate discovery incompleteness.

All findings are static research. No Gemma model weight bytes, model load, tokenizer execution, inference, model package activation, runtime installation/change, Policy V2 modification, Qwen rerun or Sprint 3B work occurred. Historical evidence is checked against a 2,868-file starting baseline; only an append to the comparison document is permitted. Final preservation verification and evidence manifest are written after document review.
''')

comparison=D/'LOCAL_MODEL_COMPARISON.md';base=comparison.read_bytes()
write(E/'comparison-prefix.json',{'bytes':len(base),'sha256':hashlib.sha256(base).hexdigest()})
with comparison.open('a') as f:f.write(f'''

## Candidate 7 — Gemma 4 E4B research only (2026-09-23)

Official `google/gemma-4-E4B-it@{OFF}` is a dense/PLE model: about 4.5B effective, about 8B total (Hub metadata 7,996,156,490). E4B is not the separate 26B A4B MoE. Static retained-runtime review identifies a native text path and 24 independent shared caches; no inference compatibility pass is claimed.

Conditional research recommendation `{REPO}@{REV}`: 5,146,800,534 published weight bytes, 1,355 matching language keys and 1,415 retained non-language entries. Tokenizer matches Google; native template matches declared Google input `{INPUT}`. Conversion card's `gemma` license tag conflicts with official Apache-2.0. **{DECISION}.** No clean acquisition clearance or experimental exception is granted.

Unmeasured proposal only: 7.0 GiB worker ceiling derived from 6.910519 GiB budget; normal conservative headroom >9.25 GiB. A possible owner-authorized planning-allowance exception must preserve every Policy V2 hard stop. Resource/quality **UNMEASURED**; qualified tasks NONE. No weights acquired, dynamic tokenizer run, model load, runtime change, Qwen rerun or later phase. All prior findings above remain unchanged. [Research](CANDIDATE7_GEMMA4_RESEARCH.md), [decision framework](CANDIDATE7_16GB_DECISION_FRAMEWORK.md).
''')
print('WROTE_SEVEN_REPORTS_AND_APPENDED_COMPARISON')

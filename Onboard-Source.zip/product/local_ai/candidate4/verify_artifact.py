"""Validate safetensors HEADER and package data; never materializes a model tensor."""
import base64
import collections
import hashlib
import json
import math
import struct
import common as c

def no_duplicates(pairs):
    d={}
    for k,v in pairs:
        assert k not in d, 'Duplicate JSON key: '+k
        d[k]=v
    return d

def main():
    acquired=json.loads((c.E/'acquisition.json').read_text())
    assert acquired['repository']==c.REPO and acquired['revision']==c.REV
    assert {p.name for p in c.QUARANTINE.iterdir()}==c.FILES
    for row in acquired['files']:
        assert c.sha(c.QUARANTINE/row['path'])==row['sha256']
    cfg=json.loads((c.QUARANTINE/'config.json').read_text())
    tc=json.loads((c.QUARANTINE/'tokenizer_config.json').read_text())
    gen=json.loads((c.QUARANTINE/'generation_config.json').read_text())
    assert cfg['model_type']=='granitemoehybrid' and cfg['num_local_experts']==0
    assert cfg['quantization']=={'bits':4,'group_size':64,'mode':'affine'}
    assert cfg['layer_types'].count('mamba')==36 and cfg['layer_types'].count('attention')==4
    assert not any(k in d for d in [cfg,tc,gen] for k in ['auto_map','model_file','custom_pipelines'])
    p=c.QUARANTINE/'model.safetensors'
    assert c.sha(p)==c.WEIGHT_SHA
    with p.open('rb') as f:
        n=struct.unpack('<Q',f.read(8))[0];assert 0<n<16*1024**2
        head=json.loads(f.read(n),object_pairs_hook=no_duplicates)
    sizes={'U32':4,'BF16':2,'F16':2,'F32':4}
    tensors={k:v for k,v in head.items() if k!='__metadata__'}
    assert tensors
    ranges=[];totals=collections.Counter();params=0;quantized=0
    for name,t in tensors.items():
        assert isinstance(name,str) and all(x not in name for x in ['..','/','\\'])
        assert t['dtype'] in sizes
        shape=t['shape'];assert isinstance(shape,list) and all(type(x)==int and 0<x<1000000 for x in shape)
        lo,hi=t['data_offsets'];assert type(lo)==type(hi)==int and 0<=lo<=hi<=p.stat().st_size-8-n
        assert hi-lo==math.prod(shape)*sizes[t['dtype']]
        ranges.append((lo,hi));totals[t['dtype']]+=hi-lo
        if t['dtype']=='U32':
            assert name.endswith('.weight') and len(shape)==2
            prefix=name[:-len('.weight')]
            scales=tensors[prefix+'.scales'];bias=tensors[prefix+'.biases']
            assert scales['shape']==bias['shape']==[shape[0],shape[1]*8//64]
            assert shape[1]*8%64==0
            params+=math.prod(shape)*8;quantized+=1
        elif not name.endswith(('.scales','.biases')):params+=math.prod(shape)
    end=0
    for lo,hi in sorted(ranges):assert lo==end;end=hi
    assert end==p.stat().st_size-8-n
    index=json.loads((c.QUARANTINE/'model.safetensors.index.json').read_text(),object_pairs_hook=no_duplicates)
    assert set(index['weight_map'])==set(tensors)
    assert set(index['weight_map'].values())=={'model.safetensors'}
    assert params==3191396096,params
    tok=json.loads((c.QUARANTINE/'tokenizer.json').read_text())
    ordinary=tok['model']['vocab']
    bs=list(range(33,127))+list(range(161,173))+list(range(174,256));cs=bs[:];i=0
    for b in range(256):
        if b not in bs:bs.append(b);cs.append(256+i);i+=1
    back={chr(v):k for k,v in zip(bs,cs)}
    data=c.RESEARCH/'sources/cl100k_base.tiktoken'
    assert c.sha(data)=='223921b76ee99bde995b7ff738513eef100fb51d18c93597a113bcffe865b2a7'
    ranks={base64.b64decode(t):int(v) for t,v in (line.split() for line in data.read_bytes().splitlines())}
    actual={bytes(back[x] for x in token):rank for token,rank in ordinary.items() if rank<len(ranks)}
    assert actual==ranks
    upstream=json.loads((c.RESEARCH/'sources/ibm-granite__granite-4.0-h-micro/tokenizer.json').read_text())
    assert tok['added_tokens']==upstream['added_tokens'] and len(tok['added_tokens'])==96
    result={'status':'PASS','weightSHA256':c.WEIGHT_SHA,'weightBytes':p.stat().st_size,
      'headerBytes':n,'tensorCount':len(tensors),'dtypePayloadBytes':dict(totals),'quantizedMatrices':quantized,
      'reconstructedOriginalParameterCount':params,'indexMetadata':index['metadata'],
      'structureChecks':['duplicate keys rejected','shape/dtype byte lengths','contiguous nonoverlapping complete payload','index exactly matches header','affine 4-bit/group64 matrix dimensions'],
      'modelType':cfg['model_type'],'layerTypes':dict(collections.Counter(cfg['layer_types'])),
      'generationConfig':gen,'cl100kOrdinaryEntriesEqual':len(ranks),'ibmAddedDefinitionsEqual':96,
      'tokenizerFilesComparedWithResearch':True,'customCodeRequired':False,
      'modelLoads':0,'weightTensorsMaterialized':0}
    c.save('safetensors-header.json',head)
    c.save('artifact-verification.json',result)
    print(json.dumps(result))

if __name__=='__main__':main()

"""One lightweight informational host snapshot; no AI imports or model admission."""
import datetime
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c

def run(argv):
    return subprocess.run(list(map(str,argv)),capture_output=True,text=True,check=True,timeout=3).stdout

def main():
    started=time.monotonic();proposal=json.loads((c.E/'resource-proposal.json').read_text())
    assert proposal['status']=='PROPOSED_NOT_ADOPTED'
    vm=run(['/usr/bin/vm_stat']);page=int(re.search(r'page size of (\d+)',vm)[1])
    counts={k:int(v) for k,v in re.findall(r'^(Pages [\w ]+):\s+(\d+)',vm,re.M)}
    pressure=int(run(['/usr/sbin/sysctl','-n','kern.memorystatus_vm_pressure_level']))
    swap_raw=run(['/usr/sbin/sysctl','vm.swapusage']);match=re.search(r'used\s*=\s*([\d.]+)([MG])',swap_raw);assert match
    swap=int(float(match[1])*{'M':1024**2,'G':1024**3}[match[2]])
    probe=c.BASE/'.artifacts/build/resource-probe'
    assert c.sha(probe)==json.loads((c.E/'runtime-identity.json').read_text())['probeSHA256']
    native=json.loads(run([probe,str(os.getpid())]));assert native['error']==0 and native['phys_footprint'] is not None
    available=page*sum(counts[k] for k in ['Pages free','Pages inactive','Pages speculative'])
    requirement=proposal['totalAdmissionRequirementBytes']
    reasons=[]
    if available<requirement:reasons.append('Available estimate below proposed 6.5 GiB threshold')
    if pressure!=1:reasons.append('Pressure non-normal or unknown')
    if native['thermal_state'] not in [0,1]:reasons.append('Thermal unsafe or unknown')
    if swap!=0:reasons.append('Nonzero swap; proposed initial baseline requires zero')
    result={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),
      'status':'INFORMATIONAL_BELOW_PROPOSED_ADMISSION' if reasons else 'INFORMATIONAL_MEETS_PROPOSED_ADMISSION',
      'reasons':reasons,'availableEstimateBytes':available,'wiredBytes':page*counts['Pages wired down'],
      'compressorBytes':page*counts['Pages occupied by compressor'],'swapUsedBytes':swap,'pressure':pressure,
      'thermal':native['thermal_state'],'power':run(['/usr/bin/pmset','-g','batt']),
      'physicalMemoryBytes':int(run(['/usr/sbin/sysctl','-n','hw.memsize'])),
      'probePhysicalFootprintBytes':native['phys_footprint'],'probeResidentBytes':native['resident_size'],
      'proposedAdmissionBytes':requirement,'shortfallBytes':max(0,requirement-available),
      'availableMethod':'free + inactive + speculative; estimate, not guaranteed allocatable; no correction/subtraction for probe footprint',
      'compressionInterpretation':'One fresh baseline only; not growth or stability measurement.',
      'elapsedSeconds':time.monotonic()-started,'modelLoads':0,'generations':0,'admissionAdopted':False,
      'modules':sorted(sys.modules)}
    c.save('host-resource-snapshot.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='modules'},indent=2))

if __name__=='__main__':main()

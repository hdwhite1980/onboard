"""Network-denied tokenizer/config/runtime checks. Weight opens and model loads blocked."""
import ast
import base64
import errno
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c

def main():
    assert json.loads((c.E/'runtime-identity.json').read_text())['status']=='PASS'
    assert json.loads((c.E/'artifact-verification.json').read_text())['status']=='PASS'
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',TOKENIZERS_PARALLELISM='false')
    try:
        with socket.socket() as s:
            s.settimeout(1);s.connect(('127.0.0.1',9))
    except OSError as e:
        assert e.errno in [errno.EPERM,errno.EACCES], 'Network boundary not established'
        network_errno=e.errno
    else:raise AssertionError('Network boundary failed')
    attempted=[]
    def audit(event,args):
        if event=='open' and isinstance(args[0],(str,bytes)) and str(args[0]).endswith(('.safetensors','.bin','.gguf')):
            attempted.append(str(args[0]));raise RuntimeError('WEIGHT_ACCESS_PROHIBITED')
        if event in ['socket.connect','socket.getaddrinfo','socket.sendto','socket.sendmsg','subprocess.Popen','os.system']:
            raise RuntimeError('Unexpected operation: '+event)
    sys.addaudithook(audit)
    import huggingface_hub
    def forbidden(*args,**kwargs):raise RuntimeError('MODEL_LOAD_OR_DOWNLOAD_PROHIBITED')
    huggingface_hub.snapshot_download=forbidden;huggingface_hub.hf_hub_download=forbidden
    import mlx.core as mx
    mx.load=forbidden
    initial_runtime_active=mx.get_active_memory()
    import mlx_lm
    import mlx_lm.utils as utils
    mlx_lm.load=forbidden;utils.load=forbidden;utils.load_model=forbidden
    cfg=json.loads((c.QUARANTINE/'config.json').read_text())
    model_class,args_class=utils._get_classes(cfg)
    assert model_class.__module__=='mlx_lm.models.granitemoehybrid'
    model_class.__init__=forbidden
    imported_runtime_active=mx.get_active_memory()
    args=args_class.from_dict(cfg)
    assert args.num_hidden_layers==40 and not args.use_moe
    assert args.position_embedding_type=='nope'
    # Never instantiate Model, any layer, embedding, or Linear. Only empty cache containers.
    from mlx_lm.models.cache import KVCache,ArraysCache
    caches=[ArraysCache(size=2),KVCache()]
    import mlx_lm.models.granitemoehybrid as architecture
    import mlx_lm.models.ssm as ssm
    assert callable(architecture.GraniteMoeHybridAttention) and callable(ssm.ssm_update)
    assert mx.metal.is_available() and ssm._ssm_kernel is not None
    from transformers import AutoTokenizer
    from tokenizers import Tokenizer
    from mlx_lm.tokenizer_utils import load as load_tokenizer
    tok=AutoTokenizer.from_pretrained(str(c.QUARANTINE),local_files_only=True,trust_remote_code=False)
    backend=Tokenizer.from_file(str(c.QUARANTINE/'tokenizer.json'))
    wrapper=load_tokenizer(c.QUARANTINE,tokenizer_config_extra={'local_files_only':True,'trust_remote_code':False},eos_token_ids=cfg['eos_token_id'])
    assert type(tok).__name__=='TokenizersBackend',type(tok).__name__
    template=(c.QUARANTINE/'chat_template.jinja').read_text()
    assert tok.chat_template==wrapper.chat_template==template
    assert tok.eos_token_id==100257 and tok.pad_token_id==100256
    assert wrapper.eos_token_ids=={100257} and tok.pad_token_id not in wrapper.eos_token_ids
    definitions=json.loads((c.QUARANTINE/'tokenizer.json').read_text())['added_tokens']
    specials=[]
    for t in definitions:
        assert tok.convert_tokens_to_ids(t['content'])==t['id']
        ids=tok.encode(t['content'],add_special_tokens=False)
        assert ids==[t['id']], (t['content'],ids)
        specials.append({'token':t['content'],'id':t['id'],'encodedIDs':ids,'specialFlag':t['special']})
    assert tok.convert_tokens_to_ids('<|start_of_role|>')==100264
    assert tok.convert_tokens_to_ids('<|end_of_role|>')==100265
    # Independent, small byte-BPE oracle using the retained official regex/rank recipe.
    tree=ast.parse((c.RESEARCH/'sources/tiktoken-openai_public.py').read_text())
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='cl100k_base')
    ret=next(n for n in fn.body if isinstance(n,ast.Return)).value
    pattern=next(ast.literal_eval(v) for k,v in zip(ret.keys,ret.values) if isinstance(k,ast.Constant) and k.value=='pat_str')
    import regex
    ranks={base64.b64decode(t):int(v) for t,v in (line.split() for line in (c.RESEARCH/'sources/cl100k_base.tiktoken').read_bytes().splitlines())}
    def oracle(text):
        output=[]
        for piece in regex.findall(pattern,text):
            data=piece.encode('utf-8')
            if data in ranks:output.append(ranks[data]);continue
            parts=[bytes([b]) for b in data]
            while len(parts)>1:
                candidates=[(ranks.get(parts[i]+parts[i+1],10**20),i) for i in range(len(parts)-1)]
                rank,i=min(candidates)
                if rank==10**20:break
                parts[i:i+2]=[parts[i]+parts[i+1]]
            output.extend(ranks[p] for p in parts)
        return output
    samples=['2023','650841823','ISO 9001:2015','October 3','2026-10-03','09/23/2026',
       '$4.7 million','$91,000','82%','0.05%','Version 3.2','v4.1.0','Project Falcon',
       'FALCON-2026-003','DOC-008','EMAIL-999','Sarah owns encryption; Don owns migration.',
       'not approved ≠ rejected','café\nRésumé: naïve','  00123\t42\n']
    cases=[]
    for text in samples:
        ids=tok.encode(text,add_special_tokens=False)
        assert ids==backend.encode(text,add_special_tokens=False).ids==wrapper.encode(text,add_special_tokens=False)==oracle(text),text
        assert tok.decode(ids,skip_special_tokens=False)==text,text
        cases.append({'text':text,'ids':ids,'allFourPathsEqual':True,'roundTrip':True})
    assert tok.encode('2023',add_special_tokens=False)==[2366,18]
    pad=tok(['short','a substantially longer sentence'],padding=True,add_special_tokens=False)
    assert any(0 in mask for mask in pad['attention_mask'])
    for ids,mask in zip(pad['input_ids'],pad['attention_mask']):
        assert all(i==100256 for i,m in zip(ids,mask) if m==0)
    def render(messages,**kw):
        prompt=tok.apply_chat_template(messages,tokenize=False,**kw)
        ids=tok.encode(prompt,add_special_tokens=False)
        assert ids==tok.apply_chat_template(messages,tokenize=True,return_dict=False,**kw)
        assert prompt==wrapper.apply_chat_template(messages,tokenize=False,**kw)
        return {'messages':messages,'arguments':kw,'prompt':prompt,'tokenIDs':ids,'promptTokens':len(ids)}
    basic=render([{'role':'system','content':'Preserve facts.'},{'role':'user','content':'Hello.'}],add_generation_prompt=True,tools=None)
    assert basic['prompt']=='<|start_of_role|>system<|end_of_role|>Preserve facts.<|end_of_text|>\n<|start_of_role|>user<|end_of_role|>Hello.<|end_of_text|>\n<|start_of_role|>assistant<|end_of_role|>'
    no_system=render([{'role':'user','content':'Hello.'}],add_generation_prompt=True)
    assert no_system['prompt'].startswith('<|start_of_role|>user') and 'system<|end_of_role|>' not in no_system['prompt']
    history=render([{'role':'user','content':'One'},{'role':'assistant','content':'Two'},{'role':'user','content':'Three'}],add_generation_prompt=False)
    assert history['prompt'].endswith('Three<|end_of_text|>\n')
    docs=render([{'role':'system','content':'Use sources.'},{'role':'user','content':'Date?'}],documents=[{'id':'DOC-008','text':'Deployment October 3.'}],add_generation_prompt=True)
    assert '<documents>' in docs['prompt'] and 'DOC-008' in docs['prompt']
    tools=render([{'role':'user','content':'Example only.'}],tools=[{'type':'function','function':{'name':'synthetic_no_execution','description':'Formatting only','parameters':{'type':'object','properties':{}}}}],add_generation_prompt=True)
    assert '<tools>' in tools['prompt'] and 'synthetic_no_execution' in tools['prompt']
    tool_history=render([{'role':'user','content':'Example'}, {'role':'assistant','content':'','tool_calls':[{'function':{'name':'synthetic_no_execution','arguments':{'x':1}}}]},{'role':'tool','content':'Synthetic result'}],add_generation_prompt=True)
    assert '<tool_call>' in tool_history['prompt'] and '<tool_response>' in tool_history['prompt']
    # Copy exact frozen C2 quality request; no rewrite of substantive instructions.
    frozen=c.ROOT/'docs/sprint3a/evidence/candidate2-quality-01/source-v1/product/local_ai/quality/fixtures.py'
    import importlib.util
    spec=importlib.util.spec_from_file_location('frozen_c2_fixtures',frozen)
    fixtures=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixtures)
    first=fixtures.basic()[0];assert first['id']=='professional-1'
    planned=render(first['messages'],add_generation_prompt=True,tools=None)
    assert planned['promptTokens']+128<=512
    planned.update(fixtureID=first['id'],source=str(frozen.relative_to(c.ROOT)),fixtureSourceSHA256=c.sha(frozen),
       maxOutputTokens=128,maxTotalTokens=512,tools='NONE',sampler='greedy argmax',prefillStepSize=128,
       templateSHA256=c.sha(c.QUARANTINE/'chat_template.jinja'),executed=False)
    corpus=[]
    for case in fixtures.basic()+fixtures.attacks():
        rendered=render(case['messages'],add_generation_prompt=True,tools=None)
        corpus.append({'id':case['id'],'messages':case['messages'],'promptTokens':rendered['promptTokens'],
           'maxNewTokens':128,'accountedTokens':rendered['promptTokens']+128,'fits512':rendered['promptTokens']+128<=512})
    assert not attempted, 'No weight access allowed'
    assert mx.get_active_memory()==imported_runtime_active, 'Unexpected allocation after runtime imports'
    assert not any('foundationmodels' in x.lower() for x in sys.modules)
    result={'status':'PASS','networkNegativeControlErrno':network_errno,'weightFileOpenAttempts':attempted,
      'remoteCode':False,'localFilesOnly':True,'resolvedModelClass':model_class.__module__+'.'+model_class.__name__,
      'argsClass':args_class.__module__+'.'+args_class.__name__,'parsedArgs':vars(args),'modelInstantiated':False,
      'cacheClasses':[type(x).__name__ for x in caches],'stateSpaceCallable':True,'metalKernelAvailable':True,
      'attentionClassAvailable':True,'metalAvailable':True,'mlxActiveBytes':mx.get_active_memory(),
      'mlxActiveBeforeRuntimeImports':initial_runtime_active,'mlxActiveAfterRuntimeImports':imported_runtime_active,
      'allocationNote':'Installed runtime imports can create constant arrays; no Model/layer was constructed. Model constructor and weight loaders are blocked.',
      'tokenizerClass':type(tok).__name__,'eosTokenIDs':sorted(wrapper.eos_token_ids),'padTokenID':tok.pad_token_id,
      'specialTokenTests':specials,'ordinaryCases':cases,'paddingTest':dict(pad),
      'templates':{'explicitSystem':basic,'noSystem':no_system,'history':history,'documents':docs,'toolsFormattingOnly':tools,'toolHistoryFormattingOnly':tool_history},
      'templateSHA256':c.sha(c.QUARANTINE/'chat_template.jinja'),'modelLoads':0,'generations':0,'toolExecutions':0,
      'runtimeModulePaths':{x:str(sys.modules[x].__file__) for x in ['mlx_lm.models.granitemoehybrid','mlx_lm.models.ssm','mlx_lm.models.cache']}}
    c.save('tokenizer-runtime-check.json',result)
    c.save('future-first-prompt.json',planned)
    c.save('future-corpus-token-budgets.json',corpus)
    print(json.dumps({'status':'PASS','ordinaryCases':len(cases),'addedTokens':len(specials),'firstPromptTokens':planned['promptTokens'],
       'maxCorpusAccountedTokens':max(x['accountedTokens'] for x in corpus),'modelLoads':0,'mlxActiveBytes':mx.get_active_memory()}))

if __name__=='__main__':main()

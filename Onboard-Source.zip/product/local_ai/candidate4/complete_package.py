"""Finish the already-created package after fail-closed metadata-stability recheck."""
import json
from pathlib import Path
import common as c

def main():
    recheck=json.loads((c.E/'package-recheck.json').read_text());assert recheck['status']=='PASS'
    identity='2ac1559f0e7d0e8848242f5db55226b23715ca9a8b12968242065b01965b3547'
    store=c.BASE/'.artifacts/store'/identity
    assert str(store)==recheck['store']
    verified=c.verify_package(store,identity,recheck['verification']['rootIdentity'])
    manifest=json.loads((store/'manifest.json').read_text())
    assert manifest['repository']==c.REPO and manifest['revision']==c.REV
    assert manifest['state']=='EXPERIMENTAL' and manifest['qualifiedTasks']==[]
    originals={r['path']:r for r in json.loads((c.E/'acquisition.json').read_text())['files']}
    for row in manifest['files']:
        if row['path'] in originals:
            assert row['sha256']==originals[row['path']]['sha256'] and row['bytes']==originals[row['path']]['bytes']
    c.save('package.json',{'manifestSHA256':identity,'store':str(store),'manifest':manifest,
      'verification':verified,'packageLogicalBytes':sum(r['bytes'] for r in manifest['files'])+(store/'manifest.json').stat().st_size,
      'activated':False,'modelLoads':0,'qualifiedTasks':[]})
    destination=c.BASE/'.artifacts/activation/candidate4-granite-01';assert not destination.exists()
    c.save('activation-plan.json',{'status':'PREPARED_NOT_EXECUTED','source':str(store),'destination':str(destination),
      'manifestSHA256':identity,'sourceRootIdentity':verified['rootIdentity'],
      'steps':['Require separate inference authorization and fresh admission','Verify trusted manifest and source identities','Create private new snapshot from allowlisted files; no links','Verify destination hashes and one-link regular files','Make files/directories read-only','Reverify in network-denied worker immediately before eager load'],
      'residual':'Same UID can change permissions/parents and replace bytes after verification. MLX-LM reopens paths; this is not a privileged or immutable production boundary.',
      'prototypeLimits':'Content-addressed experimental manifest is not a production signature, assignment, revocation or rollback-protection system.'})
    print(json.dumps({'status':'PACKAGED_NOT_ACTIVATED','manifestSHA256':identity,'files':len(manifest['files'])}))

if __name__=='__main__':main()

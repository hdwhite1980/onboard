"""Exercise verifier against synthetic file attacks only. No real model activation."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import common as c

def main():
    base=c.E/'security-fixtures';base.mkdir(mode=0o700,exist_ok=False)
    def setup(name):
        root=base/name;root.mkdir(mode=0o700)
        rows=[]
        for file in ['model.safetensors','config.json','tokenizer.json','chat_template.jinja']:
            p=root/file;p.write_text('SYNTHETIC verifier fixture: '+file)
            rows.append({'path':file,'bytes':p.stat().st_size,'sha256':c.sha(p)})
        raw=json.dumps({'files':rows},sort_keys=True).encode();(root/'manifest.json').write_bytes(raw)
        return root,hashlib.sha256(raw).hexdigest()
    results=[]
    root,identity=setup('control');control=c.verify_package(root,identity)
    results.append({'case':'unmodified control','result':'ACCEPT'})
    for name in ['path-replacement','symlink','hardlink','in-place','config','tokenizer','template','unexpected-file','traversal','executable','manifest-substitution']:
        root,identity=setup(name);anchor=[root.stat().st_dev,root.stat().st_ino]
        if name=='path-replacement':
            prior=base/(name+'-original');root.rename(prior);shutil.copytree(prior,root)
        elif name=='symlink':
            p=root/'model.safetensors';p.unlink();p.symlink_to(base/'control/model.safetensors')
        elif name=='hardlink':
            p=root/'model.safetensors';p.unlink();os.link(base/'control/model.safetensors',p)
        elif name=='in-place':
            p=root/'model.safetensors'
            with p.open('r+b') as f:f.write(b'X')
        elif name in ['config','tokenizer','template']:
            target={'config':'config.json','tokenizer':'tokenizer.json','template':'chat_template.jinja'}[name]
            p=root/target;p.unlink();p.write_text('SUBSTITUTED')
        elif name=='unexpected-file':(root/'payload.py').write_text('not executed')
        elif name=='executable':(root/'config.json').chmod(0o700)
        elif name=='manifest-substitution':(root/'manifest.json').write_text('{}')
        elif name=='traversal':
            raw=json.dumps({'files':[{'path':'../control/config.json','bytes':0,'sha256':'0'*64}]}).encode()
            (root/'manifest.json').write_bytes(raw);identity=hashlib.sha256(raw).hexdigest()
        try:c.verify_package(root,identity,anchor)
        except (AssertionError,OSError,ValueError) as e:results.append({'case':name,'result':'REJECT','reason':str(e)})
        else:raise AssertionError('Attack not rejected: '+name)
    # Evidence retains summaries/hashes only, not unsafe fixture links/executable bits.
    shutil.rmtree(base)
    c.save('activation-security.json',{'status':'PASS','syntheticCases':results,
      'realModelActivationExecuted':False,'residualSameUserPathRace':True,
      'scope':'Snapshot-time checks. Does not prove prevention of all concurrent same-UID races.'})
    print(json.dumps({'status':'PASS','controlAccepted':1,'attacksRejected':len(results)-1,'realModelActivationExecuted':False}))

if __name__=='__main__':main()

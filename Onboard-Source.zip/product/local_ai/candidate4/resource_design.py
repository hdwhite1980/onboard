"""Granite-specific estimated component budget; proposal only, no admission/load."""
import json
import math
import common as c

def main():
    MiB=1024**2;GiB=1024**3
    cfg=json.loads((c.QUARANTINE/'config.json').read_text())
    components=[
      ('quantized_weight_file',1796848117,'Exact verified file bytes; payload includes affine scales/biases.'),
      ('runtime_model_overhead',384*MiB,'Planning estimate for model graph/metadata, tokenizer, floating parameter conversion and loading overlap; not measured.'),
      ('attention_kv',2*4*8*64*512*2,'Calculated FP16 K/V, batch 1, four attention layers, 512 allocated token slots.'),
      ('mamba_recurrent_state',36*64*64*128*4,'Calculated FP32 recurrent state. Preserve native stable state precision, not blanket FP16.'),
      ('convolution_state',36*(4-1)*(64*64+2*1*128)*2,'Calculated FP16 convolution history: 36 layers, three slots, 4352 channels.'),
      ('prefill_temporaries',512*MiB,'Planning allowance for chunked prefill, projections, attention/SSM temporaries; prefill_step_size=128. Not measured.'),
      ('allocator_cache',384*MiB,'Planning allowance for allocator retention/fragmentation and Metal resources; not a new runtime cache-limit setting.'),
      ('python_native_worker',256*MiB,'Planning allowance for interpreter/native libraries/thread stacks; separate from model data. Not a measured worker peak.'),
      ('uncertainty_margin',1024*MiB,'Explicit 1 GiB uncertainty for first hybrid load and allocations not predicted by disk size.')]
    total=sum(x[1] for x in components);working=math.ceil(total/(512*MiB))*512*MiB
    assert working==int(4.5*GiB)
    proposal={'status':'PROPOSED_NOT_ADOPTED','name':'GRANITE_INITIAL_WORKING_ALLOWANCE',
      'components':[{'component':n,'bytes':v,'MiB':v/MiB,'basis':why} for n,v,why in components],
      'componentTotalBytes':total,'componentTotalGiB':total/GiB,
      'roundingMarginBytes':working-total,'workingAllowanceBytes':working,'workingAllowanceGiB':working/GiB,
      'protectedReserveBytes':2*GiB,'totalAdmissionRequirementBytes':working+2*GiB,'totalAdmissionRequirementGiB':6.5,
      'profile':{'batch':1,'totalTokens':512,'maxOutputTokens':128,'tools':[],'thinking':'No mandatory thinking mode','prefillStepSize':128,'attentionKV':'FP16','recurrentState':'FP32 expected from native state-space implementation'},
      'limitations':['Not a measured peak or guaranteed working set','Not copied from C1/C2 allowances','C1 incomplete-load peaks are lower bounds','C2 measured dense-model fit cannot establish Granite hybrid fit','No allowance or runtime policy adopted','Allocation/cache bookkeeping may overlap; estimates intentionally conservative'],
      'futureStops':{'availableEstimateAtOrBelowBytes':int(2.25*GiB),'compressorGrowthAtOrAboveBytes':512*MiB,'anySwapGrowth':True,'initialSwapMustBeZero':True,'pressureRequired':1,'thermalAllowed':[0,1],'sampleIntervalSeconds':0.25,'monitorStaleSeconds':1.5,'wallTimeoutSeconds':180,'modelLoads':1,'generationRequests':1},
      'modelLoads':0,'generations':0}
    c.save('resource-proposal.json',proposal)
    print(json.dumps({'status':proposal['status'],'componentTotalGiB':total/GiB,'workingGiB':4.5,'admissionGiB':6.5}))

if __name__=='__main__':main()

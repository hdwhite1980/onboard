"""Verify retained interpreter and complete installed wheel inventory; no AI imports."""
import base64
import csv
import importlib.metadata
import io
import json
import platform
import sys
import zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c

def main():
    prior=c.ROOT/'docs/sprint3a/evidence/calibration-01'
    interp=json.loads((prior/'interpreter.json').read_text())
    assert Path(sys.executable).resolve()==Path(interp['executable']).resolve()
    assert c.sha(Path(sys.executable).resolve())==interp['sha256']
    assert platform.python_version()==interp['version']=='3.12.14'
    assert platform.machine()==interp['architecture']=='arm64'
    identity=json.loads((prior/'runtime-identity.json').read_text())
    assert c.sha(c.BASE/'runtime/requirements.lock')==identity['wheelLockSHA256']
    assert c.sha(c.BASE/'runtime/SBOM.json')==identity['SBOMSHA256']
    checked=[]
    for comp in json.loads((c.BASE/'runtime/SBOM.json').read_text())['components']:
        wheel=c.BASE/'.artifacts/runtime/wheelhouse'/comp['wheel'];assert c.sha(wheel)==comp['sha256']
        dist=importlib.metadata.distribution(comp['package']);assert dist.version==comp['version']
        count=0
        with zipfile.ZipFile(wheel) as z:
            for f in z.infolist():
                if f.is_dir() or f.filename.endswith('.dist-info/RECORD'):continue
                assert '.data/' not in f.filename
                p=Path(dist.locate_file(f.filename));assert p.is_file() and not p.is_symlink()
                assert c.sha(p)==__import__('hashlib').sha256(z.read(f)).hexdigest(),p
                count+=1
        for path,digest,size in csv.reader(io.StringIO(dist.read_text('RECORD'))):
            if not digest:continue
            algo,value=digest.split('=',1);assert algo=='sha256'
            p=Path(dist.locate_file(path))
            assert base64.urlsafe_b64encode(bytes.fromhex(c.sha(p))).decode().rstrip('=')==value
            if size:assert p.stat().st_size==int(size)
        checked.append({'package':comp['package'],'version':comp['version'],'installedWheelFiles':count,'wheelSHA256':comp['sha256']})
    expected={x['package'].lower().replace('_','-') for x in checked}|{'pip'}
    installed={d.metadata['Name'].lower().replace('_','-') for d in importlib.metadata.distributions()}
    assert installed==expected
    probe=c.BASE/'.artifacts/build/resource-probe'
    tested=json.loads((prior/'tested-source.json').read_text())
    for item in tested['files']:assert c.sha(c.ROOT/item['path'])==item['sha256'],item['path']
    c.save('runtime-identity.json',{'status':'PASS','interpreter':interp,'packages':checked,
       'lockSHA256':identity['wheelLockSHA256'],'sbomSHA256':identity['SBOMSHA256'],
       'retainedCalibrationSourcesUnchanged':True,'probeSHA256':c.sha(probe),'modelLoads':0,'runtimeChanges':False})
    print(json.dumps({'status':'PASS','packages':len(checked),'installedWheelFiles':sum(x['installedWheelFiles'] for x in checked),'modelLoads':0}))

if __name__=='__main__':main()

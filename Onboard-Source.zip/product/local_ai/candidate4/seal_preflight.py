"""Preserve prior evidence and seal preflight reports. No model/runtime imports."""
import datetime
import json
from pathlib import Path
import common as c

def record(p):
    return {'path':str(p.relative_to(c.ROOT)),'bytes':p.stat().st_size,'sha256':c.sha(p)}

def main():
    aliases={
      'docs/sprint3a/CANDIDATE3_PUBLISHER_CLARIFICATION_DRAFT.md':c.RESEARCH/'candidate3-draft-before.md',
      'docs/sprint3a/LOCAL_MODEL_COMPARISON.md':c.E/'local-model-comparison-before.md'}
    frozen=[]
    for name in ['calibration-01','candidate2-01','candidate2-clean-01','candidate2-calibration-01',
                 'candidate2-quality-01','candidate3-tokenizer-provenance-01','candidate4-research-01']:
        manifest=c.ROOT/'docs/sprint3a/evidence'/name/'EVIDENCE_MANIFEST.json'
        old=json.loads(manifest.read_text());mapped=[]
        for row in old['files']:
            path=c.ROOT/row['path']
            if name=='candidate3-tokenizer-provenance-01' and row['path'].endswith('CANDIDATE3_PUBLISHER_CLARIFICATION_DRAFT.md'):
                path=aliases[row['path']]
            if name=='candidate4-research-01' and row['path'].endswith('LOCAL_MODEL_COMPARISON.md'):
                path=aliases[row['path']]
            assert c.sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],path
            if path!=c.ROOT/row['path']:mapped.append({'oldPath':row['path'],'exactArchivedBytes':str(path.relative_to(c.ROOT))})
        frozen.append(dict(**record(manifest),referencesVerified=len(old['files']),archivedSupersessions=mapped))
    c.save('preservation-check.json',{'status':'PASS','manifests':frozen,
       'referencesVerified':sum(x['referencesVerified'] for x in frozen),'candidate1And2Reruns':0,
       'note':'All old manifests unchanged. Prior explicitly superseded C3 draft and newly superseded comparison resolve to byte-identical archives. Other historical references unchanged.'})
    package=json.loads((c.E/'package.json').read_text());snapshot=json.loads((c.E/'host-resource-snapshot.json').read_text())
    c.save('preflight-result.json',{'decision':'READY_FOR_BOUNDED_INFERENCE_AUTHORIZATION',
       'manifestSHA256':package['manifestSHA256'],'repository':c.REPO,'revision':c.REV,
       'lifecycle':'EXPERIMENTAL','qualifiedTasks':[],'tokenizerLicense':c.TOKENIZER_LICENSE,
       'workingAllowanceGiBProposed':4.5,'totalAdmissionGiBProposed':6.5,'proposalAdopted':False,
       'hostSnapshotStatus':snapshot['status'],'availableEstimateBytes':snapshot['availableEstimateBytes'],
       'shortfallBytes':snapshot['shortfallBytes'],'activated':False,'modelLoads':0,'generationRequests':0,
       'dependenciesChanged':False,'candidate3Status':'LICENSE_PROVENANCE_HOLD','publisherClarificationSent':False,
       'ownerReview':['Proposed resource allowance and conditional one-load/one-request run','Same-user activation race','Disclosed source index-count discrepancy'],
       'stop':'Preflight complete. No inference authorized or performed.'})
    docs=[c.ROOT/'docs/sprint3a'/n for n in ['CANDIDATE4_GRANITE_PREFLIGHT.md','CANDIDATE4_GRANITE_LICENSE_PACKAGE.md','CANDIDATE4_GRANITE_RESOURCE_PLAN.md','LOCAL_MODEL_COMPARISON.md']]
    code=list((c.BASE/'candidate4').glob('*.py'))
    files=sorted({p for p in c.E.rglob('*') if p.is_file() and p.name!='EVIDENCE_MANIFEST.json'}|set(docs)|set(code))
    c.save('EVIDENCE_MANIFEST.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'scope':'Candidate4 exact Granite acquisition, package, tokenizer-only and no-load runtime preflight; excludes manifest itself.',
       'files':[record(p) for p in files],
       'externalPackageReference':{'store':package['store'],'manifestSHA256':package['manifestSHA256'],
           'files':package['manifest']['files'],'verificationEvidence':'package.json; no inference activation'},
       'quarantineReference':str(c.QUARANTINE)})
    print(json.dumps({'status':'SEALED','files':len(files),'historicalReferencesVerified':sum(x['referencesVerified'] for x in frozen),
       'manifestSHA256':c.sha(c.E/'EVIDENCE_MANIFEST.json')}))

if __name__=='__main__':main()

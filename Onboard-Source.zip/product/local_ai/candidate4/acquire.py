"""Acquire ONLY the owner-approved Granite revision into quarantine; never activate/load."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import common as c

def main():
    api_path=c.RESEARCH/'sources/mlx-community__granite-4.0-h-micro-4bit.api.json'
    api=json.loads(api_path.read_text())
    assert api['id']==c.REPO and api['sha']==c.REV
    rows=api['siblings']
    assert {r['rfilename'] for r in rows}==c.FILES and len(rows)==len(c.FILES)
    assert sum(r['size'] for r in rows)==1806622893
    weight=next(r for r in rows if r['rfilename']=='model.safetensors')
    assert weight['size']==1796848117 and weight['lfs']['sha256']==c.WEIGHT_SHA
    assert shutil.disk_usage(c.BASE).free>6*1024**3
    c.QUARANTINE.mkdir(parents=True,exist_ok=False,mode=0o700)
    fd=c.secure_root(c.QUARANTINE);os.close(fd)
    c.save('acquisition-start.json',{'repository':c.REPO,'revision':c.REV,
      'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'metadataSHA256':c.sha(api_path),'quarantine':str(c.QUARANTINE),'modelLoads':0,'activated':False})
    records=[]
    for row in rows:
        name=row['rfilename'];assert c.safe_parts(name)==(name,)
        p=c.QUARANTINE/name;assert not p.exists()
        url=f'https://huggingface.co/{c.REPO}/resolve/{c.REV}/{name}'
        result=subprocess.run(['curl','--fail','--location','--silent','--show-error',
           '--proto','=https','--proto-redir','=https','--connect-timeout','30','--max-time','900',url,'-o',str(p)],capture_output=True,text=True)
        assert result.returncode==0, f'{name}: {result.stderr}'
        fd=c.secure_root(c.QUARANTINE)
        try: got=c.file_record(fd,name)
        finally:os.close(fd)
        assert got['bytes']==row['size'],name
        if 'lfs' in row: assert got['sha256']==row['lfs']['sha256'],name
        else:
            raw=p.read_bytes()
            assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['blobId'],name
        research=c.RESEARCH/'sources/mlx-community__granite-4.0-h-micro-4bit'/name
        if research.exists():assert got['sha256']==c.sha(research),name
        p.chmod(0o400)
        got.update(publisher='mlx-community',source=url,revision=c.REV,gitBlobID=row['blobId'],
            publisherHash=row.get('lfs',{}).get('sha256',row['blobId']),
            publisherHashType='LFS_SHA256' if 'lfs' in row else 'GIT_BLOB_SHA1',
            purpose='Quantized model data; NOT loaded' if name=='model.safetensors' else 'Pinned model/tokenizer/configuration or provenance data')
        records.append(got)
        c.save('acquired-'+name.replace('.','_')+'.json',got)
        print('VERIFIED',name,got['bytes'],flush=True)
    assert {p.name for p in c.QUARANTINE.iterdir()}==c.FILES
    c.save('acquisition.json',{'status':'VERIFIED_QUARANTINE','repository':c.REPO,'revision':c.REV,
      'quarantine':str(c.QUARANTINE),'repositoryBytes':sum(r['bytes'] for r in records),
      'files':records,'activated':False,'modelLoads':0,'generations':0})
    print('QUARANTINE_COMPLETE',flush=True)

if __name__=='__main__': main()

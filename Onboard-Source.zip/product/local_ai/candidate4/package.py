"""Build a verified experimental store package. No activation or model loading."""
import json
import hashlib
import os
from pathlib import Path
import shutil
import common as c

def main():
    for name in ['artifact-verification.json','runtime-identity.json','tokenizer-runtime-check.json']:
        assert json.loads((c.E/name).read_text())['status']=='PASS',name
    acquisition=json.loads((c.E/'acquisition.json').read_text())
    stage=c.BASE/'.artifacts/packaging/candidate4-granite-01'
    stage.mkdir(parents=True,exist_ok=False,mode=0o700)
    rows=[]
    for row in acquisition['files']:
        source=c.QUARANTINE/row['path'];assert not source.is_symlink() and source.stat().st_nlink==1
        target=stage/row['path'];shutil.copyfile(source,target);target.chmod(0o400)
        assert c.sha(target)==row['sha256']
        rows.append({k:v for k,v in row.items() if k!='identity'})
    licenses=stage/'licenses';licenses.mkdir(mode=0o700)
    texts=[('IBM-Apache-2.0.txt','granite4-source-LICENSE','https://github.com/ibm-granite/granite-4.0-language-models/blob/de23701d1627c767cfc91a0ccfa360a5b247dde2/LICENSE'),
      ('OpenAI-tiktoken-MIT.txt','tiktoken-LICENSE','https://github.com/openai/tiktoken/blob/4e71bbe0c078468e00fefbf94b39849389f346e5/LICENSE')]
    for name,src,url in texts:
        p=licenses/name;shutil.copyfile(c.RESEARCH/'sources'/src,p)
        rows.append({'path':'licenses/'+name,'bytes':p.stat().st_size,'sha256':c.sha(p),'source':url,
                     'publisher':'IBM' if name.startswith('IBM') else 'OpenAI','purpose':'Preserved license/attribution text'})
    notice={'label':'TECHNICAL LICENSE INVENTORY — EXPERIMENTAL EVALUATION ONLY',
      'modelPublisher':'IBM','modelLicense':'Apache-2.0','upstream':c.UPSTREAM,'upstreamRevision':c.UPREV,
      'conversionPublisher':'mlx-community','conversionLicenseDeclaration':'Apache-2.0','repository':c.REPO,'revision':c.REV,
      'tokenizerLicense':c.TOKENIZER_LICENSE,'tokenizerSpecificLicenseConfirmed':False,
      'origin':'All 100256 ordinary byte/rank entries match official cl100k_base; 96 IBM-distributed added-token definitions match pinned upstream.',
      'ownerAcceptanceSHA256':c.sha(c.E/'owner-authorization.txt'),
      'conversionProvenance':'Publisher reports MLX-LM 0.28.2; exact input weight commit and reproducible command not attested.',
      'notices':'IBM model repository contains no standalone NOTICE/LICENSE; official Granite4 Apache text and OpenAI tiktoken MIT notice preserved separately.',
      'modifications':'No model/tokenizer/config/template bytes changed. Organization manifest and this attribution inventory added.',
      'limits':['Not production redistribution approval','Not final legal clearance','Not CUI or government procurement/accreditation approval','No training-data indemnification']}
    p=licenses/'inventory.json';p.write_text(json.dumps(notice,indent=2)+'\n')
    rows.append({'path':'licenses/inventory.json','bytes':p.stat().st_size,'sha256':c.sha(p),'source':'Organization technical inventory','publisher':'Organization','purpose':'Experimental provenance and owner acceptance limits'})
    runtime=json.loads((c.E/'runtime-identity.json').read_text())
    artifact=json.loads((c.E/'artifact-verification.json').read_text())
    manifest={'format':'Organization experimental local-model manifest v1',
      'modelID':'org.experimental.granite-4.0-h-micro.mlx4-g64','state':'EXPERIMENTAL','qualifiedTasks':[],
      'repository':c.REPO,'revision':c.REV,'upstream':c.UPSTREAM,'upstreamRevision':c.UPREV,
      'publisher':'IBM','conversionPublisher':'mlx-community','conversionToolReported':'MLX-LM 0.28.2',
      'parameters':3191396096,'modelType':'granitemoehybrid','quantization':{'bits':4,'group_size':64,'mode':'affine'},
      'weightSHA256':c.WEIGHT_SHA,'templateSHA256':c.sha(stage/'chat_template.jinja'),
      'tokenizerLicense':c.TOKENIZER_LICENSE,'modelLicense':'Apache-2.0','runtimeSBOMSHA256':runtime['sbomSHA256'],
      'runtimeCompatibility':'TOKENIZER_AND_CLASS_RESOLUTION_VERIFIED; MODEL_LOAD_NOT_TESTED',
      'runtimeVersions':{x['package']:x['version'] for x in runtime['packages'] if x['package'] in ['mlx','mlx-metal','mlx-lm','transformers','tokenizers']},
      'hardwareTarget':'Apple M3 / arm64 / 16 GiB; resource profile unapproved',
      'remoteCodeRequired':False,'trustRemoteCode':False,'localFilesOnly':True,
      'sourceIndexParameterDiscrepancy':{'index':artifact['indexMetadata']['total_parameters'],'headerReconstructed':3191396096,
        'difference':3191396096-artifact['indexMetadata']['total_parameters'],'note':'Source metadata preserved; byte map and expected parameter count independently verified.'},
      'files':sorted(rows,key=lambda r:r['path'])}
    raw=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode();identity=hashlib.sha256(raw).hexdigest()
    (stage/'manifest.json').write_bytes(raw)
    for p in stage.rglob('*'):
        if p.is_file():p.chmod(0o400)
    c.verify_package(stage,identity)
    store=c.BASE/'.artifacts/store'/identity;assert not store.exists()
    os.rename(stage,store)
    for p in store.rglob('*'):
        if p.is_dir():p.chmod(0o500)
    store.chmod(0o500)
    verified=c.verify_package(store,identity)
    c.save('package.json',{'manifestSHA256':identity,'store':str(store),'manifest':manifest,
      'verification':verified,'packageLogicalBytes':sum(r['bytes'] for r in rows)+len(raw),
      'activated':False,'modelLoads':0,'qualifiedTasks':[]})
    destination=c.BASE/'.artifacts/activation/candidate4-granite-01';assert not destination.exists()
    c.save('activation-plan.json',{'status':'PREPARED_NOT_EXECUTED','source':str(store),'destination':str(destination),
      'manifestSHA256':identity,'sourceRootIdentity':verified['rootIdentity'],
      'steps':['Require separate inference authorization and fresh admission','Verify trusted manifest and source identities','Create private new snapshot from allowlisted files; no links','Verify destination hashes and one-link regular files','Make files/directories read-only','Reverify in network-denied worker immediately before eager load'],
      'residual':'Same UID can change permissions/parents and replace bytes after verification. MLX-LM reopens paths; this is not a privileged or immutable production boundary.',
      'prototypeLimits':'Content-addressed experimental manifest is not a production signature, assignment, revocation or rollback-protection system.'})
    print(json.dumps({'status':'PACKAGED_NOT_ACTIVATED','manifestSHA256':identity,'files':len(rows),'packageLogicalBytes':sum(r['bytes'] for r in rows)+len(raw)}))

if __name__=='__main__':main()

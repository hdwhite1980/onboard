"""Pure JSON/source/byte audit. No tokenizer/runtime imports, weight access, or inference."""
import ast,base64,hashlib,json,re,shutil,zipfile
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[3];E=ROOT/'docs/sprint3a/evidence/candidate5-preflight-01';OLD=ROOT/'docs/sprint3a/evidence/candidate4-research-01/sources';SITE=ROOT/'product/local_ai/.artifacts/runtime/venv/lib/python3.12/site-packages'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def save(name,obj):
 if (E/name).exists():
  assert read(E/name)==obj,'Existing research output mismatch';return
 with (E/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
def main():
 inventories=[]
 for kind in ('conversion','upstream'):
  data=read(E/(kind+'-api.json'));rows=[]
  for row in data['siblings']:
   file=E/'sources'/kind/row['rfilename'];isweight=row['rfilename'].endswith('.safetensors')
   if isweight:
    assert not file.exists();rows.append(dict(row,localAcquired=False));continue
   assert file.is_file() and not file.is_symlink();blob=file.read_bytes();assert len(blob)==row['size']
   if row.get('lfs'):assert sha(file)==row['lfs']['sha256']
   else:assert hashlib.sha1(b'blob '+str(len(blob)).encode()+b'\0'+blob).hexdigest()==row['blobId']
   rows.append(dict(row,localAcquired=True,sha256=sha(file)))
  inventories.append({'kind':kind,'repository':data['id'],'revision':data['sha'],'files':rows,'logicalRepositoryBytes':sum(r['size'] for r in rows),'publisherUsedStorage':data.get('usedStorage'),'note':'Logical file sum differs from Hub storage accounting. Weights not acquired.'})
 save('metadata-verification.json',inventories)
 c=E/'sources/conversion';u=E/'sources/upstream';ct=read(c/'tokenizer.json');ut=read(u/'tokenizer.json');uc=read(u/'tokenizer_config.json');cc=read(c/'tokenizer_config.json')
 cm=[x.split(' ') if isinstance(x,str) else x for x in ct['model']['merges']];um=[x.split(' ') if isinstance(x,str) else x for x in ut['model']['merges']]
 extra=[x for x in ct['added_tokens'] if x['id'] not in {t['id'] for t in ut['added_tokens']}]
 assert ct['model']['vocab']==ut['model']['vocab'] and cm==um
 assert all({k:v for k,v in x.items() if k!='id'}==uc['added_tokens_decoder'][str(x['id'])] for x in extra)
 # Pure byte/rank comparison against retained published OpenAI cl100k data.
 bs=list(range(ord('!'),ord('~')+1))+list(range(ord('¡'),ord('¬')+1))+list(range(ord('®'),ord('ÿ')+1));cs=bs[:];n=0
 for b in range(256):
  if b not in bs:bs.append(b);cs.append(256+n);n+=1
 inverse={chr(c):b for b,c in zip(bs,cs)}
 vocab={bytes(inverse[ch] for ch in token):rank for token,rank in ct['model']['vocab'].items()}
 base={base64.b64decode(line.split()[0]):int(line.split()[1]) for line in (OLD/'cl100k_base.tiktoken').read_text().splitlines()}
 prior_package=read(ROOT/'docs/sprint3a/evidence/candidate2-quality-01/package.json')
 prior=Path(prior_package['store'])/'tokenizer.json'
 assert sha(prior)==next(r['sha256'] for r in prior_package['manifest']['files'] if r['path']=='tokenizer.json')
 previous=read(prior)['model']['vocab']
 overlap={'cl100kBaseCount':len(base),'sharedTokenByteStrings':len(base.keys()&vocab.keys()),'sameByteAndRankPairs':sum(vocab.get(k)==rank for k,rank in base.items()),'fullByteRankEquality':base==vocab,'qwen3SourceSHA256':sha(prior),'qwen3BaseCount':len(previous),'qwen3SharedStrings':len(previous.keys()&ct['model']['vocab'].keys()),'qwen3SameStringAndID':sum(ct['model']['vocab'].get(k)==v for k,v in previous.items()),'caution':'Overlap establishes neither complete derivation nor a data-license grant; older Qwen family documentation is not a Qwen3.5 artifact lineage attestation.'}
 save('tokenizer-static-comparison.json',{'convertedSHA256':sha(c/'tokenizer.json'),'upstreamSHA256':sha(u/'tokenizer.json'),'baseVocabularyEntries':len(vocab),'merges':len(cm),'baseVocabularyEqual':True,'normalizedMergePairsEqual':True,'standaloneVocabMatchesUpstream':sha(c/'vocab.json')==sha(u/'vocab.json'),'templateEqual':sha(c/'chat_template.jinja')==sha(u/'chat_template.jinja'),'convertedAddedTokens':len(ct['added_tokens']),'upstreamAddedTokens':len(ut['added_tokens']),'extraTokensMatchingUpstreamConfig':extra,'otherTokenizerTopLevelDifferences':[k for k in ct.keys()|ut.keys() if k not in ('model','added_tokens') and ct.get(k)!=ut.get(k)],'tokenizerConfigChangedKeys':[k for k in cc.keys()|uc.keys() if cc.get(k)!=uc.get(k)],'cl100kAndPredecessorComparison':overlap,'runtimeTokenizationExecuted':False})
 save('special-token-definitions.json',{'converted':ct['added_tokens'],'upstreamConfig':uc['added_tokens_decoder']})
 cfg=read(c/'config.json');idx=read(c/'model.safetensors.index.json');uidx=read(u/'model.safetensors.index.json');text=cfg['text_config'];vision=cfg['vision_config'];keys=list(idx['weight_map'])
 parts={'embedding_tied_output':248320*2048,'dense_mlps':24*3*2048*6144,'linear_attention':18*(2048*6144+2048*2048+2*2048*16+2048*2048+4*6144+128+2*16),'full_attention':6*(2048*4096+2*2048*512+2048*2048+2*256),'text_norms':24*2*2048+2048}
 vision_parts={'blocks':24*(4*1024**2+4*1024+2*1024*4096+4096+1024+4*1024),'patch_embedding':3*2*16*16*1024+1024,'position_embedding':2304*1024,'merger':2*1024+4096**2+4096+4096*2048+2048}
 language=sum(parts.values());vit=sum(vision_parts.values());total=language+vit
 assert total==read(E/'conversion-api.json')['safetensors']['total']
 assert cfg['quantization']=={'bits':4,'group_size':64,'mode':'affine'}
 assert not any(k.startswith('vision_tower') and k.endswith(('.scales','.biases')) for k in keys)
 save('architecture-static.json',{'config':cfg,'convertedLogicalParameters':total,'languageLogicalParametersDerived':language,'visionLogicalParametersDerived':vit,'upstreamPublishedParameters':read(E/'upstream-api.json')['safetensors']['total'],'upstreamMTPParameterDifference':read(E/'upstream-api.json')['safetensors']['total']-total,'languageParameterTerms':parts,'visionParameterTerms':vision_parts,'convertedTensorCount':len(keys),'visionTensorCount':sum(k.startswith('vision_tower') for k in keys),'languageTensorCount':sum(k.startswith('language_model') for k in keys),'upstreamMTPKeys':[k for k in uidx['weight_map'] if k.startswith('mtp.')],'convertedMTPKeys':[k for k in keys if 'mtp.' in k],'convertedTensorDataBytes':idx['metadata']['total_size'],'estimatedVisionBF16Bytes':vit*2,'estimatedTextTensorBytes':idx['metadata']['total_size']-vit*2,'weightHeaderInspected':False,'derivationCaveat':'Counts reconcile configuration/installed source with publisher metadata. Tensor dtypes/shapes/bytes not locally weight-verified. Vision bytes infer BF16 from declared converter/default and absence of quantized vision keys.'})
 paths=['mlx_lm/utils.py','mlx_lm/tokenizer_utils.py','mlx_lm/models/qwen3_5.py','mlx_lm/models/qwen3_next.py','mlx_lm/models/gated_delta.py','mlx_lm/models/cache.py','transformers/models/auto/tokenization_auto.py','transformers/tokenization_utils_tokenizers.py','transformers/models/qwen3_5/modeling_qwen3_5.py','transformers/models/qwen3_5/tokenization_qwen3_5.py']
 runtime=[]
 for name in paths:
  path=SITE/name;wheel=next((ROOT/'product/local_ai/.artifacts/runtime/wheelhouse').glob(('mlx_lm-0.31.3-' if name.startswith('mlx_lm/') else 'transformers-5.17.0-')+'*.whl'))
  with zipfile.ZipFile(wheel) as z:assert z.read(name)==path.read_bytes()
  target=E/'runtime-source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
  ast.parse(path.read_text());runtime.append({'path':str(path.relative_to(ROOT)),'sha256':sha(path),'wheelSHA256':sha(wheel),'matchesRetainedWheel':True})
 versions={}
 for package in ('mlx','mlx_metal','mlx_lm','transformers','tokenizers'):
  info=next(SITE.glob(package+'-*.dist-info'));metadata=(info/'METADATA').read_text();versions[package]=re.search(r'^Version: (.+)$',metadata,re.M).group(1)
 save('runtime-static-integrity.json',{'sources':runtime,'versions':versions,'mlxVLMInstalled':bool(list(SITE.glob('mlx_vlm*'))),'runtimeImports':0,'runtimeChanges':0,'dynamicCompatibility':'NOT_TESTED','staticConclusion':'Installed MLX-LM qwen3_5 language-only path exists; no required new dependency identified. Full artifact mx.load occurs before vision filtering; zero transient vision mapping/allocation is not established.'})
 cache={'attentionKV_FP16_bytes':6*2*1*512*2*256*2,'linearRecurrentFP32_bytes':18*1*16*128*128*4,'linearConvolutionFP16_bytes':18*1*3*6144*2,'prefillAllLogitsFP16UpperScenario_bytes':1*128*248320*2}
 save('resource-hypothesis.json',{'status':'UNMEASURED','cacheFormulas':cache,'proposalWorkerCeilingBytes':4*1024**3,'proposedWorkingAdmissionBytes':6*1024**3,'protectedReserveBytes':2*1024**3,'earlyTriggerBytes':int(2.25*1024**3),'envelopeGiB':{'entirePublishedWeightFile':1722271785/1024**3,'processTokenizerRuntime':.5,'cacheRounded':.031,'prefillQuantizationTransientAllowance':.75,'allocatorCacheAllowance':.5,'unallocatedMarginTo4GiB':4-(1722271785/1024**3+.5+.031+.75+.5)},'ceilingIsMeasured':False,'ceilingIsAuthorized':False,'admissionBypassAuthorized':False,'limitations':'Approximate engineering envelope, not a worst-case proof. Initial floating parameter creation, tensor filtering, mapping residency, dequantization and allocator behavior need bounded measurement. Vision buffer avoidance unproven.'})
 result={'researchGate':'TOKENIZER_PROVENANCE_HOLD','finalDecision':'QWEN35_RESEARCH_HOLD','conversionRevisionMatchesExpected':True,'modelLicense':'CLEAR_APACHE_2_0_DECLARATION','tokenizerLicenseProvenance':'AMBIGUOUS_COMPLETE_LINEAGE','conversionProvenance':'ACCEPTABLE_WITH_REVIEW_IDENTITY_PINNED_REPRODUCTION_UNATTESTED','runtime':'STATICALLY_PLAUSIBLE_DYNAMICALLY_UNVERIFIED','remoteCodeMandatory':False,'artifactWeightsAcquired':False,'weightBytesDownloaded':0,'organizationPackageCreated':False,'tokenizerConfigExecution':'NOT_RUN_ACQUISITION_GATE_CLOSED','modelLoads':0,'generationRequests':0,'quality':'UNMEASURED','resources':'UNMEASURED','laterPhasesExecuted':[]}
 save('research-gate.json',result);print(json.dumps({'gate':result,'overlap':overlap,'parameterCounts':{'language':language,'vision':vit,'total':total},'inventories':[{k:d[k] for k in ('kind','logicalRepositoryBytes','publisherUsedStorage')} for d in inventories]},indent=2))
if __name__=='__main__':main()

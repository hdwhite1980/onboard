"""Seal research evidence; no model acquisition/execution code."""
import datetime,hashlib,json,re,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'docs/sprint3a';E=D/'evidence/candidate5-preflight-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):
 with (E/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def main():
 prior=read(E/'preservation-before.json')['files'];changed=[r['path'] for r in prior if sha(ROOT/r['path'])!=r['sha256']];assert not changed,changed
 assert (D/'LOCAL_MODEL_COMPARISON.md').read_text().startswith((E/'LOCAL_MODEL_COMPARISON.before.md').read_text())
 for r in read(E/'runtime-static-integrity.json')['sources']:assert sha(ROOT/r['path'])==r['sha256']
 assert not list(E.rglob('*.safetensors'))
 assert read(E/'research-gate.json')['weightBytesDownloaded']==0
 files=[]
 for kind,api in [('conversion','conversion-api.json'),('upstream','upstream-api.json')]:
  d=read(E/api)
  files.append({'url':f"https://huggingface.co/api/models/{d['id']}?blobs=true",'path':api,'sha256':sha(E/api),'kind':'Current API snapshot, retrieved 2026-09-23'})
  for row in d['siblings']:
   f=E/'sources'/kind/row['rfilename']
   if f.exists():files.append({'url':f"https://huggingface.co/{d['id']}/resolve/{d['sha']}/{row['rfilename']}",'path':str(f.relative_to(E)),'sha256':sha(f),'kind':'Pinned non-weight research bytes; Git/LFS identity checked'})
 extras={
 'conversion-history.json':'https://huggingface.co/api/models/mlx-community/Qwen3.5-2B-4bit/commits/main',
 'upstream-history.json':'https://huggingface.co/api/models/Qwen/Qwen3.5-2B/commits/main',
 'mlx-vlm-tag.json':'https://api.github.com/repos/Blaizzy/mlx-vlm/commits/v0.3.12',
 'mlx-vlm-convert.py':'https://raw.githubusercontent.com/Blaizzy/mlx-vlm/739f4ab7d4b6eb236221a909e3a2b6a11daf31c1/mlx_vlm/convert.py',
 'mlx-vlm-utils.py':'https://raw.githubusercontent.com/Blaizzy/mlx-vlm/739f4ab7d4b6eb236221a909e3a2b6a11daf31c1/mlx_vlm/utils.py',
 'mlx-vlm-qwen35.py':'https://raw.githubusercontent.com/Blaizzy/mlx-vlm/739f4ab7d4b6eb236221a909e3a2b6a11daf31c1/mlx_vlm/models/qwen3_5/qwen3_5.py',
 'mlx-vlm-qwen35-language.py':'https://raw.githubusercontent.com/Blaizzy/mlx-vlm/739f4ab7d4b6eb236221a909e3a2b6a11daf31c1/mlx_vlm/models/qwen3_5/language.py',
 'qwen-technical-report.html':'https://arxiv.org/html/2309.16609v1',
 'qwen-historical-commit.json':'https://api.github.com/repos/QwenLM/Qwen/commits/main',
 'qwen-legacy-NOTICE':'https://raw.githubusercontent.com/QwenLM/Qwen/2df8e8ac450fa185c421a08b0090ef81826caa6e/NOTICE',
 'qwen-legacy-LICENSE':'https://raw.githubusercontent.com/QwenLM/Qwen/2df8e8ac450fa185c421a08b0090ef81826caa6e/LICENSE',
 'qwen-tokenization-note.md':'https://raw.githubusercontent.com/QwenLM/Qwen/2df8e8ac450fa185c421a08b0090ef81826caa6e/tokenization_note.md'}
 for path,url in extras.items():files.append({'url':url,'path':path,'sha256':sha(E/path),'kind':'Inert primary-source research; not executed'})
 write('SOURCE_REGISTER.json',{'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'additionalWebPrimaryReferences':['https://www.apache.org/licenses/LICENSE-2.0','https://www.nist.gov/itl/ai-risk-management-framework'],'retainedComparisonInputs':[{'path':'docs/sprint3a/evidence/candidate4-research-01/sources/cl100k_base.tiktoken','sha256':sha(D/'evidence/candidate4-research-01/sources/cl100k_base.tiktoken')},{'path':'docs/sprint3a/evidence/candidate2-quality-01/package.json','sha256':sha(D/'evidence/candidate2-quality-01/package.json')}],'note':'Publisher hashes do not establish legal rights or reproducible conversion. No weight bytes retrieved.'})
 write('lineage-search-log.json',{'queries':['Qwen3.5 tokenizer vocabulary 248044 origin Qwen3 VL tiktoken license','site:github.com/QwenLM tokenizer tiktoken cl100k_base license','site:github.com/QwenLM "Qwen3.5" "tokenizer" "origin"','site:github.com/QwenLM "Qwen3.5" "cl100k"','site:github.com/QwenLM "Qwen3.5" "Llama" "tokenizer"','site:github.com/QwenLM "Qwen3.5" "SentencePiece"','site:huggingface.co/Qwen/Qwen3.5-2B/discussions tokenizer license','site:github.com/QwenLM/Qwen3.5 "tokenizer" "license"'],'primaryFindings':['Pinned model and tokenizer artifacts and license','Older official Qwen report cl100k origin and official historical NOTICE','Installed and declared-converter primary source','No inspected exact Qwen3.5 full vocabulary/merge origin attestation'],'negativeFindingScope':'Bounded research, not proof of universal absence','secondarySearchResultsUsedAsEvidence':False,'publisherContacted':False})
 reports=['CANDIDATE5_QWEN35_RESEARCH.md','CANDIDATE5_QWEN35_LICENSE_PROVENANCE.md','CANDIDATE5_QWEN35_ARCHITECTURE.md','CANDIDATE5_QWEN35_PREFLIGHT.md','CANDIDATE5_QWEN35_RESOURCE_PLAN.md','LOCAL_MODEL_COMPARISON.md']
 broken=[]
 for name in reports:
  source=D/name
  for link in re.findall(r'\]\(([^)]+)\)',source.read_text()):
   if not link.startswith(('http:','https:','#')) and not (source.parent/link.split('#')[0]).exists():broken.append((name,link))
  target=E/'reports'/name;target.parent.mkdir(exist_ok=True);shutil.copyfile(source,target)
 assert not broken,broken
 for path in Path(__file__).parent.glob('*.py'):
  target=E/'research-source'/path.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(path,target)
 write('verification.json',{'historicalFilesUnchanged':len(prior),'historicalMismatches':changed,'comparisonAppendOnly':True,'installedRuntimeSourcesUnchanged':10,'allReportLocalLinksValid':True,'researchMetadataFilesVerified':sum(r.get('localAcquired',False) for d in read(E/'metadata-verification.json') for r in d['files']),'weightFilesPresent':0,'modelLoads':0,'generationRequests':0,'tokenizerExecutionTests':0,'organizationManifestCreated':False,'finalDecision':'QWEN35_RESEARCH_HOLD'})
 records=[{'path':str(p.relative_to(E)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(E.rglob('*')) if p.is_file() and p.name!='EVIDENCE_MANIFEST.json']
 write('EVIDENCE_MANIFEST.json',{'files':records})
 assert all(sha(E/r['path'])==r['sha256'] for r in read(E/'EVIDENCE_MANIFEST.json')['files'])
 print(json.dumps({'historicalFilesUnchanged':len(prior),'sealedFiles':len(records),'manifestSHA256':sha(E/'EVIDENCE_MANIFEST.json'),'finalDecision':'QWEN35_RESEARCH_HOLD'}))
if __name__=='__main__':main()

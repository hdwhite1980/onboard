"""Static, non-weight Candidate 5 research only. Never imports inference/tokenizer runtimes."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];E=ROOT/'docs/sprint3a/evidence/candidate5-preflight-01';OLD=ROOT/'docs/sprint3a/evidence/candidate4-research-01/sources'
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
 inventory=[];missing=[]
 for key,repo in [('conversion','mlx-community/Qwen3.5-2B-4bit'),('upstream','Qwen/Qwen3.5-2B')]:
  data=json.loads((E/(key+'-api.json')).read_text());revision=data['sha'];target=E/'sources'/key;target.mkdir(parents=True,exist_ok=True)
  for row in data['siblings']:
   name=row['rfilename'];assert Path(name).name==name and '..' not in name
   record=dict(row,repo=repo,revision=revision,url=f'https://huggingface.co/{repo}/resolve/{revision}/{name}',kind='WEIGHTS_NOT_ACQUIRED' if name.endswith('.safetensors') else 'RESEARCH_METADATA')
   if record['kind']=='RESEARCH_METADATA':
    src=OLD/repo.replace('/','__')/name
    if src.exists():
     blob=src.read_bytes();assert len(blob)==row['size']
     if row.get('lfs'):assert sha(blob)==row['lfs']['sha256']
     else:assert hashlib.sha1(b'blob '+str(len(blob)).encode()+b'\0'+blob).hexdigest()==row['blobId']
     shutil.copyfile(src,target/name);record.update(localSHA256=sha(blob),acquisition='Reused pinned research bytes; freshly verified against current publisher Git/LFS metadata')
    else:missing.append({'url':record['url'],'path':str((target/name).relative_to(ROOT))})
   inventory.append(record)
 (E/'inventory-research.json').write_text(json.dumps(inventory,indent=2)+'\n')
 (E/'fetch-missing.json').write_text(json.dumps(missing,indent=2)+'\n')
 print(json.dumps(missing))
if __name__=='__main__':main()

"""Offline research accounting only. No model/runtime imports or acquisition."""
import datetime
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
E = ROOT / 'docs/sprint3a/evidence/candidate3-01'
R = E / 'research'
GIB = 1024**3


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        for b in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def save(name, data):
    with (E / name).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def main():
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    shutil.copyfile('/Users/donwhite/.codex/attachments/349b9cef-5e4d-47d9-a3ce-953d5a9d9053/Pasted text.txt', E / 'owner-authorization.txt')
    artifact = json.loads((R / 'artifact-api.json').read_text())
    upstream = json.loads((R / 'upstream-api.json').read_text())
    assert artifact['sha'] == 'd3a7e0594d6642dbcfb7d149bed8b0bdf49f95ce'
    assert artifact['id'] == 'mlx-community/SmolLM3-3B-4bit'
    assert upstream['sha'] == 'a07cc9a04f16550a088caea529712d1d335b0ac1'
    assert artifact['cardData']['license'] == upstream['cardData']['license'] == 'apache-2.0'
    rows = []
    for row in artifact['siblings']:
        item = dict(row)
        p = R / row['rfilename']
        item['payloadAcquired'] = False
        if p.exists():
            raw = p.read_bytes()
            assert len(raw) == row['size']
            assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['blobId']
            item['researchMetadataSHA256'] = sha(p)
        rows.append(item)
    cfg = json.loads((R / 'config.json').read_text())
    tok = json.loads((R / 'tokenizer_config.json').read_text())
    assert cfg['model_type'] == 'smollm3'
    assert cfg['quantization'] == {'bits': 4, 'group_size': 64}
    assert cfg['no_rope_layers'] == [int((i + 1) % 4 != 0) for i in range(36)]
    assert not any(k in d for d in [cfg, tok] for k in ['auto_map', 'model_file'])
    assert tok['tokenizer_class'] == 'PreTrainedTokenizerFast'
    urows = {r['rfilename']: r for r in upstream['siblings']}
    for name in ['tokenizer.json', 'tokenizer_config.json', 'special_tokens_map.json']:
        a = next(r for r in rows if r['rfilename'] == name)
        assert a['blobId'] == urows[name]['blobId'] and a['size'] == urows[name]['size']
    save('artifact-inventory.json', {
        'timestamp': timestamp, 'repository': artifact['id'], 'revision': artifact['sha'],
        'publisher': artifact['author'], 'reviewedUpstream': upstream['id'],
        'reviewedUpstreamRevision': upstream['sha'], 'repositoryBytes': sum(r['size'] for r in rows),
        'files': rows, 'tokenizerMetadataMatchesReviewedUpstream': True,
        'weightAndTokenizerLocalSHA256': 'NOT AVAILABLE: payload acquisition stopped at license gate',
        'sourceRevisionOfOriginalConversion': 'NOT ATTESTED by conversion card',
        'safetensorsInspection': 'NOT PERFORMED', 'organizationPackageCreated': False,
    })
    site = ROOT / 'product/local_ai/.artifacts/runtime/venv/lib/python3.12/site-packages'
    sbom = json.loads((ROOT / 'product/local_ai/runtime/SBOM.json').read_text())
    component = next(c for c in sbom['components'] if c['package'] == 'mlx-lm')
    wheel = ROOT / 'product/local_ai/.artifacts/runtime/wheelhouse' / component['wheel']
    assert sha(wheel) == component['sha256']
    source_rows = []
    with zipfile.ZipFile(wheel) as archive:
        for name in ['mlx_lm/utils.py', 'mlx_lm/models/smollm3.py', 'mlx_lm/models/llama.py', 'mlx_lm/models/base.py']:
            p = site / name
            assert sha(p) == hashlib.sha256(archive.read(name)).hexdigest()
            source_rows.append({'path': str(p.relative_to(ROOT)), 'sha256': sha(p)})
    save('runtime-static-review.json', {
        'timestamp': timestamp, 'status': 'BUILTIN_ARCHITECTURE_PRESENT_STATIC_REVIEW_ONLY',
        'mlxLMVersion': component['version'], 'wheelSHA256': component['sha256'],
        'sourceFilesMatchRetainedReviewedWheel': source_rows,
        'newDependenciesIdentified': [], 'remoteCodeRequiredByConfig': False,
        'runtimeExecution': False, 'fullInstalledRuntimeReverification': 'DEFERRED: research gate stop',
        'lockSHA256': sha(ROOT / 'product/local_ai/runtime/requirements.lock'),
        'SBOMSHA256': sha(ROOT / 'product/local_ai/runtime/SBOM.json'),
    })
    weights = next(r['size'] for r in rows if r['rfilename'] == 'model.safetensors')
    kv = 2 * 36 * 4 * 128 * 512 * 2
    components = {
        'quantizedWeightFileUpperProxy': weights,
        'temporaryOneAdditionalWeightSizedLoadCopy': weights,
        'tokenizerAndRepositoryMetadata': sum(r['size'] for r in rows) - weights,
        'fp16KV512Tokens': kv,
        'runtimePythonMetalOverheadUnmeasured': GIB // 2,
        'activationScratchUnmeasured': GIB // 4,
        'additionalUncertaintyUnmeasured': GIB // 2,
    }
    save('planning-allowance.json', {
        'label': 'UNMEASURED PLANNING ALLOWANCE', 'timestamp': timestamp,
        'contextCeiling': 512, 'maxOutputIncluded': 128, 'batch': 1, 'thinking': False,
        'kvProposedDtype': 'float16; not yet observed', 'componentsBytes': components,
        'rawWorkingBytes': sum(components.values()), 'roundedWorkingAllowanceBytes': int(4.75 * GIB),
        'protectedHostReserveBytes': 2 * GIB, 'requiredAvailableEstimateBytes': int(6.75 * GIB),
        'rounding': 'up to next 0.25 GiB',
        'loadCopyRationale': 'Conservatively allow a second quantized-weight-sized live copy during materialization/transfer; not a measured MLX duplication claim.',
        'measuredProfile': False, 'admission': 'NOT RUN: earlier license/provenance stop',
        'hostState': None, 'shortfall': None,
    })
    prior = []
    for folder in ['calibration-01', 'candidate2-01', 'candidate2-clean-01', 'candidate2-calibration-01', 'candidate2-quality-01']:
        p = E.parent / folder / 'EVIDENCE_MANIFEST.json'
        manifest = json.loads(p.read_text())
        for row in manifest['files']:
            target = ROOT / row['path']
            assert target.stat().st_size == row['bytes'] and sha(target) == row['sha256'], row['path']
        prior.append({'manifest': str(p.relative_to(ROOT)), 'sha256': sha(p), 'unchangedFiles': len(manifest['files'])})
    packages = []
    for identity in ['ed11af86637bd7268e36704ecb36fda1cac97b7e02b9e81fd7fdfee90124ee07', '1721e23c79d4367cb3e12a6811aabd61a8526c511b0f30f7134ecaeb40ef0778']:
        store = ROOT / 'product/local_ai/.artifacts/store' / identity
        assert sha(store / 'manifest.json') == identity
        m = json.loads((store / 'manifest.json').read_text())
        for row in m['files']:
            p = store / row['path']
            assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256']
        packages.append({'manifestSHA256': identity, 'unchangedFiles': len(m['files'])})
    save('preservation.json', {'status': 'PASS', 'timestamp': timestamp, 'historicalEvidence': prior, 'modelPackages': packages, 'candidate1Executions': 0, 'candidate2Executions': 0, 'runtimeModified': False})
    save('result.json', {
        'timestamp': timestamp, 'stage': 'RESEARCH_GATE_STOP',
        'reason': 'UNRESOLVED_TOKENIZER_LICENSE_PROVENANCE', 'researchGatePassed': False,
        'candidateQualificationStatus': None, 'lifecycleIntent': 'EXPERIMENTAL; no package created',
        'sprintDecision': 'CONTINUE SPRINT 3A', 'modelLoads': 0, 'generationRequests': 0,
        'weightsAcquired': False, 'tokenizerPayloadAcquired': False,
        'resourceAdmissionPerformed': False, 'noThinkingRenderedPrompt': None, 'tokenIDs': None,
        'stopAuthorization': 'Owner request sections 4, 5 and 37; unresolved redistribution restriction prevents conditional acquisition.',
    })
    print(json.dumps({'research': 'STOP_LICENSE_PROVENANCE', 'repositoryBytes': sum(r['size'] for r in rows), 'rawPlanningGiB': sum(components.values()) / GIB, 'priorManifestsVerified': len(prior), 'modelPackagesVerified': len(packages)}))


if __name__ == '__main__':
    main()

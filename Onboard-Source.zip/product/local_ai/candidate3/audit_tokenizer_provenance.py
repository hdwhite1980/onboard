"""Reproducible offline comparison of authorized tokenizer research files only."""
import datetime
import difflib
import hashlib
import html.parser
import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
E = ROOT / 'docs/sprint3a/evidence/candidate3-tokenizer-provenance-01'
S = E / 'sources'
PRIOR = ROOT / 'docs/sprint3a/evidence/candidate3-01/research'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(name, data):
    (E / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def changes(a, b, path=''):
    if a == b:
        return []
    if isinstance(a, dict) and isinstance(b, dict):
        return sum((changes(a.get(k), b.get(k), path + '/' + k) for k in sorted(a.keys() | b.keys())), [])
    if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        return sum((changes(x, y, path + '/' + str(i)) for i, (x, y) in enumerate(zip(a, b))), [])
    return [{'path': path, 'base': a, 'instruct': b}]


class Props(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.objects = []

    def handle_starttag(self, tag, attrs):
        for k, v in attrs:
            if k == 'data-props':
                try:
                    self.objects.append(json.loads(v))
                except (ValueError, TypeError):
                    pass


def find_comment(value):
    if isinstance(value, dict):
        if value.get('id') == '6890781460f3b828efde64cf':
            return value
        for v in value.values():
            result = find_comment(v)
            if result:
                return result
    if isinstance(value, list):
        for v in value:
            result = find_comment(v)
            if result:
                return result


def main():
    copied = {'artifact-api.json': 'mlx-api.json', 'upstream-api.json': 'upstream-api.json',
              'README.md': 'mlx/README.md', 'upstream-README.md': 'upstream/README.md',
              'upstream-discussions.json': 'upstream-discussions.json'}
    for src, dest in copied.items():
        if not (S / dest).exists():
            shutil.copy2(PRIOR / src, S / dest)
        assert sha(PRIOR / src) == sha(S / dest)
    inventory = []
    license_rows = []
    for kind in ['mlx', 'upstream', 'base']:
        api = json.loads((S / (kind + '-api.json')).read_text())
        rows = {x['rfilename']: x for x in api['siblings']}
        license_rows.append({'repository': api['id'], 'revision': api['sha'],
                             'declaredLicense': api['cardData']['license'],
                             'licenseNoticePaths': [n for n in rows if re.search(r'license|notice|copyright|copying', n, re.I)]})
        for p in sorted((S / kind).iterdir()):
            raw = p.read_bytes()
            row = rows[p.name]
            assert len(raw) == row['size']
            if 'lfs' in row:
                assert sha(p) == row['lfs']['sha256']
            else:
                assert blob(raw) == row['blobId']
            inventory.append({'repository': api['id'], 'revision': api['sha'], 'file': p.name,
                              'bytes': len(raw), 'sha256': sha(p), 'publisherBlobSHA1': row['blobId'],
                              'publisherLFS_SHA256': row.get('lfs', {}).get('sha256'),
                              'source': f'https://huggingface.co/{api["id"]}/resolve/{api["sha"]}/{p.name}',
                              'localPath': str(p.relative_to(ROOT)), 'publisherVerification': 'PASS'})
    save('verified-file-inventory.json', inventory)
    comparisons = []
    historical = json.loads((S / 'upstream-at-conversion-api.json').read_text())
    hist_rows = {r['rfilename']: r for r in historical['siblings']}
    for name in ['tokenizer.json', 'tokenizer_config.json', 'special_tokens_map.json', 'chat_template.jinja']:
        a, b = S / 'mlx' / name, S / 'upstream' / name
        equal = a.read_bytes() == b.read_bytes()
        hist = hist_rows[name]
        hist_equal = sha(a) == hist['lfs']['sha256'] if 'lfs' in hist else blob(a.read_bytes()) == hist['blobId']
        assert hist_equal
        comparisons.append({'file': name, 'currentUpstreamByteEqual': equal,
                            'currentUpstreamClassification': 'IDENTICAL_TO_UPSTREAM' if equal else 'MODIFIED_FROM_UPSTREAM',
                            'historicalUpstreamRevision': historical['sha'],
                            'historicalUpstreamClassification': 'IDENTICAL_TO_UPSTREAM',
                            'mlxModificationEstablished': False})
    assert (S / 'mlx/chat_template.jinja').read_bytes() == (S / 'upstream-at-conversion-template.jinja').read_bytes()
    save('mlx-upstream-comparison.json', comparisons)
    (E / 'chat-template-current-upstream.diff').write_text(''.join(difflib.unified_diff(
        (S / 'mlx/chat_template.jinja').read_text().splitlines(True),
        (S / 'upstream/chat_template.jinja').read_text().splitlines(True),
        fromfile='MLX-and-upstream-90486a3', tofile='upstream-a07cc9a')))
    diffs = {}
    for name in ['tokenizer.json', 'tokenizer_config.json', 'special_tokens_map.json']:
        diffs[name] = changes(json.loads((S / 'base' / name).read_text()), json.loads((S / 'upstream' / name).read_text()))
    save('base-to-instruct-structural-diff.json', diffs)
    # Verify official training configuration/license bytes against the pinned Git tree.
    tree = json.loads((S / 'smollm-tree.json').read_text())
    assert tree['truncated'] is False
    tree_rows = {r['path']: r for r in tree['tree']}
    source_rows = []
    for p in sorted((S / 'smollm').iterdir()):
        path = p.name if p.name in ['LICENSE', 'README.md'] else 'text/pretraining/smollm3/' + p.name
        assert blob(p.read_bytes()) == tree_rows[path]['sha']
        source_rows.append({'path': path, 'sha256': sha(p), 'gitBlobVerified': True,
                            'tokenizerReferences': [x.strip() for x in p.read_text().splitlines() if 'tokenizer_name' in x or 'tokenizer_revision' in x]})
    save('official-source-verification.json', source_rows)
    save('repository-license-inventory.json', license_rows)
    parsed = Props()
    parsed.feed((S / 'official-blog.html').read_text())
    comment = find_comment(parsed.objects)
    assert comment and comment['author']['name'] == 'loubnabnl'
    assert 'we used LLama 3.2 tokenizer as is' in comment['data']['latest']['raw']
    save('publisher-origin-statement.json', {
        'source': 'https://huggingface.co/blog/smollm3', 'commentID': comment['id'],
        'author': comment['author']['fullname'], 'handle': comment['author']['name'],
        'createdAt': comment['createdAt'], 'sourceHTML_SHA256': sha(S / 'official-blog.html'),
        'shortExcerpt': 'we used LLama 3.2 tokenizer as is (except for removing `bos_token`)',
        'assessment': 'Direct publisher statement of derivation; not a tokenizer-specific license grant.',
    })
    # Search metadata, not ordinary learned vocabulary/merge entries, for license claims.
    terms = r'license|notice|copyright|SPDX|attribut|sentencepiece|llama|meta|gemma|qwen'
    search = []
    for kind in ['mlx', 'upstream', 'base']:
        for name in ['tokenizer.json', 'tokenizer_config.json', 'special_tokens_map.json']:
            value = json.loads((S / kind / name).read_text())
            if name == 'tokenizer.json':
                value['model'] = {k: v for k, v in value['model'].items() if k not in ['vocab', 'merges']}
            serialized = json.dumps(value)
            search.append({'file': kind + '/' + name, 'terms': terms,
                           'hits': sorted(set(m.group(0).lower() for m in re.finditer(terms, serialized, re.I))),
                           'exclusion': 'learned vocab/merges omitted: ordinary token spellings are not attribution'})
    save('tokenizer-metadata-license-search.json', search)
    print(json.dumps({'verifiedFiles': len(inventory), 'sameCurrentTokenizerJSONFiles': 3,
                      'historicalTemplateByteEqual': True, 'publisherOriginStatementExtracted': True,
                      'recommendation': 'SEEK_PUBLISHER_CLARIFICATION'}))


if __name__ == '__main__':
    main()

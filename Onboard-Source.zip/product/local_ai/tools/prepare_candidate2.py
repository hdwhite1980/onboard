"""Local artifact/template verification and activation preparation; never loads MLX."""
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
B = ROOT / 'product/local_ai'
E = ROOT / 'docs/sprint3a/evidence/candidate2-clean-01'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    def audit(event, args):
        if event.startswith('socket.') and event not in ['socket.__new__']:
            raise RuntimeError('Unexpected network request during local template preparation: ' + event)
    sys.addaudithook(audit)
    package = json.loads((E / 'package.json').read_text())
    store = Path(package['store'])
    assert sha(store / 'manifest.json') == package['manifestSHA256']
    for row in package['manifest']['files']:
        path = store / row['path']
        assert not path.is_symlink() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
    assert sha(store / 'model.safetensors') == '0e86d9677e519323849eac1bc272caae88567a481ff188c431f70be543d9995f'
    assert sha(store / 'tokenizer.json') == 'aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4'
    for local, research in [('config.json', 'qwen3-17-config.json'), ('tokenizer_config.json', 'qwen3-17-tokenizer_config.json')]:
        assert json.loads((store / local).read_text()) == json.loads((ROOT / 'docs/sprint3a/evidence/research' / research).read_text())
    cfg = json.loads((store / 'config.json').read_text())
    tc = json.loads((store / 'tokenizer_config.json').read_text())
    assert not any(k in d for d in [cfg, tc] for k in ['auto_map', 'model_file'])
    template = tc['chat_template']
    assert 'enable_thinking is defined and enable_thinking is false' in template
    snap = B / '.artifacts/activation/candidate2-clean-01'
    if not snap.exists():
        shutil.copytree(store, snap, copy_function=shutil.copyfile)
    assert {str(p.relative_to(snap)) for p in snap.rglob('*') if p.is_file()} == {x['path'] for x in package['manifest']['files']} | {'manifest.json'}
    assert sha(snap / 'manifest.json') == package['manifestSHA256']
    for row in package['manifest']['files']:
        assert sha(snap / row['path']) == row['sha256']
    for path in snap.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert path.stat().st_nlink == 1
            path.chmod(0o400)
        elif path.is_dir():
            path.chmod(0o500)
    snap.chmod(0o500)
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(snap), local_files_only=True, trust_remote_code=False)
    messages = [
        {'role': 'system', 'content': 'Rewrite only. Preserve names, dates and meaning. Do not add facts.'},
        {'role': 'user', 'content': 'Rewrite professionally:\n\n"hey sarah just wanted to see if you figured out what was going on with the encryption issue because we need to know if this is going to mess up the october 3 deployment"'},
    ]
    prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, enable_thinking=False)
    assert prompt.endswith('<|im_start|>assistant\n<think>\n\n</think>\n\n')
    ids = tokenizer.encode(prompt, add_special_tokens=False)
    assert ids == tokenizer.apply_chat_template(messages, tokenize=True, return_dict=False, add_generation_prompt=True, enable_thinking=False)
    assert len(ids) + 650 <= 2048
    forbidden = ['mlx', 'mlx_lm', 'FoundationModels']
    assert not any(n == f or n.startswith(f + '.') for n in sys.modules for f in forbidden)
    data = {'modelManifestSHA256': package['manifestSHA256'], 'messages': messages,
            'rawPrompt': prompt, 'tokenIDs': ids, 'promptTokens': len(ids),
            'maxNewTokens': 650, 'totalContextLimit': 2048, 'maximumAccountedTokens': len(ids) + 650,
            'batch': 1, 'KV': 'FP16', 'thinking': False, 'enable_thinking': False,
            'chatTemplateSHA256': hashlib.sha256(template.encode()).hexdigest(),
            'generation': {'sampler': 'greedy argmax', 'temperature': 0, 'kv_bits': None,
                           'prefill_step_size': 128, 'max_tokens': 650, 'stop': 'tokenizer eos_token_ids'},
            'localFilesOnly': True, 'trustRemoteCode': False, 'preparationPID': os.getpid(),
            'mlxImported': False, 'modelLoaded': False}
    (E / 'token-budget.json').write_text(json.dumps(data, indent=2) + '\n')
    (E / 'chat-template.jinja').write_text(template)
    (E / 'activation.json').write_text(json.dumps({'snapshot': str(snap), 'manifestSHA256': package['manifestSHA256'],
        'controls': ['private copy', 'no hardlinks/symlinks', 'read-only files', 'per-file hash verification before eager load'],
        'residual': 'RESIDUAL SAME-USER ACTIVATION RACE: same UID can change permissions/parents; MLX-LM reopens paths. No privileged/production boundary.'}, indent=2) + '\n')
    print(json.dumps({'status': 'ARTIFACT_AND_TEMPLATE_VERIFIED', 'promptTokens': len(ids),
                     'maxNewTokens': 650, 'maximumAccountedTokens': len(ids) + 650,
                     'thinking': False, 'modelLoads': 0, 'pid': os.getpid()}))


if __name__ == '__main__':
    main()

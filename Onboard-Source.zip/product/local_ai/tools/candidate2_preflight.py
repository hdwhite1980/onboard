"""Candidate 2 identity and admission gate only. Never loads or downloads a model."""
import base64
import csv
import datetime
import hashlib
import importlib.metadata
import io
import json
import platform
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'product/local_ai'
EVIDENCE = ROOT / 'docs/sprint3a/evidence/candidate2-01'
PRIOR = ROOT / 'docs/sprint3a/evidence/calibration-01'
GIB = 1024**3


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(name, value):
    if '--host-monitor' in sys.argv:
        name = name.replace('.json', '-host.json')
    with (EVIDENCE / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    result = {'scope': 'CANDIDATE_2_NORMAL_ADMISSION',
              'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'modelLoads': 0, 'generationRequests': 0, 'dependenciesChanged': False}
    try:
        interpreter = json.loads((PRIOR / 'interpreter.json').read_text())
        assert Path(sys.executable).resolve() == Path(interpreter['executable']).resolve()
        assert sha(Path(sys.executable).resolve()) == interpreter['sha256']
        assert platform.python_version() == interpreter['version']
        assert platform.machine() == interpreter['architecture']
        prior = json.loads((PRIOR / 'runtime-identity.json').read_text())
        for name, key in [('requirements.lock', 'wheelLockSHA256'), ('SBOM.json', 'SBOMSHA256')]:
            assert sha(BASE / 'runtime' / name) == prior[key], name
        # Verify installed bytes against the retained, publisher-hash-verified wheels,
        # in addition to each installed RECORD. No MLX or Transformers import.
        components = json.loads((BASE / 'runtime/SBOM.json').read_text())['components']
        verified = []
        for component in components:
            wheel = BASE / '.artifacts/runtime/wheelhouse' / component['wheel']
            assert sha(wheel) == component['sha256'], wheel.name
            distribution = importlib.metadata.distribution(component['package'])
            assert distribution.version == component['version'], component['package']
            count = 0
            with zipfile.ZipFile(wheel) as archive:
                for info in archive.infolist():
                    if info.is_dir() or info.filename.endswith('.dist-info/RECORD'):
                        continue
                    assert '.data/' not in info.filename, 'Unreviewed install mapping'
                    target = Path(distribution.locate_file(info.filename))
                    assert target.is_file() and not target.is_symlink(), target
                    assert sha(target) == hashlib.sha256(archive.read(info)).hexdigest(), target
                    count += 1
            for path, value, size in csv.reader(io.StringIO(distribution.read_text('RECORD'))):
                if not value:
                    continue
                algorithm, digest = value.split('=', 1)
                assert algorithm == 'sha256'
                target = Path(distribution.locate_file(path))
                actual = base64.urlsafe_b64encode(bytes.fromhex(sha(target))).decode().rstrip('=')
                assert actual == digest, target
                if size:
                    assert target.stat().st_size == int(size), target
            verified.append({'name': component['package'], 'version': distribution.version,
                             'wheelSHA256': component['sha256'], 'installedWheelFilesVerified': count})
        expected = {x['name'].lower().replace('_', '-') for x in verified} | {'pip'}
        installed = {d.metadata['Name'].lower().replace('_', '-') for d in importlib.metadata.distributions()}
        assert installed == expected, {'unexpected': sorted(installed - expected), 'missing': sorted(expected - installed)}
        tested = json.loads((PRIOR / 'tested-source.json').read_text())
        for item in tested['files']:
            assert sha(ROOT / item['path']) == item['sha256'], item['path']
        result.update(status='PASS', interpreter=interpreter, packages=verified,
                      wheelLockSHA256=prior['wheelLockSHA256'], SBOMSHA256=prior['SBOMSHA256'],
                      retainedCalibrationSourcesAndProbeUnchanged=True)
    except Exception as error:
        result.update(status='FAIL', error=repr(error))
    save('runtime-reverification.json', result)
    if result['status'] != 'PASS':
        print(json.dumps({'status': 'STOP_RUNTIME_IDENTITY', 'error': result['error']}))
        return
    # Read-only reuse of the unchanged native host sampler; main() is never called.
    sys.path.insert(0, str(Path(__file__).parent))
    import calibrate
    try:
        sample = calibrate.sample()
        required = int(5.25 * GIB)
        reason = calibrate.violation(sample, sample)
        if sample['availableEstimateBytes'] < required:
            reason = 'RESOURCE: below Candidate 2 normal admission target of 5.25 GiB'
        gate = {'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'status': 'STOP_ADMISSION' if reason else 'PASS', 'reason': reason,
                'scope': 'CANDIDATE_2_NORMAL_ADMISSION', 'sample': sample,
                'physicalMemoryBytes': int(calibrate.run(['/usr/sbin/sysctl', '-n', 'hw.memsize'])),
                'power': calibrate.run(['/usr/bin/pmset', '-g', 'batt']),
                'workingAllowanceBytes': int(3.25 * GIB), 'reserveBytes': 2 * GIB,
                'requiredAvailableEstimateBytes': required,
                'shortfallBytes': max(0, required - sample['availableEstimateBytes']),
                'availableMethod': 'free + inactive + speculative pages; estimate, not guaranteed allocatable',
                'bypass': False, 'modelLoads': 0, 'generationRequests': 0,
                'note': 'Early gate before acquisition; if passed, repeat immediately before actual load.'}
    except Exception as error:
        gate = {'status': 'STOP_MONITOR_UNAVAILABLE', 'error': repr(error), 'modelLoads': 0}
    save('admission.json', gate)
    print(json.dumps(gate, indent=2))


if __name__ == '__main__':
    main()

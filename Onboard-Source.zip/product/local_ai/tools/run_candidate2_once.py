"""One-use Candidate 2 normal admission supervisor. No calibration bypass."""
import os,sys,json,time,subprocess,threading,queue,signal,re,hashlib,shutil,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];B=ROOT/'product/local_ai';E=ROOT/'docs/sprint3a/evidence/candidate2-clean-01';GiB=1024**3
POLICY={'label':'CANDIDATE_2_BOUNDED_NORMAL_ADMISSION','normalAdmissionBytes':int(5.25*GiB),'normalWorkingAllowanceBytes':int(3.25*GiB),'reserveBytes':2*GiB,'abortAvailableBytes':int(2.25*GiB),'maxCompressorGrowthBytes':512*1024**2,'maxSwapGrowthBytes':0,'maxThermalState':1,'sampleIntervalSeconds':.25,'monitorStaleSeconds':1.5,'generationRequests':1,'maxTotalContext':2048,'maxNewTokens':650,'wallTimeoutSeconds':180}
def run(cmd):
 p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True,timeout=1);assert p.returncode==0,(cmd,p.stderr);return p.stdout
def sample(pid=None):
 vm=run(['/usr/bin/vm_stat']);page=int(re.search(r'page size of (\d+)',vm)[1]);counts={k:int(v) for k,v in re.findall(r'^(Pages [\w ]+):\s+(\d+)',vm,re.M)}
 pressure=int(run(['/usr/sbin/sysctl','-n','kern.memorystatus_vm_pressure_level']).strip());swap=run(['/usr/sbin/sysctl','vm.swapusage']);used=re.search(r'used\s*=\s*([\d.]+)([MG])',swap);assert used
 native=json.loads(run([B/'.artifacts/build/resource-probe',str(pid or os.getpid())]));assert native['error']==0 and native['phys_footprint'] is not None
 return {'monotonic':time.monotonic(),'availableEstimateBytes':page*sum(counts[k] for k in ['Pages free','Pages inactive','Pages speculative']),'wiredBytes':page*counts['Pages wired down'],'compressorBytes':page*counts['Pages occupied by compressor'],'swapUsedBytes':int(float(used[1])*({'M':1024**2,'G':GiB}[used[2]])),'pressure':pressure,'thermal':native['thermal_state'],'workerFootprintBytes':native['phys_footprint'] if pid else None,'native':native}
def violation(row,base):
 if row['availableEstimateBytes']<=POLICY['abortAvailableBytes']:return 'RESOURCE: protected reserve approached'
 if row['pressure']!=1:return 'RESOURCE: non-normal/unknown pressure'
 if row['swapUsedBytes']>base['swapUsedBytes']:return 'RESOURCE: swap increased'
 if row['compressorBytes']-base['compressorBytes']>=POLICY['maxCompressorGrowthBytes']:return 'RESOURCE: compression growth >=512 MiB'
 if row['thermal'] not in [0,1]:return 'RESOURCE: unsafe/unknown thermal state'
 return None
def dump(name,data):(E/name).write_text(json.dumps(data,indent=2)+'\n')
def main():
 package=json.loads((E/'package.json').read_text());store=Path(package['store']);ident=package['manifestSHA256'];assert hashlib.sha256((store/'manifest.json').read_bytes()).hexdigest()==ident
 assert json.loads((E/'preload-admission.json').read_text())['status']=='NORMAL_ADMISSION_PASS'
 assert json.loads((E/'runtime-reverification.json').read_text())['status']=='PASS'
 snap=Path(json.loads((E/'activation.json').read_text())['snapshot'])
 assert snap.is_dir()
 dump('calibration-policy.json',POLICY)
 # Persistent one-use marker: no second worker/inference automatically.
 with (E/'ATTEMPT_STARTED.json').open('x') as f:json.dump({'label':POLICY['label'],'time':datetime.datetime.now(datetime.timezone.utc).isoformat()},f)
 base=sample();dump('baseline.json',{'label':POLICY['label'],'sample':base,'physicalMemory':run(['/usr/sbin/sysctl','-n','hw.memsize']).strip(),'power':run(['/usr/bin/pmset','-g','batt']),'availableMethod':'free + inactive + speculative; estimate, not guaranteed allocatable'})
 reason=violation(base,base)
 if base['availableEstimateBytes']<POLICY['normalAdmissionBytes']:reason='RESOURCE: pre-worker normal admission no longer met'
 if reason:dump('result.json',{'label':POLICY['label'],'success':False,'abort':reason,'generationRequests':0});return
 scratch=B/'.artifacts/state/candidate2-clean-01';scratch.mkdir(parents=True)
 env={'PATH':'/usr/bin:/bin','HOME':str(scratch),'TMPDIR':str(scratch),'HF_HOME':str(scratch/'hf'),'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_HUB_DISABLE_TELEMETRY':'1','HF_HUB_DISABLE_XET':'1','DO_NOT_TRACK':'1','TOKENIZERS_PARALLELISM':'false','PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1','USE_TORCH':'0','USE_TF':'0','USE_FLAX':'0'}
 cmd=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)',str(B/'.artifacts/runtime/venv/bin/python'),'-B',str(B/'backends/candidate2_worker.py'),str(snap),ident,str(E/'token-budget.json')]
 dump('launch.json',{'label':POLICY['label'],'command':cmd,'environment':env,'appleFoundationBackend':'DISABLED / UNREGISTERED','externalFallbacks':[]})
 events=[];samples=[];q=queue.Queue();aborts=[];stop=threading.Event();lastSample=[time.monotonic()];stage=['startup'];launchTime=time.monotonic()
 err=(E/'worker.stderr').open('w');raw=(E/'worker-events.jsonl').open('w');metrics=(E/'resources.jsonl').open('w')
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,env=env,start_new_session=True)
 def abort(why):
  if not aborts:
   aborts.append(why)
   try:os.killpg(proc.pid,signal.SIGKILL)
   except ProcessLookupError:pass
 def read():
  for line in proc.stdout:
   raw.write(line);raw.flush()
   try:
    event=json.loads(line);events.append(event);q.put(event)
    if event['event'] in ['fatal','unexpected_network','unexpected_process']:abort(('SECURITY' if event['event']!='fatal' else event.get('classification','RUNTIME'))+': '+str(event))
   except ValueError:abort('RUNTIME: malformed worker event')
  q.put({'event':'terminated'})
 def monitor():
  while not stop.is_set() and proc.poll() is None:
   try:
    s=sample(proc.pid);s['stage']=stage[0];samples.append(s);metrics.write(json.dumps(s)+'\n');metrics.flush();lastSample[0]=time.monotonic()
    why=violation(s,base)
    if why:abort(why);break
   except BaseException as error:
    if proc.poll() is None:abort('UNKNOWN: monitoring unavailable '+repr(error))
    break
   stop.wait(POLICY['sampleIntervalSeconds'])
 def watchdog():
  while not stop.wait(.1) and proc.poll() is None:
   if time.monotonic()-launchTime>POLICY['wallTimeoutSeconds']:abort('RUNTIME: calibration wall timeout');break
   if time.monotonic()-lastSample[0]>POLICY['monitorStaleSeconds']:abort('UNKNOWN: monitoring stale');break
 threads=[threading.Thread(target=f,daemon=True) for f in [read,monitor,watchdog]]
 for t in threads:t.start()
 def wait(wanted,limit=60):
  deadline=time.monotonic()+limit
  while not aborts:
   if time.monotonic()>deadline:abort('RUNTIME: timeout '+wanted);break
   try:e=q.get(timeout=.1)
   except queue.Empty:continue
   if e['event']==wanted:return e
   if e['event']=='terminated':raise RuntimeError('Worker terminated before '+wanted)
  raise RuntimeError(str(aborts))
 def send(name):
  assert not aborts;stage[0]=name;proc.stdin.write(json.dumps({'command':name})+'\n');proc.stdin.flush()
 success=False
 try:
  wait('started');time.sleep(.5);send('initialize');wait('ready');time.sleep(.5)
  assert any(e.get('event')=='network_negative_control' and e.get('denied') is True for e in events)
  send('load');wait('loaded',90);time.sleep(1);send('generate');wait('generated',90);time.sleep(.5);send('unload');wait('unloaded');time.sleep(1);send('exit');proc.wait(timeout=5);success=proc.returncode==0 and not aborts
 except BaseException as error:
  abort('RUNTIME: '+repr(error))
 finally:
  if proc.poll() is None:abort('RUNTIME: worker failed to terminate')
  proc.wait(timeout=5);stop.set()
  for t in threads:t.join(timeout=2)
  raw.close();metrics.close();err.close()
 recovery=[]
 for i in range(8):
  try:recovery.append(sample())
  except BaseException as error:recovery.append({'error':repr(error)})
  time.sleep(.25)
 dump('recovery.json',recovery)
 dump('result.json',{'label':POLICY['label'],'success':success,'status':'LOCAL_GENERATION_SUCCESS' if success else 'CANDIDATE_2_ATTEMPT_FAILED','abort':aborts,'exit':proc.returncode,'generationRequests':sum(e['event']=='generation_begin' for e in events),'loadRequests':sum(e['event']=='load_begin' for e in events),'normalAdmissionChanged':False,'sampleCount':len(samples),'modelManifestSHA256':ident})
 print('LOCAL_GENERATION_SUCCESS' if success else 'CANDIDATE_2_ATTEMPT_FAILED',aborts,flush=True)
if __name__=='__main__':main()

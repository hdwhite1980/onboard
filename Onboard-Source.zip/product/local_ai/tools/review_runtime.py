"""Review exact resolved wheels before offline installation. No model imports."""
import email,hashlib,json,subprocess,zipfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[3];B=ROOT/'product/local_ai';E=ROOT/'docs/sprint3a/evidence/calibration-01'
def review(wheel):
 with zipfile.ZipFile(wheel) as z:
  names=z.namelist();m=email.message_from_bytes(z.read(next(n for n in names if n.endswith('.dist-info/METADATA'))))
  name,version=m['Name'],m['Version'];safe=name.lower().replace('_','-')
  out=E/'dependency-metadata';out.mkdir(exist_ok=True)
  meta=out/(safe+'.json');url=f'https://pypi.org/pypi/{name}/{version}/json'
  r=subprocess.run(['curl','--fail','--location','--silent','--show-error','--max-time','30',url,'-o',str(meta)],capture_output=True,text=True);assert r.returncode==0,r.stderr
  publisher=json.loads(meta.read_text());entry=next(x for x in publisher['urls'] if x['filename']==wheel.name)
  sha=hashlib.sha256(wheel.read_bytes()).hexdigest();assert sha==entry['digests']['sha256'] and wheel.stat().st_size==entry['size']
  licenses=[n for n in names if ('license' in n.lower() or 'copying' in n.lower() or 'notice' in n.lower()) and '.dist-info/' in n and not n.endswith('/')]
  saved=[]
  for i,n in enumerate(licenses):
   dest=B/'runtime/licenses'/safe;dest.mkdir(parents=True,exist_ok=True);target=dest/(str(i)+'-'+Path(n).name);target.write_bytes(z.read(n));saved.append(str(target.relative_to(B)))
  classifiers=[v for v in m.get_all('Classifier',[]) if v.startswith('License ::')]
  license=m.get('License-Expression') or m.get('License') or '; '.join(classifiers)
  assert license or licenses,'No license record '+name
  native=[n for n in names if n.endswith(('.so','.dylib','.metallib'))]
  purpose={'mlx':'Array/Metal inference runtime','mlx-metal':'Metal runtime kernels','mlx-lm':'Local model architecture/generation','transformers':'Tokenizer/config compatibility','tokenizers':'Native tokenizer','safetensors':'Tensor format support','numpy':'Array dependency','huggingface-hub':'Transitive artifact helper; network disabled at inference','hf-xet':'Transitive artifact transport; disabled at inference'}.get(safe,'Resolved transitive dependency; see Requires-Dist')
  return {'package':name,'version':version,'source':entry['url'],'metadataSource':url,'wheel':wheel.name,'bytes':wheel.stat().st_size,'sha256':sha,'license':license,'licenseFiles':saved,'requires':m.get_all('Requires-Dist',[]),'purpose':purpose,'nativeBinaryStatus':bool(native),'nativeFiles':native}
def main():
 wheels=sorted((B/'.artifacts/runtime/wheelhouse').glob('*.whl'));assert wheels
 with ThreadPoolExecutor(max_workers=6) as pool:rows=list(pool.map(review,wheels))
 rows.sort(key=lambda x:x['package'].lower())
 (B/'runtime/requirements.lock').write_text('\n'.join(x['package']+'=='+x['version']+' --hash=sha256:'+x['sha256'] for x in rows)+'\n')
 (B/'runtime/SBOM.json').write_text(json.dumps({'label':'ENGINEERING_CALIBRATION_ONLY','format':'Exact runtime wheel inventory v1 (not claimed CycloneDX)','components':rows,'review':'Publisher SHA256 and size verified; wheel metadata, license/notice material and native contents inspected; no source builds; no comprehensive vulnerability or legal clearance claimed','networkDependencies':'Hub/http/Xet dependencies retained because required by package graph; offline flags, download interception and OS network denial mandatory'},indent=2)+'\n')
 print('REVIEWED',len(rows),'wheels')
 for x in rows:print(x['package'],x['version'],str(x['license'])[:90], 'native='+str(x['nativeBinaryStatus']))
if __name__=='__main__':main()

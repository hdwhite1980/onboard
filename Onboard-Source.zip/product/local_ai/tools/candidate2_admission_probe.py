"""Single lightweight host snapshot. No model, tokenizer or provider imports."""
import datetime
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
E = ROOT / 'docs/sprint3a/evidence/candidate2-clean-01'
GIB = 1024**3


def run(argv):
    return subprocess.run(argv, capture_output=True, text=True, check=True, timeout=3).stdout


def main():
    stage = sys.argv[1]
    assert stage in ['clean', 'preload']
    # Exclusive marker prevents accidental repeat of either authorized probe.
    with (E / (stage + '-probe-started.json')).open('x') as stream:
        json.dump({'pid': os.getpid(), 'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat()}, stream)
    started = time.monotonic()
    vm = run(['/usr/bin/vm_stat'])
    page = int(re.search(r'page size of (\d+)', vm)[1])
    counts = {k: int(v) for k, v in re.findall(r'^(Pages [\w ]+):\s+(\d+)', vm, re.M)}
    pressure = int(run(['/usr/sbin/sysctl', '-n', 'kern.memorystatus_vm_pressure_level']))
    swap_raw = run(['/usr/sbin/sysctl', 'vm.swapusage'])
    swap_match = re.search(r'used\s*=\s*([\d.]+)([MG])', swap_raw)
    assert swap_match
    swap = int(float(swap_match[1]) * {'M': 1024**2, 'G': GIB}[swap_match[2]])
    native = json.loads(run([str(ROOT / 'product/local_ai/.artifacts/build/resource-probe'), str(os.getpid())]))
    assert native['error'] == 0 and native['phys_footprint'] is not None
    available = page * sum(counts[k] for k in ['Pages free', 'Pages inactive', 'Pages speculative'])
    reasons = []
    if available < int(5.25 * GIB):
        reasons.append('Available estimate below 5.25 GiB')
    if pressure != 1:
        reasons.append('Pressure non-normal or unknown')
    if native['thermal_state'] not in [0, 1]:
        reasons.append('Thermal state unsafe or unknown')
    # Last accepted host snapshot had zero swap. No increase is accepted.
    if swap > 0:
        reasons.append('Swap exceeds prior accepted zero-swap baseline')
    result = {
        'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'stage': stage, 'pid': os.getpid(),
        'status': 'REJECTED_PRE_EXECUTION_RESOURCE_POLICY' if reasons else 'NORMAL_ADMISSION_PASS',
        'reasons': reasons, 'physicalMemoryBytes': int(run(['/usr/sbin/sysctl', '-n', 'hw.memsize'])),
        'pageSizeBytes': page,
        'pages': {k: counts[k] for k in ['Pages free', 'Pages inactive', 'Pages speculative', 'Pages wired down', 'Pages occupied by compressor']},
        'availableEstimateBytes': available, 'wiredBytes': page * counts['Pages wired down'],
        'compressorBytes': page * counts['Pages occupied by compressor'], 'swapUsedBytes': swap,
        'pressure': pressure, 'thermal': native['thermal_state'],
        'power': run(['/usr/bin/pmset', '-g', 'batt']),
        'probePhysicalFootprintBytes': native['phys_footprint'],
        'probeResidentBytes': native['resident_size'],
        'requiredAvailableEstimateBytes': int(5.25 * GIB),
        'planningWorkingAllowanceBytes': int(3.25 * GIB), 'protectedReserveBytes': 2 * GIB,
        'shortfallBytes': max(0, int(5.25 * GIB) - available),
        'availableMethod': 'free + inactive + speculative; no subtraction or correction for verifier/probe footprint',
        'compressionInterpretation': 'Fresh snapshot baseline; not a growth measurement. Load monitoring must enforce unchanged 512 MiB growth stop.',
        'elapsedSeconds': time.monotonic() - started,
        'modelLoads': 0, 'generationRequests': 0,
        'loadedPythonModules': sorted(sys.modules),
    }
    with (E / (stage + '-admission.json')).open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'loadedPythonModules'}, indent=2))


if __name__ == '__main__':
    main()

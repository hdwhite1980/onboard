"""One exact owner-approved artifact; acquisition only, never inference."""
import hashlib,json,os,shutil,stat,struct,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'product/local_ai'; E=ROOT/'docs/sprint3a/evidence/calibration-01'
REPO='mlx-community/Qwen3-4B-Instruct-2507-4bit'
REV='50d427756c6b1b2fe0c0a10f67fbda1fc8e82c1b'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 source=ROOT/'docs/sprint3a/evidence/research/qwen3-4b-api.json'
 data=json.loads(source.read_text());assert data['sha']==REV and data['id']==REPO
 rows=data['siblings'];assert sum(x['size'] for x in rows)==2278972236
 stage=BASE/'.artifacts/staging/candidate1';stage.mkdir(exist_ok=False)
 result=[]
 for row in rows:
  name=row['rfilename'];assert Path(name).name==name and name not in ['.','..'] and not name.endswith(('.py','.so','.dylib','.sh','.bin'))
  p=stage/name;url=f'https://huggingface.co/{REPO}/resolve/{REV}/{name}'
  run=subprocess.run(['curl','--fail','--location','--silent','--show-error','--max-time','900',url,'-o',str(p)],capture_output=True,text=True)
  if run.returncode:raise RuntimeError(f'Acquisition failed: {name}: {run.stderr}')
  assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['size'],name
  sha=digest(p)
  if 'lfs' in row:assert sha==row['lfs']['sha256'],name
  else:
   b=p.read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['blobId'],name
  p.chmod(0o400)
  result.append({'path':name,'bytes':row['size'],'sha256':sha,'source':url,'publisherVerification':'LFS SHA256' if 'lfs' in row else 'Git blob SHA1 plus local SHA256'})
  (E/'acquisition-progress.json').write_text(json.dumps(result,indent=2)+'\n')
  print('VERIFIED',name,row['size'],flush=True)
 assert set(x.name for x in stage.iterdir())==set(x['rfilename'] for x in rows)
 cfg=json.loads((stage/'config.json').read_text());tok=json.loads((stage/'tokenizer_config.json').read_text())
 assert cfg['model_type']=='qwen3' and cfg['quantization']=={'bits':4,'group_size':64}
 assert not any(k in d for d in [cfg,tok] for k in ['auto_map','model_file'])
 assert tok['tokenizer_class'] in ['Qwen2Tokenizer','Qwen2TokenizerFast','PreTrainedTokenizerFast']
 with (stage/'model.safetensors').open('rb') as f:
  n=struct.unpack('<Q',f.read(8))[0];assert 0<n<16*1024**2
  head=json.loads(f.read(n));size=(stage/'model.safetensors').stat().st_size;end=0
  tensors=[]
  for name,v in head.items():
   if name=='__metadata__':continue
   lo,hi=v['data_offsets'];assert 0<=lo<=hi<=size-8-n
   assert v['dtype'] in ['U32','BF16','F16','F32'];assert all(type(x)==int and 0<x<1000000 for x in v['shape'])
   tensors.append((lo,hi))
  for lo,hi in sorted(tensors):assert lo==end;end=hi
  assert end==size-8-n
 license_dir=stage/'licenses';license_dir.mkdir()
 shutil.copyfile(ROOT/'docs/sprint3a/evidence/research/qwen3-4b-upstream-LICENSE',license_dir/'Apache-2.0.txt')
 notice={'inventory':'TECHNICAL LICENSE INVENTORY','modelPublisher':'Qwen','conversionPublisher':'mlx-community','reviewedUpstream':'Qwen/Qwen3-4B-Instruct-2507','reviewedUpstreamRevision':'cdbee75f17c01a7cc42f958dc650907174af0554','modelTerms':'Apache-2.0','tokenizer':'Bundled tokenizer SHA256 matches reviewed upstream declaration; no separate tokenizer grant asserted','conversion':'Publisher reports mlx-lm 0.26.2; exact original source revision and reproducible command not independently attested','localModifications':'No weight/config/tokenizer conversion or modification; license inventory added','notices':'Retain Apache license and applicable attribution; no upstream NOTICE file in reviewed inventory','clearance':'No government procurement/CUI/legal clearance or training-data indemnification'}
 (license_dir/'inventory.json').write_text(json.dumps(notice,indent=2)+'\n')
 for p in sorted(license_dir.iterdir()):result.append({'path':str(p.relative_to(stage)),'bytes':p.stat().st_size,'sha256':digest(p),'source':'Retained pinned upstream license / local technical inventory'})
 manifest={'label':'ENGINEERING_CALIBRATION_ONLY','modelID':'org.experimental.qwen3-4b-instruct-2507.mlx4-g64','repository':REPO,'revision':REV,'state':'EXPERIMENTAL','qualifiedTasks':[],'quantization':cfg['quantization'],'files':sorted(result,key=lambda x:x['path']),'remoteCodeRequired':False,'safetensorsTensors':len(tensors),'provenanceLimitation':notice['conversion']}
 raw=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode();ident=hashlib.sha256(raw).hexdigest()
 (stage/'manifest.json').write_bytes(raw)
 dest=BASE/'.artifacts/store'/ident;assert not dest.exists();os.rename(stage,dest)
 for p in dest.rglob('*'):
  if p.is_file():p.chmod(0o400)
 (E/'package.json').write_text(json.dumps({'manifestSHA256':ident,'store':str(dest),'manifest':manifest},indent=2)+'\n')
 print('PACKAGE_VERIFIED',ident,flush=True)
if __name__=='__main__':main()

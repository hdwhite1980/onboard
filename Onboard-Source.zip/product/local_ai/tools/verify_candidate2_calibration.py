"""Read-only retained-runtime/package verification and bounded prompt preparation."""
import datetime
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
E = ROOT / 'docs/sprint3a/evidence/candidate2-calibration-01'
PREVIOUS = ROOT / 'docs/sprint3a/evidence/candidate2-clean-01'
LABEL = 'ENGINEERING_CALIBRATION_ONLY'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(name, value):
    with (E / name).open('x') as stream:
        json.dump({'label': LABEL, **value}, stream, indent=2)
        stream.write('\n')


def main():
    # Reuse identity checks, directing fresh evidence to a separate directory.
    path = ROOT / 'product/local_ai/tools/candidate2_verify_clean.py'
    spec = importlib.util.spec_from_file_location('retained_verifier', path)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    verifier.EVIDENCE = E
    verifier.save = save
    verifier.main()
    assert json.loads((E / 'runtime-reverification.json').read_text())['status'] == 'PASS'
    previous_manifest = json.loads((PREVIOUS / 'EVIDENCE_MANIFEST.json').read_text())
    for item in previous_manifest['files']:
        assert sha(ROOT / item['path']) == item['sha256'], item['path']
    package = json.loads((PREVIOUS / 'package.json').read_text())
    ident = '1721e23c79d4367cb3e12a6811aabd61a8526c511b0f30f7134ecaeb40ef0778'
    assert package['manifestSHA256'] == ident
    activation = json.loads((PREVIOUS / 'activation.json').read_text())
    assert activation['manifestSHA256'] == ident
    checked = []
    for root in [Path(package['store']), Path(activation['snapshot'])]:
        assert root.is_dir() and not root.is_symlink()
        assert sha(root / 'manifest.json') == ident
        manifest = json.loads((root / 'manifest.json').read_text())
        assert manifest['repository'] == 'mlx-community/Qwen3-1.7B-4bit'
        assert manifest['revision'] == '3b1b1768f8f8cf8351c712464f906e86c2b8269e'
        expected = {row['path'] for row in manifest['files']} | {'manifest.json'}
        assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == expected
        for p in root.rglob('*'):
            assert not p.is_symlink(), p
        for row in manifest['files']:
            p = root / row['path']
            assert p.stat().st_nlink == 1 and not (p.stat().st_mode & 0o222), p
            assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], p
        checked.append({'path': str(root), 'manifestSHA256': ident, 'filesVerified': len(manifest['files'])})
    snap = Path(activation['snapshot'])
    tc = json.loads((snap / 'tokenizer_config.json').read_text())
    old_budget = json.loads((PREVIOUS / 'token-budget.json').read_text())
    assert hashlib.sha256(tc['chat_template'].encode()).hexdigest() == old_budget['chatTemplateSHA256']
    def audit(event, args):
        if event.startswith('socket.') and event != 'socket.__new__':
            raise RuntimeError('Unexpected verification network activity: ' + event)
    sys.addaudithook(audit)
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(snap), local_files_only=True, trust_remote_code=False)
    messages = [
        {'role': 'system', 'content': 'Rewrite only. Preserve names, dates and meaning. Do not add facts.'},
        {'role': 'user', 'content': 'hey sarah just wanted to see if you figured out what was going on with the encryption issue because we need to know if this is going to mess up the october 3 deployment'},
    ]
    prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, enable_thinking=False)
    assert prompt.endswith('<|im_start|>assistant\n<think>\n\n</think>\n\n')
    ids = tokenizer.encode(prompt, add_special_tokens=False)
    assert ids == tokenizer.apply_chat_template(messages, tokenize=True, return_dict=False, add_generation_prompt=True, enable_thinking=False)
    assert len(ids) + 128 <= 512
    assert not any(n == 'mlx' or n.startswith('mlx.') or n == 'mlx_lm' or n.startswith('mlx_lm.') for n in sys.modules)
    save('token-budget.json', {'modelManifestSHA256': ident, 'messages': messages, 'rawPrompt': prompt,
         'tokenIDs': ids, 'promptTokens': len(ids), 'maxNewTokens': 128, 'totalContextLimit': 512,
         'maximumAccountedTokens': len(ids) + 128, 'batch': 1, 'KV': 'FP16', 'thinking': False,
         'chatTemplateSHA256': old_budget['chatTemplateSHA256'],
         'generation': {'sampler': 'greedy argmax', 'temperature': 0, 'kv_bits': None,
                        'prefill_step_size': 128, 'max_tokens': 128, 'stop': 'tokenizer eos_token_ids'},
         'localFilesOnly': True, 'trustRemoteCode': False})
    save('package.json', package)
    save('activation.json', activation)
    save('verification.json', {'status': 'PASS', 'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'pid': os.getpid(), 'roots': checked, 'previousEvidenceFilesUnchanged': len(previous_manifest['files']),
         'templateUnchanged': True, 'tokenizerUnchanged': True, 'runtimeUnchanged': True,
         'mlxImported': False, 'modelLoads': 0, 'generationRequests': 0})
    print(json.dumps({'label': LABEL, 'status': 'VERIFICATION_PASS', 'pid': os.getpid(),
                      'promptTokens': len(ids), 'maximumAccountedTokens': len(ids) + 128}))


if __name__ == '__main__':
    main()

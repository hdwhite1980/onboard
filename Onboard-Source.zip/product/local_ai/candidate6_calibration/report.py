"""Write owner-requested reports from the sealed single-attempt evidence only."""
import json
from pathlib import Path
import common as c
D=c.ROOT/'docs/sprint3a';E=c.E;G=1024**3
read=lambda n:json.loads((E/n).read_text())
pkg=read('package.json');acq=read('acquisition.json');art=read('artifact-verification.json');pre=read('tokenizer-runtime-check.json');m=read('measurements.json');r=m['result'];decision=read('decision.json')
def write(name,text):
 with (D/name).open('x') as f:f.write(text.rstrip()+'\n')
def gib(n):return f'{n/G:.6f} GiB'
def link(name):return f'[evidence/{E.name}/{name}](evidence/{E.name}/{name})'
write('CANDIDATE6_EXPERIMENT_EXCEPTION.md',f'''# Candidate 6 — owner-specific experimental provenance exception

Owner instruction preserved verbatim in {link('owner-authorization.txt')}. This is a new Candidate 6 exception, not reuse of Candidate 5's exception.

Exact identity: `{c.REPO}` at `{c.REV}`. Declared upstream `{c.UPSTREAM}`; research pin `{c.UPREV}` is **not** an attested conversion input.

- Exception: **EXPERIMENTAL_PROVENANCE_EXCEPTION**.
- Execution admission: **UNMEASURED_PROFILE_OWNER_AUTHORIZED_CALIBRATION**, exactly once.
- Scope: **LOCAL_ENGINEERING_EVALUATION_ONLY**.
- Lifecycle: EXPERIMENTAL; qualified tasks: NONE.
- Holds: **TOKENIZER_PROVENANCE_PENDING**, **CONVERSION_REPRODUCIBILITY_PENDING**, **NO_REDISTRIBUTION**.
- Distribution: **PROHIBITED_PENDING_REVIEW**.

Apache-2.0 is the declared upstream model license; it does not settle historical tokenizer provenance or prove the conversion's exact input revision and reproducibility. The package preserves the upstream license verbatim and adds a clearly organization-authored limitation record, not an invented upstream NOTICE. No newly acquired alternative artifact, official BF16 model, or Gemma model is included.

The only bypass was the unmeasured planning requirement for >9.75 GiB legacy-equivalent headroom. The 2 GiB protected reserve, <=2.25 GiB early stop, 7.5 GiB worker ceiling, NORMAL pressure, zero initial swap/no growth/no activity, nominal/fair thermal, fresh telemetry, network denial and all deadlines remained enforced. Compression alone remained diagnostic.

The exact plan was one load, one professional-1 generation if safely loaded, and one unload if reached; no retries. The actual attempt stopped during its one load on WARN pressure, before generation or cooperative unload. The full 16-case corpus was rendered only for token budgets. No later quality suite, sustained test, RAG/meeting/adversarial phase, production catalog promotion, deployment, CUI/FCI processing or Sprint 3B occurred.

Outcome: `{decision['decision']}`. Owner authorization does not confer production, customer, government, procurement, redistribution or CUI clearance.
''')
rows='\n'.join(f"| `{x['path']}` | {x['bytes']:,} | `{x['sha256']}` |" for x in pkg['manifest']['files'])
publisher='\n'.join(f"| `{x['path']}` | `{x['gitBlobID']}` | {x['publisherHashType']}: `{x['publisherHash']}` |" for x in acq['files'])
write('CANDIDATE6_PACKAGE.md',f'''# Candidate 6 — verified local experimental package

**PASS: exact publisher identity and complete tensor inventory.**

Repository `{c.REPO}`; revision `{c.REV}`. The 13 publisher files total **5,977,073,303 bytes**; the two weight shards total **5,950,221,072 bytes**. Eleven previously acquired pinned metadata files were copied after Git/LFS verification; only the two authorized shards were downloaded, into a new quarantine. Both curl transfers exited 0 without retry. See {link('download-exits.json')} and {link('acquisition.json')}.

Package ID: `org.experimental.qwen3.5-9b.mlx4-g64`.

Manifest SHA-256: `{pkg['manifestSHA256']}`.

Content-addressed store: `{pkg['store']}`.

Full manifest and source-purpose records: {link('package.json')}. There are 15 payload files: 13 unchanged publisher files plus the verbatim upstream license and organization limitation record. `manifest.json` is additional to those 15. Full vision weights are retained; no stripped derivative was created.

| Payload file | Bytes | Complete local SHA-256 |
|---|---:|---|
{rows}

| Publisher file | Git blob identity | Publisher content identity |
|---|---|---|
{publisher}

All publisher file sizes and Git blob/LFS identities matched the pinned API inventory. Descriptor-based verification checked allowlists, safe paths, no symlink ancestors/members, regular single-link files, UID ownership, non-executable payload, stable metadata and post-read/root identities. Private package and activation copies are read-only. The immediately pre-load activation verification passed; no runtime or model repository Python was installed/executed. Same-UID post-verification path changes remain a development-security limitation because the unchanged MLX loader subsequently opens paths.

All **1,260 tensor names, shapes and dtypes** matched an independently config-derived 9B inventory. The index mapped every entry to the correct shard; all contiguous offsets and byte totals matched. **927 language entries** occupy 5,038,041,600 tensor bytes; **333 BF16 vision entries** occupy 912,020,960 tensor bytes. No MTP entries exist. Affine 4-bit/group-64 projections are U32-packed; scales/biases and other floating weights have verified BF16/F32 types. Full header evidence: {link('safetensors-header.json')}; verification: {link('artifact-verification.json')}.

Config, tokenizer/config, vocab, template and processor JSON were parsed and publisher-verified; duplicate JSON keys were rejected, vocab matched tokenizer vocab, and no remote-code declarations were present. Processor configs remained inert. No vision tower/merger or image/video processor was intentionally instantiated.

Lifecycle EXPERIMENTAL; qualified tasks NONE. TOKENIZER_PROVENANCE_PENDING; CONVERSION_REPRODUCIBILITY_PENDING; actual conversion input revision UNATTESTED; NO_REDISTRIBUTION; distribution PROHIBITED_PENDING_REVIEW.
''')
suite=read('frozen-suite.json')['requests'];budgetrows='\n'.join(f"| {x['id']} | {x['promptTokens']} | 128 | {x['accountedTokens']} | PASS |" for x in suite)
write('CANDIDATE6_TOKENIZER_PREFLIGHT.md',f'''# Candidate 6 — offline tokenizer/config preflight

**PASS**, with zero model constructions, zero weight loads and zero generations. The package was fully verified before this preflight. The same retained runtime was verified against 34 packages and 5,555 installed wheel files; no installation or upgrade occurred. Python 3.12.14 arm64; MLX/MLX-metal 0.32.2; MLX-LM 0.31.3; Transformers 5.17.0; tokenizers 0.23.2.

The process ran under macOS network denial; deliberate loopback connect returned EPERM. Hub downloads, network/process operations, weight-opening APIs and model constructors were blocked. `trust_remote_code=False`, `local_files_only=True`; no processor or multimodal input path was used. Full result: {link('tokenizer-runtime-check.json')}.

The built-in `mlx_lm.models.qwen3_5` class resolved and 32-layer dense text arguments parsed. Three tokenizer paths agreed on 20 ordinary round-trip cases (numbers, dates, currency, percentages, versions, names, Project Falcon identifiers and formatting). All {len(pre['specialTokens'])} special-token IDs matched.

The exact native 9B template was used with explicit **enable_thinking=False**, tools=None and an empty, closed `<think>` block. System/user roles and no-system rendering matched exact strings. The default thinking branch was not used. There was no prompt tuning, truncation, soft /think command, reasoning rescue or generation.

- Template SHA-256: `{pre['templateSHA256']}`.
- Tokenizer SHA-256: `{pre['tokenizerSHA256']}`.
- Conversational EOS/stop set: **[248046]**.
- Nested text-config EOS/pad ID: 248044. The installed wrapper uses tokenizer EOS because top-level config has no EOS override; the nested EOS was not substituted for the conversational stop.
- First professional-1 prompt: **114 tokens**; reserved output: **128**; total accounted: **242/512**.
- Largest accounted budget: **{pre['maximumAccountedTokens']}/512**.

All 16 exact Candidate 2 substantive message pairs were rendered. Source fixture SHA-256: `{pre['sourceSHA256']}`. All input messages, rendered text, token IDs/counts, hashes, stop set and thinking state were frozen before construction in {link('frozen-suite.json')} and {link('future-first-prompt.json')}. Only professional-1 appears in the run's one-request manifest; none was generated because loading aborted.

| Fixture | Prompt | Reserved output | Accounted total | Fit |
|---|---:|---:|---:|---|
{budgetrows}

Twenty-six pure adapter tests passed before execution, including resource boundaries, stale/unknown telemetry, expansion refusal, exact 9B inventory and one-request-only scope. Tested source hashes and copies are retained under `calibration/source` and `calibration/tested-source.json`. This is tokenizer/config compatibility evidence; a completed 9B load, cache population and generation remain unverified.
''')
shards='; '.join(f"{x['file']}: {x['loadedTensorEntries']} entries, {x['visionTensorEntries']} vision" for x in m['visionShardObservations'])
write('CANDIDATE6_CALIBRATION.md',f'''# Candidate 6 — one-shot M3 / 16 GiB calibration

**{decision['decision']}**

Primary: **{r['primary']}**. Supervisor: **{r['supervisor']}**. Evidence completeness: **{r['evidenceCompleteness']}**. No retry.

The baseline passed after {m['naturalSettlingSeconds']:.3f} seconds of natural settling following completed verification/preparation. Headroom was {gib(m['baselineHeadroomBytes'])}, pressure NORMAL, swap zero, thermal nominal and power AC. No applications were closed, security software stopped, caches purged, VM settings changed or synthetic pressure allocated by this task.

The single load reached text-only construction and binding of packed language parameters, then pressure became **WARN during eager weight evaluation**. The monitor stopped execution. No model-load completion event, generation request, response, cache population or cooperative unload occurred. The nominal 7.5 GiB ceiling and 2.25 GiB early-headroom threshold were not the triggering guards; NORMAL pressure is independently mandatory.

| Owner item | Recorded result |
|---|---|
| A. Exact artifact | `{c.REPO}` at `{c.REV}` |
| B. Complete hashes | [CANDIDATE6_PACKAGE.md](CANDIDATE6_PACKAGE.md), all 15 payload hashes and publisher Git/LFS identities |
| C. Manifest | `{pkg['manifestSHA256']}`; {link('package.json')} |
| D. Provenance | TOKENIZER_PROVENANCE_PENDING; CONVERSION_REPRODUCIBILITY_PENDING; NO_REDISTRIBUTION |
| E. Preflight | PASS: offline tokenizer/config only, all 16 fixtures fit, no truncation |
| F. First prompt | 114 tokens + 128 reserved = 242/512, native template, explicit nonthinking |
| G. Runtime | Exact retained runtime passes 34-package/5,555-file checks; dynamic text construction/binding succeeded; completed load/cache/inference compatibility unverified |
| H. Text construction | Built-in `mlx_lm.models.qwen3_5.Model` constructed text modules only; no vision/processor modules observed |
| I. Vision | Both complete shards opened: {shards}. 333 vision entries/912,020,960 logical bytes observed; physical residency not isolated |
| J. Network/providers | Same worker loopback negative control DENIED (EPERM/1) before load; offline flags, no remote code/downloads; no configured provider/fallback/tool; no forbidden provider module/Foundation Models image observed |
| K. Load | Aborted; no successful load duration. Load-start to first WARN {m['loadBeginToFirstWarnSeconds']:.6f} s; to TERM journal {m['loadBeginToTERMJournalSeconds']:.6f} s |
| L. Worker peak | Physical footprint {gib(m['nativeBounds']['workerPhysicalFootprintBytes']['max'])} ({m['nativeBounds']['workerPhysicalFootprintBytes']['max']:,} bytes); RSS {gib(m['nativeBounds']['workerResidentBytes']['max'])} |
| M. MLX | Observed maximum active/peak {gib(m['mlxObservedBounds']['active']['max'])} ({m['mlxObservedBounds']['active']['max']:,} bytes); cache {m['mlxObservedBounds']['cache']['max']:,} bytes |
| N. Headroom | Minimum {gib(m['nativeBounds']['availableEstimateLegacyBytes']['min'])}; legacy estimate, not a guarantee of resident capacity |
| O. Compression | Baseline {gib(m['baselineCompressionBytes'])}; maximum {gib(m['nativeBounds']['compressorOccupancyBytes']['max'])}; maximum increase {gib(m['nativeBounds']['compressorDeltaBytes']['max'])}. Diagnostic only; did not independently trigger stop |
| P. Swap | Initial/maximum/growth 0 bytes; swap-in/out deltas 0 pages; recovery also zero |
| Q. Pressure/thermal | NORMAL → WARN during load; all 12 recovery samples NORMAL. Thermal nominal throughout; AC |
| R. Raw response | None. Zero generation requests and no partial generated text |
| S. Semantics | Not evaluated: no response. No claim about Sarah/encryption/date/uncertainty/tone or first-response quality |
| T. Unload/recovery | No cooperative unload reached. Worker reaped with exit -15; group absent. Twelve recovery samples at ~250 ms, headroom {gib(m['recoveryHeadroomBounds']['min'])}–{gib(m['recoveryHeadroomBounds']['max'])} |
| U. Supervisor/evidence | TERM SENT; immediate zero-grace KILL attempt returned EPERM. Retain TERMINATION_PERMISSION_ERROR / PARTIAL despite later absence. Helper cleanup complete and all four threads joined |
| V. Measured envelope | **Cannot be called MEASURED_EXPERIMENTAL**: complete safe load/generation/unload path failed |
| W. Remaining blockers | Historical tokenizer lineage unresolved; conversion input revision unattested and reproducibility incomplete; no redistribution or qualification |
| X. Recommendation | **Do not authorize the 16-case suite yet.** Resource calibration did not complete and the worker's hard-stop KILL permission outcome requires separate investigation before further model execution |

## Packed storage and vision observations

The unmodified retained loader opened both root safetensors shards before constructing the text model. At those boundaries, MLX active counters remained 8 bytes; this is consistent with deferred realization but **does not prove zero file mapping or vision residency**. Full publisher vision payload remains in both package and private snapshot. No image/video processor, vision tower or merger was constructed by the observed text path.

All **927 bound language parameters** matched exact expected shapes/dtypes before eager evaluation, including **250 U32 packed arrays**, with 5,038,041,600 logical tensor bytes. Eager-evaluation arguments included **561,670,656 floating bytes**, not a 16+ GiB BF16 language copy. No full-precision expansion was observed. Metadata guards rejected changed packed shapes/dtypes, >2 GiB aggregate floating eager arguments, and unexpected dequantize calls during loading. These are guarded boundaries, not proof against every unobservable internal native allocation. The independent footprint/pressure guards remained active. The eager evaluation did not finish; subsequent compute cast, caches and generation were never reached.

## Monitoring and termination evidence

There were {m['nativeSampleCount']} native samples; median interval {m['nativeIntervalsSeconds']['median']:.6f} s and maximum {m['nativeIntervalsSeconds']['max']:.6f} s. Maximum native sample age was {m['nativeBounds']['sampleAgeSeconds']['max']:.6f} s; maximum reported MLX event age {m['nativeBounds']['mlxSampleAgeSeconds']['max']:.6f} s, both below 1.5 s. The asynchronous pressure subscription was enabled before runtime initialization; WARN was detected in polled native telemetry, with no asynchronous WARN notification recorded. Independent watchdog and termination threads were active.

First WARN was recorded at monotonic {m['firstWarnSample']['monotonic']:.9f}; the TERM signal journal began {m['warnSampleToTERMJournalSeconds']:.6f} seconds later. This journal timing is not a kernel acknowledgement timestamp. TERM was sent; the zero-grace wait timed out as expected and KILL returned errno 1/EPERM. The worker was later reaped with exit -15 and the group was absent. The exact cause of EPERM is not established by this evidence; do not relabel it a harmless race or successful KILL. The qualified helper used its separate 100 ms cleanup allowance, exited on TERM, and required no KILL. All monitor, watchdog, terminator and reader threads joined.

The recovery rows' MLX fields are carried-forward pretermination values, with growing ages; they are **not live post-exit allocator measurements** and are excluded from the allocator peak summary. Worker physical memory after exit is unavailable rather than a measured zero. Twelve independent native recovery samples showed NORMAL pressure, nominal thermal, zero swap and worker/group absence. Compressor occupancy remained above baseline by {gib(m['recoveryCompressorDeltaBounds']['min'])}–{gib(m['recoveryCompressorDeltaBounds']['max'])} during the bounded recovery window; complete host restoration to the exact pre-load state is not claimed.

Resource peaks are sampled observed maxima and may miss sub-sample transients. This is a failed measurement on this host/session, not proof that every M3/16 GiB state can never load this artifact. It provides no normal-product admission, sustained, 2048-context, RAG, meeting or quality qualification.

The original result and run manifests remain untouched. See {link('measurements.json')}, {link('calibration/run-result.json')}, {link('calibration/lifecycle/termination.json')}, {link('calibration/lifecycle/recovery.json')}, {link('calibration/helper-cleanup-and-joins.json')} and {link('decision.json')}. Post-run analysis and sealing do not upgrade the recorded PARTIAL status.

Stop boundary honored: one load attempted, zero requests generated, no retry, no 16-case session and no Sprint 3B.
''')
comparison=D/'LOCAL_MODEL_COMPARISON.md';before=(E/'comparison-before.md').read_bytes();assert comparison.read_bytes()==before
with comparison.open('a') as f:f.write(f'''\n\n## Candidate 6 — owner-authorized single calibration (2026-09-23)

Exact `mlx-community/Qwen3.5-9B-4bit@{c.REV}`; new Candidate6-specific experimental provenance exception. Both authorized shard hashes and all 1,260 tensor shapes/dtypes verified; full vision payload retained. Offline native nonthinking tokenizer preflight passed all 16 frozen Candidate2 fixtures (first 114 tokens, maximum 287 including 128 reserved). Retained runtime verified; no runtime change.

On this M3/16 GiB session, the one load attempt aborted on **WARN memory pressure during eager evaluation**. Baseline headroom {gib(m['baselineHeadroomBytes'])}; observed worker peak {gib(m['nativeBounds']['workerPhysicalFootprintBytes']['max'])}; observed MLX active/peak {gib(m['mlxObservedBounds']['active']['max'])}; minimum headroom {gib(m['nativeBounds']['availableEstimateLegacyBytes']['min'])}; maximum compression delta {gib(m['nativeBounds']['compressorDeltaBytes']['max'])}. Swap/activity remained zero and thermal nominal. Compression alone was not a stop. Text construction and packed binding succeeded; load completion, generation and cooperative unload did not occur. No quality comparison can be made.

Primary MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2; supervisor TERMINATION_PERMISSION_ERROR; evidence PARTIAL (TERM sent, KILL EPERM; subsequently reaped -15/group absent). All 12 recovery samples NORMAL and worker absent; helper cleanup/join complete. **Not MEASURED_EXPERIMENTAL.** One load attempted, zero generations, no retry or 16-case suite. TOKENIZER_PROVENANCE_PENDING, CONVERSION_REPRODUCIBILITY_PENDING and NO_REDISTRIBUTION remain; qualified tasks NONE. [Full calibration evidence](CANDIDATE6_CALIBRATION.md).
''')
print('Four reports created; comparison appended without altering historical prefix.')

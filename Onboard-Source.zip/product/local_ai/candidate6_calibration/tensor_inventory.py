"""Independent config-derived 9B shape/dtype inventory; inert safetensors parsing only."""
import hashlib,json,math,struct

def expected_inventory():
 out={}
 def add(n,shape,dtype='BF16'):out[n]={'shape':shape,'dtype':dtype}
 def quant(n,o,i):
  add(n+'.weight',[o,i//8],'U32')
  for suffix in ('scales','biases'):add(n+'.'+suffix,[o,i//64])
 base='language_model.'
 quant(base+'model.embed_tokens',248320,4096);quant(base+'lm_head',248320,4096)
 add(base+'model.norm.weight',[4096])
 for i in range(32):
  b=base+f'model.layers.{i}.'
  for norm in ('input_layernorm','post_attention_layernorm'):add(b+norm+'.weight',[4096])
  for n,o,inp in [('gate_proj',12288,4096),('up_proj',12288,4096),('down_proj',4096,12288)]:quant(b+'mlp.'+n,o,inp)
  if i%4==3:
   for n,o,inp in [('q_proj',8192,4096),('k_proj',1024,4096),('v_proj',1024,4096),('o_proj',4096,4096)]:quant(b+'self_attn.'+n,o,inp)
   for n in ('q_norm','k_norm'):add(b+'self_attn.'+n+'.weight',[256])
  else:
   b+='linear_attn.'
   add(b+'A_log',[32],'F32');add(b+'dt_bias',[32]);add(b+'conv1d.weight',[8192,4,1]);add(b+'norm.weight',[128])
   for n,o,inp in [('in_proj_a',32,4096),('in_proj_b',32,4096),('in_proj_qkv',8192,4096),('in_proj_z',4096,4096),('out_proj',4096,4096)]:quant(b+n,o,inp)
 v='vision_tower.'
 for i in range(27):
  b=v+f'blocks.{i}.'
  for n,o,inp in [('attn.proj',1152,1152),('attn.qkv',3456,1152),('mlp.linear_fc1',4304,1152),('mlp.linear_fc2',1152,4304)]:
   add(b+n+'.weight',[o,inp]);add(b+n+'.bias',[o])
  for n in ('norm1','norm2'):
   for suffix in ('weight','bias'):add(b+n+'.'+suffix,[1152])
 for n,o,inp in [('merger.linear_fc1',4608,4608),('merger.linear_fc2',4096,4608)]:
  add(v+n+'.weight',[o,inp]);add(v+n+'.bias',[o])
 for suffix in ('weight','bias'):add(v+'merger.norm.'+suffix,[1152])
 add(v+'patch_embed.proj.weight',[1152,2,16,16,3]);add(v+'patch_embed.proj.bias',[1152]);add(v+'pos_embed.weight',[2304,1152])
 return out

def unique(pairs):
 d={}
 for k,v in pairs:
  assert k not in d,'Duplicate JSON key: '+k;d[k]=v
 return d

def verify_headers(root,shards):
 expected=expected_inventory();idx=json.loads((root/'model.safetensors.index.json').read_text(),object_pairs_hook=unique)
 assert set(idx['weight_map'])==set(expected) and set(idx['weight_map'].values())==set(shards)
 all_tensors={};details=[];counts={'language':0,'vision':0};totals=dict.fromkeys(counts,0);dtypes={}
 for filename,(length,sha) in shards.items():
  fpath=root/filename;assert fpath.stat().st_size==length
  with fpath.open('rb') as f:
   size=struct.unpack('<Q',f.read(8))[0];assert 0<size<16*1024**2
   raw=f.read(size);header=json.loads(raw,object_pairs_hook=unique)
  tensors={k:v for k,v in header.items() if k!='__metadata__'}
  assert set(tensors)=={k for k,v in idx['weight_map'].items() if v==filename}
  end=0
  for name,t in sorted(tensors.items(),key=lambda kv:kv[1]['data_offsets'][0]):
   assert set(t)=={'dtype','shape','data_offsets'} and all(type(n)is int and n>0 for n in t['shape']),name
   assert {k:t[k] for k in ('shape','dtype')}==expected[name],(name,t,expected[name])
   start,stop=t['data_offsets'];assert type(start)is int and type(stop)is int and start==end and stop>=start
   assert stop-start==math.prod(t['shape'])*{'BF16':2,'F32':4,'U32':4}[t['dtype']]
   kind='language' if name.startswith('language_model.') else 'vision'
   counts[kind]+=1;totals[kind]+=stop-start;dtypes[t['dtype']]=dtypes.get(t['dtype'],0)+1;end=stop
  assert 8+size+end==length
  all_tensors.update(tensors)
  details.append({'file':filename,'headerBytes':size,'headerSHA256':hashlib.sha256(raw).hexdigest(),'entries':len(tensors),'tensorBytes':end})
 assert counts=={'language':927,'vision':333}
 assert totals=={'language':5038041600,'vision':912020960}
 assert sum(totals.values())==idx['metadata']['total_size']==5950062560
 return all_tensors,{'tensorCounts':counts,'tensorBytes':totals,'dtypes':dtypes,'shards':details,'all1260ShapesAndDtypesMatchDerived9BInventory':True,'noMTP':True,'noGapsOrOverlaps':True,'indexMappingsExact':True}

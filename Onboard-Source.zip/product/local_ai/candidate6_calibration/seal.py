"""Verify and seal records, preserving the failed/partial run exactly. No inference."""
import json,shutil
from pathlib import Path
import common as c
E=c.E;P=E/'calibration'
old=json.loads((E/'historical-before.json').read_text())
for row in old:assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path']
assert (c.ROOT/'docs/sprint3a/LOCAL_MODEL_COMPARISON.md').read_bytes().startswith((E/'comparison-before.md').read_bytes())
for row in json.loads((P/'tested-source.json').read_text())['files']:assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path']
for row in json.loads((P/'run-manifest.json').read_text())['files']:assert c.sha(P/row['path'])==row['sha256'],row['path']
r=json.loads((P/'run-result.json').read_text());assert r['primary']=='MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2' and r['supervisor']=='TERMINATION_PERMISSION_ERROR' and r['evidenceCompleteness']=='PARTIAL'
assert r['workerLaunches']==r['modelLoads']==r['modelLoadCommands']==1 and r['generationRequests']==r['generationBegins']==r['unloadRequests']==0
assert r['workerExitCode']==-15 and r['processGroupPresent'] is False
assert not list(P.glob('response-*.json')) and not (E/'quality').exists()
events=[json.loads(s) for s in (P/'worker-events.jsonl').read_text().splitlines()]
assert not any(x['event'] in ('MODEL_LOADED','generation_begin','generated','unloaded') for x in events)
assert any(x['event']=='network_negative_control' and x['denied'] for x in events)
assert any(x['event']=='weight_binding_end' and x['packedStorageVerification']['entries']==927 for x in events)
cleanup=json.loads((P/'helper-cleanup-and-joins.json').read_text());assert cleanup['clean'] and all(j['completed'] for j in cleanup['joins'])
recover=json.loads((P/'lifecycle/result.json').read_text())['recovery']['samples'];assert len(recover)==12 and all(not x['workerPresent'] and not x['processGroupMembers'] and x['memoryPressure']=='NORMAL' and x['swapUsedBytes']==0 for x in recover)
pkg=json.loads((E/'package.json').read_text());verified=c.verify_package(Path(pkg['store']),pkg['manifestSHA256'],pkg['verification']['rootIdentity'])
reports=['CANDIDATE6_EXPERIMENT_EXCEPTION.md','CANDIDATE6_PACKAGE.md','CANDIDATE6_TOKENIZER_PREFLIGHT.md','CANDIDATE6_CALIBRATION.md','LOCAL_MODEL_COMPARISON.md']
(E/'reports').mkdir()
for name in reports:shutil.copyfile(c.ROOT/'docs/sprint3a'/name,E/'reports'/name)
(E/'post-run-source').mkdir()
for name in ('analyze.py','report.py','seal.py'):shutil.copyfile(Path(__file__).with_name(name),E/'post-run-source'/name)
c.save('final-verification.json',{'status':'EVIDENCE_PRESERVATION_VERIFIED','decision':'CANDIDATE6_RESOURCE_CALIBRATION_FAILED','primary':r['primary'],'supervisor':r['supervisor'],'evidenceCompleteness':r['evidenceCompleteness'],'historicalFilesUnchanged':len(old),'historicalComparisonPrefixUnchanged':True,'frozenSourceAndOriginalRunManifestUnchanged':True,'loadsAttempted':1,'loadsCompleted':0,'generations':0,'cooperativeUnloads':0,'retries':0,'workerExitCode':-15,'workerGroupAbsent':True,'helperCleanupAndJoinsComplete':True,'recoverySamples':12,'packageReverified':verified,'resourceClassification':'NOT_MEASURED_EXPERIMENTAL','qualifiedTasks':[],'provenance':['TOKENIZER_PROVENANCE_PENDING','CONVERSION_REPRODUCIBILITY_PENDING','NO_REDISTRIBUTION'],'laterPhasesExecuted':[],'note':'Successful integrity sealing does not upgrade the original PARTIAL supervisor/evidence outcome.'})
files=[{'path':str(p.relative_to(E)),'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in sorted(E.rglob('*')) if p.is_file() and p.name!='EVIDENCE_MANIFEST.json']
c.save('EVIDENCE_MANIFEST.json',{'files':files,'historicalPreserved':len(old),'originalRunEvidenceCompleteness':'PARTIAL','note':'Self excluded; immutable run plus separate post-run analysis/report snapshots. No inference on analysis/seal.'})
print(json.dumps({'status':'SEALED_NOT_QUALIFIED','files':len(files),'manifestSHA256':c.sha(E/'EVIDENCE_MANIFEST.json'),'historicalFilesUnchanged':len(old),'decision':'CANDIDATE6_RESOURCE_CALIBRATION_FAILED'}))

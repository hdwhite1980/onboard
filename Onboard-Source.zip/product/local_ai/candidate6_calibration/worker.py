"""One Qwen3.5 load, one frozen request, one unload, supervised externally. No alternative backend."""
import ctypes
import datetime
import errno
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import socket
import sys
import threading
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p
sys.path.insert(0,str(p.B/'candidate6_calibration'))
import common as c

phase='startup';mx=None;done=threading.Event();lock=threading.Lock()
def emit(event,**data):
    with lock:print(json.dumps(dict(label=p.LABEL,event=event,phase=phase,monotonic=time.monotonic(),**data)),flush=True)
def memory():
    return {'active':mx.get_active_memory(),'cache':mx.get_cache_memory(),'peak':mx.get_peak_memory()} if mx else None
def images():
    lib=ctypes.CDLL(None);lib._dyld_image_count.restype=ctypes.c_uint32
    lib._dyld_get_image_name.argtypes=[ctypes.c_uint32];lib._dyld_get_image_name.restype=ctypes.c_char_p
    names=[lib._dyld_get_image_name(i).decode() for i in range(lib._dyld_image_count())]
    assert not any('foundationmodels' in n.lower() for n in names),'FORBIDDEN_FOUNDATION_MODELS_IMAGE'
    assert not any(n.split('.')[0].lower() in ['openai','anthropic','ollama','litellm','foundationmodels'] for n in sys.modules),'FORBIDDEN_PROVIDER_MODULE'
    return names
def command(expected):
    row=json.loads(sys.stdin.readline());assert row=={'command':expected},'Unexpected protocol command'
def telemetry():
    while not done.wait(.1):
        try:emit('mlx_memory',memory=memory())
        except BaseException as error:emit('fatal',classification='RUNTIME',error=repr(error));os._exit(70)

def cache_record(caches,layer_types,populated=False):
    rows=[];totals={'attentionAllocatedBytes':0,'recurrentArrayBytes':0,'convolutionArrayBytes':0}
    assert len(caches)==32 and layer_types.count('linear')==24 and layer_types.count('attention')==8
    for i,(cache,kind) in enumerate(zip(caches,layer_types)):
        row={'layer':i,'kind':kind,'class':type(cache).__name__,'slots':[]}
        if kind=='linear':
            assert type(cache).__name__=='ArraysCache' and len(cache.cache)==2,'CACHE_CLASS_MISMATCH'
            values=cache.cache;roles=['convolution','recurrent']
        else:
            assert type(cache).__name__=='KVCache','CACHE_CLASS_MISMATCH'
            values=[cache.keys,cache.values];roles=['key','value'];row['usedTokenOffset']=cache.offset
        for role,array in zip(roles,values):
            if array is None:
                assert not populated,'CACHE_UNPOPULATED';row['slots'].append({'role':role,'allocated':False});continue
            shape=list(array.shape);dtype=str(array.dtype)
            slot={'role':role,'shape':shape,'dtype':dtype,'logicalArrayBytes':array.nbytes}
            if role=='recurrent':
                assert shape==[1,32,128,128] and dtype=='mlx.core.float32',('CACHE_DTYPE_OR_SHAPE',i,slot)
                totals['recurrentArrayBytes']+=array.nbytes
            elif role=='convolution':
                assert shape==[1,3,8192] and dtype=='mlx.core.float16',('CACHE_DTYPE_OR_SHAPE',i,slot)
                totals['convolutionArrayBytes']+=array.nbytes
            else:
                assert shape[0:2]==[1,4] and shape[3]==256 and dtype=='mlx.core.float16',('CACHE_DTYPE_OR_SHAPE',i,slot)
                assert cache.offset<=512 and shape[2]>=cache.offset
                totals['attentionAllocatedBytes']+=array.nbytes
            row['slots'].append(slot)
        rows.append(row)
    return {'layers':rows,'totals':totals,'note':'Array nbytes is logical tensor/storage size, not independent RSS; convolution slices may share larger backing allocations.'}

def main():
    global mx,phase
    activation=json.loads((p.E/'activation.json').read_text());snapshot=Path(activation['snapshot'])
    assert activation['manifestSHA256']==p.IDENT
    budget=json.loads((p.E/'token-budget.json').read_text());assert len(budget['requests'])==p.REQUESTS
    emit('started',pid=os.getpid(),pgid=os.getpgrp(),fallbacks=[],appleFoundationBackend='DISABLED_UNREGISTERED',images=images())
    command('initialize');phase='network_control'
    try:
        with socket.socket() as s:s.settimeout(1);s.connect(('127.0.0.1',9))
    except OSError as error:
        denied=error.errno in [errno.EPERM,errno.EACCES]
        emit('network_negative_control',denied=denied,errno=error.errno)
        if not denied:raise RuntimeError('NETWORK_DENIAL_NOT_ESTABLISHED')
    else:raise RuntimeError('NETWORK_BOUNDARY_FAILED')
    def audit(event,args):
        if event in ['socket.connect','socket.connect_ex','socket.getaddrinfo','socket.sendto','socket.sendmsg']:
            emit('fatal',classification='NETWORK',error=event);os._exit(71)
        if event in ['subprocess.Popen','os.system','os.exec','os.posix_spawn']:
            emit('fatal',classification='SECURITY',error='Unexpected process '+event);os._exit(72)
    sys.addaudithook(audit)
    phase='runtime_initialization';emit('runtime_initialize_begin')
    import mlx.core as core
    mx=core
    import huggingface_hub
    def no_download(*args,**kwargs):
        emit('fatal',classification='NETWORK',error='Hub resolution/download requested');os._exit(71)
    huggingface_hub.snapshot_download=no_download;huggingface_hub.hf_hub_download=no_download
    import mlx_lm.utils as utils
    utils.snapshot_download=no_download
    from mlx_lm.tokenizer_utils import load as load_tokenizer
    from mlx_lm.generate import generate_step
    assert mx.metal.is_available(),'COMPATIBILITY: Metal unavailable'
    emit('runtime_ready',runtime={n:importlib.metadata.version(n) for n in ['mlx','mlx-metal','mlx-lm','transformers','tokenizers']},memory=memory(),images=images())
    thread=threading.Thread(target=telemetry,daemon=True);thread.start()
    command('load');phase='activation_verification'
    verification=c.verify_package(snapshot,p.IDENT,activation['rootIdentity'])
    cfg=json.loads((snapshot/'config.json').read_text());tc=json.loads((snapshot/'tokenizer_config.json').read_text())
    assert cfg['model_type']=='qwen3_5' and cfg['quantization']=={'bits':4,'group_size':64,'mode':'affine'}
    assert not any(k in d for d in [cfg,tc] for k in ['auto_map','model_file','custom_pipelines'])
    assert c.sha(snapshot/'chat_template.jinja')==budget['templateSHA256']
    for name,(length,sha) in c.SHARDS.items():
        record=next(x for x in verification['files'] if x['path']==name)
        assert record['sha256']==sha and record['bytes']==length
    emit('activation_verified',manifestSHA256=p.IDENT,files=len(verification['files']),rootIdentity=verification['rootIdentity'])
    tokenizer=load_tokenizer(snapshot,tokenizer_config_extra={'local_files_only':True,'trust_remote_code':False},eos_token_ids=cfg.get('eos_token_id',None))
    assert tokenizer.eos_token_ids==set(budget['stopSet'])=={248046}
    assert c.sha(snapshot/'tokenizer.json')==budget['tokenizerSHA256']
    rendered=[]
    for row in budget['requests']:
        prompt=tokenizer.apply_chat_template(row['messages'],tokenize=False,add_generation_prompt=True,tools=None,enable_thinking=False)
        ids=tokenizer.encode(prompt,add_special_tokens=False)
        assert len(ids)==row['expectedQwenPromptTokens'] and len(ids)+128<=512,'UNSUPPORTED_RESOURCE_PROFILE'
        assert prompt==row['rawPrompt'] and ids==row['tokenIDs'],'ACTIVATION: frozen rendering changed'
        rendered.append((prompt,ids))
        emit('prompt_preflight',fixtureID=row['id'],promptTokens=len(ids),tokenIDs=ids,rawPrompt=prompt,renderedPromptSHA256=hashlib.sha256(prompt.encode()).hexdigest(),inputSHA256=row['inputSHA256'],templateSHA256=budget['templateSHA256'])
    # Instrument the existing implementation without replacing its computation/loading logic.
    phase='model_load';emit('load_begin');started=time.monotonic()
    model_class,args_class=utils._get_classes(cfg)
    assert model_class.__module__=='mlx_lm.models.qwen3_5','COMPATIBILITY: wrong model class'
    original_init=model_class.__init__;original_bind=model_class.load_weights;original_mxload=mx.load
    from mlx.utils import tree_flatten
    from allocation_guard import verify_bound,check_eager
    from tensor_inventory import expected_inventory
    expected={k:v for k,v in expected_inventory().items() if k.startswith('language_model.')}
    def parameter_records(parameters):
        return {k:{'shape':list(v.shape),'dtype':str(v.dtype),'bytes':v.nbytes} for k,v in tree_flatten(parameters)}
    original_eval=mx.eval;original_async_eval=mx.async_eval;original_dequantize=mx.dequantize
    def guarded_eval(*args,**kwargs):
        rec=[{'dtype':str(v.dtype),'bytes':v.nbytes} for _,v in tree_flatten(args) if isinstance(v,mx.array)]
        floating=check_eager(rec)
        emit('eager_evaluation_begin',floatingArgumentBytes=floating,arrayArguments=len(rec),memory=memory())
        result=original_eval(*args,**kwargs)
        emit('eager_evaluation_end',memory=memory());return result
    def guarded_async_eval(*args,**kwargs):
        check_eager([{'dtype':str(v.dtype),'bytes':v.nbytes} for _,v in tree_flatten(args) if isinstance(v,mx.array)])
        return original_async_eval(*args,**kwargs)
    def forbidden_dequantize(*args,**kwargs):
        raise RuntimeError('FULL_PRECISION_EXPANSION: unexpected dequantize during weight load')
    def traced_init(self,*args,**kwargs):
        global phase
        phase='model_construction';emit('model_construction_begin',memory=memory())
        original_init(self,*args,**kwargs)
        modules=[{'path':n,'class':type(m).__module__+'.'+type(m).__name__} for n,m in self.named_modules()]
        assert not any(any(v in r['path'].lower() or v in r['class'].lower() for v in ('vision','visual','projector','processor')) for r in modules),'COMPATIBILITY: vision/processor module constructed'
        emit('model_construction_end',memory=memory(),modules=modules,visionModulesConstructed=False)
        phase='quantized_model_preparation'
    def traced_bind(self,*args,**kwargs):
        global phase
        phase='weight_binding';emit('weight_binding_begin',memory=memory())
        value=original_bind(self,*args,**kwargs)
        packed=verify_bound(parameter_records(self.parameters()),expected)
        emit('weight_binding_end',memory=memory(),packedStorageVerification=packed);phase='eager_weight_evaluation';return value
    def traced_mxload(path,*args,**kwargs):
        assert Path(path).parent==snapshot and Path(path).name in c.SHARDS,'ACTIVATION: unexpected weight path'
        emit('weight_file_read_begin',file=Path(path).name,memory=memory());value=original_mxload(path,*args,**kwargs)
        vision=[(k,v) for k,v in value.items() if k.startswith('vision_tower.')]
        emit('weight_file_read_end',file=Path(path).name,memory=memory(),loadedTensorEntries=len(value),visionTensorEntries=len(vision),visionLogicalBytes=sum(v.nbytes for k,v in vision),attribution='Full file read by unchanged mx.load; aggregate allocation counters do not isolate physical vision residency');return value
    model_class.__init__=traced_init;model_class.load_weights=traced_bind;mx.load=traced_mxload
    mx.eval=guarded_eval;mx.async_eval=guarded_async_eval;mx.dequantize=forbidden_dequantize
    try:model,loaded_cfg=utils.load_model(snapshot,lazy=False,strict=True)
    finally:
        model_class.__init__=original_init;model_class.load_weights=original_bind;mx.load=original_mxload
        mx.eval=original_eval;mx.async_eval=original_async_eval;mx.dequantize=original_dequantize
    phase='compute_dtype_preparation'
    from mlx.utils import tree_map_with_path
    # Installed model cast predicate preserves A_log; integer quantized storage remains unchanged.
    model.update(tree_map_with_path(lambda k,v:v.astype(mx.float16) if model.cast_predicate(k) and mx.issubdtype(v.dtype,mx.floating) else v,model.parameters()))
    packed=verify_bound(parameter_records(model.parameters()),expected,cast=True)
    check_eager(list(parameter_records(model.parameters()).values()))
    emit('compute_cast_packed_verified',verification=packed,memory=memory())
    mx.eval(model.parameters());mx.synchronize()
    layer_types=['linear' if layer.is_linear else 'attention' for layer in model.layers]
    caches=model.make_cache();empty_cache=cache_record(caches,layer_types)
    phase='loaded';emit('MODEL_LOADED',seconds=time.monotonic()-started,memory=memory(),images=images(),
       cacheStructure=empty_cache,manifestSHA256=p.IDENT,compute='FP16 floating weights; native FP32 gated-delta recurrence; A_log preserved via installed cast predicate')
    del caches
    for request_index,row in enumerate(budget['requests']):
        prompt=tokenizer.apply_chat_template(row['messages'],tokenize=False,add_generation_prompt=True,tools=None,enable_thinking=False)
        ids=tokenizer.encode(prompt,add_special_tokens=False)
        assert (prompt,ids)==rendered[request_index] and len(ids)+128<=512,'UNSUPPORTED_RESOURCE_PROFILE'
        caches=model.make_cache()
        emit('cache_reset',fixtureID=row['id'],freshCache=cache_record(caches,layer_types),peakReset=False,memory=memory())
        command('generate-'+str(request_index));phase='prefill';emit('generation_begin',fixtureID=row['id'],promptTokens=len(ids),maxNewTokens=128,totalCeiling=512,batch=1)
        generated=[];sampled=[];finish='length';t=time.monotonic();first=None;last=None
        def progress(processed,total):
            global phase
            emit('prefill_progress',processed=processed,total=total,memory=memory())
            if processed:
                emit('hybrid_cache',checkpoint='prefill_'+str(processed),cache=cache_record(caches,layer_types,True),memory=memory())
            if processed==total:phase='generation'
        stream=generate_step(mx.array(ids),model,max_tokens=128,sampler=lambda logits:mx.argmax(logits,axis=-1),prompt_cache=caches,prefill_step_size=128,kv_bits=None,prompt_progress_callback=progress)
        for token,logprobs in stream:
            now=time.monotonic();first=first or now;last=now;value=int(token);sampled.append(value)
            assert len(sampled)<=128
            emit('sampled_token',index=len(sampled),token=value,memory=memory())
            if value in tokenizer.eos_token_ids:finish='stop';break
            generated.append(value)
            emit('partial_output',tokenCount=len(generated),rawOutput=tokenizer.decode(generated))
        stream.close();mx.synchronize();elapsed=time.monotonic()-t
        cache_state=cache_record(caches,layer_types,True)
        text=tokenizer.decode(generated);assert text.strip(),'Empty generation'
        phase='post_generation';emit('generated',fixtureID=row['id'],rawOutput=text,promptTokens=len(ids),outputTokens=len(generated),
           sampledTokensIncludingStop=len(sampled),tokenIDs=generated,sampledTokenIDs=sampled,finishReason=finish,seconds=elapsed,
           firstTokenSeconds=first-t if first else None,tokensPerSecond=(len(generated)/elapsed if elapsed else None),
           decodeTokensPerSecond=((len(sampled)-1)/(last-first) if first and last>first else None),
           cacheStructure=cache_state,memory=memory(),images=images())
        del stream,logprobs,token,caches
        gc.collect();mx.synchronize();mx.clear_cache()
        emit('between_requests',fixtureID=row['id'],memory=memory())
    command('unload');phase='unload';emit('unload_begin',memory=memory())
    del model,tokenizer
    gc.collect();mx.synchronize();mx.clear_cache();emit('unloaded',memory=memory(),images=images())
    command('exit');done.set();thread.join(timeout=1);phase='exit';emit('exiting',memory=memory(),images=images())

if __name__=='__main__':
    try:main()
    except BaseException as error:
        text=str(error)
        classification=('NETWORK' if phase=='network_control' or 'NETWORK_' in text else
          'ACTIVATION' if phase=='activation_verification' or text.startswith('ACTIVATION:') else
          'RESOURCE' if 'FULL_PRECISION_EXPANSION' in text else
          'SECURITY' if 'FORBIDDEN_' in text else
          'COMPATIBILITY' if isinstance(error,ImportError) or 'CACHE_' in text or 'COMPATIBILITY:' in text or phase=='runtime_initialization' else 'RUNTIME')
        emit('fatal',classification=classification,error=repr(error));done.set();sys.exit(1)

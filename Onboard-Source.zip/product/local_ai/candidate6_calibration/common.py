"""Exact owner-authorized experimental Qwen3.5 artifact; no AI imports."""
import hashlib,json,os,stat
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'product/local_ai'
E=ROOT/'docs/sprint3a/evidence/candidate6-calibration-01'
RESEARCH=ROOT/'docs/sprint3a/evidence/candidate6-research-01'
REPO='mlx-community/Qwen3.5-9B-4bit'
REV='8b2b98c00a6b4d291155e4890773ca8f769aee53'
UPSTREAM='Qwen/Qwen3.5-9B'
UPREV='c202236235762e1c871ad0ccb60c8ee5ba337b9a'
SHARDS={'model-00001-of-00002.safetensors':(5349771222,'a68b87558c6ef43f74c2bd63ce7e9092ceddc3101f3def0030774bae5f42aadd'),'model-00002-of-00002.safetensors':(600449850,'b0a770bf8469c7f3f18756a0e0283f1c1174344a83e059a4e483f6af4907352d')}
QUARANTINE=BASE/'.artifacts/quarantine/candidate6-qwen35-01'
FILES={'.gitattributes','README.md','chat_template.jinja','config.json',*SHARDS,'model.safetensors.index.json','preprocessor_config.json','processor_config.json','tokenizer.json','tokenizer_config.json','video_preprocessor_config.json','vocab.json'}
def save(name, data):
    with (E/name).open('x') as f:
        json.dump(data, f, indent=2); f.write('\n')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def ident(st):
    return [st.st_dev, st.st_ino]

def secure_root(path, expected_identity=None):
    path = Path(path).absolute()
    for p in [*reversed(path.parents), path]:
        assert not stat.S_ISLNK(p.lstat().st_mode), 'Symlink ancestor: '+str(p)
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    st = os.fstat(fd)
    try:
        assert st.st_uid == os.getuid(), 'Wrong package owner'
        assert not st.st_mode & 0o022, 'Group/world-writable package root'
        if expected_identity is not None:
            assert ident(st) == expected_identity, 'Package root replaced'
        return fd
    except BaseException:
        os.close(fd); raise

def safe_parts(name):
    p = Path(name)
    assert not p.is_absolute() and name == p.as_posix()
    assert p.parts and all(x not in ['.', '..', ''] for x in p.parts), 'Unsafe member path'
    return p.parts

def file_record(root_fd, name):
    parts = safe_parts(name)
    parent = os.dup(root_fd)
    try:
        for part in parts[:-1]:
            nxt = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent); parent = nxt
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        try:
            before = os.fstat(fd)
            assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'Nonregular or hardlinked member'
            assert before.st_uid == os.getuid() and not before.st_mode & 0o111, 'Wrong owner or executable file'
            h = hashlib.sha256()
            for b in iter(lambda:os.read(fd, 1024*1024), b''): h.update(b)
            after = os.fstat(fd)
            attrs = lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink)
            assert attrs(before) == attrs(after), ('File metadata changed during hashing', name, attrs(before), attrs(after))
            named = os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)
            assert attrs(named) == attrs(after), 'File path replaced during hashing'
            return {'path':name,'bytes':after.st_size,'sha256':h.hexdigest(),'identity':ident(after)}
        finally: os.close(fd)
    finally: os.close(parent)

def verify_package(root, manifest_sha, root_identity=None):
    fd = secure_root(root, root_identity)
    try:
        mr = file_record(fd, 'manifest.json')
        assert mr['sha256'] == manifest_sha, 'Manifest substitution'
        mf = os.open('manifest.json', os.O_RDONLY | os.O_NOFOLLOW, dir_fd=fd)
        with os.fdopen(mf, 'rb') as f:
            raw=f.read()
        assert hashlib.sha256(raw).hexdigest() == manifest_sha
        manifest = json.loads(raw)
        expected = {r['path'] for r in manifest['files']} | {'manifest.json'}
        assert len(expected) == len(manifest['files'])+1
        actual = set()
        for directory, dirs, files, dfd in os.fwalk('.', dir_fd=fd, follow_symlinks=False):
            for n in dirs:
                ds=os.stat(n,dir_fd=dfd,follow_symlinks=False)
                assert stat.S_ISDIR(ds.st_mode) and ds.st_uid==os.getuid() and not ds.st_mode & 0o022
            for n in files:
                actual.add((Path(directory)/n).as_posix())
        assert actual == expected, 'Unexpected/missing package member'
        rows = []
        for r in manifest['files']:
            got = file_record(fd,r['path'])
            assert got['bytes']==r['bytes'] and got['sha256']==r['sha256'], 'Content substitution: '+r['path']
            rows.append(got)
        assert ident(os.stat(root,follow_symlinks=False))==ident(os.fstat(fd)), 'Root replaced during verification'
        return {'manifestSHA256':manifest_sha,'rootIdentity':ident(os.fstat(fd)), 'files':rows}
    finally: os.close(fd)

"""Offline verification/sealing only. No model, process launch, or network."""
from pathlib import Path
import datetime,hashlib,json,re
R=Path(__file__).resolve().parents[3]
E=R/'docs/sprint3a/evidence/resource-policy-v2'
D=R/'docs/sprint3a'
NAMES=['MACOS_MEMORY_POLICY_REVIEW.md','MACOS_RESOURCE_POLICY_V2_PROPOSAL.md','SUPERVISOR_TERMINATION_REVIEW.md','SUPERVISOR_TEST_RESULTS.md','RESOURCE_TELEMETRY_SCHEMA.md','MODEL_CALIBRATION_POLICY.md']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,obj):(E/name).write_text(json.dumps(obj,indent=2)+'\n')
def main():
 previous=json.loads((E/'preservation-before.json').read_text())['files'];bad=[row['path'] for row in previous if not (R/row['path']).is_file() or digest(R/row['path'])!=row['sha256']]
 assert not bad,bad
 write('preservation-after.json',{'checked':len(previous),'unchanged':True,'changed':bad,'scope':'Historical Sprint 3A docs/evidence and non-artifact local_ai sources recorded before task; no historical recalculation'})
 manifests=[]
 for folder in [E/'real-tests',E/'revision-02/real-tests',E/'revision-03/real-tests',E/'unit-cases-r3']:
  for p in sorted(folder.glob('*/manifest.json')):
   for row in json.loads(p.read_text())['files']:assert digest(p.parent/row['path'])==row['sha256'],str(p)
   manifests.append(str(p.relative_to(E)))
 real=json.loads((E/'revision-03/real-test-results.json').read_text());assert real['allPassed'] and len(real['tests'])==7
 # All code that actually launched/observed/terminated real workers remains byte-exact.
 tested=json.loads((E/'revision-03/tested-source.json').read_text())['files']
 verified=[];post=[]
 for row in tested:
  p=R/row['path']
  if digest(p)==row['sha256']:verified.append(row['path'])
  else:post.append(row['path'])
 assert post==['product/local_ai/resource_harness_v2/policy_proposal.py'],post
 write('verification.json',{'historicalFilesUnchanged':len(previous),'verifiedNestedManifests':manifests,'realExecutedFilesStillExact':verified,'postRealChanges':post,'postRealChangeReason':'Pure evaluator numeric-input validation; no real harness code changed; 19 final pure policy tests passed.','modelLoads':0,'generationRequests':0,'optionalMemoryStress':False})
 missing=[]
 for name in NAMES:
  p=D/name
  for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
   if target.startswith(('http:','https:')):continue
   if not (p.parent/target.split('#')[0]).exists():missing.append((name,target))
 assert not missing,missing
 write('decision.json',{'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'RESOURCE_HARNESS_V2_READY_FOR_OWNER_REVIEW','scope':'Corrected reusable lifecycle component, harmless test boundary, research and unadopted policy proposal','distinctUnitTestsPassed':41,'finalRealCasesPassed':7,'totalRealHarmlessCasesAcrossRevisions':21,'policyAdopted':False,'modelExecutionAuthorized':False,'modelLoads':0,'generationRequests':0,'reserveBytes':2*1024**3,'futureExecutionRequires':'Owner-reviewed policy and exact-model adapter/preflight, fresh admission and qualified unchanged execution boundary','documents':NAMES})
 files=sorted([p for p in E.rglob('*') if p.is_file() and p.name!='EVIDENCE_MANIFEST.json']+[D/n for n in NAMES]+[p for p in (R/'product/local_ai/resource_harness_v2').iterdir() if p.is_file()])
 write('EVIDENCE_MANIFEST.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]})
 print(json.dumps({'historicalFilesUnchanged':len(previous),'nestedManifestsVerified':len(manifests),'sealedFiles':len(files),'manifestSHA256':digest(E/'EVIDENCE_MANIFEST.json'),'allDocumentLinksResolve':True},indent=2))
if __name__=='__main__':main()

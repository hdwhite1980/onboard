"""Non-AI lifecycle correction. No model/runtime imports or model launch path.

All injected OS/monitor operations must be bounded. A disk/OS/process death can
prevent durable output; recoverable cleanup errors must not short-circuit it.
"""
import datetime
import errno
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time


def stamp():
    return {'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'monotonic': time.monotonic()}


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(temporary, path)
    directory = os.open(path.parent, os.O_RDONLY)
    try: os.fsync(directory)
    finally: os.close(directory)


class Supervisor:
    """Own one start_new_session child; no retries and no arbitrary PID interface.

    request_abort() only latches intent; finish() performs one serialized cleanup.
    SIGNAL_FAILED is never turned into successful signal delivery by later absence.
    """
    def __init__(self, directory, proc=None, pgid=None, *, signal_group=os.killpg,
                 group_present=lambda: None, term_wait=.5, kill_wait=1.0):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=False)
        self.proc, self.pgid = proc, pgid
        self.signal_group, self.group_present = signal_group, group_present
        self.term_wait, self.kill_wait = term_wait, kill_wait
        self.lock = threading.RLock()
        self.abort_reasons, self.events, self.errors = [], [], []
        self.state, self.result, self.sent = 'RUNNING', None, set()
        self._error('initial_result', lambda: atomic_json(self.directory/'result.json', {
            **stamp(), 'primary': 'INCOMPLETE', 'supervisor': 'RUNNING',
            'evidenceCompleteness': 'PARTIAL', 'modelLoads': 0, 'generationRequests': 0}))

    def _error(self, stage, operation):
        try: return operation()
        except BaseException as error:
            self.errors.append({**stamp(), 'stage': stage, 'type': type(error).__name__,
                                'errno': getattr(error, 'errno', None), 'exception': repr(error)})
            return None

    def transition(self, state):
        self.state = state
        self.events.append({**stamp(), 'event': 'STATE', 'state': state})
        self._error('journal', lambda: atomic_json(self.directory/'termination.json', self.events))

    def request_abort(self, reason):
        with self.lock:
            if self.result is not None: return
            if reason not in self.abort_reasons: self.abort_reasons.append(reason)
            if self.state == 'RUNNING': self.transition('ABORT_REQUESTED')

    def _poll(self):
        return self._error('poll', self.proc.poll) if self.proc is not None else None

    def _present(self):
        value = self._error('group_observation', self.group_present)
        if value not in (True, False): return None
        return value

    def _signal(self, sig):
        if sig in self.sent: return
        self.sent.add(sig)
        row = {**stamp(), 'event': 'SIGNAL', 'targetPID': self.proc.pid if self.proc else None,
               'targetPGID': self.pgid, 'signal': signal.Signals(sig).name,
               'workerKnownExit': self._poll(), 'errno': None, 'exception': None}
        self.events.append(dict(row,event='SIGNAL_INTENT',result='PENDING'))
        self._error('journal', lambda: atomic_json(self.directory/'termination.json', self.events))
        # Caller must bind pgid to the newly owned Popen session before cleanup.
        if self.proc is None or not isinstance(self.pgid, int) or self.pgid <= 1 or self.pgid != self.proc.pid or self.pgid == os.getpgrp():
            row.update(result='OTHER_ERROR', errno=errno.EINVAL, exception='Invalid or unowned process group')
        else:
            try:
                self.signal_group(self.pgid, sig)
                row['result'] = 'SENT'
            except ProcessLookupError as error:
                row.update(result='PROCESS_NOT_FOUND', errno=error.errno, exception=repr(error))
            except PermissionError as error:
                row.update(result='PERMISSION_DENIED', errno=error.errno, exception=repr(error))
            except BaseException as error:
                row.update(result='OTHER_ERROR', errno=getattr(error, 'errno', None), exception=repr(error))
        self.events.append(row)
        self.transition(('TERM_SENT' if sig == signal.SIGTERM else 'KILL_SENT') if row['result']=='SENT'
                        else 'ALREADY_EXITED' if row['result']=='PROCESS_NOT_FOUND' else 'SIGNAL_FAILED')

    def _terminate(self):
        if self.proc is None:
            self.transition('ALREADY_EXITED'); return
        exited, present = self._poll(), self._present()
        if exited is not None and present is False:
            self.transition('ALREADY_EXITED')
        else:
            self._signal(signal.SIGTERM)
            self._error('term_wait', lambda: self.proc.wait(timeout=self.term_wait))
            if self._poll() is None or self._present() is not False:
                self._signal(signal.SIGKILL)
        self.transition('REAP')
        self._error('reap', lambda: self.proc.wait(timeout=self.kill_wait))

    def finish(self, primary, *, recovery=lambda: {}, cleanup=lambda: None, evidence=lambda: None):
        with self.lock:
            if self.result is not None: return self.result
            if self.state == 'RUNNING': self.request_abort('Lifecycle completion')
            # Deliberately independent stages; each exception becomes evidence.
            self._error('termination', self._terminate)
            self._error('additional_cleanup', cleanup)
            recovery_data = self._error('recovery', recovery)
            self._error('write_resources', evidence)
            worker_exit = self._poll()
            present = self._present()
            signal_rows = [x for x in self.events if x['event']=='SIGNAL']
            if any(x['result']=='PERMISSION_DENIED' for x in signal_rows):
                safety = 'TERMINATION_PERMISSION_ERROR'
            elif any(x['result']=='OTHER_ERROR' for x in signal_rows): safety = 'TERMINATION_SIGNAL_ERROR'
            elif (self.proc is not None and worker_exit is None) or present is not False:
                safety = 'TERMINATION_UNCONFIRMED'
            elif any(e['stage'] not in ('term_wait',) for e in self.errors): safety = 'CLEANUP_OR_EVIDENCE_ERROR'
            else: safety = 'TERMINATION_CONFIRMED'
            self.transition('FINALIZE')
            result = {**stamp(), 'primary': primary, 'supervisor': safety,
                      'workerExitCode': worker_exit, 'workerPresent': None if self.proc is None else worker_exit is None,
                      'processGroupPresent': present, 'abortReasons': self.abort_reasons,
                      'evidenceCompleteness': 'COMPLETE' if safety=='TERMINATION_CONFIRMED' and recovery_data is not None else 'PARTIAL',
                      'modelLoads': 0, 'generationRequests': 0,
                      'events': self.events, 'errors': self.errors, 'recovery': recovery_data}
            # Pre-created result survives an update failure. Independent writes maximize salvage.
            self._error('write_events', lambda: atomic_json(self.directory/'termination.json', self.events))
            self._error('write_recovery', lambda: atomic_json(self.directory/'recovery.json', recovery_data))
            if any(e['stage'].startswith('write_') for e in self.errors):
                result.update(supervisor='CLEANUP_OR_EVIDENCE_ERROR', evidenceCompleteness='PARTIAL')
            self._error('write_result', lambda: atomic_json(self.directory/'result.json', result))
            files = []
            def seal():
                for file in sorted(self.directory.iterdir()):
                    if file.is_file() and file.name != 'manifest.json':
                        files.append({'path': file.name, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(), 'bytes': file.stat().st_size})
                atomic_json(self.directory/'manifest.json', {'files':files})
            error_count = len(self.errors)
            self._error('seal', seal)
            if len(self.errors) != error_count:
                result.update(supervisor='CLEANUP_OR_EVIDENCE_ERROR', evidenceCompleteness='PARTIAL')
                self._error('write_result_after_seal_failure', lambda: atomic_json(self.directory/'result.json', result))
            self.result = result
            return result

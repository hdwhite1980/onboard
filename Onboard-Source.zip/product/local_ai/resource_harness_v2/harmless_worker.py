"""Fixed harmless worker: network negative control, readiness, then sleep/crash.
No configurable command, imports of ML packages, or user data access.
"""
import errno,json,os,signal,socket,sys,time
mode=sys.argv[1]
if mode not in ('term','ignore_term','exit','crash'):raise SystemExit(2)
signal.signal(signal.SIGALRM,signal.SIG_DFL)
signal.alarm(8)  # independent upper bound even if the supervisor cannot signal
if mode=='ignore_term':signal.signal(signal.SIGTERM,signal.SIG_IGN)
s=socket.socket()
try:
    s.settimeout(.2);code=s.connect_ex(('127.0.0.1',9))
finally:s.close()
print(json.dumps({'event':'ready','pid':os.getpid(),'pgid':os.getpgrp(),'mode':mode,
                  'networkNegativeControlErrno':code,'networkDenied':code in (errno.EPERM,errno.EACCES),
                  'selfExpirySeconds':8,'modelLoads':0}),flush=True)
if mode=='exit':raise SystemExit(0)
if mode=='crash':os._exit(7)
while True:time.sleep(.1)

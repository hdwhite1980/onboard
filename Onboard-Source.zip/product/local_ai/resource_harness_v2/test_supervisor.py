"""Fault injection only: these tests do not signal any real process."""
import errno,hashlib,json,signal,subprocess,sys,tempfile,threading,unittest,shutil
from unittest.mock import patch
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from supervisor import Supervisor
from policy_proposal import Policy,GIB

class Fake:
    pid=2147483000
    def __init__(self,ignore=False): self.exit=None;self.ignore=ignore;self.present=True;self.signals=[]
    def poll(self):return self.exit
    def wait(self,timeout):
        if self.exit is None: raise subprocess.TimeoutExpired('fake',timeout)
        return self.exit
    def killpg(self,pgid,sig):
        self.signals.append(sig)
        if not self.present:raise ProcessLookupError(errno.ESRCH,'simulated gone')
        if sig==signal.SIGKILL or not self.ignore:self.exit=-sig;self.present=False

class Cases(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.proc=Fake();self.directory=Path(self.tmp.name)/'run'
    def tearDown(self):
        if self.directory.exists():
            dest=Path(__file__).resolve().parents[3]/'docs/sprint3a/evidence/resource-policy-v2/unit-cases-r3'/self._testMethodName
            dest.parent.mkdir(exist_ok=True)
            shutil.copytree(self.directory,dest)
    def make(self,**kw):return Supervisor(self.directory,self.proc,kw.pop('pgid',self.proc.pid),signal_group=kw.pop('signal_group',self.proc.killpg),group_present=kw.pop('group_present',lambda:self.proc.present),**kw)
    def verify(self,s,**kw):
        r=s.finish('SYNTHETIC_GUARD_ABORT',recovery=kw.pop('recovery',lambda:{'samples':[{'synthetic':True}]}),**kw)
        self.assertTrue((self.directory/'result.json').exists());self.assertTrue((self.directory/'recovery.json').exists())
        for f in json.loads((self.directory/'manifest.json').read_text())['files']:
            self.assertEqual(hashlib.sha256((self.directory/f['path']).read_bytes()).hexdigest(),f['sha256'])
        self.assertEqual(r['modelLoads'],0);return r
    def test_normal_term(self):
        r=self.verify(self.make());self.assertEqual(self.proc.signals,[signal.SIGTERM]);self.assertEqual(r['supervisor'],'TERMINATION_CONFIRMED')
    def test_ignore_term_kill(self):
        self.proc.ignore=True;r=self.verify(self.make());self.assertEqual(self.proc.signals,[signal.SIGTERM,signal.SIGKILL]);self.assertEqual(r['workerExitCode'],-9)
    def test_already_exited(self):
        self.proc.exit=0;self.proc.present=False;self.verify(self.make());self.assertEqual(self.proc.signals,[])
    def test_group_already_gone(self):
        self.proc.present=False;r=self.verify(self.make());self.assertEqual([e['result'] for e in r['events'] if e['event']=='SIGNAL'],['PROCESS_NOT_FOUND','PROCESS_NOT_FOUND']);self.assertEqual(r['supervisor'],'TERMINATION_UNCONFIRMED')
    def test_invalid_pgid(self):
        r=self.verify(self.make(pgid=0));self.assertEqual(self.proc.signals,[]);self.assertEqual(r['supervisor'],'TERMINATION_SIGNAL_ERROR')
    def test_permission_error(self):
        def denied(*_):raise PermissionError(errno.EPERM,'injected permission denied')
        r=self.verify(self.make(signal_group=denied));self.assertEqual(r['supervisor'],'TERMINATION_PERMISSION_ERROR');self.assertEqual(r['evidenceCompleteness'],'PARTIAL')
    def test_lookup_error(self):
        def gone(*_):raise ProcessLookupError(errno.ESRCH,'injected missing')
        r=self.verify(self.make(signal_group=gone));self.assertTrue(all(e['result']=='PROCESS_NOT_FOUND' for e in r['events'] if e['event']=='SIGNAL'))
    def test_oserror(self):
        def fail(*_):raise OSError(errno.EIO,'injected IO')
        r=self.verify(self.make(signal_group=fail));self.assertEqual(r['supervisor'],'TERMINATION_SIGNAL_ERROR')
    def test_unexpected_signal_exception(self):
        def fail(*_):raise RuntimeError('injected unexpected')
        r=self.verify(self.make(signal_group=fail));self.assertEqual(r['supervisor'],'TERMINATION_SIGNAL_ERROR')
    def test_monitor_failure(self):
        s=self.make();s.request_abort('MONITOR_FAILED');r=self.verify(s);self.assertIn('MONITOR_FAILED',r['abortReasons'])
    def test_worker_crash(self):
        self.proc.exit=7;self.proc.present=False;r=self.verify(self.make());self.assertEqual(r['workerExitCode'],7)
    def test_double_abort(self):
        s=self.make();s.request_abort('first');s.request_abort('second');r=self.verify(s);self.assertIs(s.finish('OTHER'),r);self.assertEqual(len(self.proc.signals),1)
    def test_concurrent_abort(self):
        s=self.make();threads=[threading.Thread(target=s.request_abort,args=('guard',)) for _ in range(8)]
        for t in threads:t.start()
        for t in threads:t.join()
        self.verify(s);self.assertEqual(s.abort_reasons,['guard']);self.assertEqual(len(self.proc.signals),1)
    def test_timeout_cleanup(self):
        def fail():raise subprocess.TimeoutExpired('cleanup',1)
        r=self.verify(self.make(),cleanup=fail);self.assertEqual(r['supervisor'],'CLEANUP_OR_EVIDENCE_ERROR')
    def test_cleanup_exception(self):
        def fail():raise RuntimeError('cleanup failure')
        r=self.verify(self.make(),cleanup=fail);self.assertIsNotNone(r['recovery']);self.assertEqual(r['evidenceCompleteness'],'PARTIAL')
    def test_recovery_sampler_failure(self):
        def fail():raise RuntimeError('sampler failure')
        r=self.verify(self.make(),recovery=fail);self.assertIsNone(r['recovery']);self.assertEqual(r['supervisor'],'CLEANUP_OR_EVIDENCE_ERROR')
    def test_permission_then_absent_never_relabels_delivery(self):
        def denied(*_):self.proc.exit=0;self.proc.present=False;raise PermissionError(errno.EPERM,'race')
        r=self.verify(self.make(signal_group=denied));self.assertEqual(r['supervisor'],'TERMINATION_PERMISSION_ERROR');self.assertFalse(r['processGroupPresent'])
    def test_evidence_writer_error_still_finalizes(self):
        def fail():raise OSError(errno.EIO,'injected resource evidence failure')
        r=self.verify(self.make(),evidence=fail);self.assertEqual(r['evidenceCompleteness'],'PARTIAL');self.assertIsNotNone(r['recovery'])
    def test_manifest_failure_still_finalizes(self):
        import supervisor
        original=supervisor.atomic_json
        def fail(path,value):
            if Path(path).name=='manifest.json':raise OSError(errno.EIO,'injected manifest failure')
            return original(path,value)
        with patch('supervisor.atomic_json',side_effect=fail):r=self.make().finish('TEST',recovery=lambda:{'samples':[]})
        self.assertEqual(r['evidenceCompleteness'],'PARTIAL');self.assertEqual(json.loads((self.directory/'result.json').read_text())['supervisor'],'CLEANUP_OR_EVIDENCE_ERROR')
    def test_unknown_group_is_not_absence(self):
        r=self.verify(self.make(group_present=lambda:None));self.assertEqual(r['supervisor'],'TERMINATION_UNCONFIRMED')

class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.row={'phase':'LOAD','sampleAgeSeconds':0,'availableEstimateLegacyBytes':5*GIB,'memoryPressure':'NORMAL','thermalState':0,'swapUsedBytes':0,'swapInBytesPerSecond':0,'swapOutBytesPerSecond':0,'workerPhysicalFootprintBytes':GIB,'compressorGrowthBytesPerSecond':0}
        self.profile={'peakLimitBytes':3*GIB,'admissionAllowanceBytes':3*GIB}
    def evaluate(self,**kw):return Policy().evaluate(dict(self.row,**kw),{'swapUsedBytes':0},self.profile)
    def test_compression_not_hard_stop(self):self.assertEqual(self.evaluate(compressorGrowthBytesPerSecond=2*GIB)['state'],'DEGRADED')
    def test_pressure_critical(self):self.assertEqual(self.evaluate(memoryPressure='CRITICAL')['action'],'STOP')
    def test_pressure_warn(self):self.assertEqual(self.evaluate(memoryPressure='WARN')['action'],'STOP')
    def test_pressure_unknown(self):self.assertEqual(self.evaluate(memoryPressure='UNKNOWN')['action'],'STOP')
    def test_reserve_unchanged(self):self.assertEqual(self.evaluate(availableEstimateLegacyBytes=2.25*GIB)['action'],'STOP')
    def test_swap_churn_net_zero(self):self.assertEqual(self.evaluate(swapInBytesPerSecond=1)['action'],'STOP')
    def test_swap_used_growth(self):self.assertEqual(self.evaluate(swapUsedBytes=1)['action'],'STOP')
    def test_footprint_missing(self):self.assertEqual(self.evaluate(workerPhysicalFootprintBytes=None)['action'],'STOP')
    def test_stale(self):self.assertEqual(self.evaluate(sampleAgeSeconds=1.51)['action'],'STOP')
    def test_nan(self):self.assertEqual(self.evaluate(sampleAgeSeconds=float('nan'))['action'],'STOP')
    def test_thermal(self):self.assertEqual(self.evaluate(thermalState=2)['action'],'STOP')
    def test_stop_latched(self):
        p=Policy();p.evaluate(dict(self.row,memoryPressure='WARN'),{'swapUsedBytes':0},self.profile)
        self.assertEqual(p.evaluate(self.row,{'swapUsedBytes':0},self.profile)['action'],'STOP_LATCHED')
    def test_warning_latched(self):
        p=Policy();p.evaluate(dict(self.row,compressorGrowthBytesPerSecond=1),{'swapUsedBytes':0},self.profile)
        self.assertEqual(p.evaluate(self.row,{'swapUsedBytes':0},self.profile)['state'],'DEGRADED')
    def test_unknown_profile_blocks_admission(self):self.assertEqual(Policy().evaluate(dict(self.row,phase='ADMISSION'),{'swapUsedBytes':0})['action'],'BLOCK')

class ClockTests(unittest.TestCase):
    def test_future_clock_rejected(self):
        from run_harmless import enrich
        with self.assertRaises(ValueError):enrich({'monotonic':1e20},{},None,'IDLE')
    def test_stale_clock_rejected(self):
        from run_harmless import enrich
        with self.assertRaises(ValueError):enrich({'monotonic':0},{},None,'IDLE')

if __name__=='__main__':unittest.main(verbosity=2)

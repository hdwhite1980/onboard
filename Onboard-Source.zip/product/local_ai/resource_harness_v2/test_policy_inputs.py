"""Additional pure boundary checks; no process launch or model imports."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from policy_proposal import Policy,GIB
class Inputs(unittest.TestCase):
 def setUp(self):
  self.row={'phase':'LOAD','sampleAgeSeconds':0,'availableEstimateLegacyBytes':5*GIB,'memoryPressure':'NORMAL','thermalState':0,'swapUsedBytes':0,'swapInBytesPerSecond':0,'swapOutBytesPerSecond':0,'workerPhysicalFootprintBytes':GIB}
 def test_invalid_ceilings_fail_closed(self):
  for value in (float('nan'),float('inf'),-1,0,True,'100'):
   self.assertEqual(Policy().evaluate(self.row,{'swapUsedBytes':0},{'peakLimitBytes':value})['reason'],'PROFILE_UNAVAILABLE')
 def test_invalid_baseline_fails_closed(self):
  for value in (None,float('nan'),-1,False):
   self.assertEqual(Policy().evaluate(self.row,{'swapUsedBytes':value},{'peakLimitBytes':2*GIB})['reason'],'BASELINE_UNAVAILABLE')
 def test_boolean_thermal_not_nominal(self):
  self.row['thermalState']=False
  self.assertEqual(Policy().evaluate(self.row,{'swapUsedBytes':0},{'peakLimitBytes':2*GIB})['action'],'STOP')
 def test_missing_diagnostic_not_exception(self):
  self.assertEqual(Policy().evaluate(self.row,{'swapUsedBytes':0},{'peakLimitBytes':2*GIB})['state'],'SAFE')
 def test_unknown_phase_rejected(self):
  self.row['phase']='MODEL'
  self.assertEqual(Policy().evaluate(self.row,{'swapUsedBytes':0},{'peakLimitBytes':2*GIB})['action'],'STOP')
if __name__=='__main__':unittest.main(verbosity=2)

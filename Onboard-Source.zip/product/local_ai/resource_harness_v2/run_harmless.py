"""Harmless real boundary qualification. Fixed worker only; never accepts a model."""
import json,os,resource,selectors,subprocess,sys,time,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from supervisor import Supervisor,atomic_json,stamp
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
E=ROOT/'docs/sprint3a/evidence/resource-policy-v2/revision-03'
SANDBOX=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)']

def members(pgid):
    p=subprocess.run(['/bin/ps','-axo','pid=,pgid='],capture_output=True,text=True,check=True,timeout=1)
    return [int(f[0]) for l in p.stdout.splitlines() if len(f:=l.split())==2 and int(f[1])==pgid]

def sample(pid=0):
    p=subprocess.run([str(HERE/'resource-probe'),str(pid),'.1','0'],capture_output=True,text=True,check=True,timeout=1)
    return json.loads(p.stdout)

def enrich(row,base,previous,phase):
    now=time.monotonic()
    age=now-row['monotonic']
    if age<0 or age>1.5:raise ValueError('Clock mismatch or stale native sample')
    row.update(phase=phase,sampleAgeSeconds=age,
         mlxActiveBytes=None,mlxCacheBytes=None,mlxPeakBytes=None,
         mlxUnavailableReason='No AI runtime imported; harmless test only',guardState='OBSERVATION',guardReason='HARMLESS_PROCESS_TEST')
    for current,delta in [('compressorOccupancyBytes','compressorDeltaBytes'),('swapUsedBytes','swapDeltaBytes')]:
        row[delta]=row[current]-base[current] if row.get(current) is not None and base.get(current) is not None else None
    dt=row['monotonic']-previous['monotonic'] if previous else None
    for current,target,multiplier in [('compressorOccupancyBytes','compressorGrowthBytesPerSecond',1),('swapInPagesTotal','swapInBytesPerSecond',row.get('pageSizeBytes')),('swapOutPagesTotal','swapOutBytesPerSecond',row.get('pageSizeBytes'))]:
        difference=row[current]-previous[current] if previous and row.get(current) is not None and previous.get(current) is not None else None
        row[target]=difference*multiplier/dt if dt and dt>0 and difference is not None and multiplier and (current=='compressorOccupancyBytes' or difference>=0) else None
    return row

def one(case,mode,expected):
    directory=E/'real-tests'/case
    s=Supervisor(directory,group_present=lambda:False)
    rows=[];proc=None;ready=None;primary='HARNESS_FAILURE'
    try:
        base=sample();rows.append(enrich(base,base,None,'ADMISSION'))
        # Test itself is tiny; never proceed with a pressured host or approached reserve.
        assert base['memoryPressure']=='NORMAL' and base['availableEstimateLegacyBytes']>2.25*1024**3
        assert base['thermalState'] in (0,1)
        cmd=SANDBOX+[sys.executable,'-I','-B',str(HERE/'harmless_worker.py'),mode]
        atomic_json(directory/'launch.json',{'command':cmd,'parentPID':os.getpid(),'parentExecutionContext':'tool-approved execution outside Codex filesystem/process sandbox','childExecutionContext':'network-denied seatbelt, separate session, same UID','modelImports':[]})
        with (directory/'worker.stderr').open('x') as err:
            proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=err,text=True,start_new_session=True)
        s.proc=proc;s.pgid=proc.pid;s.group_present=lambda:bool(members(proc.pid))
        sel=selectors.DefaultSelector();sel.register(proc.stdout,selectors.EVENT_READ)
        try:
            if not sel.select(2):raise TimeoutError('harmless readiness timeout')
            ready=json.loads(proc.stdout.readline())
        finally:sel.close()
        atomic_json(directory/'ready.json',ready)
        assert ready['pgid']==proc.pid and ready['pid']==proc.pid and ready['networkDenied']
        if mode in ('exit','crash'):
            proc.wait(timeout=1)
            primary='HARMLESS_EXIT' if mode=='exit' else 'HARMLESS_WORKER_CRASH'
        else:
            row=sample(proc.pid);rows.append(enrich(row,base,rows[-1],'LOAD'))
            if case=='monitor-failure':raise RuntimeError('INJECTED_MONITOR_FAILURE_AFTER_READINESS')
            if case=='timeout':time.sleep(.3)
            primary='HARMLESS_TIMEOUT' if case=='timeout' else 'SYNTHETIC_RESOURCE_GUARD'
            s.request_abort(primary)
            if case=='double-abort':s.request_abort(primary);s.request_abort('SECOND_ABORT')
    except BaseException as error:
        primary='HARMLESS_MONITOR_FAILURE' if 'INJECTED_MONITOR_FAILURE' in str(error) else 'HARNESS_FAILURE'
        s.request_abort(repr(error))
    finally:
        def recovery():
            observations=[]
            for _ in range(4):
                row=sample();rows.append(enrich(row,rows[0],rows[-1],'RECOVERY'))
                observations.append({'monotonic':time.monotonic(),'workerPresent':None if proc is None else proc.poll() is None,
                    'processGroupMembers':members(proc.pid) if proc else [],'sample':rows[-1]})
                time.sleep(.1)
            return {'observations':observations,'immediate':True}
        def save_resources():atomic_json(directory/'resources.json',rows)
        result=s.finish(primary,recovery=recovery,evidence=save_resources)
        if proc and proc.stdout:proc.stdout.close()
    passed=result['supervisor']=='TERMINATION_CONFIRMED' and result['workerExitCode']==expected and result['processGroupPresent'] is False and ready and ready['networkDenied'] and len(result['recovery']['observations'])==4
    return {'case':case,'passed':bool(passed),'primary':result['primary'],'supervisor':result['supervisor'],'exitCode':result['workerExitCode'],'signals':[r for r in result['events'] if r['event']=='SIGNAL']}

def cadence(interval):
    before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic()
    p=subprocess.run([str(HERE/'resource-probe'),str(os.getpid()),str(interval),'3'],capture_output=True,text=True,check=True,timeout=5)
    elapsed=time.monotonic()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN)
    events=[json.loads(l) for l in p.stdout.splitlines()];samples=[e for e in events if e['event']=='sample']
    gaps=[b['monotonic']-a['monotonic'] for a,b in zip(samples,samples[1:])]
    record={'intervalSeconds':interval,'elapsedSeconds':elapsed,'probeCPUSeconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,
            'samples':len(samples),'maxGapSeconds':max(gaps),'meanGapSeconds':sum(gaps)/len(gaps),'maxCollectionSeconds':max(s['collectionSeconds'] for s in samples),
            'nativeSubscriptionReady':any(e['event']=='pressure_subscription_ready' for e in events),
            'pressureNotifications':sum(e['event']=='pressure_notification' for e in events),'events':events}
    atomic_json(E/f'cadence-{interval}.json',record)
    return {k:v for k,v in record.items() if k!='events'}

def main():
    E.mkdir(parents=True,exist_ok=False)
    marker=E/'REAL_TESTS_STARTED.json'
    with marker.open('x') as f:json.dump({**stamp(),'pid':os.getpid(),'noModels':True},f,indent=2)
    atomic_json(E/'tested-source.json',{'files':[{'path':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(HERE.iterdir()) if f.is_file()]})
    tests=[]
    for args in [('normal-term','term',-15),('term-ignored-kill','ignore_term',-9),('already-exited','exit',0),('worker-crash','crash',7),('monitor-failure','term',-15),('double-abort','term',-15),('timeout','term',-15)]:
        result=one(*args);tests.append(result);atomic_json(E/'real-test-results.json',{'tests':tests,'allPassed':all(t['passed'] for t in tests),'modelLoads':0,'generationRequests':0})
        print(json.dumps(result),flush=True)
        if not result['passed']:
            print('STOP: boundary or test failure; no model execution permitted',flush=True);return 1
    atomic_json(E/'cadence-summary.json',{'tests':[cadence(.25),cadence(.1)],'stressApplied':False})
    return 0
if __name__=='__main__':raise SystemExit(main())

"""MACOS_RESOURCE_POLICY_V2 candidate evaluator; NOT adopted by any model runner."""
import math
GIB=1024**3
RESERVE=2*GIB
EARLY_RESERVE=int(2.25*GIB)
def valid_number(value):
    return type(value) in (int,float) and math.isfinite(value) and value>=0

PHASES={'IDLE','ADMISSION','LOAD','PREFILL','GENERATION','UNLOAD','RECOVERY'}

class Policy:
    def __init__(self): self.stop=None; self.degraded=False
    def evaluate(self, row, baseline, profile=None):
        if self.stop: return {'state':'UNSAFE','action':'STOP_LATCHED','reason':self.stop}
        reason=None
        if row.get('phase') not in PHASES: reason='INVALID_PHASE'
        required=('sampleAgeSeconds','availableEstimateLegacyBytes','swapUsedBytes','swapInBytesPerSecond','swapOutBytesPerSecond')
        if not valid_number(baseline.get('swapUsedBytes')): reason='BASELINE_UNAVAILABLE'
        elif any(not valid_number(row.get(k)) for k in required): reason='TELEMETRY_UNAVAILABLE'
        elif row['sampleAgeSeconds']>1.5: reason='TELEMETRY_STALE'
        elif row.get('memoryPressure') not in ('NORMAL','WARN','CRITICAL'): reason='PRESSURE_UNKNOWN'
        elif row['memoryPressure']!='NORMAL': reason='OS_PRESSURE_'+row['memoryPressure']
        elif row['availableEstimateLegacyBytes']<=EARLY_RESERVE: reason='RESERVE_APPROACHED'
        elif (type(row.get('thermalState')) is not int or row['thermalState'] not in (0,1)): reason='THERMAL_UNSAFE_OR_UNKNOWN'
        elif row['swapUsedBytes']>baseline['swapUsedBytes'] or row['swapInBytesPerSecond']>0 or row['swapOutBytesPerSecond']>0: reason='ACTIVE_SWAP'
        elif row.get('phase')=='ADMISSION' and row['swapUsedBytes']!=0: reason='EXPERIMENT_ZERO_SWAP_BASELINE'
        elif row.get('phase') in ('LOAD','PREFILL','GENERATION'):
            footprint=row.get('workerPhysicalFootprintBytes')
            if not valid_number(footprint): reason='FOOTPRINT_UNKNOWN'
            elif profile is None or not valid_number(profile.get('peakLimitBytes')) or profile['peakLimitBytes']==0: reason='PROFILE_UNAVAILABLE'
            elif footprint>profile['peakLimitBytes']: reason='PROFILE_FOOTPRINT_LIMIT'
        if reason:
            self.stop=reason;return {'state':'UNSAFE','action':'BLOCK' if row.get('phase')=='ADMISSION' else 'STOP','reason':reason}
        if row.get('phase')=='ADMISSION':
            allowance=profile.get('admissionAllowanceBytes') if profile else None
            if not valid_number(allowance) or allowance==0 or row['availableEstimateLegacyBytes']<RESERVE+allowance:
                return {'state':'BLOCKED','action':'BLOCK','reason':'UNMEASURED_OR_INSUFFICIENT_PROFILE_HEADROOM'}
        growth=row.get('compressorGrowthBytesPerSecond')
        if (type(growth) in (int,float) and math.isfinite(growth) and growth>0) or row.get('thermalState')==1:
            self.degraded=True
        return {'state':'DEGRADED' if self.degraded else 'SAFE',
                'action':'OBSERVE' if self.degraded else 'CONTINUE',
                'reason':'DIAGNOSTIC_LATCH' if self.degraded else 'OBSERVED_SIGNALS_NORMAL'}

# Resource harness V2 review implementation

No model imports or model-launch entry point. Policy V2 is **not adopted**.

- `supervisor.py`: reusable idempotent termination, error containment, recovery/finalization and signal journaling.
- `Probe.m` / `resource-probe`: read-only native telemetry and Dispatch pressure subscription.
- `run_harmless.py`, `harmless_worker.py`: fixed bounded process tests, exact worker network-denial sandbox. Completed unique evidence run; do not overwrite it.
- `policy_proposal.py`: pure sample evaluator for owner review. Admission-window aggregation, event fusion, watchdog and model adapter are separately required before model execution.
- `test_supervisor.py`, `test_policy_inputs.py`: fault/guard tests. Historical test output directories are exclusive; a future test run needs a new output location.

Owner deliverables: [memory review](../../../docs/sprint3a/MACOS_MEMORY_POLICY_REVIEW.md), [policy proposal](../../../docs/sprint3a/MACOS_RESOURCE_POLICY_V2_PROPOSAL.md), [test results](../../../docs/sprint3a/SUPERVISOR_TEST_RESULTS.md).

Old candidate scripts remain immutable executed records, including their defects. No model should be run through them again. The new lifecycle component must be integrated into a separately reviewed exact-model adapter before any future owner-authorized calibration.

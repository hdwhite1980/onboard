// Read-only native telemetry. No Metal, MLX, model, or allocation stress.
#import <Foundation/Foundation.h>
#import <IOKit/ps/IOPowerSources.h>
#include <mach/mach.h>
#include <mach/mach_time.h>
#include <sys/sysctl.h>
#include <sys/resource.h>
#include <libproc.h>
#include <time.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
static double mono(void){mach_timebase_info_data_t tb;mach_timebase_info(&tb);return (double)mach_absolute_time()*tb.numer/tb.denom/1e9;}
static void emit(NSDictionary *r){NSData *d=[NSJSONSerialization dataWithJSONObject:r options:0 error:NULL];if(d){fwrite(d.bytes,1,d.length,stdout);puts("");fflush(stdout);}}
static id numberSysctl(const char *name, size_t bytes){uint64_t n=0;size_t s=bytes;return sysctlbyname(name,&n,&s,NULL,0)==0?@(n):(id)[NSNull null];}
static NSDictionary *sample(pid_t pid){
 double start=mono(); NSMutableDictionary *r=[@{@"event":@"sample",@"schemaVersion":@2,@"monotonicClock":@"mach_absolute_time",@"monotonic":@(start),@"timestamp":[[NSDate date] description],@"workerPID":@(pid)} mutableCopy];
 vm_statistics64_data_t v={0};mach_msg_type_number_t count=HOST_VM_INFO64_COUNT;mach_port_t host=mach_host_self();vm_size_t page=0;
 kern_return_t pc=host_page_size(host,&page),vc=host_statistics64(host,HOST_VM_INFO64,(host_info64_t)&v,&count);mach_port_deallocate(mach_task_self(),host);
 r[@"vmError"]=@(vc);r[@"pageSizeBytes"]=pc==KERN_SUCCESS?@(page):(id)[NSNull null];r[@"physicalMemoryBytes"]=numberSysctl("hw.memsize",8);
 if(vc==KERN_SUCCESS&&pc==KERN_SUCCESS){
 #define FIELD(name,value) r[@name]=@((uint64_t)(value)*page)
 FIELD("machFreeIncludingSpeculativeBytes",v.free_count);FIELD("freeBytes",v.free_count-v.speculative_count);
 FIELD("inactiveBytes",v.inactive_count);FIELD("speculativeBytes",v.speculative_count);FIELD("activeBytes",v.active_count);FIELD("wiredBytes",v.wire_count);FIELD("purgeableBytes",v.purgeable_count);
 FIELD("compressorOccupancyBytes",v.compressor_page_count);FIELD("uncompressedRepresentedBytes",v.total_uncompressed_pages_in_compressor);
 FIELD("fileBackedBytes",v.external_page_count);FIELD("anonymousBytes",v.internal_page_count);
 FIELD("availableEstimateLegacyBytes",(uint64_t)v.free_count+v.inactive_count);
 r[@"swapInPagesTotal"]=@(v.swapins);r[@"swapOutPagesTotal"]=@(v.swapouts);r[@"compressionPagesTotal"]=@(v.compressions);r[@"decompressionPagesTotal"]=@(v.decompressions);
 }
 struct xsw_usage swap={0};size_t sn=sizeof(swap);int sc=sysctlbyname("vm.swapusage",&swap,&sn,NULL,0);r[@"swapUsedBytes"]=sc==0?@(swap.xsu_used):(id)[NSNull null];r[@"swapError"]=@(sc?errno:0);
 id pressure=numberSysctl("kern.memorystatus_vm_pressure_level",4);r[@"pressureRaw"]=pressure;
 r[@"memoryPressure"]= [pressure isEqual:@1]?@"NORMAL":[pressure isEqual:@2]?@"WARN":[pressure isEqual:@4]?@"CRITICAL":@"UNKNOWN";
 struct rusage_info_v4 usage={0};int rc=pid>0?proc_pid_rusage(pid,RUSAGE_INFO_V4,(rusage_info_t*)&usage):-1;
 r[@"workerPhysicalFootprintBytes"]=rc==0?@(usage.ri_phys_footprint):(id)[NSNull null];r[@"workerResidentBytes"]=rc==0?@(usage.ri_resident_size):(id)[NSNull null];r[@"workerProbeError"]=@(pid>0?(rc?errno:0):0);
 r[@"thermalState"]=@([NSProcessInfo processInfo].thermalState);
 CFTypeRef info=IOPSCopyPowerSourcesInfo();CFStringRef power=info?IOPSGetProvidingPowerSourceType(info):NULL;r[@"powerSource"]=power?(__bridge NSString*)power:(id)[NSNull null];if(info)CFRelease(info);
 r[@"collectionSeconds"]=@(mono()-start);return r;
}
int main(int argc,char **argv){@autoreleasepool{
 if(argc!=4)return 2;__block pid_t pid=atoi(argv[1]);double interval=atof(argv[2]),duration=atof(argv[3]);if(interval<.05||interval>1||duration<0||duration>210)return 2;
 if(duration==0){emit(sample(pid));return 0;}
 dispatch_queue_t queue=dispatch_queue_create("resource.probe",DISPATCH_QUEUE_SERIAL);
 dispatch_source_t pressure=dispatch_source_create(DISPATCH_SOURCE_TYPE_MEMORYPRESSURE,0,DISPATCH_MEMORYPRESSURE_NORMAL|DISPATCH_MEMORYPRESSURE_WARN|DISPATCH_MEMORYPRESSURE_CRITICAL,queue);
 if(!pressure)return 3;
 dispatch_source_set_event_handler(pressure,^{@autoreleasepool{emit(@{@"event":@"pressure_notification",@"monotonic":@(mono()),@"timestamp":[[NSDate date] description],@"pressureMask":@(dispatch_source_get_data(pressure))});}});dispatch_resume(pressure);
 emit(@{@"event":@"pressure_subscription_ready",@"monotonic":@(mono()),@"intervalSeconds":@(interval)});
 dispatch_source_t timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,queue);
 dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,0),(uint64_t)(interval*NSEC_PER_SEC),NSEC_PER_MSEC);
 dispatch_source_set_event_handler(timer,^{@autoreleasepool{emit(sample(pid));}});dispatch_resume(timer);
 fcntl(STDIN_FILENO,F_SETFL,fcntl(STDIN_FILENO,F_GETFL)|O_NONBLOCK);
 __block NSMutableData *input=[NSMutableData data];
 dispatch_source_t controls=dispatch_source_create(DISPATCH_SOURCE_TYPE_READ,STDIN_FILENO,0,queue);
 dispatch_source_set_event_handler(controls,^{
  char buf[128];ssize_t n=read(STDIN_FILENO,buf,sizeof(buf));
  if(n==0){dispatch_source_cancel(controls);return;}
  if(n<0){if(errno==EAGAIN)return;exit(4);}
  [input appendBytes:buf length:n];if(input.length>256)exit(4);
  NSString *text=[[NSString alloc] initWithData:input encoding:NSUTF8StringEncoding];
  NSArray *lines=[text componentsSeparatedByString:@"\n"];
  if(lines.count>1){
   for(NSUInteger i=0;i+1<lines.count;i++){
    int nextPID;double nextInterval;char extra;NSString *line=lines[i];
    if(sscanf(line.UTF8String,"%d %lf %c",&nextPID,&nextInterval,&extra)!=2 || nextPID<0 || (nextInterval!=.1 && nextInterval!=.25))exit(4);
    pid=nextPID;
    dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,0),(uint64_t)(nextInterval*NSEC_PER_SEC),NSEC_PER_MSEC);
    emit(@{@"event":@"control_applied",@"monotonic":@(mono()),@"workerPID":@(pid),@"intervalSeconds":@(nextInterval)});
   }
   input=[[lines.lastObject dataUsingEncoding:NSUTF8StringEncoding] mutableCopy];
  }
 });dispatch_resume(controls);
 dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(duration*NSEC_PER_SEC)),queue,^{exit(0);});dispatch_main();
}return 0;}

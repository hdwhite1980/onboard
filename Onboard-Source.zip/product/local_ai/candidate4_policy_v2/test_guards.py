"""Pure adapter checks only. No model imports or workers."""
import sys,time,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p
class Guards(unittest.TestCase):
 def setUp(self):
  self.row={k:0 for k in p.REQUIRED};self.row.update(monotonic=10,physicalMemoryBytes=16*p.GIB,pageSizeBytes=16384,availableEstimateLegacyBytes=5*p.GIB,memoryPressure='NORMAL',thermalState=0,powerSource='AC Power',workerPhysicalFootprintBytes=p.GIB,workerResidentBytes=p.GIB)
 def check(self,**changes):return p.violation(dict(self.row,**changes),self.row,self.row,10,True)
 def test_compression_not_stop(self):self.assertIsNone(self.check(compressorOccupancyBytes=3*p.GIB,compressionPagesTotal=100000))
 def test_ceiling_equal_allowed(self):self.assertIsNone(self.check(workerPhysicalFootprintBytes=4.5*p.GIB))
 def test_ceiling_exceeded(self):self.assertIn('footprint exceeded',self.check(workerPhysicalFootprintBytes=4.5*p.GIB+1))
 def test_reserve_equal_stop(self):self.assertIn('reserve',self.check(availableEstimateLegacyBytes=2.25*p.GIB))
 def test_pressure_all_fail(self):
  for v in ('WARN','CRITICAL','UNKNOWN',None):self.assertIn('pressure',self.check(memoryPressure=v))
 def test_swap_growth(self):self.assertIn('swap used',self.check(swapUsedBytes=1))
 def test_swap_in(self):self.assertIn('swap-in',self.check(swapInPagesTotal=1))
 def test_swap_out(self):self.assertIn('swap-out',self.check(swapOutPagesTotal=1))
 def test_initial_swap(self):
  a=dict(self.row,swapUsedBytes=1);self.assertIn('initial swap',p.violation(a,a,a,10))
 def test_counter_reset(self):
  self.row['compressionPagesTotal']=1;self.assertIn('reset',self.check(compressionPagesTotal=0))
 def test_missing(self):
  for field in p.REQUIRED:self.assertIsNotNone(self.check(**{field:None}))
 def test_nan(self):self.assertIsNotNone(self.check(compressorOccupancyBytes=float('nan')))
 def test_unknown_footprint(self):self.assertIn('unavailable',self.check(workerPhysicalFootprintBytes=None))
 def test_thermal(self):
  for v in (None,2,3,False):self.assertIn('thermal',self.check(thermalState=v))
 def test_fair_allowed(self):self.assertIsNone(self.check(thermalState=1))
 def test_stale(self):self.assertIn('stale',self.check(monotonic=8))
 def test_future(self):self.assertIn('clock',self.check(monotonic=11))
 def test_events(self):
  self.assertIsNone(p.pressure_reason(1))
  for mask in (0,2,4,6,8,None):self.assertIsNotNone(p.pressure_reason(mask))
 def test_deadlines(self):
  self.assertIn('host',p.deadline(2,None,0,None,'IDLE',None))
  self.assertIn('MLX',p.deadline(2,None,2,0,'LOAD',0))
  self.assertIn('load',p.deadline(91,0,91,91,'LOAD',0))
  self.assertIn('generation',p.deadline(61,0,61,61,'GENERATION',0))
  self.assertIn('wall',p.deadline(181,0,181,181,'UNLOAD',180))
 def test_classify(self):
  self.assertEqual(p.classify(False,['RESOURCE: stop'],[]),'MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2')
  self.assertEqual(p.classify(False,['MONITOR: stale'],[{'event':'MODEL_LOADED'}]),'LOCAL_GENERATION_ABORTED_RESOURCE_POLICY_V2')
  self.assertEqual(p.classify(True,[],[]),'LOCAL_GENERATION_SUCCESS')
 def test_owner_limits(self):
  self.assertEqual(p.POLICY['reserveBytes'],2*p.GIB);self.assertEqual(p.POLICY['workerCeilingBytes'],4.5*p.GIB);self.assertFalse(p.POLICY['compressionOnlyStop'])
if __name__=='__main__':unittest.main(verbosity=2)

"""Pure mock tests of the unchanged component with adapter's immediate-stop setting."""
import errno,json,signal,subprocess,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'resource_harness_v2'))
from supervisor import Supervisor
class Fake:
 pid=2147483000
 def __init__(self):self.status=None;self.present=True;self.calls=[]
 def poll(self):return self.status
 def wait(self,timeout):
  if self.status is None:raise subprocess.TimeoutExpired('fake',timeout)
  return self.status
 def send(self,pgid,sig):
  self.calls.append(sig)
  if sig==signal.SIGKILL:self.status=-9;self.present=False
class Tests(unittest.TestCase):
 def test_zero_grace_kills_and_seals(self):
  with tempfile.TemporaryDirectory() as d:
   p=Fake();s=Supervisor(Path(d)/'run',p,p.pid,signal_group=p.send,group_present=lambda:p.present,term_wait=0)
   s.request_abort('RESOURCE: synthetic');s._error('termination',s._terminate)
   result=s.finish('MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2',recovery=lambda:{'samples':['synthetic']})
   self.assertEqual(p.calls,[signal.SIGTERM,signal.SIGKILL]);self.assertEqual(result['supervisor'],'TERMINATION_CONFIRMED')
   self.assertEqual(len([e for e in result['events'] if e['event']=='SIGNAL_INTENT']),2)
   self.assertTrue((Path(d)/'run/manifest.json').exists())
 def test_permission_error_never_escapes(self):
  def denied(*_):raise PermissionError(errno.EPERM,'synthetic')
  with tempfile.TemporaryDirectory() as d:
   p=Fake();s=Supervisor(Path(d)/'run',p,p.pid,signal_group=denied,group_present=lambda:True,term_wait=0)
   s.request_abort('RESOURCE: synthetic');s._error('termination',s._terminate)
   result=s.finish('MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2',recovery=lambda:{'samples':['synthetic']})
   self.assertEqual(result['supervisor'],'TERMINATION_PERMISSION_ERROR');self.assertEqual(result['evidenceCompleteness'],'PARTIAL')
   self.assertEqual(len([e for e in result['events'] if e['event']=='SIGNAL']),2)
if __name__=='__main__':unittest.main(verbosity=2)

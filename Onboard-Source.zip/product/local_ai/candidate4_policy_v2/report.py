"""Write the measured report/comparison, without running or changing the experiment."""
import json
from pathlib import Path
R=Path(__file__).resolve().parents[3];D=R/'docs/sprint3a';E=D/'evidence/candidate4-policy-v2-calibration-01'
m=json.loads((E/'measurements.json').read_text());r=json.loads((E/'run-result.json').read_text());out=(E/'raw-output.txt').read_text();G=1024**3
fmt=lambda n:f'{n/G:.6f} GiB'
g=m['generation'];re=m['recoveryLast'];c=m['cacheTotals']
report=f'''# Candidate 4 Granite — Policy V2 bounded calibration

2026-09-23 · **UNMEASURED_PROFILE_OWNER_AUTHORIZED_CALIBRATION** · Experimental qualification only.

| Result dimension | Recorded result |
|---|---|
| **PRIMARY** | **LOCAL_GENERATION_SUCCESS** |
| **SUPERVISOR_RESULT** | **CLEANUP_OR_EVIDENCE_ERROR** |
| Native monitor lifecycle sub-result | **TERMINATION_PERMISSION_ERROR** |
| **EVIDENCE_COMPLETENESS** | **PARTIAL** |
| Model lifecycle / qualified tasks | **EXPERIMENTAL / NONE** |
| Profile promotion | **Withheld** pending safety-control resolution; no automatically adopted working allowance. |

One worker launched, one model load completed, one generation request completed, and one unload completed. The Granite worker exited **0**, was reaped and its group was absent. No Policy V2 hard resource condition was recorded. Compression growth latched **LOCAL_DEGRADED** and did not terminate the attempt.

The native telemetry helper's cleanup recorded TERM **SENT**, then an immediate KILL fallback **PERMISSION_DENIED / errno 1**. The helper was reaped with exit **-15** and its group was observed absent. Its failed KILL was not relabeled successful. The corrected lifecycle contained the error and continued independent recovery and finalization. This is successful bounded local generation with a separate safety-control failure, **not a fully qualified resource/supervisor pass**. No retry, second prompt or corrective generation occurred.

## Authority and identity

The owner approved MACOS_RESOURCE_POLICY_V2 only for experimental model qualification and authorized this exact attempt. The sole admission exception was the unmeasured 4.5 GiB working allowance; the 2 GiB reserve, 2.25 GiB early trigger, zero-swap conditions, pressure/thermal/security/telemetry stops and 4.5 GiB worker ceiling remained. Compression-only termination was removed for this new experiment. All earlier experiments retain their original rules and results.

- Organization ID: `org.experimental.granite-4.0-h-micro.mlx4-g64`.
- Repository: `mlx-community/granite-4.0-h-micro-4bit`.
- Revision: `0a29e17503da7de371af61a0a532853810637627`.
- Package manifest SHA-256: `2ac1559f0e7d0e8848242f5db55226b23715ca9a8b12968242065b01965b3547`.
- Weight SHA-256: `573654ce0613804f3e0e5ec692b039f907f13c88273dc08993b9adbeb04428f1`.
- Weight size: 1,796,848,117 bytes; affine 4-bit, group 64.
- Retained Python 3.12.14 arm64; MLX/MLX-Metal 0.32.2, MLX-LM 0.31.3, Transformers 5.17.0, tokenizers 0.23.2. Full runtime reverification passed for 34 packages / 5,555 installed wheel files; no runtime or quantization change.

A new adapter imported the unchanged Resource Harness V2 lifecycle component; it did not execute or patch the historical Granite/Qwen supervisors. Worker boundary identity matched the final harmless test: same interpreter and UID, `-I -B`, fresh process session, and the same network-denied seatbelt policy. The parent ran through the tool-approved execution context outside the Codex sandbox. Zero TERM grace was selected for immediate hard stops and verified with mock lifecycle tests. The monitor helper has a separate lifecycle instance; its failed cleanup remains disclosed below.

Before the unique attempt, 21 pure guard tests, two mock lifecycle adapter tests, and one passive native sampler protocol check passed. The sampler check targeted its own small test process; it did not launch an AI worker. Twelve source/binary dependencies were frozen before execution. No model execution occurred during preparation/testing.

## Preparation, activation and security

The verifier rechecked the exact package, complete retained runtime and private activation snapshot, then exited successfully. Natural settling lasted **10.001281 seconds** before the monitor/watchdog and admission baseline. No host purge, application closure, VM adjustment, synthetic memory pressure or security-software termination was performed.

The worker reverified the private snapshot immediately before load with allowlist, hashes, no-follow descriptors, regular/single-link/owner/non-executable checks, metadata stability, root identity and post-read identity. The documented same-user race remains: the runtime reopens verified paths; a same-UID process can potentially change permissions or path state after verification. This is not production activation hardening.

The worker's negative connection control returned **EPERM (1), DENIED** before runtime/model loading. Offline/local-only paths were used, Hub download/resolution calls were trapped, and remote code, tools, external providers and fallback were disabled. Worker audit hooks prohibited later connection/process launches. Loaded-image/module checks reported no FoundationModels framework or prohibited provider. No network/security hard stop or unexpected worker-group member was recorded.

For **this exact completed bounded request only**:

| Dependency question | Answer |
|---|---|
| APPLE INTELLIGENCE REQUIRED | **NO** |
| APPLE FOUNDATION MODELS REQUIRED | **NO** |
| EXTERNAL AI REQUIRED | **NO** |
| INTERNET INFERENCE REQUIRED | **NO** |

These statements concern the observed inference request. They do not convert the monitor-cleanup failure into a safety pass or generalize to other workloads.

## Exact workload and timings

The preflight's frozen Candidate 2 `professional-1` messages, pinned native Granite template, rendered text and token IDs matched both preflight and prior calibration evidence **before model construction**. The shorter conflicting system instruction was not used.

| Field | Observation |
|---|---|
| Batch / sampler / prefill chunk | 1 / greedy argmax / 128 tokens |
| Context / maximum output | 512 total / 128 maximum output within total |
| Prompt tokens | **110** |
| Maximum reserved prompt + output | **238** |
| Actual output tokens | **58** non-stop tokens |
| Sampled tokens including EOS | **59** |
| Prompt + sampled tokens | **169**, below both 238 reserved and 512 total ceiling |
| Stop reason | EOS (`stop`) |
| Measured model-load interval | **{m['loadDurationSeconds']:.6f} s** |
| Runtime-ready to load-begin interval | **{m['activationAndPromptVerificationSeconds']:.6f} s**, covering activation/prompt work and command scheduling |
| Generation latency | **{g['seconds']:.6f} s** including prefill |
| First token | **{g['firstTokenSeconds']:.6f} s** |
| End-to-end output throughput | **{g['tokensPerSecond']:.3f} non-stop tokens/s** |
| Decode interval throughput | **{g['decodeTokensPerSecond']:.3f} sampled intervals/s**, distinct denominator from end-to-end throughput |
| Unload interval | **{m['unloadSeconds']:.6f} s** |

Load duration starts at `load_begin` and ends at `MODEL_LOADED`; it excludes earlier runtime initialization, package verification and tokenizer rendering. It is not a cold-start benchmark. The pinned generator pipelines a next step; actual attention offset was 169. No second generation request was issued.

## Resource observations

The named legacy-equivalent estimate is native `(free_count + inactive_count) × page_size`, equivalent to historical printed `free + inactive + speculative`. It remains an approximate headroom indicator, not guaranteed allocatable RAM.

| Resource | Observation |
|---|---|
| Physical host memory | 16 GiB shared RAM |
| Baseline available estimate | **{fmt(m['baselineAvailableEstimateBytes'])}** |
| Minimum available estimate | **{fmt(m['minimumAvailableEstimateBytes'])}** |
| Protected reserve / early trigger | Unchanged 2 / 2.25 GiB |
| Baseline compressor occupancy | **{fmt(m['baselineCompressorBytes'])}** |
| Maximum compressor occupancy | **{fmt(m['maxCompressorBytes'])}** |
| Maximum growth from baseline | **{fmt(m['maxCompressorDeltaBytes'])}**, {m['maxCompressorDeltaBytes']/1024**2:.3f} MiB |
| Observed growth-rate range | {m['compressorGrowthRateBytesPerSecond']['min']/G:.3f} to **{m['compressorGrowthRateBytesPerSecond']['max']/G:.3f} GiB/s**, interval-derived; negative is shrinkage |
| Lifetime compression / decompression counter increases during live monitoring | {m['compressionCounterDeltaPages']:,} / {m['decompressionCounterDeltaPages']:,} pages |
| Swap used / growth | **0 / 0 bytes** |
| Swap-in / swap-out measured rates | **0 / 0 page-equivalent bytes/s** |
| Periodic pressure | **NORMAL** throughout recorded live/recovery samples |
| Native pressure events | Subscription confirmed; **zero transition callbacks** observed |
| Worker physical footprint maximum | **{fmt(m['workerPhysicalFootprintBytes']['max'])}** |
| Worker resident-size maximum | **{fmt(m['workerResidentBytes']['max'])}** |
| Experimental footprint ceiling | Unchanged **4.5 GiB** |
| Highest observed MLX active | **{fmt(m['mlx']['active'])}** |
| Highest observed MLX allocator cache | **{fmt(m['mlx']['cache'])}** |
| MLX recorded peak-active counter | **{fmt(m['mlx']['peak'])}** |
| Thermal / power | **Nominal / AC** in every recorded sample |

Task footprint, RSS and MLX counters have different accounting and must not be added as separate physical pools. Sampled maxima are not certified terminal peaks. Host-wide compression is not attributed solely to Granite. The observed growth exceeds the historical 512 MiB condition, but there was no old-policy rerun and host conditions were not held identical; this does not isolate causation or retroactively change the historical outcome.

## Hybrid caches and unload

All 40 cache entries were observed empty after load and populated during the one generation. The adapter validated native mixed precision rather than applying the old Qwen FP16-only assumption.

| Structure | Count / class | Observed shape / dtype | Logical bytes total |
|---|---|---|---|
| Recurrent state | 36 / ArraysCache recurrent slot | `[1, 64, 64, 128]` / FP32 | {c['recurrentArrayBytes']:,} (**72 MiB**) |
| Convolution state | 36 / ArraysCache convolution slot | `[1, 3, 4352]` / FP16 | {c['convolutionArrayBytes']:,} |
| Attention caches | 4 / KVCache, key and value each | `[1, 8, 256, 64]` / FP16; used offset 169 | {c['attentionAllocatedBytes']:,} (**2 MiB**) |

These are observable logical array sizes. Slices can share backing allocations; no independent physical allocation per state is claimed. Full per-layer classes/shapes/dtypes and checkpoints are preserved in [cache observations](evidence/candidate4-policy-v2-calibration-01/cache-observations.json).

At `MODEL_LOADED`, MLX active was {fmt(m['atLoad']['active'])}; after generation it was {fmt(m['afterGeneration']['active'])}. After explicit unload and allocator-cache release, MLX active was **32 bytes**, cache **0**, and the peak counter retained its high-water value. The worker then exited normally and was reaped. No forced termination signal was needed for the Granite worker.

## Raw output and narrow quality review

The exact response is preserved in [raw-output.txt](evidence/candidate4-policy-v2-calibration-01/raw-output.txt), SHA-256 `{m['rawOutputSHA256']}`:

```text
{out}
```

| Requested quality check | Assessment |
|---|---|
| Sarah preserved | PASS |
| Encryption uncertainty preserved | PASS for uncertainty about deployment impact; the resolution-progress phrasing is stronger than the source's question about understanding the issue. |
| October 3 preserved | PASS; “October 3rd” is the same date. |
| Deployment preserved | PASS |
| Professional tone materially improved | PASS; capitalization, sentences and greeting improved. The response is verbose and adds boilerplate. |
| No invented facts | **Strict pass withheld.** No fabricated resolution/cause/impact outcome appears, but “progress made in resolving” presupposes progress beyond the source. A sign-off and `[Your Name]` placeholder are additions. |

This is one response, not a Candidate 4 quality qualification or a corpus comparison. No repair generation was requested.

## Supervisor and evidence findings

The Granite worker PID/PGID was **76791**. The native monitor PID/PGID was **76790**. Worker cleanup observed an already-exited process, reaped exit 0, and confirmed an empty group.

Monitor cleanup then recorded:

1. SIGTERM intent and **SENT** result.
2. Zero-grace wait expired; SIGKILL fallback was attempted.
3. SIGKILL returned **PERMISSION_DENIED**, errno 1.
4. Monitor was reaped with **-15** and its group was observed absent.
5. The monitor lifecycle retained **TERMINATION_PERMISSION_ERROR / PARTIAL**.
6. The outer lifecycle recorded **CLEANUP_OR_EVIDENCE_ERROR / PARTIAL**, then attempted and preserved independent recovery and final results.

There is no inference that failed KILL succeeded. Its relation to the successful TERM and exiting-group race is a hypothesis, not an established EPERM cause. The monitor cleanup exception occurred before the adapter's subsequent thread-join loop; that verification was therefore skipped. Stop intent was set, recovery ran, the main process completed, and final logs were sealed, but explicit join completion was not certified. No executable code was changed after the unique run.

The component's harmless-only zero workload placeholders were replaced in its final record by the adapter's actual launch/command/event counts; the field identifies that source. The top-level [run result](evidence/candidate4-policy-v2-calibration-01/run-result.json) and nested [monitor result](evidence/candidate4-policy-v2-calibration-01/monitor-lifecycle/result.json) remain the unmodified execution artifacts.

## Sampling and recovery

There were **50 live samples**. LOAD gaps averaged {m['phaseSampling']['LOAD']['meanSeconds']*1000:.3f} ms (maximum {m['phaseSampling']['LOAD']['maxSeconds']*1000:.3f}); PREFILL maximum was {m['phaseSampling']['PREFILL']['maxSeconds']*1000:.3f} ms. GENERATION gaps averaged {m['phaseSampling']['GENERATION']['meanSeconds']*1000:.3f} ms (maximum {m['phaseSampling']['GENERATION']['maxSeconds']*1000:.3f}). Maximum live sample age at receipt was **{m['maxLiveSampleAgeSeconds']*1000:.3f} ms**. No 1.5-second outer freshness violation was recorded. Native event silence was not used as freshness proof; periodic data and an independent watchdog remained active.

Independent recovery began **{m['firstRecoveryAfterLastLiveSeconds']:.6f} s** after the last live sample and produced **12** read-only samples. Their actual intervals averaged **{m['recoverySampling']['meanSeconds']*1000:.3f} ms**, maximum **{m['recoverySampling']['maxSeconds']*1000:.3f} ms**. The 250 ms recovery target was not met exactly: the loop slept 250 ms after probe/process checks rather than compensating for their overhead. This is a disclosed cadence limitation, not silently relabeled 250 ms sampling.

Every recovery observation found the Granite worker/group absent, pressure NORMAL, swap zero and thermal nominal. Last recovery estimate: **{fmt(re['availableEstimateLegacyBytes'])}**; compressor occupancy **{fmt(re['compressorOccupancyBytes'])}**. The helper's absence and reaping are separately recorded in its lifecycle. Recovery MLX fields carry the last worker sample with explicit increasing age; they are not new measurements from an exited worker.

## Profile analysis and stop

A complete one-request observation now exists: measured task maximum {fmt(m['workerPhysicalFootprintBytes']['max'])}, load/generation checkpoints, hybrid states and graceful unload. This supports further review, but does not establish a safe general working allowance, sustained steady envelope or 512-token worst case. Actual context was only 169 tokens including stop; cache capacity was not a test at the 512 ceiling.

**Do not promote this profile to MEASURED_EXPERIMENTAL acceptance yet:** the overall safety/evidence result is partial. Model lifecycle remains EXPERIMENTAL and qualified tasks NONE. Preserve the existing **4.5 GiB experimental ceiling**. A future working allowance should cover the observed workload footprint plus independently justified context-growth, allocation-burst, concurrency and measurement-uncertainty margins; this one run cannot quantify those margins. No smaller number or production admission threshold is adopted. The unadopted 4.5 + 2 GiB planning proposal is not validated by this result.

The next prerequisite is a separately authorized review of native-monitor termination/finalization and recovery cadence. This task performs no repair/retry and no further model work. No 16-case quality, adversarial, RAG, meeting preparation, 2,048-context, sustained run, alternative model or Sprint 3B work followed.

Raw evidence is appended under [candidate4-policy-v2-calibration-01](evidence/candidate4-policy-v2-calibration-01). Historical experiment evidence and executed sources are preserved; the prior comparison was archived byte-for-byte before its authorized measured-facts update.
'''
with (D/'CANDIDATE4_GRANITE_POLICY_V2_CALIBRATION.md').open('x') as f:f.write(report)
comparison=(D/'LOCAL_MODEL_COMPARISON.md').read_text()
comparison=comparison.replace('Granite now has one bounded load attempt ending at a resource guard, with no generation or quality evidence.','Granite has a historical resource-guard-aborted load plus one new Policy V2 request with LOCAL_GENERATION_SUCCESS and PARTIAL safety/evidence status due to native-monitor cleanup. The single response is not quality qualification.')
old='No generated Granite output exists to compare with C2.'
comparison=comparison.replace(old,'At that preflight stage, no generated Granite output existed to compare with C2; the later Policy V2 single-response observation is recorded below.')
comparison+='''\n## Candidate 4 Policy V2 calibration — one measured request\n\nThe owner approved experimental Policy V2 and one new Granite attempt with the exact 110-token frozen prompt. **PRIMARY: LOCAL_GENERATION_SUCCESS. SUPERVISOR: CLEANUP_OR_EVIDENCE_ERROR. EVIDENCE: PARTIAL.** One load/generation/unload completed; worker exit 0 and empty group were recorded. No retry occurred. [Full Policy V2 report](CANDIDATE4_GRANITE_POLICY_V2_CALIBRATION.md).\n\nSampled worker physical-footprint maximum was **2.382082 GiB**, MLX peak-active counter **2.189797 GiB**, and minimum legacy-equivalent available estimate **3.873108 GiB**. Compressor growth reached **0.743805 GiB** and latched LOCAL_DEGRADED without a standalone stop. All recorded pressure was NORMAL, swap used/growth/activity zero, and thermal nominal. These observations cover one request, not a general safe memory envelope.\n\nModel load interval was **0.314636 s** excluding activation/runtime preparation. The response produced **58 output tokens** (59 sampled including EOS) in **2.861894 s**, about **20.266 end-to-end output tokens/s**. The worker used 36 FP32 recurrent states, 36 FP16 convolution states and four FP16 attention caches. Raw output materially improved professional tone and preserved Sarah, October 3 and uncertainty about deployment impact. Strict factual-fidelity pass is withheld because resolution-progress phrasing is stronger than the source and boilerplate/signature placeholder was added. No multi-case quality claim follows.\n\nNative monitor cleanup recorded TERM SENT followed by KILL EPERM; the helper was reaped with -15 and its group absent. The corrected lifecycle preserved the permission failure, recovery and final results. Twelve recovery samples found the Granite worker/group absent with normal pressure and zero swap; recovery intervals averaged about 328 ms against a 250 ms target. This prevents a clean safety-control qualification.\n\nNo profile promotion or reduced working allowance is adopted. Lifecycle remains **EXPERIMENTAL**, qualified tasks **NONE**. Historical Candidate 1/2/4 outcomes remain unchanged; no alternate models or further workloads were run.\n'''
(D/'LOCAL_MODEL_COMPARISON.md').write_text(comparison)
print('Created calibration report and updated comparison with measured facts.')

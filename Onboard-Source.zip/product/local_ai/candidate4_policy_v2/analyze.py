"""Offline analysis only. No AI runtime imports or execution."""
import json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[3];E=R/'docs/sprint3a/evidence/candidate4-policy-v2-calibration-01'
def save(name,value):
 with (E/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def main():
 run=json.loads((E/'run-result.json').read_text());ev=[json.loads(l) for l in (E/'worker-events.jsonl').read_text().splitlines()];rows=[json.loads(l) for l in (E/'resources.jsonl').read_text().splitlines()];rec=json.loads((E/'lifecycle/recovery.json').read_text())['samples'];base=json.loads((E/'baseline.json').read_text())['sample']
 events={name:[x for x in ev if x['event']==name] for name in ['started','network_negative_control','runtime_ready','activation_verified','prompt_verified','load_begin','MODEL_LOADED','generation_begin','generated','unload_begin','unloaded','exiting']}
 assert all(len(v)==1 for v in events.values()),{k:len(v) for k,v in events.items()}
 generated=events['generated'][0];load=events['MODEL_LOADED'][0];unloaded=events['unloaded'][0]
 assert run['primary']=='LOCAL_GENERATION_SUCCESS' and not run['aborts'] and run['workerExitCode']==0
 assert run['workerLaunches']==run['modelLoads']==run['generationRequests']==run['unloadRequests']==1
 assert all(x['memoryPressure']=='NORMAL' and x['swapUsedBytes']==0 and x['thermalState'] in (0,1) for x in rows+rec)
 assert max(x['swapInPagesTotal'] for x in rows+rec)==min(x['swapInPagesTotal'] for x in rows+rec)
 assert max(x['swapOutPagesTotal'] for x in rows+rec)==min(x['swapOutPagesTotal'] for x in rows+rec)
 assert min(x['availableEstimateLegacyBytes'] for x in rows)>2.25*1024**3
 assert max(x['workerPhysicalFootprintBytes'] or 0 for x in rows)<=4.5*1024**3
 assert all(not x['workerPresent'] and not x['processGroupMembers'] for x in rec)
 assert events['network_negative_control'][0]['denied']
 imgs=[n for x in ev for n in x.get('images',[])];assert not any('foundationmodels' in n.lower() for n in imgs)
 frozen=json.loads((R/'docs/sprint3a/evidence/candidate4-calibration-01/token-budget.json').read_text());assert events['prompt_verified'][0]['tokenIDs']==frozen['tokenIDs']
 with (E/'raw-output.txt').open('x') as f:f.write(generated['rawOutput'])
 def gaps(rs):
  d=[b['monotonic']-a['monotonic'] for a,b in zip(rs,rs[1:])]
  return {'count':len(rs),'minSeconds':min(d) if d else None,'maxSeconds':max(d) if d else None,'meanSeconds':sum(d)/len(d) if d else None}
 def rng(field,rs=rows):
  vals=[x[field] for x in rs if x.get(field) is not None]
  return {'min':min(vals),'max':max(vals)} if vals else None
 phases={phase:gaps([x for x in rows if x['phase']==phase]) for phase in sorted({r['phase'] for r in rows})}
 cache=generated['cacheStructure'];save('cache-observations.json',{'emptyAtLoad':load['cacheStructure'],'checkpoints':[x for x in ev if x['event']=='hybrid_cache'],'afterGeneration':cache})
 metrics={'baselineAvailableEstimateBytes':base['availableEstimateLegacyBytes'],'minimumAvailableEstimateBytes':min(x['availableEstimateLegacyBytes'] for x in rows),
  'baselineCompressorBytes':base['compressorOccupancyBytes'],'maxCompressorBytes':max(x['compressorOccupancyBytes'] for x in rows),
  'maxCompressorDeltaBytes':max(x['compressorOccupancyBytes'] for x in rows)-base['compressorOccupancyBytes'],
  'compressorGrowthRateBytesPerSecond':rng('compressorGrowthBytesPerSecond'),'compressionCounterDeltaPages':rows[-1]['compressionPagesTotal']-base['compressionPagesTotal'],'decompressionCounterDeltaPages':rows[-1]['decompressionPagesTotal']-base['decompressionPagesTotal'],
  'swapUsedBytes':rng('swapUsedBytes',rows+rec),'swapDeltaBytes':rng('swapDeltaBytes',rows+rec),'swapInRate':rng('swapInBytesPerSecond',rows+rec),'swapOutRate':rng('swapOutBytesPerSecond',rows+rec),
  'pressureStates':sorted({x['memoryPressure'] for x in rows+rec}),'pressureNotifications':[x for x in map(json.loads,(E/'pressure-events.jsonl').read_text().splitlines()) if x['event']=='pressure_notification'],
  'workerPhysicalFootprintBytes':rng('workerPhysicalFootprintBytes'),'workerResidentBytes':rng('workerResidentBytes'),
  'mlx':{k:max(x['memory'][k] for x in ev if x.get('memory')) for k in ('active','cache','peak')},
  'atLoad':load['memory'],'afterGeneration':generated['memory'],'afterUnload':unloaded['memory'],'cacheTotals':cache['totals'],
  'loadDurationSeconds':load['seconds'],'activationAndPromptVerificationSeconds':events['load_begin'][0]['monotonic']-events['runtime_ready'][0]['monotonic'],
  'generation':{k:generated[k] for k in ['promptTokens','outputTokens','sampledTokensIncludingStop','finishReason','seconds','firstTokenSeconds','tokensPerSecond','decodeTokensPerSecond']},
  'unloadSeconds':unloaded['monotonic']-events['unload_begin'][0]['monotonic'],
  'thermalStates':sorted({x['thermalState'] for x in rows+rec}),'powerSources':sorted({x['powerSource'] for x in rows+rec}),
  'liveSampling':gaps(rows),'phaseSampling':phases,'maxLiveSampleAgeSeconds':max(x['sampleAgeSeconds'] for x in rows),'recoverySampling':gaps(rec),
  'recoveryFirst':rec[0],'recoveryLast':rec[-1],'firstRecoveryAfterLastLiveSeconds':rec[0]['monotonic']-rows[-1]['monotonic'],
  'first512MiBCompressionCrossing':next((x for x in rows if x['compressorDeltaBytes']>=512*1024**2),None),
  'rawOutputSHA256':hashlib.sha256((E/'raw-output.txt').read_bytes()).hexdigest(),'foundationModelsImagesObserved':False}
 save('measurements.json',metrics)
 save('quality-review.json',{'scope':'Only frozen professional-1 response; not quality qualification','Sarah':'PASS','encryptionUncertainty':'PASS: whether impact remains unresolved; wording shifts from understanding the issue toward resolution progress','October3':'PASS: October 3rd is the same calendar date','deployment':'PASS','professionalToneMateriallyImproved':'PASS: professional greeting, capitalization, complete sentences; verbose boilerplate added','noInventedFacts':'STRICT_PASS_WITHHELD: no fabricated resolution or impact outcome, but progress made in resolving presupposes progress beyond the source; signature and [Your Name] placeholder are additions','overall':'Single-response tone improvement observed; strict fidelity pass withheld','productTasksQualified':[]})
 print(json.dumps({k:v for k,v in metrics.items() if k not in ('recoveryFirst','recoveryLast','first512MiBCompressionCrossing')},indent=2))
if __name__=='__main__':main()

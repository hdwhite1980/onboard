"""Read-only checks plus append-only final seal; no runtime/model execution."""
from pathlib import Path
import datetime,hashlib,json,re
R=Path(__file__).resolve().parents[3];E=R/'docs/sprint3a/evidence/candidate4-policy-v2-calibration-01';D=R/'docs/sprint3a';H=R/'product/local_ai/candidate4_policy_v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
 with (E/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def main():
 old=json.loads((E/'preservation-before.json').read_text());comparison='docs/sprint3a/LOCAL_MODEL_COMPARISON.md'
 changed=[row['path'] for row in old if sha(R/row['path'])!=row['sha256']]
 assert changed==[comparison],changed
 expected=next(row for row in old if row['path']==comparison)
 assert sha(E/'comparison-before.md')==expected['sha256']
 frozen=json.loads((E/'tested-source.json').read_text())['files']
 for row in frozen:assert sha(R/row['path'])==row['sha256'],row['path']
 checked=[]
 for name in ['run-manifest.json','lifecycle/manifest.json','monitor-lifecycle/manifest.json']:
  p=E/name
  for row in json.loads(p.read_text())['files']:
   f=p.parent/row['path'];assert sha(f)==row['sha256'],str(f)
  checked.append(name)
 report=D/'CANDIDATE4_GRANITE_POLICY_V2_CALIBRATION.md'
 for p in [report,D/'LOCAL_MODEL_COMPARISON.md']:
  for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
   if not link.startswith(('http:','https:')):assert (p.parent/link).exists(),link
 result=json.loads((E/'run-result.json').read_text());assert result['primary']=='LOCAL_GENERATION_SUCCESS' and result['evidenceCompleteness']=='PARTIAL'
 monitor=json.loads((E/'monitor-lifecycle/result.json').read_text());assert monitor['supervisor']=='TERMINATION_PERMISSION_ERROR' and monitor['workerExitCode']==-15
 save('preservation-check.json',{'historicalFilesChecked':len(old),'unchanged':len(old)-1,'authorizedComparisonUpdate':comparison,'priorComparisonArchivedByteExact':True,'executedSourceFilesStillExact':len(frozen),'originalExecutionManifestsVerified':checked,'executedCodeChangedAfterRun':False})
 save('completion.json',{'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'primary':result['primary'],'supervisorResult':result['supervisor'],'monitorSupervisorResult':monitor['supervisor'],'evidenceCompleteness':'PARTIAL','workerLaunches':1,'modelLoads':1,'generationRequests':1,'unloadRequests':1,'modelLifecycle':'EXPERIMENTAL','qualifiedTasks':[],'profilePromotion':'WITHHELD_SAFETY_CONTROL_REVIEW_REQUIRED','retries':0,'additionalModelWork':False,'stop':True})
 files=sorted([p for p in E.rglob('*') if p.is_file() and p.name!='EVIDENCE_MANIFEST.json']+[p for p in H.iterdir() if p.is_file()]+[report,D/'LOCAL_MODEL_COMPARISON.md'])
 save('EVIDENCE_MANIFEST.json',{'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'note':'Sealed does not mean complete: recorded supervisor/evidence status remains PARTIAL.','files':[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]})
 print(json.dumps({'sealedFiles':len(files),'manifestSHA256':sha(E/'EVIDENCE_MANIFEST.json'),'historicalFilesUnchanged':len(old)-1,'frozenExecutedFilesUnchanged':len(frozen),'primary':result['primary'],'supervisor':result['supervisor'],'evidenceCompleteness':'PARTIAL'},indent=2))
if __name__=='__main__':main()

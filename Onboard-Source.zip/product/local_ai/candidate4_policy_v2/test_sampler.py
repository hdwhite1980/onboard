"""Passive native sampler protocol check; targets this small test process only."""
import json,os,subprocess,time
from pathlib import Path
h=Path(__file__).resolve().parent;e=h.parents[2]/'docs/sprint3a/evidence/candidate4-policy-v2-calibration-01'
started=time.monotonic()
p=subprocess.Popen([str(h/'resource-probe'),'0','.1','1.5'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
out,err=p.communicate(f'{os.getpid()} 0.1\n{os.getpid()} 0.25\n',timeout=4)
rows=[json.loads(x) for x in out.splitlines()]
assert p.returncode==0,(p.returncode,err)
assert sum(x['event']=='control_applied' for x in rows)==2
assert any(x['event']=='pressure_subscription_ready' for x in rows)
samples=[x for x in rows if x['event']=='sample']
assert len(samples)>=5 and all(started<=x['monotonic']<=time.monotonic() for x in samples)
assert any(x['workerPID']==os.getpid() and x['workerPhysicalFootprintBytes']>0 for x in samples)
assert not err
with (e/'sampler-protocol-test.json').open('x') as f:json.dump({'status':'PASS','modelLoads':0,'workerLaunches':0,'observationalHelperLaunches':1,'events':rows},f,indent=2)
print('PASS: native control coalescing, pressure subscription, same-clock samples, own-process footprint; no model worker.')

"""Pure guard tests; no model import/load or worker process."""
import importlib.util,unittest
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'tools/calibrate_candidate2_once.py';s=importlib.util.spec_from_file_location('calibrate',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Guards(unittest.TestCase):
 def setUp(self):self.base={'availableEstimateBytes':4*m.GiB,'pressure':1,'swapUsedBytes':0,'compressorBytes':3*m.GiB,'thermal':0}
 def test_calibration_preserves_normal_admission_and_reserve(self):
  self.assertIsNone(m.violation(self.base,self.base));self.assertEqual(m.POLICY['normalAdmissionBytes'],int(5.25*m.GiB));self.assertEqual(m.POLICY['reserveBytes'],2*m.GiB)
 def test_approaching_reserve_stops(self):self.assertTrue(m.violation(dict(self.base,availableEstimateBytes=int(2.25*m.GiB)),self.base))
 def test_pressure(self):self.assertTrue(m.violation(dict(self.base,pressure=2),self.base))
 def test_any_swap_increase(self):self.assertTrue(m.violation(dict(self.base,swapUsedBytes=16384),self.base))
 def test_compression(self):self.assertTrue(m.violation(dict(self.base,compressorBytes=self.base['compressorBytes']+512*1024**2),self.base))
 def test_thermal(self):self.assertTrue(m.violation(dict(self.base,thermal=2),self.base))
 def test_bounds(self):self.assertEqual((m.POLICY['generationRequests'],m.POLICY['maxTotalContext'],m.POLICY['maxNewTokens']),(1,512,128))
if __name__=='__main__':unittest.main()

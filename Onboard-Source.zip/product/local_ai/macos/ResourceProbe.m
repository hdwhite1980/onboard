// ENGINEERING_CALIBRATION_ONLY. Footprint portion adapted from preserved proof.
#import <Foundation/Foundation.h>
#include <libproc.h>
#include <sys/resource.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
int main(int argc,char **argv){
 @autoreleasepool {
  if(argc!=2)return 2;
  struct rusage_info_v4 r={0};int pid=atoi(argv[1]);
  int code=proc_pid_rusage(pid,RUSAGE_INFO_V4,(rusage_info_t*)&r);
  NSDictionary *result=@{@"pid":@(pid),@"error":@(code ? errno : 0),
    @"phys_footprint":code ? (id)[NSNull null] : @(r.ri_phys_footprint),
    @"resident_size":code ? (id)[NSNull null] : @(r.ri_resident_size),
    @"thermal_state":@([NSProcessInfo processInfo].thermalState)};
  NSData *d=[NSJSONSerialization dataWithJSONObject:result options:0 error:nil];
  fwrite(d.bytes,1,d.length,stdout);puts("");return 0;
 }
}

"""Freeze all experiment inputs and tested adapter before any model construction."""
import ast,hashlib,json,shutil,subprocess,sys
from pathlib import Path
import common as c
D=Path(__file__).resolve().parent
assert not (c.E/'calibration/ATTEMPT_STARTED.json').exists()
assert json.loads((c.E/'tokenizer-runtime-check.json').read_text())['status']=='PASS'
assert c.sha(D/'validation.py')=='d558ac6a173216463b63a44902fb0aebf0295048a33965fce0af1f508f1eacbd'
suite=json.loads((c.E/'frozen-suite.json').read_text());old=json.loads((c.ROOT/'docs/sprint3a/evidence/candidate2-quality-01/basic-suite.json').read_text())
for a,b in zip(suite['requests'],old['requests']):
 for key in ('id','task','messages','maxTotalContext','maxNewTokens','expected','expectedLabel','currentOnly'):assert a.get(key)==b.get(key),(a['id'],key)
 assert a['promptTokens']==len(a['tokenIDs']) and a['promptTokens']+128<=512
from validation import validate
reviews=json.loads((c.ROOT/'docs/sprint3a/evidence/candidate2-quality-01/basic-quality-review.json').read_text())['rows']
for row,review in zip(suite['requests'],reviews):assert validate(row,review['rawOutput'],'stop')==review['correctedValidatorReplay']
for f in D.glob('*.py'):ast.parse(f.read_text())
result=subprocess.run([sys.executable,'-B',str(D/'test_guards.py')],capture_output=True,text=True)
assert result.returncode==0,result.stderr
c.save('adapter-tests.json',{'status':'PASS','pureGuards':21,'exactC2Fixtures':16,'unchangedC2ValidatorReplay':16,'allAdapterSyntax':'PASS','validatorSHA256':c.sha(D/'validation.py'),'stdout':result.stdout,'stderr':result.stderr,'modelLoads':0})
for phase in ('calibration','quality'):
 folder=c.E/phase;subset=dict(suite);subset['requests']=suite['requests'][:1] if phase=='calibration' else suite['requests']
 with (folder/'frozen-suite.json').open('x') as f:json.dump(subset,f,indent=2);f.write('\n')
 shutil.copyfile(c.E/'prospective-protocol.json',folder/'prospective-protocol.json')
 sources=list(D.glob('*.py'))+[c.BASE/'resource_harness_v2/supervisor.py',c.BASE/'monitor_lifecycle_v3/lifecycle.py',c.BASE/'candidate4_policy_v2/resource-probe',c.E/'owner-authorization.txt',c.E/'future-first-prompt.json',c.E/'tokenizer-runtime-check.json',folder/'frozen-suite.json',folder/'prospective-protocol.json']
 rows=[]
 for source in sorted(sources):
  relative=source.relative_to(c.ROOT);target=folder/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
  rows.append({'path':str(relative),'sha256':c.sha(source)})
 with (folder/'tested-source.json').open('x') as f:json.dump({'files':rows,'beforeAnyModelLoad':True},f,indent=2);f.write('\n')
print('FROZEN: 16 exact C2 cases; current corrected validator; 21 guards passed; both phases source sealed.')

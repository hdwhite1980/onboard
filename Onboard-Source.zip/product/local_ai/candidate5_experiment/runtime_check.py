"""Reuse immutable retained runtime verifier, redirect evidence only; no AI imports."""
import importlib.util,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c
spec=importlib.util.spec_from_file_location('retained_runtime_verifier',c.BASE/'candidate4/runtime_identity.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
v.c=c
v.main()

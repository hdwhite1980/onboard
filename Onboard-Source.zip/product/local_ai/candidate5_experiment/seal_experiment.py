"""Seal new evidence and prove historical/source preservation, without inference."""
import hashlib,json,shutil
from pathlib import Path
import common as c
E=c.E
old=json.loads((E/'historical-before.json').read_text())
for row in old:assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path']
comparison=c.ROOT/'docs/sprint3a/LOCAL_MODEL_COMPARISON.md';assert comparison.read_bytes().startswith((E/'comparison-before.md').read_bytes())
checked=[];raws=[]
for phase,count in [('calibration',1),('quality',16)]:
 P=E/phase;result=json.loads((P/'run-result.json').read_text())
 assert result['modelLoads']==result['unloadRequests']==1 and result['generationRequests']==result['generationBegins']==count
 assert result['primary']=='LOCAL_GENERATION_SUCCESS' and result['supervisor']=='TERMINATION_CONFIRMED' and result['evidenceCompleteness']=='COMPLETE' and not result['aborts'] and result['processGroupPresent'] is False and result['workerExitCode']==0
 cleanup=json.loads((P/'helper-cleanup-and-joins.json').read_text());assert cleanup['clean'] and all(j['completed'] for j in cleanup['joins'])
 for row in json.loads((P/'tested-source.json').read_text())['files']:
  assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path'];checked.append(row['path'])
 for row in json.loads((P/'run-manifest.json').read_text())['files']:assert c.sha(P/row['path'])==row['sha256'],row['path']
 review=json.loads((P/'semantic-review.json').read_text())['rows']
 for i,row in enumerate(review):
  raw=json.loads((P/('response-%02d.json'%i)).read_text())
  assert raw['rawOutput']==row['rawOutput'] and hashlib.sha256(raw['rawOutput'].encode()).hexdigest()==row['rawOutputSHA256']
  raws.append({'phase':phase,'fixture':row['fixtureID'],'sha256':row['rawOutputSHA256']})
 replay=json.loads((P/'validator-postreview-replay.json').read_text())
 assert replay['generations']==0 and replay['testsPassed']==10
assert json.loads((E/'quality/quality-decision.json').read_text())['status']=='QWEN35_BASIC_QUALITY_FAIL'
pkg=json.loads((E/'package.json').read_text());verified=c.verify_package(Path(pkg['store']),pkg['manifestSHA256'],pkg['verification']['rootIdentity'])
reports=['CANDIDATE5_QWEN35_EXPERIMENT_EXCEPTION.md','CANDIDATE5_QWEN35_PACKAGE.md','CANDIDATE5_QWEN35_TOKENIZER_PREFLIGHT.md','CANDIDATE5_QWEN35_CALIBRATION.md','CANDIDATE5_QWEN35_BASIC_QUALITY.md','CANDIDATE5_VS_CANDIDATE2_GRANITE.md','LOCAL_MODEL_COMPARISON.md']
(E/'reports').mkdir()
for name in reports:shutil.copyfile(c.ROOT/'docs/sprint3a'/name,E/'reports'/name)
post=E/'post-generation-source';post.mkdir()
for name in ('analyze.py','validation_postreview.py','replay_postreview.py','report.py','seal_experiment.py'):shutil.copyfile(Path(__file__).with_name(name),post/name)
c.save('final-verification.json',{'status':'PASS','decision':'QWEN35_BASIC_QUALITY_FAIL','historicalFilesUnchanged':len(old),'historicalComparisonPrefixUnchanged':True,'testedSourceHashChecks':len(checked),'originalRunManifestsUnchanged':True,'rawResponsesVerified':raws,'packageReverified':verified,'exactWorkloads':{'calibration':{'loads':1,'generations':1,'unloads':1},'quality':{'loads':1,'generations':16,'unloads':1}},'newParserReplayGenerations':0,'postGenerationChanges':'Separate abbreviated-literal comparison parser only; frozen parser and raw outputs unchanged','qualification':'NONE','provenance':'TOKENIZER_PROVENANCE_PENDING','distribution':'PROHIBITED_PENDING_REVIEW','laterPhasesExecuted':[]})
files=[{'path':str(p.relative_to(E)),'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in sorted(E.rglob('*')) if p.is_file() and p.name!='EVIDENCE_MANIFEST.json']
c.save('EVIDENCE_MANIFEST.json',{'files':files,'historicalPreserved':len(old),'note':'Includes pre-generation source snapshots, raw runs, separate post-generation analysis/replay and report snapshots. Self excluded.'})
print(json.dumps({'status':'SEALED','files':len(files),'manifestSHA256':c.sha(E/'EVIDENCE_MANIFEST.json'),'historicalFilesUnchanged':len(old),'decision':'QWEN35_BASIC_QUALITY_FAIL'}))

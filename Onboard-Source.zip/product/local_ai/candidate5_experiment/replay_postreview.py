"""Post-generation same-raw-output parser replay; no inference imports."""
import collections,hashlib,json,unittest
from pathlib import Path
import common as c
from validation import validate as original
from validation_postreview import validate as corrected,literals
class Tests(unittest.TestCase):
 def test_equivalent_months(self):
  for short,long in [('Jan','January'),('Feb.','February'),('Mar','March'),('Apr','April'),('Jun','June'),('Jul','July'),('Aug','August'),('Sep','September'),('Sept.','September'),('Oct','October'),('Nov','November'),('Dec','December')]:self.assertEqual(literals(short+' 3rd'),literals(long+' 3'))
 def test_currency_abbreviations(self):
  for a,b in [('$4.7M','$4.7 million'),('$2.6 m','$2.6 million'),('$1B','$1 billion')]:self.assertEqual(literals(a),literals(b))
 def test_mutations_preserved(self):
  for a,b in [('$4.7M','$4.2 million'),('$4.7B','$4.7 million'),('Oct 8','October 3'),('Nov 3','October 3')]:self.assertNotEqual(literals(a),literals(b))
 def test_no_plain_suffix_currency_invention(self):self.assertNotEqual(literals('4.7M'),literals('$4.7 million'))
 def test_abbreviation_without_date_not_month(self):self.assertEqual(literals('Oct report 82%'),{'82'})
 def test_c2_unchanged(self):
  E=c.ROOT/'docs/sprint3a/evidence/candidate2-quality-01'
  for row,review in zip(json.loads((E/'basic-suite.json').read_text())['requests'],json.loads((E/'basic-quality-review.json').read_text())['rows']):self.assertEqual(corrected(row,review['rawOutput'],'stop'),review['correctedValidatorReplay'])
 def test_granite_unchanged(self):
  E=c.ROOT/'docs/sprint3a/evidence/candidate4-basic-quality-01'
  rows=json.loads((E/'semantic-review.json').read_text())['rows'];suite=json.loads((E/'frozen-suite.json').read_text())['requests']
  for row,review in zip(suite,rows):self.assertEqual(corrected(row,review['rawOutput'],review['finishReason']),original(row,review['rawOutput'],review['finishReason']))
 def test_existing_ordinal_numbered_behavior(self):self.assertEqual(literals('1. Date October 3rd. 2. Don submits.',True),literals('Date October 3. Don submits.'))
 def test_schema_not_relaxed(self):
  row={'task':'extraction','expected':{'version':'Version 3.2'}}
  self.assertFalse(corrected(row,'{"architecture":"Version 3.2"}','stop')['valid'])
 def test_length_not_relaxed(self):self.assertFalse(corrected({'task':'concise','messages':[{'content':'Rewrite'},{'content':'October 3 $4.7 million'}]},'Oct 3 $4.7M','length')['valid'])
def main():
 import io
 out=io.StringIO();tests=unittest.TextTestRunner(stream=out,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests));assert tests.wasSuccessful(),out.getvalue()
 for phase in ('calibration','quality'):
  E=c.E/phase;run=json.loads((E/'run-result.json').read_text());assert run['evidenceCompleteness']=='COMPLETE'
  suite=json.loads((E/'frozen-suite.json').read_text())['requests'];reviews=json.loads((E/'semantic-review.json').read_text())['rows'];rows=[]
  for fixture,review in zip(suite,reviews):
   before=original(fixture,review['rawOutput'],review['finishReason']);assert before==review['validatorAssessment']
   after=corrected(fixture,review['rawOutput'],review['finishReason'])
   rows.append({'fixtureID':fixture['id'],'rawOutputSHA256':review['rawOutputSHA256'],'original':before,'postreview':after,'changed':before!=after,'semanticAssessmentUnchanged':review['semanticAssessment'],'releaseAfterSemanticReview':'RELEASE' if after['valid'] and review['semanticAssessment']=='SEMANTIC_PASS' else 'WITHHOLD'})
  result={'originalSHA256':c.sha(Path(__file__).with_name('validation.py')),'postreviewSHA256':c.sha(Path(__file__).with_name('validation_postreview.py')),'changedAfterAllGenerationCompleted':True,'modelLoads':0,'generations':0,'rawOutputsModified':False,'testsPassed':tests.testsRun,'testOutput':out.getvalue(),'rows':rows,'automaticReleaseCounts':dict(collections.Counter(r['postreview']['releaseDecision'] for r in rows)),'reviewReleaseCounts':dict(collections.Counter(r['releaseAfterSemanticReview'] for r in rows))}
  with (E/'validator-postreview-replay.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
  print(phase,result['automaticReleaseCounts'],result['reviewReleaseCounts'])
 print(out.getvalue())
if __name__=='__main__':main()

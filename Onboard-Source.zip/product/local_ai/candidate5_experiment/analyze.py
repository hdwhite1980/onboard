"""Post-generation evidence analysis only; never imports AI runtime or regenerates."""
import collections,hashlib,json,statistics,sys
from pathlib import Path
import common as c
from validation import validate
E=c.E
assessments=[
 ('SEMANTIC_FAIL','Names/date/encryption retained and grammar improved. Asking whether resolved is not itself a progress claim, but “this change” introduces an unestablished change and reframes the question about issue impact as confirmation that a change will not impact deployment.'),
 ('SEMANTIC_FAIL','Drops Don and addresses Team; adds a request to confirm the already stated budget; turns “do not say it is approved yet” into a definite unapproved schedule state.'),
 ('SEMANTIC_FAIL','Friendly tone and literals preserved, but asks whether the issue will block deployment instead of whether it affects deployment. Blocking is narrower than impact; this changes the requested inquiry.'),
 ('SEMANTIC_PASS','Friendly natural rewrite preserves Don, migration request, exact 82% testing progress and Version 3.2.'),
 ('SEMANTIC_PASS','Materially concise; Project Falcon, approved deployment, budget, 82% and Version 3.2 retained. Oct 3 and $4.7M are equivalent conventional abbreviations; “testing complete at 82%” states the exact partial completion figure, not 100% completion.'),
 ('SEMANTIC_PASS','Keeps Sarah and unresolved encryption review, Don’s submission action, October 3 and no confirmed delay. “Don: revised migration schedule submission” identifies the specific owned action, not just general schedule responsibility.'),
 ('SEMANTIC_FAIL','Preserves principal facts/owners/uncertainty but produces three sentences, violating exactly two short sentences and repeating the unresolved issue.'),
 ('SEMANTIC_FAIL','Invents rejection of October 8 from non-approval and produces three sentences. Continued proposal wording does not repair the invented rejection.'),
 ('SEMANTIC_FAIL','Values correct, but returns architecture instead of the explicitly required version key. Exact extraction schema not followed.'),
 ('SEMANTIC_FAIL','Values correct, but returns architecture instead of the explicitly required version key. Exact extraction schema not followed.'),
 ('SEMANTIC_PASS','Exact IT_SUPPORT/HIGH category and urgency; correct strict JSON.'),
 ('SEMANTIC_FAIL','Direct-deposit request classified IT_SUPPORT instead of HR under the frozen category definition. NORMAL urgency correct.'),
 ('SEMANTIC_PASS','INTERNAL advisory label with substantive rationale consistent with synthetic internal planning note.'),
 ('SEMANTIC_PASS','RESTRICTED advisory label with payroll/privacy rationale; no actual policy enforcement or relabeling.'),
 ('SEMANTIC_PASS','Professional rewrite preserves date/budget/version/82%, Sarah ownership and unresolved review, Don’s must-submit action and lack of final deployment approval. No ownership transfer to speaker.'),
 ('SEMANTIC_PASS','Exactly two sentences; retains current approved baseline, percentage and owners/actions, excludes superseded values as requested.')]
def save(path,data):
 with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
def bounds(values):
 values=[v for v in values if isinstance(v,(int,float))];return {'min':min(values),'max':max(values),'median':statistics.median(values)} if values else None
suite=json.loads((E/'frozen-suite.json').read_text())['requests']
for phase in ('calibration','quality'):
 P=E/phase;result=json.loads((P/'run-result.json').read_text())
 assert result['primary']=='LOCAL_GENERATION_SUCCESS' and result['supervisor']=='TERMINATION_CONFIRMED' and result['evidenceCompleteness']=='COMPLETE' and not result['aborts']
 raws=[json.loads(f.read_text()) for f in sorted(P.glob('response-*.json'))]
 rows=[]
 for i,r in enumerate(raws):
  fixture=suite[i];assert r['fixtureID']==fixture['id'];sem,reason=assessments[i]
  rows.append({'fixtureID':fixture['id'],'task':fixture['task'],'rawOutput':r['rawOutput'],'rawOutputSHA256':hashlib.sha256(r['rawOutput'].encode()).hexdigest(),'finishReason':r['finishReason'],'semanticAssessment':sem,'semanticRationale':reason,'validatorAssessment':validate(fixture,r['rawOutput'],r['finishReason']),'generationSource':'response-%02d.json'%i})
 save(P/'semantic-review.json',{'reviewer':'Assistant engineering assessment for owner review, not independent human validation','validatorFrozenBeforeGenerationSHA256':c.sha(Path(__file__).with_name('validation.py')),'rows':rows,'semanticCounts':dict(collections.Counter(r['semanticAssessment'] for r in rows)),'originalValidatorCounts':dict(collections.Counter(r['validatorAssessment']['releaseDecision'] for r in rows))})
 events=[json.loads(s) for s in (P/'worker-events.jsonl').read_text().splitlines()];samples=[json.loads(s) for s in (P/'resources.jsonl').read_text().splitlines()]
 mem=[r['memory'] for r in events if r.get('memory')];life=json.loads((P/'lifecycle/result.json').read_text());recovery=life['recovery']['samples']
 fields=['workerPhysicalFootprintBytes','workerResidentBytes','availableEstimateLegacyBytes','compressorOccupancyBytes','compressorDeltaBytes','compressorGrowthBytesPerSecond','swapUsedBytes','swapInPagesTotal','swapOutPagesTotal','sampleAgeSeconds','mlxSampleAgeSeconds']
 load=next(r for r in events if r['event']=='MODEL_LOADED');unload=next(r for r in events if r['event']=='unloaded')
 first=next(r for r in events if r['event']=='started');last=next(r for r in events if r['event']=='exiting')
 metrics={'nativeSampleCount':len(samples),'nativeBounds':{f:bounds([r.get(f) for r in samples]) for f in fields},'mlxBounds':{f:bounds([r[f] for r in mem]) for f in ('active','cache','peak')},'pressureStates':sorted({r['memoryPressure'] for r in samples}),'thermalStates':sorted({r['thermalState'] for r in samples}),'powerSources':sorted({r['powerSource'] for r in samples}),'swapInPagesDelta':samples[-1]['swapInPagesTotal']-samples[0]['swapInPagesTotal'],'swapOutPagesDelta':samples[-1]['swapOutPagesTotal']-samples[0]['swapOutPagesTotal'],'generationSeconds':bounds([r['seconds'] for r in raws]),'loadSeconds':load['seconds'],'unloadSeconds':unload['monotonic']-next(r for r in events if r['event']=='unload_begin')['monotonic'],'workerSessionSeconds':last['monotonic']-first['monotonic'],'maxPromptTokens':max(r['promptTokens'] for r in raws),'maxOutputTokens':max(r['outputTokens'] for r in raws),'maxActualTotalIncludingStop':max(r['promptTokens']+r['sampledTokensIncludingStop'] for r in raws),'finishReasons':dict(collections.Counter(r['finishReason'] for r in raws)),'cacheResets':sum(r['event']=='cache_reset' for r in events),'betweenRequestAllocatorClears':sum(r['event']=='between_requests' for r in events),'postUnloadMemory':unload['memory'],'networkNegativeControl':next(r for r in events if r['event']=='network_negative_control'),'visionFileReadObservation':next(r for r in events if r['event']=='weight_file_read_end'),'visionModulesConstructed':next(r for r in events if r['event']=='model_construction_end')['visionModulesConstructed'],'recoverySamples':len(recovery),'recoveryIntervalsSeconds':bounds([b['monotonic']-a['monotonic'] for a,b in zip(recovery,recovery[1:])]),'recoveryAllWorkerAbsent':all(not r['workerPresent'] and not r['processGroupMembers'] for r in recovery),'recoveryHeadroomBounds':bounds([r['availableEstimateLegacyBytes'] for r in recovery]),'peakCounter':'Cumulative, not reset between fixtures; sampled native peak may miss sub-sample transients.','sampleIntervalsByPhase':{}}
 for phase_name in ('LOAD','PREFILL','GENERATION'):
  intervals=[b['monotonic']-a['monotonic'] for a,b in zip(samples,samples[1:]) if a['phase']==b['phase']==phase_name and a['fixtureID']==b['fixtureID']]
  metrics['sampleIntervalsByPhase'][phase_name]=bounds(intervals)
 save(P/'measurements.json',metrics)
 print(phase,json.dumps({'semantic':collections.Counter(r['semanticAssessment'] for r in rows),'validator':collections.Counter(r['validatorAssessment']['releaseDecision'] for r in rows),'peakWorkerGiB':metrics['nativeBounds']['workerPhysicalFootprintBytes']['max']/1024**3,'peakMLXGiB':metrics['mlxBounds']['peak']['max']/1024**3,'minHeadroomGiB':metrics['nativeBounds']['availableEstimateLegacyBytes']['min']/1024**3,'compressionDeltaMaxGiB':metrics['nativeBounds']['compressorDeltaBytes']['max']/1024**3,'generationSeconds':metrics['generationSeconds'],'loadSeconds':metrics['loadSeconds'],'workerSeconds':metrics['workerSessionSeconds']}))
quality=json.loads((E/'quality/semantic-review.json').read_text())['rows'];capabilities={}
for task in ['professional','casual','concise','summary','extraction','classification','sensitivity']:
 rows=[r for r in quality if r['task']==task];capabilities[task]={'cases':[r['semanticAssessment'] for r in rows],'bothPass':all(r['semanticAssessment']=='SEMANTIC_PASS' for r in rows)}
passed=sum(r['bothPass'] for r in capabilities.values());assert passed==2
save(E/'quality/quality-decision.json',{'status':'QWEN35_BASIC_QUALITY_FAIL','capabilities':capabilities,'passingCapabilities':passed,'requiredPassingCapabilities':4,'writingOrSummaryPassed':True,'factCases':[r['semanticAssessment'] for r in quality if r['task']=='facts'],'lifecycle':'EXPERIMENTAL','provenance':'TOKENIZER_PROVENANCE_PENDING','distribution':'BLOCKED','qualifiedTasks':[],'stopAfterBasic':True,'noRetries':True})

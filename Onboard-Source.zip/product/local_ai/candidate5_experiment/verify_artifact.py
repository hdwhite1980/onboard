"""Verify unchanged publisher payload and build local-only experimental package; no AI imports."""
import json,hashlib,math,os,shutil,struct
from pathlib import Path
import common as c

def main():
 api=json.loads((c.RESEARCH/'conversion-api.json').read_text());assert api['sha']==c.REV and api['id']==c.REPO
 assert {r['rfilename'] for r in api['siblings']}==c.FILES
 assert {p.name for p in c.QUARANTINE.iterdir()}==c.FILES
 records=[];fd=c.secure_root(c.QUARANTINE)
 try:
  for row in api['siblings']:
   name=row['rfilename'];assert c.safe_parts(name)==(name,)
   got=c.file_record(fd,name);assert got['bytes']==row['size'],name
   if 'lfs' in row:assert got['sha256']==row['lfs']['sha256'],name
   else:
    raw=(c.QUARANTINE/name).read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['blobId'],name
   got.pop('identity');got.update(gitBlobID=row['blobId'],publisherHash=row.get('lfs',{}).get('sha256',row['blobId']),publisherHashType='LFS_SHA256' if 'lfs' in row else 'GIT_BLOB_SHA1',source=f'https://huggingface.co/{c.REPO}/resolve/{c.REV}/{name}',purpose='Unchanged publisher data; full vision payload retained')
   records.append(got);(c.QUARANTINE/name).chmod(0o400)
 finally:os.close(fd)
 weight=c.QUARANTINE/'model.safetensors';assert weight.stat().st_size==1722271785 and c.sha(weight)==c.WEIGHT_SHA
 def unique(pairs):
  d={}
  for k,v in pairs:
   assert k not in d,'Duplicate JSON key';d[k]=v
  return d
 with weight.open('rb') as f:
  size=struct.unpack('<Q',f.read(8))[0];assert 0<size<16*1024**2
  raw=f.read(size);header=json.loads(raw,object_pairs_hook=unique)
 tensors={k:v for k,v in header.items() if k!='__metadata__'}
 idx=json.loads((c.QUARANTINE/'model.safetensors.index.json').read_text())
 assert set(tensors)==set(idx['weight_map']) and set(idx['weight_map'].values())=={'model.safetensors'}
 end=0;totals={'language':0,'vision':0};counts={'language':0,'vision':0};dtypes={}
 for name,t in sorted(tensors.items(),key=lambda kv:kv[1]['data_offsets'][0]):
  assert set(t)=={'dtype','shape','data_offsets'} and all(type(n)is int and n>=0 for n in t['shape'])
  start,stop=t['data_offsets'];assert start==end and stop>=start
  assert stop-start==math.prod(t['shape'])*{'BF16':2,'F16':2,'F32':4,'U32':4}[t['dtype']]
  end=stop;kind='language' if name.startswith('language_model.') else 'vision' if name.startswith('vision_tower.') else None
  assert kind is not None and 'mtp.' not in name
  totals[kind]+=stop-start;counts[kind]+=1;dtypes[t['dtype']]=dtypes.get(t['dtype'],0)+1
  if kind=='vision':assert t['dtype']=='BF16'
  if 'conv1d.weight' in name:assert t['shape']==[6144,4,1]
  if name.endswith('.scales') or name.endswith('.biases'):
   w=tensors[name.rsplit('.',1)[0]+'.weight'];assert w['dtype']=='U32' and t['shape'][-1]*64==w['shape'][-1]*8
 assert end==idx['metadata']['total_size']==1722149056 and 8+size+end==weight.stat().st_size
 assert counts=={'language':694,'vision':297}
 cfg=json.loads((c.QUARANTINE/'config.json').read_text());assert cfg['model_type']=='qwen3_5'
 assert cfg['quantization']==cfg['quantization_config']=={'group_size':64,'bits':4,'mode':'affine'}
 for name in c.FILES:
  if name.endswith('.json'):
   data=json.loads((c.QUARANTINE/name).read_text(),object_pairs_hook=unique)
   assert not any(k in data for k in ('auto_map','model_file','custom_pipelines'))
 tok=json.loads((c.QUARANTINE/'tokenizer.json').read_text());vocab=json.loads((c.QUARANTINE/'vocab.json').read_text());assert tok['model']['vocab']==vocab
 assert c.sha(c.QUARANTINE/'chat_template.jinja')=='273d8e0e683b885071fb17e08d71e5f2a5ddfb5309756181681de4f5a1822d80'
 c.save('acquisition.json',{'status':'VERIFIED_QUARANTINE','repository':c.REPO,'revision':c.REV,'files':records,'repositoryBytes':sum(r['bytes'] for r in records),'modelLoads':0})
 c.save('artifact-verification.json',{'status':'PASS','headerBytes':size,'headerSHA256':hashlib.sha256(raw).hexdigest(),'tensors':len(tensors),'tensorCounts':counts,'tensorBytes':totals,'dtypes':dtypes,'indexBytes':end,'noGapsOrOverlaps':True,'fullVisionPayloadRetained':True,'configTokenizerProcessorJSONValidated':True,'noModelLoad':True})
 c.save('safetensors-header.json',header)
 notice='''ORGANIZATION-AUTHORED EXPERIMENTAL LIMITATION RECORD — NOT AN UPSTREAM NOTICE
TOKENIZER_PROVENANCE_PENDING
NO_REDISTRIBUTION
LOCAL_ENGINEERING_EVALUATION_ONLY
EXPERIMENTAL_EVALUATION_EXCEPTION
Tokenizer provenance AMBIGUOUS; hold ACTIVE. Production, customer, government, CUI/FCI, model catalog and release qualification remain blocked. Qualified tasks NONE.
Publisher: mlx-community/Qwen3.5-2B-4bit at 674aaa7240b91e8012fcad5d791b7dfe5ba90207.
Declared upstream: Qwen/Qwen3.5-2B; research revision 15852e8c16360a2fea060d615a32b45270f8a8fc is not an attested conversion input revision.
Conversion card reports MLX-VLM 0.3.12. Actual conversion command/input revision/tokenizer lineage are not fully attested. No affirmative Meta/Llama inheritance was established. Apache-2.0 declaration does not resolve full tokenizer provenance.
The exact publisher payload, including vision tensors, is unchanged. The accompanying upstream LICENSE is retained verbatim. This organization notice does not add or invent an upstream NOTICE.
'''
 extras=c.E/'package-material';extras.mkdir()
 (extras/'EXPERIMENTAL_LIMITATIONS.txt').write_text(notice)
 license=c.RESEARCH/'sources/upstream/LICENSE';assert c.sha(license)=='bbedc3fda3305820b977265f01b8619d87570a6739de3a5582c3464840f1e57a'
 shutil.copyfile(license,extras/'UPSTREAM_LICENSE')
 for f in sorted(extras.iterdir()):records.append({'path':'organization/'+f.name,'bytes':f.stat().st_size,'sha256':c.sha(f),'purpose':'Organization limitation notice' if f.name.endswith('.txt') else 'Verbatim upstream Apache-2.0 license; research revision '+c.UPREV})
 manifest={'packageID':'org.experimental.qwen3.5-2b.mlx4-g64','lifecycle':'EXPERIMENTAL','qualifiedTasks':[],'provenanceState':'TOKENIZER_PROVENANCE_PENDING','tokenizerProvenance':'AMBIGUOUS','tokenizerProvenanceHold':'ACTIVE','distribution':'PROHIBITED_PENDING_REVIEW','scope':'LOCAL_ENGINEERING_EVALUATION_ONLY','exception':'EXPERIMENTAL_EVALUATION_EXCEPTION','repository':c.REPO,'revision':c.REV,'declaredUpstream':c.UPSTREAM,'researchUpstreamRevision':c.UPREV,'actualConversionInputRevision':'UNDOCUMENTED','files':records}
 raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();ident=hashlib.sha256(raw).hexdigest();store=c.BASE/'.artifacts/store'/ident;store.mkdir(mode=0o700)
 for r in records:
  target=store/r['path'];target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
  src=extras/target.name if r['path'].startswith('organization/') else c.QUARANTINE/r['path']
  shutil.copyfile(src,target);target.chmod(0o400)
 (store/'manifest.json').write_bytes(raw);(store/'manifest.json').chmod(0o400)
 for d in sorted((p for p in store.rglob('*') if p.is_dir()),reverse=True):d.chmod(0o500)
 store.chmod(0o500);verification=c.verify_package(store,ident)
 c.save('package.json',{'manifestSHA256':ident,'store':str(store),'manifest':manifest,'verification':verification})
 print(json.dumps({'status':'PASS','manifestSHA256':ident,'tensorCounts':counts,'tensorBytes':totals}),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as error:
  c.save('artifact-failure.json',{'status':'ARTIFACT_VERIFICATION_FAILED','error':repr(error),'modelLoads':0});raise

"""Verify immutable historical/run evidence and append final review seal."""
import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p
E=p.E;M=p.ROOT/'docs/sprint3a/evidence/monitor-lifecycle-v3-01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def verify_manifest(path):
 for row in read(path)['files']:
  file=path.parent/row['path'];assert file.is_file() and sha(file)==row['sha256'],str(file)
 return len(read(path)['files'])
def main():
 historical=read(M/'preservation-before.json')['files']
 failures=[r['path'] for r in historical if not (p.ROOT/r['path']).exists() or sha(p.ROOT/r['path'])!=r['sha256']]
 assert not failures,failures
 manifests=[M/'manifest.json',E/'run-manifest.json',E/'lifecycle/manifest.json',E/'monitor-lifecycle/manifest.json']+list(M.glob('cycle-*/manifest.json'))+list(M.glob('cycle-*/lifecycle/manifest.json'))
 validated=[{'path':str(f.relative_to(p.ROOT)),'files':verify_manifest(f),'sha256':sha(f)} for f in manifests]
 frozen=read(E/'tested-source.json')['files'];assert all(sha(p.ROOT/r['path'])==r['sha256'] for r in frozen)
 original=read(E/'semantic-review.json');replay=read(E/'validator-postreview-replay.json');events=[json.loads(l) for l in (E/'worker-events.jsonl').read_text().splitlines()]
 assert len(original['rows'])==16 and len(replay['rows'])==16
 for index,row in enumerate(original['rows']):
  raw=read(E/('response-%02d.json'%index));assert row['rawOutput']==raw['rawOutput']
  assert sha_text(row['rawOutput'])==replay['rows'][index]['rawOutputSHA256']
  assert row['accountedActualTokens']<=512 and row['outputTokens']<=128
 old=[json.loads(l) for l in (p.ROOT/'docs/sprint3a/evidence/candidate4-policy-v2-calibration-01/worker-events.jsonl').read_text().splitlines()]
 assert next(e['rawOutput'] for e in old if e['event']=='generated')==original['rows'][0]['rawOutput']
 assert sum(e['event']=='load_begin' for e in events)==1
 assert sum(e['event']=='generated' for e in events)==16
 cleanup=read(E/'helper-cleanup-and-joins.json');assert cleanup['clean'] and all(j['completed'] for j in cleanup['joins'])
 assert len([e for e in cleanup['helper']['events'] if e['event']=='SIGNAL'])==1
 recovery=read(E/'lifecycle/recovery.json')['samples'];assert len(recovery)==12
 assert all(not r['workerPresent'] and not r['processGroupMembers'] and r['memoryPressure']=='NORMAL' and r['swapUsedBytes']==0 for r in recovery)
 result=read(E/'run-result.json');assert result['evidenceCompleteness']=='COMPLETE' and not result['aborts']
 # Snapshot all post-generation review programs and required reports without altering run files.
 for path in Path(__file__).parent.glob('*.py'):
  target=E/'post-generation-source'/path.name;target.parent.mkdir(exist_ok=True);target.write_bytes(path.read_bytes())
 reports=['MONITOR_LIFECYCLE_CORRECTION.md','MONITOR_LIFECYCLE_TEST_RESULTS.md','CANDIDATE4_GRANITE_BASIC_QUALITY.md','CANDIDATE4_VS_CANDIDATE2.md','LOCAL_MODEL_COMPARISON.md']
 for name in reports:
  target=E/'reports'/name;target.parent.mkdir(exist_ok=True);target.write_bytes((p.ROOT/'docs/sprint3a'/name).read_bytes())
 evidence={'historicalFilesUnchanged':len(historical),'historicalMismatches':failures,'executedSourceFilesUnchanged':len(frozen),'validatedManifests':validated,'rawOutputMappingsExact':16,'historicalProfessional1ByteIdentical':True,'workerAndHelperAbsentAtRecovery':True,'allQualityThreadsJoined':True,'originalDecisionsPreserved':True,'postGenerationRegenerationCount':0,'finalDecision':'GRANITE_BASIC_QUALITY_FAIL'}
 with (E/'final-verification.json').open('x') as f:json.dump(evidence,f,indent=2);f.write('\n')
 files=[{'path':str(f.relative_to(E)),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(E.rglob('*')) if f.is_file() and f.name!='EVIDENCE_MANIFEST.json']
 with (E/'EVIDENCE_MANIFEST.json').open('x') as f:json.dump({'files':files},f,indent=2);f.write('\n')
 count=verify_manifest(E/'EVIDENCE_MANIFEST.json')
 print(json.dumps({'historicalFilesUnchanged':len(historical),'executedSourceUnchanged':len(frozen),'validatedPriorManifests':len(manifests),'finalFiles':count,'manifestSHA256':sha(E/'EVIDENCE_MANIFEST.json'),'decision':evidence['finalDecision']}))
def sha_text(text):return hashlib.sha256(text.encode()).hexdigest()
if __name__=='__main__':main()

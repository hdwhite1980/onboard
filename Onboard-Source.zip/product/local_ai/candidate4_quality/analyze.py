"""Post-generation review of preserved outputs only. No model imports or generation."""
import hashlib,json,statistics,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p
from validation import validate
from collections import Counter
E=p.E
review={
'professional-1':('SEMANTIC_FAIL','Professional tone improves and Sarah/date/impact question remain, but asking about progress made presupposes resolution progress not established by the source. This matches the strict historical assessment; the old response is not reinterpreted. Added salutation/signature alone is not the failure.'),
'professional-2':('SEMANTIC_FAIL','Don, $4.7 million, migration schedule and October 3 remain, but the instruction not to claim approval becomes a definite claim that this budget has not yet been officially approved. The source does not establish that specific budget-approval state or resolve the referent of it; uncertainty is narrowed without support.'),
'casual-1':('REVIEW_REQUIRED','Tone is materially friendlier and Sarah, review and date are preserved. Last remaining issue can imply that no other issues remain, while the source says only remaining issue. Human review is needed to decide whether that added exclusivity is material. No automatic pass is awarded for fluency; courtesy phrases are not independently scored as factual errors.'),
'casual-2':('SEMANTIC_PASS','Friendly natural tone; Don, requested updated migration schedule, exact 82% and Version 3.2 retained. Corrects Candidate 2 percentage loss.'),
'concise-1':('SEMANTIC_PASS','Material reduction exceeds 30%; Falcon, approved deployment date, budget amount, exact testing percentage and architecture version retained. Approval phrasing is treated consistently with the accepted Candidate 2 concise-1 output.'),
'concise-2':('SEMANTIC_FAIL','Substantial reduction preserves Sarah/unresolved review/date/no confirmed delay, but Don being responsible for the schedule omits his specific action of submitting it. General responsibility is not the same as the required submission duty.'),
'summary-1':('SEMANTIC_FAIL','Only one sentence rather than the required two, and Version 3.2 is omitted. Don submission and Sarah unresolved review are retained, but material fact loss and instruction failure remain.'),
'summary-2':('SEMANTIC_PASS','Two substantive numbered sentences preserve October 3, unapproved October 8 proposal, Sarah review ownership, Don submission duty and no confirmed delay. Does not invent rejection. Number prefixes are not counted as extra sentences.'),
'extraction-1':('SEMANTIC_PASS','Exact six-field string JSON; all supplied values and both owners correct.'),
'extraction-2':('SEMANTIC_PASS','Exact six-field string JSON with the second dates/amount/percentage/version and Michael/Sarah owner mapping correct.'),
'classification-1':('SEMANTIC_PASS','IT_SUPPORT and HIGH correctly reflect connectivity and explicitly blocked same-day deadline.'),
'classification-2':('SEMANTIC_FAIL','FINANCE is incorrect: the frozen category definitions explicitly place employee payroll/direct deposit in HR. NORMAL urgency is correct. Different wrong category from Candidate 2, not a correction.'),
'sensitivity-1':('SEMANTIC_PASS','Correct INTERNAL advisory recommendation and source-consistent operational-content rationale; no authority or policy mutation.'),
'sensitivity-2':('SEMANTIC_PASS','Correct RESTRICTED advisory recommendation for personal payroll information, with supported explanation.'),
'facts-1':('SEMANTIC_FAIL','Sarah is omitted and her encryption-review ownership becomes my ownership; approval uncertainty is omitted. The response reaches 128 output tokens and ends mid-sentence. Correct retained numbers do not offset the critical owner mutation and incomplete response.'),
'facts-2':('SEMANTIC_PASS','Two sentences preserve the current October 3/$4.7 million/Version 3.2/82% baseline, Sarah review and Don submission duty while omitting obsolete proposal values.')}
def read(name):return json.loads((E/name).read_text())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def save(name,obj):
 with (E/name).open('x') as f:json.dump(obj,f,indent=2,allow_nan=False);f.write('\n')
def bounds(rows,key):
 a=[r[key] for r in rows if type(r.get(key)) in (int,float)]
 return {'min':min(a),'max':max(a),'median':statistics.median(a)} if a else None

def main():
 source=read('tested-source.json')
 assert all(sha(p.ROOT/r['path'])==r['sha256'] for r in source['files'])
 suite=read('frozen-suite.json')['requests'];events=[json.loads(l) for l in (E/'worker-events.jsonl').read_text().splitlines()];samples=[json.loads(l) for l in (E/'resources.jsonl').read_text().splitlines()]
 baseline=read('baseline.json')['sample'];rows=[]
 resource_fields=('workerPhysicalFootprintBytes','workerResidentBytes','mlxActiveBytes','mlxCacheBytes','mlxPeakBytes','availableEstimateLegacyBytes','compressorOccupancyBytes','compressorDeltaBytes','swapUsedBytes','swapInPagesTotal','swapOutPagesTotal','thermalState','sampleAgeSeconds')
 for index,fixture in enumerate(suite):
  raw=read('response-%02d.json'%index);assert raw['fixtureID']==fixture['id']
  rendered=next(e for e in events if e['event']=='prompt_preflight' and e['fixtureID']==fixture['id'])
  begin=next(e for e in events if e['event']=='generation_begin' and e['fixtureID']==fixture['id'])
  observed=[s for s in samples if begin['monotonic']<=s['monotonic']<=raw['monotonic']]
  mlx=[e['memory'] for e in events if e.get('memory') and begin['monotonic']<=e['monotonic']<=raw['monotonic']]
  assessment,reason=review[fixture['id']];validation=validate(fixture,raw['rawOutput'],raw['finishReason'])
  rows.append({'fixtureID':fixture['id'],'task':fixture['task'],'inputSHA256':fixture['inputSHA256'],'renderedPromptSHA256':rendered['renderedPromptSHA256'],'rawPrompt':rendered['rawPrompt'],'promptTokens':raw['promptTokens'],'rawOutput':raw['rawOutput'],'outputTokens':raw['outputTokens'],'sampledTokensIncludingStop':raw['sampledTokensIncludingStop'],'accountedActualTokens':raw['promptTokens']+raw['sampledTokensIncludingStop'],'finishReason':raw['finishReason'],'latencySeconds':raw['seconds'],'firstTokenSeconds':raw['firstTokenSeconds'],'semanticAssessment':assessment,'semanticReason':reason,'validatorAssessment':validation,'automaticReleaseDecision':validation['releaseDecision'],'releaseAfterSemanticReview':'RELEASE' if assessment=='SEMANTIC_PASS' and validation['valid'] else 'WITHHOLD','resourceObservation':{'interval':[begin['monotonic'],raw['monotonic']],'sampleCount':len(observed),'native':{k:bounds(observed,k) for k in resource_fields},'mlxWorkerEvents':{k:bounds(mlx,k) for k in ('active','cache','peak')},'pressure':sorted(set(s['memoryPressure'] for s in observed)),'rawNativeSamples':observed,'peakCounterReset':False}})
 caps={}
 for task in ('professional','casual','concise','summary','extraction','classification','sensitivity'):
  taskrows=[r for r in rows if r['task']==task];counts=Counter(r['semanticAssessment'] for r in taskrows)
  caps[task]={'passes':counts['SEMANTIC_PASS'],'failures':counts['SEMANTIC_FAIL'],'reviewRequired':counts['REVIEW_REQUIRED'],'bothPass':counts['SEMANTIC_PASS']==2,'caseIDs':[r['fixtureID'] for r in taskrows]}
 full=sum(c['bothPass'] for c in caps.values());possible=sum(c['failures']==0 for c in caps.values())
 gate=full>=4 and any(caps[t]['bothPass'] for t in ('professional','casual','concise','summary'))
 decision='BASIC_QUALITY_PASS' if gate else 'BASIC_QUALITY_FAIL' if possible<4 else 'BASIC_QUALITY_INCONCLUSIVE'
 times=[r['latencySeconds'] for r in rows];recovery=read('lifecycle/recovery.json')['samples']
 summary={'nativeSampleCount':len(samples),'nativeBounds':{k:bounds(samples,k) for k in resource_fields},'baseline':baseline,'pressureStates':sorted(set(r['memoryPressure'] for r in samples)),'thermalStates':sorted(set(r['thermalState'] for r in samples)),'powerSources':sorted(set(r['powerSource'] for r in samples)),'swapInPagesDelta':samples[-1]['swapInPagesTotal']-baseline['swapInPagesTotal'],'swapOutPagesDelta':samples[-1]['swapOutPagesTotal']-baseline['swapOutPagesTotal'],'mlxBounds':{k:bounds([e['memory'] for e in events if e.get('memory')],k) for k in ('active','cache','peak')},'generationSeconds':{'min':min(times),'max':max(times),'median':statistics.median(times),'sum':sum(times)},'loadSeconds':next(e['seconds'] for e in events if e['event']=='MODEL_LOADED'),'workerSessionSeconds':next(e['monotonic'] for e in events if e['event']=='exiting')-next(e['monotonic'] for e in events if e['event']=='started'),'maxAccountedActualTokens':max(r['accountedActualTokens'] for r in rows),'maxPromptTokens':max(r['promptTokens'] for r in rows),'maxOutputTokens':max(r['outputTokens'] for r in rows),'finishReasons':dict(Counter(r['finishReason'] for r in rows)),'recoverySamples':len(recovery),'recoveryIntervalsSeconds':[b['monotonic']-a['monotonic'] for a,b in zip(recovery,recovery[1:])],'postUnloadMemory':next(e['memory'] for e in events if e['event']=='unloaded'),'networkNegativeControl':next(e for e in events if e['event']=='network_negative_control'),'fatalEvents':[e for e in events if e['event']=='fatal'],'cacheResets':sum(e['event']=='cache_reset' for e in events),'betweenRequestAllocatorClears':sum(e['event']=='between_requests' for e in events)}
 summary['sampleIntervalsByPhase']={phase:bounds([{'seconds':b['monotonic']-a['monotonic']} for a,b in zip(samples,samples[1:]) if a['phase']==b['phase']==phase and a.get('fixtureID')==b.get('fixtureID')],'seconds') for phase in ('LOAD','PREFILL','GENERATION')}
 save('semantic-review.json',{'reviewer':'Assistant semantic assessment for owner inspection; not independent human validation','rows':rows,'semanticCounts':dict(Counter(r['semanticAssessment'] for r in rows)),'automaticReleaseCounts':dict(Counter(r['automaticReleaseDecision'] for r in rows)),'reviewReleaseCounts':dict(Counter(r['releaseAfterSemanticReview'] for r in rows)),'capabilities':caps,'bothPassCapabilities':full,'maximumPossibleWithPendingReview':possible,'decision':decision,'gateFrozenBeforeGeneration':True,'validatorChanged':False,'regeneration':False})
 save('measurements.json',summary)
 save('quality-decision.json',{'decision':'GRANITE_'+decision,'basicQuality':decision,'candidateStatus':'EXPERIMENTAL','qualifiedTasks':[],'stop':True,'laterPhasesExecuted':[],'generationRequests':16,'modelLoads':1,'automaticReleaseIsNotSemanticAcceptance':True})
 print(json.dumps({'semantic':dict(Counter(r['semanticAssessment'] for r in rows)),'automaticRelease':dict(Counter(r['automaticReleaseDecision'] for r in rows)),'semanticRelease':dict(Counter(r['releaseAfterSemanticReview'] for r in rows)),'fullCapabilities':full,'maximumPossible':possible,'decision':decision,'measurements':summary},indent=2))
if __name__=='__main__':main()

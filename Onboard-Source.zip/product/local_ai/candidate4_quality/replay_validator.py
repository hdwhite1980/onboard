"""Post-generation parser correction and exact-output replay. Never regenerates."""
import hashlib,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p
from validation import validate as original
from validation_postreview import validate as corrected,literals
E=p.E
class Tests(unittest.TestCase):
 def test_ordinal_dates(self):
  for date in ('October 3rd','November 1st','September 2nd','December 12th'):
   self.assertEqual(literals(date),literals(date[:-2]))
 def test_two_numbered_sentences(self):self.assertEqual(literals('1. Date October 3. 2. Don submits.',True),literals('Date October 3. Don submits.'))
 def test_default_numbers_remain(self):self.assertIn('1',literals('1. Date October 3. 2. Don submits.'))
 def test_out_of_order_numbers_remain(self):self.assertIn('2',literals('2. Date October 3. 1. Don submits.',True))
 def test_extra_sentence_numbers_remain(self):self.assertIn('3',literals('1. First. 2. Second. 3. Third.',True))
 def test_substantive_digits_remain(self):self.assertTrue({'82','3 2','4 7 million'}<=literals('1. Testing 82% on Version 3.2. 2. Budget $4.7 million.',True))
 def test_date_mutation_still_fails(self):
  row={'task':'summary','messages':[{'content':'Summarize in two short sentences.'},{'content':'Deploy October 3.'}]}
  self.assertFalse(corrected(row,'1. Deploy October 4th. 2. Proceed.','stop')['valid'])
 def test_c2_replay_unchanged(self):
  C=p.ROOT/'docs/sprint3a/evidence/candidate2-quality-01'
  for row,review in zip(json.loads((C/'basic-suite.json').read_text())['requests'],json.loads((C/'basic-quality-review.json').read_text())['rows']):self.assertEqual(corrected(row,review['rawOutput'],'stop'),review['correctedValidatorReplay'])

def main():
 import io
 output=io.StringIO();test=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
 (E/'validator-postreview-tests.txt').write_text(output.getvalue());assert test.wasSuccessful(),output.getvalue()
 suite=json.loads((E/'frozen-suite.json').read_text())['requests'];review=json.loads((E/'semantic-review.json').read_text());rows=[]
 for fixture,row in zip(suite,review['rows']):
  assert original(fixture,row['rawOutput'],row['finishReason'])==row['validatorAssessment']
  result=corrected(fixture,row['rawOutput'],row['finishReason'])
  rows.append({'fixtureID':fixture['id'],'rawOutputSHA256':hashlib.sha256(row['rawOutput'].encode()).hexdigest(),'originalDecision':row['validatorAssessment'],'postreviewDecision':result,'changed':result!=row['validatorAssessment'],'semanticAssessmentUnchanged':row['semanticAssessment'],'releaseAfterSemanticReview':'RELEASE' if row['semanticAssessment']=='SEMANTIC_PASS' and result['valid'] else 'WITHHOLD'})
 from collections import Counter
 artifact={'originalValidatorSHA256':hashlib.sha256(Path(__file__).with_name('validation.py').read_bytes()).hexdigest(),'postreviewValidatorSHA256':hashlib.sha256(Path(__file__).with_name('validation_postreview.py').read_bytes()).hexdigest(),'changedAfterGeneration':True,'newGenerationRequests':0,'rawOutputsModified':False,'purpose':'Ordinal month/day literals and ordered two-sentence numbering only; no entailment, owner-action or approval-uncertainty solution claimed. Raw text is unchanged; only literal extraction recognizes presentation syntax.','testsPassed':test.testsRun,'rows':rows,'automaticReleaseCounts':dict(Counter(r['postreviewDecision']['releaseDecision'] for r in rows)),'reviewReleaseCounts':dict(Counter(r['releaseAfterSemanticReview'] for r in rows))}
 with (E/'validator-postreview-replay.json').open('x') as f:json.dump(artifact,f,indent=2);f.write('\n')
 print(json.dumps({k:v for k,v in artifact.items() if k!='rows'},indent=2))
if __name__=='__main__':main()

"""Frozen content, validator replay, and protocol guards; no AI imports."""
import hashlib,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p
from validation import validate
class Frozen(unittest.TestCase):
 def test_exact_fixtures(self):
  old=json.loads((p.ROOT/'docs/sprint3a/evidence/candidate2-quality-01/basic-suite.json').read_text())['requests']
  new=json.loads((p.E/'frozen-suite.json').read_text())['requests']
  self.assertEqual(len(new),16)
  for a,b in zip(old,new):
   for k in ('id','task','messages','maxTotalContext','maxNewTokens','expected','expectedLabel','currentOnly'):
    self.assertEqual(a.get(k),b.get(k),(a['id'],k))
 def test_corrected_validator_exact_replay(self):
  old=json.loads((p.ROOT/'docs/sprint3a/evidence/candidate2-quality-01/basic-quality-review.json').read_text())['rows']
  suite=json.loads((p.E/'frozen-suite.json').read_text())['requests']
  for row,review in zip(suite,old):self.assertEqual(validate(row,review['rawOutput'],'stop'),review['correctedValidatorReplay'])
 def test_gate_and_profile_frozen(self):
  protocol=json.loads((p.E/'prospective-protocol.json').read_text())
  self.assertEqual(protocol['gate']['bothFixtureCapabilitiesRequired'],4)
  self.assertTrue(protocol['gate']['writingOrSummaryCapabilityRequired'])
  self.assertEqual(p.POLICY['requestLimit'],16);self.assertEqual(p.POLICY['wallTimeoutSeconds'],180)
  self.assertEqual(p.POLICY['totalContext'],512);self.assertEqual(p.POLICY['terminationGraceSeconds'],0)
if __name__=='__main__':unittest.main(verbosity=2)

"""Unique Granite adapter: approved V2 signals; corrected lifecycle only; no retry."""
import hashlib,json,os,queue,subprocess,sys,threading,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p
H=p.B/'resource_harness_v2'
sys.path.insert(0,str(H))
from supervisor import Supervisor,atomic_json,stamp
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(p.B/'monitor_lifecycle_v3'))
from lifecycle import HelperSupervisor,launch_helper,cleanup_and_join,HELPER,group_present as helper_group_present
SANDBOX=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)']

def group_members(pgid):
 r=subprocess.run(['/bin/ps','-axo','pid=,pgid=,comm='],capture_output=True,text=True,check=True,timeout=1)
 return [dict(pid=int(f[0]),pgid=int(f[1]),name=f[2]) for line in r.stdout.splitlines() if len(f:=line.strip().split(None,2))==3 and int(f[1])==pgid]

def native_sample(pid=0):
 r=subprocess.run(SANDBOX+[str(HELPER),str(pid),'.25','0'],capture_output=True,text=True,check=True,timeout=1)
 return json.loads(r.stdout)

def counts(events,sent,worker_launched=False):
 return {'workerLaunches':int(worker_launched),
         'modelLoads':sum(e.get('event')=='load_begin' for e in events),
         'modelLoadCommands':sent.count('load'),'generationRequests':sum(c.startswith('generate-') for c in sent),'generationBegins':sum(e.get('event')=='generation_begin' for e in events),'unloadRequests':sent.count('unload')}

def main():
 for row in json.loads((p.E/'tested-source.json').read_text())['files']:
  assert hashlib.sha256((p.ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
 qualification=p.ROOT/'docs/sprint3a/evidence/monitor-lifecycle-v3-01'
 assert json.loads((qualification/'result.json').read_text())['status']=='MONITOR_LIFECYCLE_QUALIFIED_FOR_TESTED_CONTEXT'
 for row in json.loads((qualification/'tested-source.json').read_text())['files']:
  assert hashlib.sha256((p.ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],'Monitor qualification source changed'
 context=json.loads((qualification/'context.json').read_text())
 assert context['uid']==os.getuid() and context['interpreter']==sys.executable and context['sandbox']==SANDBOX
 assert context['interpreterSHA256']==hashlib.sha256(Path(sys.executable).resolve().read_bytes()).hexdigest()
 p.save('ATTEMPT_STARTED.json',{**stamp(),'pid':os.getpid(),'retryAllowed':False})
 life=Supervisor(p.E/'lifecycle',group_present=lambda:False,term_wait=0,kill_wait=1)
 atomic_json(p.E/'run-result.json',{'primary':'INCOMPLETE','supervisor':'RUNNING','evidenceCompleteness':'PARTIAL','label':p.LABEL})
 p.save('policy.json',p.POLICY)
 data_lock=threading.RLock();abort_lock=threading.RLock();native_lock=threading.Lock()
 stop=threading.Event();abort_event=threading.Event();baseline_ready=threading.Event();worker_sample_ready=threading.Event()
 events=[];samples=[];notifications=[];reasons=[];sent=[];q=queue.Queue();threads=[]
 state={'phase':'IDLE','phaseStart':None,'start':None,'lastHost':time.monotonic(),'lastWorker':None,'lastMLX':None,'mlx':None,'baseline':None,'degraded':False,'sampler':None,'worker':None,'monitorLife':None,'samplingInterval':.1}
 raw=(p.E/'worker-events.jsonl').open('x');metrics=(p.E/'resources.jsonl').open('x');notes=(p.E/'pressure-events.jsonl').open('x')
 err=(p.E/'worker.stderr').open('x');monitor_err=(p.E/'monitor.stderr').open('x')
 preparation_status=None;success=False
 def abort(why):
  with abort_lock:
   if why not in reasons:reasons.append(why)
   abort_event.set()
  # Journal outside abort lock; signal thread owns lifecycle methods and zero grace.
 def native_control(pid,interval):
  with native_lock:
   state['sampler'].stdin.write(f'{pid} {interval}\n');state['sampler'].stdin.flush()
   state['samplingInterval']=interval
 def enrich(row,previous,phase):
  now=time.monotonic();row.update(fixtureID=state.get('fixtureID'),phase=phase,receivedMonotonic=now,sampleAgeSeconds=now-row['monotonic'],label=p.LABEL,workerPGID=state['worker'].pid if state['worker'] else None)
  base=state['baseline'] or row
  row['compressorDeltaBytes']=row.get('compressorOccupancyBytes',0)-base.get('compressorOccupancyBytes',0) if 'compressorOccupancyBytes' in row and 'compressorOccupancyBytes' in base else None
  row['swapDeltaBytes']=row.get('swapUsedBytes',0)-base.get('swapUsedBytes',0) if row.get('swapUsedBytes') is not None and base.get('swapUsedBytes') is not None else None
  dt=row['monotonic']-previous['monotonic'] if previous else None
  for field,name,mult in [('compressorOccupancyBytes','compressorGrowthBytesPerSecond',1),('swapInPagesTotal','swapInBytesPerSecond',row.get('pageSizeBytes')),('swapOutPagesTotal','swapOutBytesPerSecond',row.get('pageSizeBytes'))]:
   delta=row[field]-previous[field] if previous and row.get(field) is not None and previous.get(field) is not None else None
   row[name]=delta*mult/dt if delta is not None and mult and dt and 0<dt<=1.5 and (field=='compressorOccupancyBytes' or delta>=0) else None
  memory=state['mlx']
  for field,name in [('active','mlxActiveBytes'),('cache','mlxCacheBytes'),('peak','mlxPeakBytes')]:row[name]=memory.get(field) if memory else None
  row['mlxSampleAgeSeconds']=now-state['lastMLX'] if state['lastMLX'] else None
  row['mlxUnavailableReason']=None if memory else 'Runtime not initialized or no worker memory event yet'
  if (row['compressorDeltaBytes'] is not None and row['compressorDeltaBytes']>0) or (row.get('compressorGrowthBytesPerSecond') is not None and row['compressorGrowthBytesPerSecond']>0) or row.get('thermalState')==1:state['degraded']=True
  return row
 def monitor():
  previous=None
  try:
   for line in state['sampler'].stdout:
    if stop.is_set():break
    item=json.loads(line);kind=item['event']
    if kind in ('pressure_notification','pressure_subscription_ready','control_applied'):
     item['receivedMonotonic']=time.monotonic();notifications.append(item);notes.write(json.dumps(item)+'\n');notes.flush()
     if kind=='pressure_notification':
      assert p.valid(item.get('monotonic')) and 0<=time.monotonic()-item['monotonic']<=1.5,'Pressure event clock invalid/stale'
      why=p.pressure_reason(item['pressureMask'])
      if why:abort(why)
     continue
    assert kind=='sample'
    with data_lock:
     row=enrich(item,previous,state['phase']);worker=state['worker'];alive=worker is not None and worker.poll() is None
     target_matches=alive and row.get('workerPID')==worker.pid
     why=p.violation(row,state['baseline'] or row,previous,time.monotonic(),target_matches)
     if alive and not target_matches and state['lastWorker'] and time.monotonic()-state['lastWorker']>1.5:why='MONITOR: worker binding stale'
     if target_matches and p.valid(row.get('workerPhysicalFootprintBytes')):
      state['lastWorker']=row['monotonic'];worker_sample_ready.set()
     if why:abort(why)
     row['guardState']='STOP' if reasons else 'LOCAL_DEGRADED' if state['degraded'] else 'SAFE'
     row['guardReason']=reasons[0] if reasons else 'compression/fair thermal diagnostic' if state['degraded'] else 'required signals normal'
     samples.append(row);metrics.write(json.dumps(row)+'\n');metrics.flush()
     state['lastHost']=row['monotonic']
     if state['baseline'] is None:
      assert why is None,why
      state['baseline']=dict(row)
      p.save('baseline.json',dict(sample=row,metric='vm_stat free + inactive + speculative == Mach free_count + inactive_count',calibrationAllowanceBypass=p.POLICY['workingAllowanceBypass']))
     if previous is not None and any(n['event']=='pressure_subscription_ready' for n in notifications):baseline_ready.set()
     previous=dict(row)
   if not stop.is_set():abort('MONITOR: native sampler ended')
  except BaseException as error:abort('MONITOR: '+repr(error));baseline_ready.set()
 def watchdog():
  last_check=0
  while not stop.wait(.05):
   now=time.monotonic();why=p.deadline(now,state['start'],state['lastHost'],state['lastMLX'],state['phase'],state['phaseStart'])
   if why:abort(why)
   worker=state['worker']
   if worker is not None and worker.poll() is None:
    if state['lastWorker'] is not None and now-state['lastWorker']>1.5:abort('MONITOR: worker footprint stale')
    if now-last_check>.5:
     try:
      extra=[m for m in group_members(worker.pid) if m['pid']!=worker.pid]
      if extra:abort('SECURITY: unexpected worker-group process '+repr(extra))
     except BaseException as error:abort('MONITOR: process inventory '+repr(error))
     last_check=now
 def terminator():
  while not stop.is_set():
   if not abort_event.wait(.05):continue
   with life.lock:
    life.request_abort(reasons[0] if reasons else 'Hard stop')
    life._error('termination',life._terminate)
   return
 def reader():
  try:
   for line in state['worker'].stdout:
    event=json.loads(line);assert event['label']==p.LABEL
    event['receivedMonotonic']=time.monotonic()
    memory=event.get('memory')
    if memory is not None:
     assert all(p.valid(memory.get(k)) for k in ('active','cache','peak')),'Invalid MLX counters'
     assert 0<=time.monotonic()-event['monotonic']<=1.5,'Stale worker event'
     state['mlx']=memory;state['lastMLX']=event['monotonic']
    events.append(event);raw.write(json.dumps(event)+'\n');raw.flush();q.put(event)
    if event['event'] in ('load_begin','generation_begin','unload_begin') and sum(e['event']==event['event'] for e in events)>(16 if event['event']=='generation_begin' else 1):abort('SECURITY: repeated workload event')
    if event['event']=='fatal':abort(event.get('classification','RUNTIME')+': '+event.get('error','fatal'))
    if event['event']=='prefill_progress' and event['processed']==event['total']:
     state['phase']='GENERATION';native_control(state['worker'].pid,.25)
    if event['event']=='sampled_token' and event['index']>128:abort('SECURITY: output limit exceeded')
   q.put({'event':'terminated'})
  except BaseException as error:abort('RUNTIME: worker event '+repr(error));q.put({'event':'terminated'})
 def wait(wanted,seconds):
  deadline=time.monotonic()+seconds
  while not abort_event.is_set():
   if time.monotonic()>deadline:abort('RUNTIME: timeout awaiting '+wanted);break
   try:event=q.get(timeout=.05)
   except queue.Empty:continue
   if event['event']==wanted:return event
   if event['event']=='terminated':raise RuntimeError('worker ended before '+wanted)
  raise RuntimeError('Aborted: '+repr(reasons))
 def send(command,phase=None):
  with abort_lock:
   assert not abort_event.is_set(),reasons
   assert command not in sent,'SECURITY: repeated command'
   sent.append(command)
   if phase:state['phase']=phase;state['phaseStart']=time.monotonic()
   state['worker'].stdin.write(json.dumps({'command':command})+'\n');state['worker'].stdin.flush()
 try:
  # Verify the actual supervisor/worker launch boundary matches final harmless qualification.
  tested=json.loads((p.ROOT/'docs/sprint3a/evidence/resource-policy-v2/revision-03/tested-source.json').read_text())['files']
  for row in tested:
   if Path(row['path']).name in ('supervisor.py','harmless_worker.py','run_harmless.py'):
    assert hashlib.sha256((p.ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],'COMPATIBILITY: tested boundary code changed'
  qualified=json.loads((p.ROOT/'docs/sprint3a/evidence/resource-policy-v2/revision-03/real-tests/normal-term/launch.json').read_text())
  assert qualified['command'][:6]==SANDBOX+[sys.executable,'-I','-B'],'COMPATIBILITY: execution boundary differs'
  p.save('boundary.json',{'matched':True,'launchPrefix':qualified['command'][:6],'sameUID':os.getuid(),'startNewSession':True,'parent':'tool-approved execution outside Codex sandbox','worker':'unchanged seatbelt network denial','terminationGraceSeconds':0,'difference':'Helper uses qualified helper-only 100 ms observation. Worker hard-abort TERM wait remains zero. Sixteen stateless requests within unchanged 180-second wall deadline.'})
  verification=subprocess.run([sys.executable,'-I','-B',str(HERE/'prepare.py')],capture_output=True,text=True,timeout=120)
  p.save('verification-exit.json',dict(exitCode=verification.returncode,stdout=verification.stdout,stderr=verification.stderr,**stamp()))
  if verification.returncode:
   preparation_status=json.loads((p.E/'preparation-failure.json').read_text())['status'] if (p.E/'preparation-failure.json').exists() else 'ACTIVATION_VERIFICATION_FAILED'
   raise RuntimeError('Preparation failed')
  began=time.monotonic();time.sleep(10)
  p.save('settling.json',{'seconds':time.monotonic()-began,'verifierExited':True,'naturalOnly':True})
  state['phase']='ADMISSION';state['lastHost']=time.monotonic()
  state['monitorLife']=HelperSupervisor(p.E/'monitor-lifecycle',kill_wait=1)
  state['sampler']=launch_helper(stderr=monitor_err)
  state['monitorLife'].proc=state['sampler'];state['monitorLife'].pgid=state['sampler'].pid;state['monitorLife'].group_present=lambda:helper_group_present(state['sampler'].pid)
  for f in (monitor,watchdog,terminator):
   t=threading.Thread(target=f,name=f.__name__,daemon=True);threads.append(t);t.start()
  assert baseline_ready.wait(3) and state['baseline'] is not None and len(samples)>=2,'MONITOR: baseline unavailable'
  assert not reasons,reasons
  scratch=p.B/'.artifacts/state/candidate4-basic-quality-01';scratch.mkdir(parents=True,exist_ok=False)
  env=dict(os.environ);env.update(PATH='/usr/bin:/bin',TMPDIR=str(scratch),HF_HOME=str(scratch/'hf'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',HF_HUB_DISABLE_XET='1',DO_NOT_TRACK='1',TOKENIZERS_PARALLELISM='false',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1',USE_TORCH='0',USE_TF='0',USE_FLAX='0')
  cmd=SANDBOX+[sys.executable,'-I','-B',str(HERE/'worker.py')]
  p.save('launch.json',{'command':cmd,'offlineFlags':{k:env[k] for k in ('HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_HUB_DISABLE_TELEMETRY','USE_TORCH','USE_TF','USE_FLAX')},'appleFoundationBackend':'DISABLED_UNREGISTERED','fallbacks':[],'tools':[]})
  with abort_lock:
   assert not abort_event.is_set()
   worker=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,start_new_session=True,env=env)
   state['worker']=worker;life.proc=worker;life.pgid=worker.pid;life.group_present=lambda:bool(group_members(worker.pid))
   state['start']=time.monotonic();state['lastWorker']=state['start'];state['phase']='LOAD'
   p.save('worker-start.json',{'pid':worker.pid,'pgid':worker.pid,'startedMonotonic':state['start'],'monitorStartedBeforeWorker':True})
  native_control(worker.pid,.1)
  t=threading.Thread(target=reader,name='worker-reader',daemon=True);threads.append(t);t.start()
  started=wait('started',10);assert started['pid']==worker.pid and started['pgid']==worker.pid,'SECURITY: worker group mismatch'
  assert worker_sample_ready.wait(2) and not reasons,'MONITOR: worker footprint unavailable'
  send('initialize');wait('runtime_ready',30)
  assert any(e['event']=='network_negative_control' and e['denied'] for e in events),'NETWORK: negative control failed'
  send('load','LOAD');wait('MODEL_LOADED',90)
  suite=json.loads((p.E/'frozen-suite.json').read_text())['requests']
  assert len([e for e in events if e['event']=='prompt_preflight'])==16,'ACTIVATION: prompt verification missing'
  for index,row in enumerate(suite):
   state['fixtureID']=row['id'];native_control(worker.pid,.1)
   send('generate-'+str(index),'PREFILL');generated=wait('generated',60)
   assert generated['fixtureID']==row['id'] and generated['promptTokens']+generated['sampledTokensIncludingStop']<=512,'SECURITY: fixture/context mismatch'
   p.save('response-%02d.json'%index,generated)
  state['fixtureID']=None
  native_control(worker.pid,.25);send('unload','UNLOAD');wait('unloaded',10)
  send('exit');worker.wait(timeout=3)
  success=worker.returncode==0 and not reasons
 except BaseException as error:
  text=str(error);prefix='COMPATIBILITY: ' if 'COMPATIBILITY:' in text else 'NETWORK: ' if 'NETWORK:' in text else 'SECURITY: ' if 'SECURITY:' in text else 'ACTIVATION: ' if 'ACTIVATION:' in text else 'MONITOR: ' if 'MONITOR:' in text else 'RUNTIME: '
  abort(prefix+repr(error))
 finally:
  if reasons and len(threads)>=3:
   threads[2].join(timeout=5)
  primary=preparation_status or p.classify(success and not reasons,reasons,events)
  def cleanup_monitor():
   stop.set()
   ml=state['monitorLife']
   if ml:
    cleanup=cleanup_and_join(ml,threads,stop)
    atomic_json(p.E/'helper-cleanup-and-joins.json',cleanup)
    if not cleanup['clean']:raise RuntimeError('Helper cleanup or thread join incomplete')
   else:
    from lifecycle import join_threads
    joins=join_threads(threads)
    atomic_json(p.E/'helper-cleanup-and-joins.json',{'joins':joins,'helper':None})
    if not all(j['completed'] for j in joins):raise RuntimeError('Thread join incomplete')
  def recovery():
   state['phase']='RECOVERY';rows=[];previous=samples[-1] if samples else None
   recovery_start=time.monotonic()
   for index in range(12):
    time.sleep(max(0,recovery_start+index*.25-time.monotonic()))
    try:
     row=enrich(native_sample(),previous,'RECOVERY');previous=dict(row)
     row['workerPresent']=state['worker'].poll() is None if state['worker'] else False
     row['processGroupMembers']=group_members(state['worker'].pid) if state['worker'] else []
     rows.append(row)
    except BaseException as error:rows.append(dict(stamp(),error=repr(error)))
   if any('error' in r for r in rows):
    atomic_json(p.E/'partial-recovery.json',{'samples':rows});raise RuntimeError('Recovery samples incomplete')
   return {'samples':rows,'boundedSecondsTarget':3}
  def evidence():
   for stream in (raw,metrics,notes,err,monitor_err):stream.flush();stream.close()
   for stream in ([state['worker'].stdin,state['worker'].stdout] if state['worker'] else []):stream.close()
   atomic_json(p.E/'workload-summary.json',dict(counts(events,sent,state['worker'] is not None),commands=sent,aborts=reasons,diagnostic='LOCAL_DEGRADED' if state['degraded'] else 'NORMAL'))
  life_result=life.finish(primary,cleanup=cleanup_monitor,recovery=recovery,evidence=evidence)
  # The reusable harmless component has placeholder zero workload counters; adapter supplies actual counts.
  life_result.update(counts(events,sent,state['worker'] is not None));life_result['workloadCounterSource']='Adapter command/event journal; replaces component-only placeholder counters'
  primary=preparation_status or p.classify(success and not reasons,reasons,events)
  life_result['primary']=primary
  life._error('write_actual_workload_counts',lambda:atomic_json(p.E/'lifecycle/result.json',life_result))
  life._error('reseal_actual_workload_counts',lambda:atomic_json(p.E/'lifecycle/manifest.json',{'files':[{'path':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted((p.E/'lifecycle').iterdir()) if f.is_file() and f.name!='manifest.json']}))
  complete=life_result['evidenceCompleteness']=='COMPLETE' and not any(e['stage']!='term_wait' for e in life.errors)
  if not complete and life_result['supervisor']=='TERMINATION_CONFIRMED':life_result['supervisor']='CLEANUP_OR_EVIDENCE_ERROR'
  result=dict(stamp(),label=p.LABEL,primary=primary,supervisor=life_result['supervisor'],evidenceCompleteness='COMPLETE' if complete else 'PARTIAL',**counts(events,sent,state['worker'] is not None),commands=sent,aborts=reasons,diagnostic='LOCAL_DEGRADED' if state['degraded'] else 'NORMAL',workerExitCode=life_result['workerExitCode'],processGroupPresent=life_result['processGroupPresent'],lifecycle='EXPERIMENTAL',qualifiedTasks=[],retryAllowed=False)
  atomic_json(p.E/'run-result.json',result)
  atomic_json(p.E/'run-manifest.json',{'files':[{'path':str(f.relative_to(p.E)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted(p.E.rglob('*')) if f.is_file() and f.name!='run-manifest.json']})
  print(json.dumps(result),flush=True)
if __name__=='__main__':main()

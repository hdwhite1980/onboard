# Organization-controlled local AI — bounded calibration only

ENGINEERING_CALIBRATION_ONLY. This directory currently contains the separately authorized Candidate 1 acquisition, isolated dependency environment and one-use calibration harness. It is not the completed Sprint 3A product implementation.

The single attempt aborted during model loading due to compressor growth. Generation did not start. Do not rerun the harness or remove its ATTEMPT_STARTED marker without a new explicit owner authorization. Normal admission remains 5 GiB working allowance + 2 GiB reserve. No model/profile is QUALIFIED.

See ../../docs/sprint3a/BOUNDED_4B_CALIBRATION_REPORT.md for measurements, limitations and exact evidence. Historical demo/feasibility/proof paths were not modified. Artifact/runtime data are local under .artifacts; runtime/requirements.lock and runtime/SBOM.json identify the exact installed wheels. No cloud, Graph or Foundation Models fallback exists in this calibration worker.

"""ENGINEERING_CALIBRATION_ONLY: one local load, one <=128-token generation."""
import os,sys,json,time,threading,socket,errno,hashlib,gc,ctypes,importlib
from pathlib import Path
LABEL='ENGINEERING_CALIBRATION_ONLY';lock=threading.Lock();phase='startup';mx=None;done=threading.Event()
def emit(event,**data):
 with lock:print(json.dumps({'label':LABEL,'event':event,'monotonic':time.monotonic(),'phase':phase,**data}),flush=True)
def images():
 lib=ctypes.CDLL(None);lib._dyld_image_count.restype=ctypes.c_uint32;lib._dyld_get_image_name.argtypes=[ctypes.c_uint32];lib._dyld_get_image_name.restype=ctypes.c_char_p
 names=[lib._dyld_get_image_name(i).decode() for i in range(lib._dyld_image_count())]
 if any('foundationmodels' in n.lower() for n in names):raise RuntimeError('FORBIDDEN_FOUNDATION_MODELS_IMAGE')
 return names
def memory():return {'active':mx.get_active_memory(),'cache':mx.get_cache_memory(),'peak':mx.get_peak_memory()} if mx else None
def telemetry():
 while not done.wait(.1):
  try:emit('mlx_memory',memory=memory())
  except BaseException as e:emit('fatal',classification='RUNTIME',error='MLX monitoring unavailable: '+repr(e));os._exit(70)
def command(expected):
 row=json.loads(sys.stdin.readline());assert row=={'command':expected},'Unexpected protocol command'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 global mx,phase
 snapshot=Path(sys.argv[1]);expected=sys.argv[2];budget=json.loads(Path(sys.argv[3]).read_text())
 assert budget['modelManifestSHA256']==expected and budget['promptTokens']+128<=512
 emit('started',pid=os.getpid(),fallbacks=[],appleFoundationBackend='DISABLED_UNREGISTERED',images=images())
 command('initialize')
 # Deliberate negative control is the only allowed network attempt. No data sent.
 try:
  with socket.socket() as s:s.settimeout(1);s.connect(('127.0.0.1',9))
 except OSError as e:
  emit('network_negative_control',denied=e.errno in [errno.EPERM,errno.EACCES],errno=e.errno)
  if e.errno not in [errno.EPERM,errno.EACCES]:raise RuntimeError('NETWORK_DENIAL_NOT_ESTABLISHED')
 else:raise RuntimeError('NETWORK_BOUNDARY_FAILED')
 def audit(event,args):
  if event in ['socket.connect','socket.connect_ex','socket.getaddrinfo','socket.sendto','socket.sendmsg']:
   emit('unexpected_network',operation=event);os._exit(71)
  if event in ['subprocess.Popen','os.system','os.exec']:
   emit('unexpected_process',operation=event);os._exit(72)
 sys.addaudithook(audit)
 import mlx.core as core
 mx=core
 import huggingface_hub
 def no_download(*args,**kwargs):
  emit('unexpected_network',operation='artifact_download_request');os._exit(71)
 huggingface_hub.snapshot_download=no_download;huggingface_hub.hf_hub_download=no_download
 from mlx_lm import load
 from mlx_lm.generate import generate_step
 from mlx_lm.models.cache import make_prompt_cache
 from importlib.metadata import version
 assert mx.metal.is_available(),'Metal unavailable'
 emit('ready',runtime={n:version(n) for n in ['mlx','mlx-metal','mlx-lm','transformers','tokenizers']},memory=memory(),device=mx.device_info(),images=images())
 monitor=threading.Thread(target=telemetry,daemon=True);monitor.start()
 command('load');phase='verify_snapshot';raw=(snapshot/'manifest.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
 manifest=json.loads(raw);expected_files={x['path'] for x in manifest['files']}|{'manifest.json'}
 assert {str(p.relative_to(snapshot)) for p in snapshot.rglob('*') if p.is_file()}==expected_files
 for row in manifest['files']:
  p=snapshot/row['path'];assert not p.is_symlink() and p.stat().st_nlink==1 and p.stat().st_size==row['bytes'] and digest(p)==row['sha256']
 cfg=json.loads((snapshot/'config.json').read_text());tc=json.loads((snapshot/'tokenizer_config.json').read_text())
 assert cfg['model_type']=='qwen3' and cfg['quantization']=={'bits':4,'group_size':64}
 assert not any(k in d for d in [cfg,tc] for k in ['model_file','auto_map'])
 assert hashlib.sha256(tc['chat_template'].encode()).hexdigest()==budget['chatTemplateSHA256']
 emit('preload_token_budget',promptTokens=budget['promptTokens'],maxNewTokens=128,totalContextLimit=512,thinking=False,rawPrompt=budget['rawPrompt'])
 phase='load';emit('load_begin');t=time.monotonic()
 model,tokenizer=load(str(snapshot),tokenizer_config={'local_files_only':True,'trust_remote_code':False},lazy=False)
 # Floating compute/KV FP16; packed 4-bit integer weights and artifact bytes unchanged.
 model.set_dtype(mx.float16);mx.eval(model.parameters());mx.synchronize()
 emit('loaded',seconds=time.monotonic()-t,memory=memory(),manifestSHA256=expected,compute='FP16',weightQuantization='4-bit group-64',images=images())
 command('generate');phase='tokenize'
 prompt=tokenizer.apply_chat_template(budget['messages'],tokenize=False,add_generation_prompt=True,enable_thinking=False)
 ids=tokenizer.encode(prompt,add_special_tokens=False)
 assert prompt==budget['rawPrompt'] and ids==budget['tokenIDs'] and len(ids)+128<=512
 emit('prompt',rawPrompt=prompt,promptTokens=len(ids),totalContextLimit=512,maxNewTokens=128,batch=1,kv='FP16',thinking=False,sampler='greedy argmax')
 cache=make_prompt_cache(model);phase='generate';emit('generation_begin');t=time.monotonic();first=None;last=None;tokens=[];reason='length'
 # Direct generation_step avoids MLX-LM's automatic wired-limit adjustment.
 stream=generate_step(mx.array(ids),model,max_tokens=128,prompt_cache=cache,prefill_step_size=128,kv_bits=None)
 for token,logprobs in stream:
  now=time.monotonic();first=first or now;last=now;value=int(token)
  if value in tokenizer.eos_token_ids:reason='stop';break
  tokens.append(value)
  emit('token',index=len(tokens),token=value,memory=memory())
  if len(tokens)>=128:break
 stream.close();mx.synchronize();elapsed=time.monotonic()-t
 types=sorted({str(a.dtype) for c in cache for a in c.state});assert types==['mlx.core.float16'],types
 text=tokenizer.decode(tokens);assert text.strip(),'Empty generation'
 emit('generated',rawOutput=text,outputTokens=len(tokens),seconds=elapsed,firstTokenSeconds=first-t if first else None,generationTokensPerSecond=(len(tokens)-1)/(last-first) if first and last>first and len(tokens)>1 else None,finishReason=reason,kvDtypes=types,memory=memory(),images=images())
 command('unload');phase='unload'
 del stream,logprobs,token,cache,model,tokenizer
 gc.collect();mx.synchronize();mx.clear_cache();emit('unloaded',memory=memory())
 command('exit');done.set();monitor.join(timeout=1);emit('exiting',memory=memory())
if __name__=='__main__':
 try:main()
 except BaseException as e:
  kind='ARTIFACT' if phase=='verify_snapshot' else 'SECURITY' if 'NETWORK_' in str(e) or 'FOUNDATION' in str(e) else 'RUNTIME'
  emit('fatal',classification=kind,error=repr(e));done.set();sys.exit(1)

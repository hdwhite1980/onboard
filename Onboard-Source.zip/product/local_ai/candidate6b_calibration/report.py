"""Produce final Candidate6B documents and append measured comparison only."""
import json
from pathlib import Path
import common as c
D=c.ROOT/'docs/sprint3a';E=c.E;G=1024**3
read=lambda n:json.loads((E/n).read_text());m=read('measurements.json');pkg=read('package.json');pre=read('tokenizer-runtime-check.json');hyp=read('resource-hypothesis.json');cmp=read('comparison-to-candidate6.json');r=m['result'];decision=read('decision.json')
def write(n,t):
 with (D/n).open('x') as f:f.write(t.rstrip()+'\n')
def gib(n):return f'{n/G:.6f} GiB'
def link(n):return f'[evidence/{E.name}/{n}](evidence/{E.name}/{n})'
write('CANDIDATE6B_EXPERIMENT_EXCEPTION.md',f'''# Candidate 6B — experimental exception

**CANDIDATE6B_EXPERIMENTAL_PROVENANCE_EXCEPTION** applies only to `{c.REPO}` at `{c.REV}`. It is separate from the retained multimodal Candidate 6 package and its failed result.

Stage 1 passed before Stage 2. The [bounded artifact review](CANDIDATE6B_ARTIFACT_REVIEW.md) selected exactly this pin based on identity, post-trained upstream declaration, tokenizer equivalence, standard converter family, license material, native runtime compatibility and actual language-only index. All heads remained unchanged. No new conflicting/restrictive terms were found in the reviewed material; the known historical Qwen tokenizer issue remains unresolved. This is an engineering exception, not a legal clearance claim.

Declared upstream `{c.UPSTREAM}`; research revision `{c.UPREV}` is not attested as the conversion input. The exact command, complete dependency/build record and converter input commit remain unknown. A version declaration/hash-pinned artifact does not prove reproducibility.

Status remains LOCAL_ENGINEERING_EVALUATION_ONLY; NO_REDISTRIBUTION; TOKENIZER_PROVENANCE_PENDING; CONVERSION_REPRODUCIBILITY_PENDING; PRODUCTION_BLOCKED; CUSTOMER_BLOCKED; GOVERNMENT_BLOCKED; CUI_FCI_BLOCKED; QUALIFIED_TASKS_NONE. Distribution PROHIBITED_PENDING_REVIEW. Lifecycle EXPERIMENTAL.

Owner authorization is preserved in {link('owner-authorization.txt')}. Only the unmeasured pre-load working-allowance threshold was bypassed for one calibration. All hard Policy V2 guards remained. The run failed on pressure WARN; no generation, retry, alternate derivative acquisition, full 16-case quality suite, Gemma or Sprint 3B followed.
''')
rows='\n'.join(f"| `{x['path']}` | {x['bytes']:,} | `{x['sha256']}` |" for x in pkg['manifest']['files'])
pub='\n'.join(f"| `{x['path']}` | `{x['gitBlobID']}` | {x['publisherHashType']}: `{x['publisherHash']}` |" for x in read('acquisition.json')['files'])
write('CANDIDATE6B_PACKAGE.md',f'''# Candidate 6B — distinct verified text-only package

**PASS**: `{c.REPO}@{c.REV}`. Eight publisher files total **5,058,247,448 bytes**. One weight file is **5,038,162,675 bytes**; seven pinned metadata files were copied only after fresh Git/LFS validation. Only this candidate's weights were downloaded, without retry. No other derivative, Candidate 6 multimodal or Gemma weights were acquired.

Package ID: `org.experimental.qwen3.5-9b-text.mlx4-g64`.

Manifest SHA-256: `{pkg['manifestSHA256']}`.

Full manifest: {link('package.json')}. Content-addressed store: `{pkg['store']}`.

This is the unchanged separately published derivative, not an organization-stripped copy of the multimodal artifact. Ten payload files include the eight publisher files, verbatim upstream Apache-2.0 LICENSE and clearly organization-authored limitation record. `manifest.json` is additional. No invented upstream NOTICE.

| Payload | Bytes | Complete local SHA-256 |
|---|---:|---|
{rows}

| Publisher file | Git blob | Publisher content identity |
|---|---|---|
{pub}

All allowlisted inventory, file sizes, publisher hashes and local hashes matched. Descriptor checks enforce safe names, no-follow traversal, regular single-link files, correct owner, no execute bits, stable metadata, root identity and post-read identity. The content store and private activation snapshot are read-only. Full snapshot verification passed immediately before loading. Same-UID path replacement after verification remains a development limitation because the retained loader reopens paths; this is not production activation security.

The safetensors header, offsets, complete payload span and index all matched: **927 language entries**, **0 vision**, **0 MTP**, **5,038,041,600 logical tensor bytes**. Every shape and dtype matched an independently config-derived 32-layer Qwen3.5-9B inventory. Language projections remain U32-packed affine 4-bit/group-64, scales/biases BF16, recurrent A_log F32. Convolutions are already [8192,4,1], compatible with the retained sanitizer without a second norm shift. Header shapes establish storage structure, not an attested history of transformation values.

There are no processor files or vision_config. Residual image/video token IDs and conditional-generation architecture metadata are inert under the built-in text wrapper. Config/tokenizer JSON, native template and embedded vocabulary matched pinned identities; embedded vocabulary matches official upstream. No repository executable, native binary, auto_map, model_file or remote-code requirement was found. See {link('artifact-verification.json')}, {link('safetensors-header.json')} and {link('config-validation.json')}.

Lifecycle EXPERIMENTAL, qualified tasks NONE, tokenizer/conversion provenance PENDING, distribution PROHIBITED_PENDING_REVIEW. Successful acquisition does not establish safe model execution.
''')
suite=read('frozen-suite.json')['requests'];budget='\n'.join(f"| {x['id']} | {x['promptTokens']} | 128 | {x['accountedTokens']} |" for x in suite)
write('CANDIDATE6B_TOKENIZER_PREFLIGHT.md',f'''# Candidate 6B — offline tokenizer/config preflight

**PASS** with zero models constructed and zero generations. Retained Python 3.12.14 arm64, MLX/MLX-metal 0.32.2, MLX-LM 0.31.3, Transformers 5.17.0 and tokenizers 0.23.2 were reverified against 34 packages and 5,555 wheel files. No runtime change occurred.

The same explicit macOS network-denied boundary rejected the deliberate loopback control with EPERM. Hub/network/subprocess and weight-loading APIs/model construction were prohibited. `local_files_only=True`, `trust_remote_code=False`; no image/video processor, external provider, Foundation Models or fallback.

All 33 special tokens matched. Twenty ordinary cases covering numbers, dates, currency, percentages, versions, names, Falcon IDs, Unicode and whitespace round-tripped across three tokenizer paths. Exact system/user and no-system rendering passed. Use of the native template explicitly set `enable_thinking=False`, producing one empty closed reasoning block. No thinking rescue, prompt rewrite or truncation.

Tokenizer SHA-256 `{pre['tokenizerSHA256']}` is **byte-identical** to Candidate 6. Template SHA-256 `{pre['templateSHA256']}` is also byte-identical. The Stage 2 prose originally described tokenizer object equality despite serialization differences; the raw comparison already correctly recorded byte equality. [The correction record]({f'evidence/{E.name}/research-report-correction.json'}) preserves that distinction without rewriting the sealed Stage 2 snapshot.

Conversational EOS/stop set **[248046]**; nested text EOS/pad 248044 is not used as a top-level conversational stop override. The wrapper's installed default is used.

First professional-1: **114 prompt tokens + 128 output reserve = 242/512**. Maximum across all rendered cases: **287/512**. All 16 exact Candidate2 message pairs were rendered; none generated. The run manifest contained only professional-1. Messages, rendered text, IDs/count, template/tokenizer hashes, stop set and thinking state were frozen before construction in {link('future-first-prompt.json')} and {link('frozen-suite.json')}.

| Fixture | Prompt | Reserved output | Accounted total |
|---|---:|---:|---:|
{budget}

Twenty-six pure adapter guards passed. Exact worker hard-abort source and context hashes were checked against Stage 1 qualification; helper lifecycle remained unchanged. The physical run later failed during model loading, so preflight does not imply cache/generation compatibility or quality qualification.
''')
terms='\n'.join(f"| {k} | {v:,} | {v/G:.6f} |" for k,v in hyp['termsBytes'].items())
write('CANDIDATE6B_RESOURCE_PLAN.md',f'''# Candidate 6B — independently derived finite resource hypothesis

Frozen before the one attempt. **CANDIDATE6B_WORKER_CEILING = 6.75 GiB** ({hyp['workerCeilingBytes']:,} bytes). Derived from the verified text-only artifact, not inherited from Candidate 6's 7.5 GiB ceiling and not reduced to force admission.

| Term | Bytes | GiB |
|---|---:|---:|
{terms}

Raw sum {gib(hyp['rawBudgetBytes'])}; upward quarter-GiB rounding adds {hyp['quarterGiBRoundingBytes']:,} bytes. Persistent caches total 68,288,512 bytes: 16 MiB attention KV, 48 MiB FP32 recurrent state, 1.125 MiB convolution state at batch 1/context 512. Prefill-128 FP16 vocabulary logits are 63,569,920 bytes and included in the temporary allowance. Remaining temporary, allocator, process and uncertainty terms are unmeasured budget allowances, not residency observations. Weight bytes are not RAM measurements.

Conservative unmeasured planning admission would require >9.0 GiB legacy-equivalent headroom (6.75 + 2.25). Owner authorizes bypass of only that working allowance for exactly one run labeled **CANDIDATE6B_UNMEASURED_PROFILE_OWNER_AUTHORIZED_CALIBRATION**.

Unchanged hard guards: NORMAL pressure; reserve 2 GiB/early stop <=2.25 GiB; zero initial swap/no growth/no swap-in/out; nominal/fair thermal; required fresh telemetry <=1.5 s; new finite footprint ceiling; allocation/packed-storage/security/network/runtime checks; load 90 s, generation 60 s, wall 180 s. Compression-only growth remains diagnostic. The margin does not prove immunity to instantaneous allocation bursts or OS scheduling delays.

Use immediate-KILL worker hard abort qualified separately from the helper's 100 ms TERM window. Native LOAD/PREFILL sampling 100 ms; GENERATION/RECOVERY 250 ms; native pressure events and independent watchdog. Host preparation uses completed verification processes, >=10 seconds natural settling and a fresh hard-guard baseline; no forced app closure, security termination, cache purge, VM changes or artificial pressure.

Profile: batch 1, total 512, output 128 included, prefill 128, native template, thinking false, greedy argmax, no tools/providers/fallback. One load/request/unload maximum, no retry. This hypothesis remains unqualified because the actual run failed on WARN pressure before load completion.
''')
old=json.loads((c.ROOT/'docs/sprint3a/evidence/candidate6-calibration-01/measurements.json').read_text())
comparisonrows=[('Published weight bytes','5,950,221,072','5,038,162,675'),('Opened shard tensor entries','1,260','927'),('Bound packed language bytes','5,038,041,600','5,038,041,600'),('Vision entries / logical bytes','333 / 912,020,960','0 / 0'),('Baseline headroom',gib(old['baselineHeadroomBytes']),gib(m['baseline']['availableEstimateLegacyBytes'])),('Observed worker footprint peak',gib(old['nativeBounds']['workerPhysicalFootprintBytes']['max']),gib(m['nativeBounds']['workerPhysicalFootprintBytes']['max'])),('Observed MLX active/peak',gib(old['mlxObservedBounds']['active']['max']),gib(m['mlxObservedBounds']['active']['max'])),('Minimum legacy headroom',gib(old['nativeBounds']['availableEstimateLegacyBytes']['min']),gib(m['nativeBounds']['availableEstimateLegacyBytes']['min'])),('Maximum compression increase',gib(old['nativeBounds']['compressorDeltaBytes']['max']),gib(m['nativeBounds']['compressorDeltaBytes']['max'])),('Maximum compressor occupancy',gib(old['nativeBounds']['compressorOccupancyBytes']['max']),gib(m['nativeBounds']['compressorOccupancyBytes']['max'])),('Pressure','NORMAL → WARN','NORMAL → WARN'),('Swap usage / in-out activity','0 / 0','0 / 0'),('Thermal/power','nominal / AC','nominal / AC'),('Load-start to first WARN',f"{old['loadBeginToFirstWarnSeconds']:.6f} s",f"{m['loadBeginToFirstWarnSeconds']:.6f} s"),('Load progression','Eager evaluation, incomplete','Eager evaluation, incomplete'),('Generated requests','0','0'),('Supervisor/evidence','TERMINATION_PERMISSION_ERROR / PARTIAL','TERMINATION_CONFIRMED / COMPLETE')]
table='\n'.join(f'| {a} | {b} | {d} |' for a,b,d in comparisonrows)
write('CANDIDATE6B_CALIBRATION.md',f'''# Candidate 6B — final one-shot text-only result

**{decision['decision']}**

This conclusion applies to the tested multimodal Candidate 6 and text-only Candidate 6B artifacts, their measured sessions on the current M3/16 GiB Mac, and the bounded 512-total/128-output nonthinking profile. It does **not** establish that Qwen3.5-9B cannot run on every 16 GiB Mac or every future host configuration.

Primary: **MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2**.
Supervisor: **TERMINATION_CONFIRMED**.
Evidence: **COMPLETE**.

## Sequential gates and workload

Stage 1: **MODEL_WORKER_ABORT_QUALIFIED_FOR_TESTED_CONTEXT**. Fifty-four harmless strategy comparisons reproduced the prior TERM→KILL EPERM behavior without changing its historical interpretation. The final corrected immediate-KILL component passed 18 synthetic fault tests and 40 real harmless cases. [Qualification](CANDIDATE6B_WORKER_ABORT_QUALIFICATION.md).

Stage 2: **SELECT_EBUSBY**, `{c.REPO}@{c.REV}`. All three heads/pins freshly verified; only this candidate selected under its new conditional experimental exception. [Review](CANDIDATE6B_ARTIFACT_REVIEW.md).

Stage 3: exact acquired weight SHA-256 **`89c1bfbf2fcc6784910414ba6422e4579a92abac949c6c4db28b2f45bf3d05c9`**; [package manifest](CANDIDATE6B_PACKAGE.md) SHA-256 `{pkg['manifestSHA256']}`. All 927 shapes/dtypes, zero vision/MTP, Git/LFS hashes, runtime, activation and [tokenizer gates](CANDIDATE6B_TOKENIZER_PREFLIGHT.md) passed. New finite worker ceiling **6.75 GiB**; [derivation](CANDIDATE6B_RESOURCE_PLAN.md).

Actual workload: **one model-load attempt, zero completed loads, zero generation requests, zero cooperative unloads, no retry**. No unselected weight artifact or Gemma was acquired. No full 16-case quality session or Sprint 3B occurred.

After verification processes exited, natural settling lasted {m['naturalSettlingSeconds']:.3f} seconds. Fresh baseline headroom was {gib(m['baseline']['availableEstimateLegacyBytes'])}, NORMAL pressure, swap zero, thermal nominal and AC. Only the unmeasured working-allowance admission was bypassed; no hard guard was relaxed.

## Actual progression and comparison

The same-worker loopback control was **DENIED (EPERM)** before load. Built-in `mlx_lm.models.qwen3_5` instantiated text-only modules; no vision tower/merger/image/video processor, remote code, external provider, Foundation Models backend, tools or fallback was invoked. Apple Intelligence/PCC were not used by the application. Runtime and loader source were unchanged; metadata/allocator observers and fail-closed guards wrapped the existing load without changing model computation.

The loader opened one shard containing **927 language entries and zero vision entries**, compared with 1,260 total opened entries in Candidate 6. All 927 bound language parameters retained expected types/shapes, including 250 packed U32 arrays. Logical bound language bytes were **5,038,041,600** in both runs. Eager-evaluation floating arguments totaled **561,670,656 bytes**; no unexpected full BF16 language expansion was observed. Neither run completed eager evaluation, compute casting, cache population or MODEL_LOADED.

| Measurement | Candidate 6 multimodal (historical) | Candidate 6B text-only |
|---|---:|---:|
{table}

The separately published derivative removes **912,058,397 weight-file bytes** ({gib(912058397)}) and has zero vision header entries. It did **not** achieve a safe completed load in this session. Observed smaller partial worker/MLX peaks are not proof of a causal memory saving: load stopped before completion, publisher conversions differ, host baseline/OS behavior/timing differ, and the abort strategy changed. Historical physical vision residency was never isolated. Do not equate file size or logical tensor bytes with physical RAM.

The actual stop was **pressure WARN**, independent of headroom and footprint ceilings. Headroom remained above 2.25 GiB; footprint remained below 6.75 GiB. Compression increased but remained diagnostic. Swap-used growth and swap-in/out activity were zero; thermal stayed nominal.

## Hard abort and recovery

The newly qualified supervisor sent exactly one SIGKILL to owned PID/PGID/SID **{m['signal']['targetPID']}**, with no TERM and no cooperative grace. KILL succeeded; the worker reaped **-9** and its group was absent. No EPERM or supervisor error occurred in this run. The helper used its unchanged qualified cleanup, and all four monitoring/control threads joined.

- First WARN sample → KILL syscall start: **{m['firstWarnToKILLSeconds']*1000:.3f} ms**.
- Abort request → KILL syscall start: **{m['abortRequestToKILLSeconds']*1000:.3f} ms**.
- KILL syscall duration: **{m['killSyscallSeconds']*1000:.3f} ms**.
- KILL return → reaped exit observation: **{m['killReturnToReapSeconds']*1000:.3f} ms**.
- KILL return → group absence observation: **{m['killReturnToGroupAbsenceSeconds']*1000:.3f} ms**.

Actual model teardown was slower than the harmless qualification (which observed <=1.893 ms signal-to-reap). That earlier harmless measurement was not a promised GPU/OS teardown bound. The real worker still completed the supervisor's 1-second bounded reap and all cleanup checks. Signal actuation and completed memory release are distinct.

Native telemetry had {m['nativeSampleCount']} samples, median interval {m['nativeIntervalSeconds']['median']:.6f} s, maximum {m['nativeIntervalSeconds']['max']:.6f} s. Maximum host sample age {m['nativeBounds']['sampleAgeSeconds']['max']:.6f} s; maximum reported MLX sample age {m['nativeBounds']['mlxSampleAgeSeconds']['max']:.6f} s. Native pressure subscription and independent watchdog were enabled; WARN was detected via sampled telemetry. MLX observed maximum cache was **5,316 bytes**; sampled RSS peak **{gib(m['nativeBounds']['workerResidentBytes']['max'])}**. Observed maxima can miss transient peaks.

All **12 recovery samples** showed worker/group absence, NORMAL pressure, zero swap and nominal thermal. Recovery headroom ranged **{gib(m['recoveryHeadroom']['min'])}–{gib(m['recoveryHeadroom']['max'])}**. Recovery allocator columns carry the last pretermination worker values and are not fresh live allocator measurements; they were excluded from allocator bounds. No cooperative model unload is claimed after a hard kill, and complete restoration of all host memory categories is not established by this short window.

## Quality, qualification and stop boundary

**Raw response: none.** No generation or partial generated text exists. Sarah, encryption, October 3, deployment, impact uncertainty, professional tone, invented progress/approval and semantic narrowing cannot be evaluated. Tokenizer preparation is not a quality result.

The envelope cannot be called **MEASURED_EXPERIMENTAL** because safe load/generation/unload did not complete. All provenance/deployment/distribution holds remain; qualified tasks NONE. Recommend **not proceeding to the 16-case quality suite on this current profile**. No retry, larger ceiling, weaker pressure guard, loader modification, derivative switch or cloud fallback was attempted.

The historical Candidate 6 failure and PARTIAL supervisor evidence remain unchanged. Its failure is valid; Candidate 6B adds a distinct failed text-only calibration with a successful abort lifecycle. See {link('measurements.json')}, {link('comparison-to-candidate6.json')}, {link('calibration/run-result.json')}, {link('calibration/lifecycle/termination.json')}, {link('calibration/lifecycle/recovery.json')} and {link('decision.json')}.
''')
p=D/'LOCAL_MODEL_COMPARISON.md';assert p.read_bytes()==(E/'comparison-before.md').read_bytes()
with p.open('a') as f:f.write(f'''\n\n## Candidate 6B — published text-only derivative (2026-09-23)

Stage 1 qualified a distinct immediate-KILL model-worker hard-abort path (18 synthetic tests, 40 final harmless cases); historical supervisor/helper files and Candidate 6 failure remain unchanged. Bounded fresh review of exactly Micklavin, ebusby and inferencerlabs selected `ebusby/Qwen3.5-9B-mlx-4Bit@{c.REV}` under a Candidate6B-specific local experimental provenance exception.

The exact verified artifact contains 927 language/zero vision/zero MTP entries and 5,038,162,675 published weight bytes, versus Candidate 6's 5,950,221,072. Native nonthinking tokenizer preflight passed all 16 rendered fixtures; first 114 tokens. Independently derived ceiling 6.75 GiB. One load attempted; WARN pressure stopped eager evaluation before generation. Observed worker peak {gib(m['nativeBounds']['workerPhysicalFootprintBytes']['max'])}, MLX active/peak {gib(m['mlxObservedBounds']['active']['max'])}, minimum headroom {gib(m['nativeBounds']['availableEstimateLegacyBytes']['min'])}, maximum compression increase {gib(m['nativeBounds']['compressorDeltaBytes']['max'])}; zero swap activity, nominal thermal. KILL sent, exit -9/group absent, 12 NORMAL recovery samples. Primary MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2; supervisor TERMINATION_CONFIRMED; evidence COMPLETE.

**QWEN35_9B_NOT_SUPPORTED_FOR_CURRENT_M3_16GIB_EXPERIMENTAL_PROFILE** applies to tested artifacts/host/profile evidence, not every 16 GiB Mac. No successful-load advantage or causal residency reduction established. No generated response, quality qualification, retry, full suite or Sprint 3B. Tokenizer/conversion provenance PENDING; NO_REDISTRIBUTION; qualified tasks NONE. [Full report](CANDIDATE6B_CALIBRATION.md).
''')
print('Candidate6B reports written; comparison appended.')

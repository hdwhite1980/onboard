"""Verify unchanged publisher payload and build local-only experimental package; no AI imports."""
import json,hashlib,math,os,shutil,struct
from pathlib import Path
import common as c

def main():
 api=json.loads((c.RESEARCH/'sources/ebusby__Qwen3.5-9B-mlx-4Bit.api.json').read_text());assert api['sha']==c.REV and api['id']==c.REPO
 assert {r['rfilename'] for r in api['siblings']}==c.FILES
 assert {p.name for p in c.QUARANTINE.iterdir()}==c.FILES
 records=[];fd=c.secure_root(c.QUARANTINE)
 try:
  for row in api['siblings']:
   name=row['rfilename'];assert c.safe_parts(name)==(name,)
   got=c.file_record(fd,name);assert got['bytes']==row['size'],name
   if 'lfs' in row:assert got['sha256']==row['lfs']['sha256'],name
   else:
    raw=(c.QUARANTINE/name).read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['blobId'],name
   got.pop('identity');got.update(gitBlobID=row['blobId'],publisherHash=row.get('lfs',{}).get('sha256',row['blobId']),publisherHashType='LFS_SHA256' if 'lfs' in row else 'GIT_BLOB_SHA1',source=f'https://huggingface.co/{c.REPO}/resolve/{c.REV}/{name}',purpose=('Unchanged publisher text-only packed language tensors' if name in c.SHARDS else 'Tensor-to-shard mapping' if name=='model.safetensors.index.json' else 'Native nonthinking-capable chat template' if name=='chat_template.jinja' else 'Tokenizer vocabulary/configuration; provenance pending' if name in ('tokenizer.json','tokenizer_config.json','vocab.json') else 'Inert processor configuration; never instantiated' if 'processor' in name else 'Exact model/quantization architecture configuration' if name=='config.json' else 'Publisher attribution/model card' if name=='README.md' else 'Publisher Git/LFS metadata'))
   records.append(got);(c.QUARANTINE/name).chmod(0o400)
 finally:os.close(fd)
 from tensor_inventory import verify_headers
 header,detail=verify_headers(c.QUARANTINE,c.SHARDS)
 counts=detail['tensorCounts'];totals=detail['tensorBytes']
 assert sum(r['bytes'] for r in records)==5058247448
 def unique(pairs):
  d={}
  for k,v in pairs:
   assert k not in d,'Duplicate JSON key';d[k]=v
  return d
 cfg=json.loads((c.QUARANTINE/'config.json').read_text());assert cfg['model_type']=='qwen3_5'
 assert cfg['quantization']==cfg['quantization_config']=={'group_size':64,'bits':4,'mode':'affine'}
 for name in c.FILES:
  if name.endswith('.json'):
   data=json.loads((c.QUARANTINE/name).read_text(),object_pairs_hook=unique)
   assert not any(k in data for k in ('auto_map','model_file','custom_pipelines'))
 tok=json.loads((c.QUARANTINE/'tokenizer.json').read_text());official=json.loads((c.ROOT/'docs/sprint3a/evidence/candidate6-research-01/sources/Qwen__Qwen3.5-9B/tokenizer.json').read_text());assert tok['model']['vocab']==official['model']['vocab']
 assert c.sha(c.QUARANTINE/'chat_template.jinja')=='a4aee8afcf2e0711942cf848899be66016f8d14a889ff9ede07bca099c28f715'
 c.save('acquisition.json',{'status':'VERIFIED_QUARANTINE','repository':c.REPO,'revision':c.REV,'files':records,'repositoryBytes':sum(r['bytes'] for r in records),'modelLoads':0})
 c.save('config-validation.json',{'status':'PASS','configSHA256':c.sha(c.QUARANTINE/'config.json'),'tokenizerSHA256':c.sha(c.QUARANTINE/'tokenizer.json'),'allMetadataPublisherIdentitiesVerified':True,'allJSONDuplicateKeysRejected':True,'embeddedVocabMatchesPinnedOfficial':True,'processorFilesPresent':False,'fullVisionRetained':False,'noVisionPayload':True,'noRemoteCodeDeclarations':True})
 c.save('artifact-verification.json',dict(detail,status='PASS',fullVisionPayloadRetained=False,noVisionPayload=True,configTokenizerJSONValidated=True,noModelLoad=True))
 c.save('safetensors-header.json',header)
 notice='''ORGANIZATION-AUTHORED EXPERIMENTAL LIMITATION RECORD — NOT AN UPSTREAM NOTICE
TOKENIZER_PROVENANCE_PENDING
CONVERSION_REPRODUCIBILITY_PENDING
NO_REDISTRIBUTION
LOCAL_ENGINEERING_EVALUATION_ONLY
CANDIDATE6B_EXPERIMENTAL_PROVENANCE_EXCEPTION
Tokenizer provenance AMBIGUOUS; hold ACTIVE. Production, customer, government, CUI/FCI, model catalog and release qualification remain blocked. Qualified tasks NONE.
Publisher: ebusby/Qwen3.5-9B-mlx-4Bit at 76edcb1d8a8472259c91568dc7edfc9711672ebe.
Declared upstream: Qwen/Qwen3.5-9B; research revision c202236235762e1c871ad0ccb60c8ee5ba337b9a is not an attested conversion input revision.
Conversion card reports MLX-LM 0.31.2. Actual conversion command/input revision/tokenizer lineage are not fully attested. No affirmative Meta/Llama inheritance was established. Apache-2.0 declaration does not resolve full tokenizer provenance.
The exact publisher text-only payload is unchanged; no organization-stripped derivative was created. The accompanying upstream LICENSE is retained verbatim. This organization notice does not add or invent an upstream NOTICE.
'''
 extras=c.E/'package-material';extras.mkdir()
 (extras/'EXPERIMENTAL_LIMITATIONS.txt').write_text(notice)
 license=c.ROOT/'docs/sprint3a/evidence/candidate6-research-01/sources/Qwen__Qwen3.5-9B/LICENSE';assert c.sha(license)=='bbedc3fda3305820b977265f01b8619d87570a6739de3a5582c3464840f1e57a'
 shutil.copyfile(license,extras/'UPSTREAM_LICENSE')
 for f in sorted(extras.iterdir()):records.append({'path':'organization/'+f.name,'bytes':f.stat().st_size,'sha256':c.sha(f),'purpose':'Organization limitation notice' if f.name.endswith('.txt') else 'Verbatim upstream Apache-2.0 license; research revision '+c.UPREV})
 manifest={'packageID':'org.experimental.qwen3.5-9b-text.mlx4-g64','lifecycle':'EXPERIMENTAL','qualifiedTasks':[],'provenanceState':'TOKENIZER_PROVENANCE_PENDING','tokenizerProvenance':'AMBIGUOUS','tokenizerProvenanceHold':'ACTIVE','distribution':'PROHIBITED_PENDING_REVIEW','scope':'LOCAL_ENGINEERING_EVALUATION_ONLY','exception':'CANDIDATE6B_EXPERIMENTAL_PROVENANCE_EXCEPTION','repository':c.REPO,'revision':c.REV,'declaredUpstream':c.UPSTREAM,'researchUpstreamRevision':c.UPREV,'actualConversionInputRevision':'UNATTESTED','conversionReproducibility':'CONVERSION_REPRODUCIBILITY_PENDING','redistribution':'NO_REDISTRIBUTION','blocks':['PRODUCTION_BLOCKED','CUSTOMER_BLOCKED','GOVERNMENT_BLOCKED','CUI_FCI_BLOCKED','QUALIFIED_TASKS_NONE'],'files':records}
 raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();ident=hashlib.sha256(raw).hexdigest();store=c.BASE/'.artifacts/store'/ident;store.mkdir(mode=0o700)
 for r in records:
  target=store/r['path'];target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
  src=extras/target.name if r['path'].startswith('organization/') else c.QUARANTINE/r['path']
  shutil.copyfile(src,target);target.chmod(0o400)
 (store/'manifest.json').write_bytes(raw);(store/'manifest.json').chmod(0o400)
 for d in sorted((p for p in store.rglob('*') if p.is_dir()),reverse=True):d.chmod(0o500)
 store.chmod(0o500);verification=c.verify_package(store,ident)
 c.save('package.json',{'manifestSHA256':ident,'store':str(store),'manifest':manifest,'verification':verification})
 print(json.dumps({'status':'PASS','manifestSHA256':ident,'tensorCounts':counts,'tensorBytes':totals}),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as error:
  c.save('artifact-failure.json',{'status':'ARTIFACT_VERIFICATION_FAILED','error':repr(error),'modelLoads':0});raise

"""Single fail-closed package/runtime recheck and private snapshot; never loads a model."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import policy as p
sys.path.insert(0,str(p.B/'candidate6b_calibration'))
import common as c

def main():
    # Exclusive marker prevents retrying an artifact/metadata failure until pass.
    p.save('PREPARATION_STARTED.json',{'pid':os.getpid(),'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    phase='RUNTIME'
    try:
        # Reuse unchanged full runtime verifier; redirect only output, no source changes.
        spec=importlib.util.spec_from_file_location('granite_retained_runtime_verifier',p.B/'candidate4/runtime_identity.py')
        verifier=importlib.util.module_from_spec(spec);spec.loader.exec_module(verifier)
        c.save=lambda name,data:p.save('runtime-reverification.json',data)
        verifier.main()
        phase='ACTIVATION'
        pkg=json.loads((p.PREFLIGHT/'package.json').read_text())
        assert pkg['manifestSHA256']==p.IDENT
        store=Path(pkg['store']);assert store==p.B/'.artifacts/store'/p.IDENT
        source=c.verify_package(store,p.IDENT,pkg['verification']['rootIdentity'])
        snapshot=p.B/'.artifacts/activation'/('candidate6b-'+p.PHASE+'-01');snapshot.mkdir(parents=True,mode=0o700,exist_ok=False)
        for row in pkg['manifest']['files']:
            target=snapshot/row['path'];target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
            shutil.copyfile(store/row['path'],target);target.chmod(0o400)
        shutil.copyfile(store/'manifest.json',snapshot/'manifest.json');(snapshot/'manifest.json').chmod(0o400)
        for directory in sorted((x for x in snapshot.rglob('*') if x.is_dir()),reverse=True):directory.chmod(0o500)
        snapshot.chmod(0o500)
        dest=c.verify_package(snapshot,p.IDENT)
        first=json.loads((p.PREFLIGHT/'future-first-prompt.json').read_text())
        assert c.sha(snapshot/'chat_template.jinja')==first['templateSHA256']
        suite=json.loads((p.E/'frozen-suite.json').read_text())
        assert len(suite['requests'])==p.REQUESTS
        p.save('token-budget.json',{'templateSHA256':first['templateSHA256'],'requests':suite['requests'],'tokenizerSHA256':first['tokenizerSHA256'],'stopSet':first['stopSet'],'maxOutputTokens':128,'maxTotalTokens':512})
        p.save('activation.json',{'snapshot':str(snapshot),'manifestSHA256':p.IDENT,'rootIdentity':dest['rootIdentity'],
          'controls':['Exact allowlist','Content hashes','No-follow descriptors','Regular single-link owned non-executable files','Stable metadata','Pinned root identity','Post-read path identity','Private read-only copy'],
          'residual':'Same UID can still change permissions/parent paths after verification; MLX reopens paths. Not production activation security.'})
        p.save('verification.json',{'status':'PASS','source':source,'snapshot':dest,'modelLoads':0,
            'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    except BaseException as error:
        p.save('preparation-failure.json',{'status':'ARTIFACT_VERIFICATION_FAILED' if phase=='ACTIVATION' else 'RUNTIME_COMPATIBILITY_FAILED',
           'phase':phase,'error':repr(error),'modelLoads':0,'retryAllowed':False})
        raise

if __name__=='__main__':main()

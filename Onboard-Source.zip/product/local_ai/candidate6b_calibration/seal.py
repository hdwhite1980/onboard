"""Preserve all previous evidence and seal Candidate6B; no model execution."""
import json,shutil
from pathlib import Path
import common as c
E=c.E;P=E/'calibration';old=json.loads((E/'historical-before.json').read_text())
for row in old:assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path']
assert (c.ROOT/'docs/sprint3a/LOCAL_MODEL_COMPARISON.md').read_bytes().startswith((E/'comparison-before.md').read_bytes())
# Historical source inventory from before Stage 1 is also protected.
previous=json.loads((c.ROOT/'docs/sprint3a/evidence/candidate6b-worker-abort-01/historical-before.json').read_text())
for row in previous:assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path']
for row in json.loads((P/'tested-source.json').read_text())['files']:assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path']
for row in json.loads((P/'run-manifest.json').read_text())['files']:assert c.sha(P/row['path'])==row['sha256'],row['path']
Q=c.ROOT/'docs/sprint3a/evidence/candidate6b-worker-abort-01/qualification-v2'
for row in json.loads((Q/'tested-source.json').read_text())['files']:assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path']
r=json.loads((P/'run-result.json').read_text());assert r['primary']=='MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2' and r['supervisor']=='TERMINATION_CONFIRMED' and r['evidenceCompleteness']=='COMPLETE'
assert r['workerLaunches']==r['modelLoads']==r['modelLoadCommands']==1 and r['generationRequests']==r['generationBegins']==r['unloadRequests']==0 and r['workerExitCode']==-9 and r['processGroupPresent'] is False
assert not list(P.glob('response-*.json')) and not (E/'quality').exists()
l=json.loads((P/'lifecycle/result.json').read_text());signals=[x for x in l['events'] if x['event']=='SIGNAL'];assert len(signals)==1 and signals[0]['signal']=='SIGKILL' and signals[0]['result']=='SENT' and not l['errors']
recovery=l['recovery']['samples'];assert len(recovery)==12 and all(not x['workerPresent'] and not x['processGroupMembers'] and x['memoryPressure']=='NORMAL' and x['swapUsedBytes']==0 for x in recovery)
cleanup=json.loads((P/'helper-cleanup-and-joins.json').read_text());assert cleanup['clean'] and all(x['completed'] for x in cleanup['joins'])
pkg=json.loads((E/'package.json').read_text());verified=c.verify_package(Path(pkg['store']),pkg['manifestSHA256'],pkg['verification']['rootIdentity'])
reports=['CANDIDATE6B_WORKER_ABORT_QUALIFICATION.md','CANDIDATE6B_ARTIFACT_REVIEW.md','CANDIDATE6B_EXPERIMENT_EXCEPTION.md','CANDIDATE6B_PACKAGE.md','CANDIDATE6B_TOKENIZER_PREFLIGHT.md','CANDIDATE6B_RESOURCE_PLAN.md','CANDIDATE6B_CALIBRATION.md','LOCAL_MODEL_COMPARISON.md']
(E/'reports').mkdir()
for name in reports:shutil.copyfile(c.ROOT/'docs/sprint3a'/name,E/'reports'/name)
(E/'post-run-source').mkdir()
for name in ('analyze.py','report.py','seal.py'):shutil.copyfile(Path(__file__).with_name(name),E/'post-run-source'/name)
c.save('final-verification.json',{'status':'EVIDENCE_PRESERVATION_VERIFIED','decision':'QWEN35_9B_NOT_SUPPORTED_FOR_CURRENT_M3_16GIB_EXPERIMENTAL_PROFILE','primary':r['primary'],'supervisor':r['supervisor'],'evidenceCompleteness':r['evidenceCompleteness'],'historicalEvidenceFilesUnchanged':len(old),'preStage1EvidenceAndSourcesUnchanged':len(previous),'historicalComparisonPrefixUnchanged':True,'frozenSourceAndOriginalRunManifestUnchanged':True,'loadsAttempted':1,'loadsCompleted':0,'generations':0,'cooperativeUnloads':0,'retries':0,'workerExitCode':-9,'workerGroupAbsent':True,'helperCleanupAndJoinsComplete':True,'recoverySamples':12,'packageReverified':verified,'resourceClassification':'NOT_MEASURED_EXPERIMENTAL','qualifiedTasks':[],'provenance':['TOKENIZER_PROVENANCE_PENDING','CONVERSION_REPRODUCIBILITY_PENDING','NO_REDISTRIBUTION'],'unselectedWeightsAcquired':0,'laterPhasesExecuted':[]})
files=[{'path':str(p.relative_to(E)),'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in sorted(E.rglob('*')) if p.is_file() and p.name!='EVIDENCE_MANIFEST.json']
c.save('EVIDENCE_MANIFEST.json',{'files':files,'historicalPreserved':len(old),'originalRunEvidenceCompleteness':'COMPLETE','note':'Self excluded; original one-shot run and separate post-run report/analysis snapshots. Resource failure, not model qualification.'})
print(json.dumps({'status':'SEALED_RESOURCE_FAILURE','files':len(files),'manifestSHA256':c.sha(E/'EVIDENCE_MANIFEST.json'),'historicalFilesUnchanged':len(old),'preStage1FilesUnchanged':len(previous),'decision':'QWEN35_9B_NOT_SUPPORTED_FOR_CURRENT_M3_16GIB_EXPERIMENTAL_PROFILE'}))

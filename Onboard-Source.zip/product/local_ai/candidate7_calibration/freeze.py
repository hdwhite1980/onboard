"""Freeze one authorized generation and all tokenizer-only fixtures before construction."""
import ast,json,shutil,subprocess,sys
from pathlib import Path
import common as c
D=Path(__file__).resolve().parent
assert not (c.E/'calibration/ATTEMPT_STARTED.json').exists()
assert json.loads((c.E/'tokenizer-runtime-check.json').read_text())['status']=='PASS'
suite=json.loads((c.E/'frozen-suite.json').read_text());old=json.loads((c.ROOT/'docs/sprint3a/evidence/candidate2-quality-01/basic-suite.json').read_text())
assert len(suite['requests'])==len(old['requests'])==16
for a,b in zip(suite['requests'],old['requests']):
 for key in ('id','task','messages','maxTotalContext','maxNewTokens','expected','expectedLabel','currentOnly'):assert a.get(key)==b.get(key),(a['id'],key)
 assert a['promptTokens']==len(a['tokenIDs']) and a['promptTokens']+128<=512
for f in D.glob('*.py'):ast.parse(f.read_text())
result=subprocess.run([sys.executable,'-B',str(D/'test_guards.py')],capture_output=True,text=True)
assert result.returncode==0,result.stderr
c.save('adapter-tests.json',{'status':'PASS','pureGuards':26,'exactC2Fixtures':16,'allAdapterSyntax':'PASS','stdout':result.stdout,'stderr':result.stderr,'modelLoads':0})
protocol={'frozenBeforeGeneration':True,'tokenizerOnlyFixtures':16,'executedRequestsAuthorized':1,'fixtureID':'professional-1','profile':{'total':512,'maxOutput':128,'batch':1,'prefill':128,'sampling':'greedy argmax','enableThinking':False,'tools':[],'fallback':[]},'semanticCriteria':['Sarah preserved','encryption issue preserved','October 3 preserved','deployment preserved','uncertainty about impact preserved','materially professional tone','no invented progress','no invented approval state','no meaning mutation','no narrowing from impact to blocking','no invented facts'],'future16CaseSuiteAuthorized':False,'futureGateOnly':'>=4 of 7 capabilities pass BOTH fixtures, with writing or summarization complete; fact cases separate','stopAfterSingleRequest':True,'retryAllowed':False}
c.save('prospective-protocol.json',protocol)
folder=c.E/'calibration';folder.mkdir();subset=dict(suite);subset['requests']=suite['requests'][:1]
with (folder/'frozen-suite.json').open('x') as f:json.dump(subset,f,indent=2);f.write('\n')
shutil.copyfile(c.E/'prospective-protocol.json',folder/'prospective-protocol.json')
sources=list(D.glob('*.py'))+[c.ROOT/'docs/sprint3a/evidence/candidate7-research-01/static-analysis.json',c.RESEARCH/'sources/mlx-community__gemma-4-e4b-it-4bit/config.json',c.E/'prompt-freeze.json',c.BASE/'resource_harness_v2/supervisor.py',c.BASE/'monitor_lifecycle_v3/lifecycle.py',c.BASE/'candidate4_policy_v2/resource-probe',c.BASE/'worker_abort_v4/worker_lifecycle.py',c.BASE/'worker_abort_v4/common.py',c.E/'resource-hypothesis.json',c.E/'owner-authorization.txt',c.E/'future-first-prompt.json',c.E/'tokenizer-runtime-check.json',folder/'frozen-suite.json',folder/'prospective-protocol.json']
rows=[]
for source in sorted(sources):
 relative=source.relative_to(c.ROOT);target=folder/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
 rows.append({'path':str(relative),'sha256':c.sha(source)})
with (folder/'tested-source.json').open('x') as f:json.dump({'files':rows,'beforeAnyModelLoad':True},f,indent=2);f.write('\n')
print('FROZEN: 16 exact C2 tokenizer cases; one generation only; 26 pure guards passed.')

"""Seal the failed one-shot experiment, preserving historical evidence and frozen source."""
import json,shutil,datetime
from pathlib import Path
import common as c
P=c.E/'calibration';L=c.RESEARCH
baseline=json.loads((L/'historical-baseline.json').read_text());changed=[]
for rel,digest in baseline.items():
 if rel=='docs/sprint3a/LOCAL_MODEL_COMPARISON.md':
  old=(c.E/'comparison-before.md').read_bytes();assert c.sha(c.E/'comparison-before.md')==digest
  assert (c.ROOT/rel).read_bytes().startswith(old)
 elif not (c.ROOT/rel).is_file() or c.sha(c.ROOT/rel)!=digest:changed.append(rel)
assert not changed,changed
for row in json.loads((P/'tested-source.json').read_text())['files']:assert c.sha(c.ROOT/row['path'])==row['sha256'],row['path']
for row in json.loads((P/'run-manifest.json').read_text())['files']:assert c.sha(P/row['path'])==row['sha256'],row['path']
rt=json.loads((c.ROOT/'docs/sprint3a/evidence/candidate7-research-01/retained-runtime-source-record.json').read_text())
for row in rt:assert c.sha(Path(row['source']))==row['sha256'],row['source']
r=json.loads((P/'run-result.json').read_text());assert r['primary']=='MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2' and r['supervisor']=='TERMINATION_CONFIRMED' and r['evidenceCompleteness']=='COMPLETE'
assert r['workerLaunches']==r['modelLoads']==r['modelLoadCommands']==1 and r['generationRequests']==r['generationBegins']==r['unloadRequests']==0 and r['workerExitCode']==-9 and r['processGroupPresent'] is False
assert not list(P.glob('response-*.json')) and not (c.E/'quality').exists()
l=json.loads((P/'lifecycle/result.json').read_text());signals=[x for x in l['events'] if x['event']=='SIGNAL'];assert len(signals)==1 and signals[0]['signal']=='SIGKILL' and signals[0]['result']=='SENT' and not l['errors']
recovery=l['recovery']['samples'];assert len(recovery)==12 and all(not x['workerPresent'] and not x['processGroupMembers'] and x['memoryPressure']=='NORMAL' and x['swapUsedBytes']==0 for x in recovery)
cleanup=json.loads((P/'helper-cleanup-and-joins.json').read_text());assert cleanup['clean'] and all(x['completed'] for x in cleanup['joins'])
pkg=json.loads((c.E/'package.json').read_text());verified=c.verify_package(Path(pkg['store']),pkg['manifestSHA256'],pkg['verification']['rootIdentity'])
activation=json.loads((P/'activation.json').read_text());av=c.verify_package(Path(activation['snapshot']),pkg['manifestSHA256'],activation['rootIdentity'])
reports=['CANDIDATE7_LICENSE_RESOLUTION.md','CANDIDATE7_EXPERIMENT_EXCEPTION.md','CANDIDATE7_PACKAGE.md','CANDIDATE7_TOKENIZER_PREFLIGHT.md','CANDIDATE7_CALIBRATION.md','CANDIDATE7_16GB_DECISION.md','LOCAL_MODEL_COMPARISON.md']
(c.E/'reports').mkdir()
for name in reports:shutil.copyfile(c.ROOT/'docs/sprint3a'/name,c.E/'reports'/name)
(c.E/'post-run-source').mkdir()
for name in ('analyze.py','report.py','seal.py','preflight_report.py'):shutil.copyfile(Path(__file__).with_name(name),c.E/'post-run-source'/name)
(L/'source-code').mkdir()
for name in ('license_research.py','license_history.py','license_decision.py'):shutil.copyfile(Path(__file__).with_name(name),L/'source-code'/name)
licfiles=[{'path':str(p.relative_to(L)),'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in sorted(L.rglob('*')) if p.is_file()]
with (L/'EVIDENCE_MANIFEST.json').open('x') as f:json.dump({'files':licfiles,'classification':'LICENSE_ACCEPTABLE_WITH_OWNER_EXPERIMENT_EXCEPTION','selfExcluded':True},f,indent=2)
c.save('final-verification.json',{'status':'EVIDENCE_PRESERVATION_VERIFIED','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'CANDIDATE7_RESOURCE_CALIBRATION_FAILED','primary':r['primary'],'supervisor':r['supervisor'],'evidenceCompleteness':r['evidenceCompleteness'],'historicalEvidenceFilesUnchanged':len(baseline)-1,'historicalComparisonPrefixUnchanged':True,'historicalBaselineEntries':len(baseline),'retainedRuntimeSourceAndMetadataHashesUnchanged':len(rt),'frozenSourceAndOriginalRunManifestUnchanged':True,'loadsAttempted':1,'loadsCompleted':0,'generations':0,'cooperativeUnloads':0,'retries':0,'workerExitCode':-9,'workerGroupAbsent':True,'helperCleanupAndJoinsComplete':True,'recoverySamples':12,'packageReverified':verified,'activationReverified':av,'resourceClassification':'NOT_MEASURED_EXPERIMENTAL','qualifiedTasks':[],'licenseClassification':'LICENSE_ACCEPTABLE_WITH_OWNER_EXPERIMENT_EXCEPTION','exception':'CANDIDATE7_EXPERIMENTAL_LICENSE_EXCEPTION','licenseEvidenceManifestSHA256':c.sha(L/'EVIDENCE_MANIFEST.json'),'unselectedWeightsAcquired':0,'laterPhasesExecuted':[]})
files=[{'path':str(p.relative_to(c.E)),'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in sorted(c.E.rglob('*')) if p.is_file() and p.name!='EVIDENCE_MANIFEST.json']
c.save('EVIDENCE_MANIFEST.json',{'files':files,'historicalBaselineEntriesPreserved':len(baseline),'originalRunEvidenceCompleteness':'COMPLETE','licenseEvidenceManifestSHA256':c.sha(L/'EVIDENCE_MANIFEST.json'),'note':'Self excluded. Exact original run and separate post-run reports/sources. Failed resource experiment, no model/task qualification.'})
print(json.dumps({'status':'SEALED_RESOURCE_FAILURE','files':len(files),'licenseFiles':len(licfiles),'manifestSHA256':c.sha(c.E/'EVIDENCE_MANIFEST.json'),'licenseManifestSHA256':c.sha(L/'EVIDENCE_MANIFEST.json'),'historicalEntriesPreserved':len(baseline),'decision':'CANDIDATE7_RESOURCE_CALIBRATION_FAILED'}))

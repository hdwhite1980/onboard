"""Post-run factual report; no inference or source changes."""
import json,shutil
from pathlib import Path
import common as c
D=c.ROOT/'docs/sprint3a';m=json.loads((c.E/'measurements.json').read_text());p=c.E/'calibration';r=m['result'];g=1024**3;b=m['nativeBounds'];a=m['mlxObservedBounds'];binding=m['binding'];pkg=json.loads((c.E/'package.json').read_text())
assert r['primary']=='MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2'
metrics=[('Baseline legacy headroom',m['baseline']['availableEstimateLegacyBytes']),('Minimum legacy headroom',b['availableEstimateLegacyBytes']['min']),('Maximum sampled worker physical footprint',b['workerPhysicalFootprintBytes']['max']),('Maximum sampled worker RSS',b['workerResidentBytes']['max']),('Maximum observed MLX active',a['active']['max']),('Maximum observed MLX peak',a['peak']['max']),('Maximum observed MLX cache',a['cache']['max']),('Baseline compressor occupancy',m['baseline']['compressorOccupancyBytes']),('Maximum compressor occupancy',b['compressorOccupancyBytes']['max']),('Maximum compressor delta',b['compressorDeltaBytes']['max']),('Maximum swap used',b['swapUsedBytes']['max']),('Minimum recovery headroom',m['recoveryHeadroom']['min']),('Maximum recovery headroom',m['recoveryHeadroom']['max'])]
table='\n'.join(f'| {name} | {value:,} | {value/g:.9f} |' for name,value in metrics)
text=f'''# Candidate 7 bounded calibration

**CANDIDATE7_RESOURCE_CALIBRATION_FAILED**. Primary `MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2`; supervisor `TERMINATION_CONFIRMED`; evidence **COMPLETE**. One load attempt, zero completed loads, zero generation requests, zero cooperative unloads, zero retries. Stopped September 24, 2026 at 10:39:15 UTC on native **pressure WARN** during eager weight evaluation, before `MODEL_LOADED`.

License: **LICENSE_ACCEPTABLE_WITH_OWNER_EXPERIMENT_EXCEPTION** under `CANDIDATE7_EXPERIMENTAL_LICENSE_EXCEPTION`, not final legal clearance. Exact artifact `mlx-community/gemma-4-e4b-it-4bit@475b9088d29754a3379866cf5aeb6b41acd313c2`. Package manifest SHA-256 `{pkg['manifestSHA256']}`. Local weight SHA-256 `932b8271fc3fe65adcc78b96c10c6268bbfb13e8f67d1358727c0d6ee97e1eff`. Verification/provenance/preflight documented separately; no identity mismatch or runtime change.

The package and runtime verification process exited successfully. Natural settling lasted **{m['naturalSettlingSeconds']:.6f} seconds**, with no cache purge, VM change, security-software action, synthetic pressure or automatic app closure. Fresh baseline: pressure NORMAL, zero swap, thermal nominal, AC power, **{m['baseline']['availableEstimateLegacyBytes']/g:.6f} GiB** legacy headroom. This did not meet the unmeasured >9.25 GiB planning rule. Only that planning rule was bypassed under the explicit owner exception; every hard Policy V2 stop remained unchanged.

Frozen profile: batch1, total512 including max128 output, native unchanged nonthinking template, greedy argmax, prefill128, tools/fallback none. Exact original Candidate2 `professional-1`: **107 prompt tokens**; exact rendered text/IDs/hash matched again inside the worker before construction. No quality-fixture generation occurred.

Same-worker network negative control returned **DENIED / EPERM**, before runtime initialization/load. Seatbelt denied network; Hub resolution forbidden; local files only / no remote code. Apple Intelligence and PCC were not used by the application. Apple Foundation Models backend disabled/unregistered/not invoked; loaded-image/provider-module checks passed at startup/runtime readiness. No external, government or commercial AI; no fallback or tools. This is application-boundary evidence, not a claim about unrelated OS services.

Actual progression:

1. Retained runtime initialized and Metal available; activation files and first prompt reverified.
2. `mx.load` opened the sole complete weight file and returned **2,770 tensor arrays**. At that event MLX active/peak were **8 bytes**. These lazy arrays included **947,698,048 logical multimodal bytes**; aggregate counters do not establish physical residency or page/map attribution.
3. Native `mlx_lm.models.gemma4` text model constructed; recorded module inventory contains no audio/vision encoders or processors.
4. Native sanitization filtered **1,415** nonlanguage entries, retaining all **1,355** expected language entries. Published artifact remained unchanged.
5. Strict weight binding verified **4,198,750,292 logical language bytes**, with 345 packed U32 tensors and native BF16 side/norm tensors. This is bound storage metadata, not proof all bytes were resident. PLE stayed packed: U32 weight `[262144,1344]` **1,409,286,144 bytes**, BF16 scales/biases `[262144,168]` **88,080,384 bytes each**; total **1,585,446,912 bytes**. Attention bindings including q/k norms: **330,340,864 bytes**; 18 shared tail layers have no independent K/V bindings. No full-table/full-model dequantization was observed before abort.
6. Eager evaluation began with 1,355 array arguments and **467,523,668 floating argument bytes**. It did not complete. No cache construction, PLE lookup, prefill, generation or cooperative unload was reached.
7. First WARN sample occurred **{m['loadBeginToFirstWarnSeconds']:.6f} seconds** after `load_begin`. The warning was the hard stop; compression growth was diagnostic only. Worker footprint remained below7GiB and headroom above2.25GiB, but neither overrides pressure.

| Measurement | Bytes | GiB |
|---|---:|---:|
{table}

Observed peaks are sampled lower bounds on instantaneous peaks, not a completed-load requirement or steady-state model size. RSS differs from task physical footprint. Compression belongs to the host, not uniquely the worker. Maximum observed positive compressor growth was **{b['compressorGrowthBytesPerSecond']['max']/g:.6f} GiB/s** over a sampling interval. Initial swap, growth and cumulative swap-in/out deltas all **zero**. Thermal **nominal** throughout measured load/recovery; AC power. Pressure states NORMAL and WARN; no CRITICAL recorded.

Telemetry: {m['nativeSampleCount']} native samples; load target100ms, median interval **{m['nativeIntervalSeconds']['median']:.6f}s**, max **{m['nativeIntervalSeconds']['max']:.6f}s**. Maximum host sample age **{b['sampleAgeSeconds']['max']:.6f}s**; maximum MLX sample age **{b['mlxSampleAgeSeconds']['max']:.6f}s**, below1.5s. Native pressure-event subscription was enabled and readiness recorded; this abort arose from a native polled WARN sample. No separate pressure notification was recorded before the abort. Independent50ms watchdog and qualified worker/helper lifecycles were active. Generation target250ms was not reached.

Qualified hard termination: worker PID=PGID=SID **{m['signal']['targetPID']}**, one **SIGKILL** sent, zero cooperative grace, no SIGTERM to model worker. Abort-request→KILL syscall **{m['abortRequestToKILLSeconds']*1000:.3f}ms**; WARN sample timestamp→KILL **{m['firstWarnToKILLSeconds']*1000:.3f}ms**. Exit **-9**, reaped **{m['killReturnToReapSeconds']:.6f}s** after kill return; group absence confirmed at **{m['killReturnToGroupAbsenceSeconds']:.6f}s**. Separate helper used its qualified SIGTERM/100ms observation lifecycle, exit-15, group absent. All four supervisory threads joined cleanly; no lifecycle errors.

Recovery: **12 samples**, target250ms (median **{m['recoveryIntervalSeconds']['median']:.6f}s**). All show worker/group absent, pressure NORMAL, swap0, nominal thermal. Headroom recovered to **{m['recoveryHeadroom']['min']/g:.6f}–{m['recoveryHeadroom']['max']/g:.6f} GiB**. Recovery rows carry the final pretermination MLX numbers as stale last-known values; they are not live recovery allocator measurements and are excluded from allocator summaries. Recovery is OS reclamation after KILL, not a successful cooperative unload.

Raw response: **NONE**. Semantic assessment: **NOT EVALUATED**. Sarah, encryption, October3, deployment, uncertainty, tone and hallucination criteria remain untested. No passing capability or model quality claim follows from this result.

**MEASURED_EXPERIMENTAL is not supported**: safe complete load/generation/unload/recovery did not occur. No qualified tasks. Do not authorize/run the frozen quality suite on this unchanged host/profile based on this evidence. No retry, ceiling increase, guard weakening, alternate artifact/runtime, automatic app closure, cloud fallback or Sprint3B. The current16GiB product-tier recommendation is in `CANDIDATE7_16GB_DECISION.md`.

Raw evidence: `evidence/candidate7-calibration-01/calibration/` contains source/protocol freeze, worker events, resource samples, pressure subscription, package/runtime reverification, lifecycles, recovery, original run manifest. `measurements.json` records derived metrics; final seal verifies original run and historical preservation independently. Evidence completeness means the bounded failed experiment was captured; it does not mean every planned stage executed.
'''
with (D/'CANDIDATE7_CALIBRATION.md').open('x') as o:o.write(text)
text='''# Candidate 7 current 16 GiB architecture decision

**CANDIDATE7_RESOURCE_CALIBRATION_FAILED**.

Recommend **STOP SEARCHING FOR A UNIVERSAL PRIMARY LOCAL MODEL FOR THE CURRENT 16 GiB BASELINE**, unless materially new evidence or a materially different model architecture emerges.

The exact Gemma4 E4B affine4/group64 package passed identity, header, runtime and tokenizer preflight, but native pressure reached WARN during eager loading under unchanged PolicyV2. One load was attempted; no safe completed load or generation occurred. The 7GiB worker ceiling was not reached; raising it would not address the observed pressure stop. Compression remained diagnostic, and zero swap/nominal thermal did not override pressure.

This adds a distinct architecture's measured resource failure to the earlier Candidate6/6B Qwen9B load failures and prior candidate quality/resource constraints. It is sufficient for an engineering product-tier decision for this current M3/16GiB baseline; it is not proof that no useful local model exists, that every16GiB Mac behaves identically, or that this Gemma model lacks quality. Baseline processes, memory history, conversion/runtime and hard policy are part of the tested context. No successful comparison or causal per-modality memory saving was measured.

Recommended16GiB tier: local utility AI plus deterministic retrieval/fact processing, capability-specific classification/extraction/label assistance, privacy/PII/policy enforcement, and policy-controlled approved escalation. Each AI task still requires its own resource/quality/security qualification; Candidate7 qualifies none. Escalation is an architectural proposal, never automatic permission to send protected content. Data classification, tenant/customer policy and the approved destination's eligibility must gate it; when none is allowed, remain local/deterministic or decline the AI step.

Recommended higher-memory tier: separately validate a stronger full local assistant for writing, summarization, meeting preparation and larger grounded retrieval/synthesis. Do not infer a specific RAM threshold or successful deployment from this failed16GiB run. Size that tier from measured complete workloads and sustained tests.

This preserves the product objective: Calendar→Graph→relevant mail/docs/Teams→grounded retrieval→classification→policy→eligible local AI→approved government AI only if necessary and permitted→personalized briefing. Retrieval and policy retain value independently of a universal on-device generative model.

No MEASURED_EXPERIMENTAL promotion, no qualified tasks, no redistribution, no production/customer/government/CUI/FCI use. Do not run the frozen16-case suite on the unchanged failed profile. If materially new evidence later enables a safely completed calibration, quality testing needs separate owner authorization; its existing gate remains at least4 of7 capabilities passing both fixtures, with a complete writing or summarization capability. No such suite or Sprint3B was started here.

The owner's single attempt is consumed. Preserve this evidence and stop.
'''
with (D/'CANDIDATE7_16GB_DECISION.md').open('x') as o:o.write(text)
comparison=D/'LOCAL_MODEL_COMPARISON.md';shutil.copyfile(comparison,c.E/'comparison-before.md')
with comparison.open('a') as o:o.write(f'''\n\n## Candidate 7 — measured bounded result (2026-09-24)\n\nExact `mlx-community/gemma-4-e4b-it-4bit@475b9088d29754a3379866cf5aeb6b41acd313c2`: **CANDIDATE7_RESOURCE_CALIBRATION_FAILED**. Complete artifact SHA/size and 2,770 shapes/dtypes verified. Native tokenizer-only preflight passed16 unchanged C2 fixtures; first107 tokens, max283 including output. No quality generations.\n\nOne load attempt reached text construction, native removal of1,415 nonlanguage bindings, strict1,355-entry language binding (4,198,750,292 logical bytes; PLE1,585,446,912 packed bytes), then pressureWARN in eager evaluation at{m['loadBeginToFirstWarnSeconds']:.6f}s. No completed load/generation/unload. Full file opened; per-modality physical residency not isolated. No full-precision expansion observed before abort.\n\nBaseline headroom{m['baseline']['availableEstimateLegacyBytes']/g:.6f}GiB; min{b['availableEstimateLegacyBytes']['min']/g:.6f}GiB; sampled physical footprint peak{b['workerPhysicalFootprintBytes']['max']/g:.6f}GiB; observed MLX active/peak{a['active']['max']/g:.6f}GiB; compressor delta max{b['compressorDeltaBytes']['max']/g:.6f}GiB diagnostic; swap0/no activity; nominal thermal. ImmediateKILL exit-9, reaped, group absent, helper/joins clean,12NORMAL recovery samples. SupervisorTERMINATION_CONFIRMED/evidenceCOMPLETE. Peaks do not establish completed-load RAM. MEASURED_EXPERIMENTAL unsupported; qualified tasksNONE. No retry or suite. See `CANDIDATE7_CALIBRATION.md`; separate recommendation in `CANDIDATE7_16GB_DECISION.md`.\n''')
print('Calibration/decision reports and append-only comparison written')

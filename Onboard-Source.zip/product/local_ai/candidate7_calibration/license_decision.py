"""Persist evidence-based owner experiment exception before acquiring any weights."""
import json,hashlib,datetime,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[3];E=R/'docs/sprint3a/evidence/candidate7-license-resolution-01';S=E/'sources';D=R/'docs/sprint3a'
rev='475b9088d29754a3379866cf5aeb6b41acd313c2';src='fee6332c1abaafb77f6f9624236c63aa2f1d0187'
rows=[]
for repo in ['google/gemma-4-E4B-it','mlx-community/gemma-4-e4b-it-4bit']:
 key=repo.replace('/','__')
 for c in json.loads((S/(key+'.history.json')).read_text()):
  p=S/'history'/key/(c['id']+'.md');raw=p.read_text() if p.exists() else None
  rows.append(dict(repository=repo,revision=c['id'],date=c['date'],title=c['title'],license=('apache-2.0' if 'license: apache-2.0' in raw else 'gemma' if 'license: gemma' in raw else 'NO_DECLARATION') if raw else 'README_ABSENT_HTTP404',sha256=hashlib.sha256(p.read_bytes()).hexdigest() if raw else None))
assert sum(r['license']=='apache-2.0' for r in rows if r['repository'].startswith('google/'))==12
assert [r['license'] for r in rows if r['revision']==rev]==['gemma']
for key in ['google__gemma-4-E4B-it','mlx-community__gemma-4-e4b-it-4bit']:
 a=json.loads((S/(key+'.pinned.json')).read_text()); assert not any(r['rfilename'].upper().startswith(('LICENSE','NOTICE')) for r in a['siblings'])
authority=Path('/Users/donwhite/.codex/attachments/9c6e0c27-05b4-4856-b34f-83d6952c9cbd/Pasted text.txt')
shutil.copyfile(authority,E/'owner-authorization.txt')
decision={'classification':'LICENSE_ACCEPTABLE_WITH_OWNER_EXPERIMENT_EXCEPTION','exception':'CANDIDATE7_EXPERIMENTAL_LICENSE_EXCEPTION','scope':['LOCAL_ENGINEERING_EVALUATION_ONLY','NO_REDISTRIBUTION','PRODUCTION_BLOCKED','CUSTOMER_BLOCKED','GOVERNMENT_BLOCKED','CUI_FCI_BLOCKED','QUALIFIED_TASKS_NONE','LICENSE_REVIEW_PENDING'],'upstreamGrant':'Apache-2.0 from initial release through declared conversion input and current inspected revision','artifactLevelAdditionalTermsFound':False,'ambiguousMetadata':'Exact July 6 re-upload replaced apache-2.0 plus license_link with gemma. No explanation, corresponding terms text, LICENSE or NOTICE supplied. Intent and automatic inheritance unproven.','history':rows,'conversionReproducibility':'CONVERSION_REPRODUCIBILITY_PENDING','tokenizerStatus':'Package grant and unchanged tokenizer identity; tokenizer-only corpus-rights attestation not found. No inference from software license.','weightsAcquiredAtDecision':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (E/'license-decision.json').open('x') as f:json.dump(decision,f,indent=2)
text='''# Candidate 7 license resolution

Classification: **LICENSE_ACCEPTABLE_WITH_OWNER_EXPERIMENT_EXCEPTION**.

The exact selected `mlx-community/gemma-4-e4b-it-4bit` revision `475b9088d29754a3379866cf5aeb6b41acd313c2` declares `license: gemma`. Its card links the official Google model and names conversion input `fee6332c1abaafb77f6f9624236c63aa2f1d0187`, but supplies no license link, additional terms, LICENSE or NOTICE. Both exact repository inventories were inspected. No conversion-specific restrictive text was found. The tag is a real publisher declaration, not something we discard or correct.

Google's earliest visible model commit `292a7e278a400932df35f9fd4b1501edd04133a5` (2026-04-02 10:53:06 UTC), all 12 inspected official commits, the declared June 3 input, and current `ee0ef6023621cff504d758262d4e04895a5af4a2` all declare Apache-2.0 and link Google's Gemma 4 license. Google's April 2 launch likewise identifies Apache-2.0. There is no evidence in this history that Gemma 4 E4B was released under the older Gemma license or subsequently relicensed to Apache.

The conversion initially declared Apache-2.0 and Google's license link at `27a21443a6ba09d04285df04e986398f4e16d0e8` (April 2 17:37:50 UTC), preserving that declaration through `deb1db712068b1c9f83fb1c97f08c1204b9459a1` (May 19). The July 6 01:11:51 UTC re-upload changed the declaration to `gemma` and removed the link while naming the Apache-declared June 3 Google input. It therefore does not predate an observed Apache update. Initial empty conversion commit `b205222c5370251227681cb3bb5c2661efd4e48c` has no README (HTTP 404). No evidence establishes whether the replacement metadata was generated automatically, intentionally relicensed, or mistaken; no claim of stale metadata is made.

Hugging Face documents README metadata as a license declaration/display mechanism. Its `gemma` identifier names Gemma; it does not specify a separate revision of terms within this artifact. Google's currently published older Gemma terms expressly delimit their listed models and direct Gemma 4 to its separate Apache license. The bare conversion tag does not explain how those older terms could apply to this Gemma 4 derivative. The mlx-community organization page and exact conversion commit/tree add no artifact-specific licensing explanation. This is a characterized metadata ambiguity, not final legal clearance. An affirmative incompatible artifact-level term was not found in the inspected material; absence is not proof that no undiscovered claim exists.

Under the owner's explicit conditional exception, the clear upstream grant plus lack of affirmative additional artifact restrictions is sufficient for the single local engineering experiment. The discrepancy remains open for licensing review. Neither Apache redistribution clearance nor production approval is inferred for the derivative.

Tokenizer status is unchanged: Google/Gemini SentencePiece lineage; published tokenizer JSON contains 262,144 vocabulary entries and 514,906 merges. Selected tokenizer SHA-256 `cc8d3a0ce36466ccc1278bf987df5f71db1719b9ca6b4118264f45cb627bfe0f` remains identical to research; selected template SHA-256 `2f1b4d75d067bae3fe44e676721c7f077d243bc007156cb9c2f8b5836613d082` matches the declared Google input, while Google's later template differs. Rights rest on the model package declaration, not tokenizer implementation licensing. No tokenizer-only corpus-rights attestation was found.

Conversion provenance: source revision and `mlx_vlm.convert` from a local checkout are declared. Exact converter revision, runtime versions, command and reproducible build remain unattested: **CONVERSION_REPRODUCIBILITY_PENDING**. No repository instructions or executable payload have been executed.

Sources: [official selected input](https://huggingface.co/google/gemma-4-E4B-it/blob/fee6332c1abaafb77f6f9624236c63aa2f1d0187/README.md), [exact conversion](https://huggingface.co/mlx-community/gemma-4-e4b-it-4bit/blob/475b9088d29754a3379866cf5aeb6b41acd313c2/README.md), [conversion history](https://huggingface.co/mlx-community/gemma-4-e4b-it-4bit/commits/475b9088d29754a3379866cf5aeb6b41acd313c2), [Google launch](https://blog.google/innovation-and-ai/technology/developers-tools/gemma-4/), [Gemma terms](https://ai.google.dev/gemma/terms), [Gemma 4 Apache license](https://ai.google.dev/gemma/apache_2), [Hub licensing semantics](https://huggingface.co/docs/hub/repositories-licenses).

Fresh local evidence: `evidence/candidate7-license-resolution-01/`: exact metadata verified against Git/LFS, dated history/cards, full license/legal pages, retrieval failures retained, owner authorization and `license-decision.json`. The attempted raw Hub license-identifiers source returned HTTP404; the published Hub license documentation was available. This decision was persisted before weight acquisition.
'''
with (D/'CANDIDATE7_LICENSE_RESOLUTION.md').open('x') as f:f.write(text)
with (D/'CANDIDATE7_EXPERIMENT_EXCEPTION.md').open('x') as f:f.write('# Candidate 7 owner experiment exception\n\n**CANDIDATE7_EXPERIMENTAL_LICENSE_EXCEPTION** applies only to exact revision `'+rev+'`, local acquisition/package verification, tokenizer/config testing and at most one bounded local calibration.\n\n'+ '\n'.join('- '+s for s in decision['scope'])+'\n\nNo redistribution, customer demonstration, government use, CUI/FCI processing, qualification, release or subsequent quality-suite execution is authorized. No final legal clearance. The exception does not clear conversion reproducibility or tokenizer-only corpus-rights attestation. The authorizing owner attachment is preserved in the license evidence directory.\n')
print(decision['classification'])

"""Finite Gemma4 ceiling recomputed from verified unchanged full artifact. No model imports."""
import json
import common as c
pkg=json.loads((c.E/'package.json').read_text());v=json.loads((c.E/'artifact-verification.json').read_text());assert v['status']=='PASS' and v['languageTensorBytes']==4198750292
G=1024**3;weight=sum(x['bytes'] for x in pkg['manifest']['files'] if x['path'].endswith('.safetensors'));assert weight==5146800534
cache=2*512*2*(20*256+4*512)*4;assert cache==58720256
terms={'verifiedFullPublishedWeightBytes':weight,'runtimeProcess':int(.375*G),'tokenizer':int(.1875*G),'loadTemporaries':int(.375*G),'prefillTemporariesIncludingFP32Logits':int(.5*G),'KV512FP32':cache,'allocatorCache':int(.25*G),'uncertainty':int(.375*G)}
raw=sum(terms.values());assert raw<7*G and raw>6.9*G
c.save('resource-hypothesis.json',{'status':'UNMEASURED_PROFILE','packageManifestSHA256':pkg['manifestSHA256'],'weightFileBytes':weight,'actualLanguageTensorBytes':v['languageTensorBytes'],'multimodalTensorBytes':v['multimodalTensorBytes'],'perLayerEmbeddingPackedBytes':v['perLayerEmbeddingPackedBytes'],'termsBytes':terms,'rawBudgetBytes':raw,'rawBudgetGiB':raw/G,'workerCeilingBytes':7*G,'workerCeilingGiB':7.0,'protectedReserveBytes':2*G,'earlyStopBytes':int(2.25*G),'conservativePlanningHeadroomBytes':int(9.25*G),'ownerBypass':'ONLY unmeasured >9.25 GiB planning allowance; no hard guard bypass','basis':'Full artifact conservatively charged despite text-only binding; 20 local plus 4 global KV caches, BF16 nominal 28MiB/FP32 bound56MiB; finite process/tokenizer/temporary/allocator/uncertainty. Retain proposed 7GiB ceiling. File bytes are not measured RAM.','measuredRAM':False,'scope':{'batch':1,'context':512,'maxOutput':128,'prefill':128,'thinking':False,'requests':1},'warning':'0.25GiB early reserve margin is not a guarantee against bursts; pressure hard stop unchanged.'})
print(json.dumps({'rawBudgetGiB':raw/G,'ceilingGiB':7,'planningGiB':9.25}))

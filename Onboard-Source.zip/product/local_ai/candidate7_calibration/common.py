"""Exact owner-authorized experimental Gemma4 artifact; no AI imports."""
import hashlib,json,os,stat
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'product/local_ai'
E=ROOT/'docs/sprint3a/evidence/candidate7-calibration-01'
RESEARCH=ROOT/'docs/sprint3a/evidence/candidate7-license-resolution-01'
REPO='mlx-community/gemma-4-e4b-it-4bit'
REV='475b9088d29754a3379866cf5aeb6b41acd313c2'
UPSTREAM='google/gemma-4-E4B-it'
UPREV='ee0ef6023621cff504d758262d4e04895a5af4a2'
SHARDS={'model.safetensors':(5146800534,'932b8271fc3fe65adcc78b96c10c6268bbfb13e8f67d1358727c0d6ee97e1eff')}
QUARANTINE=BASE/'.artifacts/quarantine/candidate7-gemma4-e4b-01'
FILES={'.gitattributes','README.md','chat_template.jinja','config.json','model.safetensors','model.safetensors.index.json','tokenizer.json','tokenizer_config.json','generation_config.json','processor_config.json'}

def save(name, data):
    with (E/name).open('x') as f:
        json.dump(data, f, indent=2); f.write('\n')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def ident(st):
    return [st.st_dev, st.st_ino]

def secure_root(path, expected_identity=None):
    path = Path(path).absolute()
    for p in [*reversed(path.parents), path]:
        assert not stat.S_ISLNK(p.lstat().st_mode), 'Symlink ancestor: '+str(p)
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    st = os.fstat(fd)
    try:
        assert st.st_uid == os.getuid(), 'Wrong package owner'
        assert not st.st_mode & 0o022, 'Group/world-writable package root'
        if expected_identity is not None:
            assert ident(st) == expected_identity, 'Package root replaced'
        return fd
    except BaseException:
        os.close(fd); raise

def safe_parts(name):
    p = Path(name)
    assert not p.is_absolute() and name == p.as_posix()
    assert p.parts and all(x not in ['.', '..', ''] for x in p.parts), 'Unsafe member path'
    return p.parts

def file_record(root_fd, name):
    parts = safe_parts(name)
    parent = os.dup(root_fd)
    try:
        for part in parts[:-1]:
            nxt = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent); parent = nxt
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        try:
            before = os.fstat(fd)
            assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'Nonregular or hardlinked member'
            assert before.st_uid == os.getuid() and not before.st_mode & 0o111, 'Wrong owner or executable file'
            h = hashlib.sha256()
            for b in iter(lambda:os.read(fd, 1024*1024), b''): h.update(b)
            after = os.fstat(fd)
            attrs = lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink)
            assert attrs(before) == attrs(after), ('File metadata changed during hashing', name, attrs(before), attrs(after))
            named = os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)
            assert attrs(named) == attrs(after), 'File path replaced during hashing'
            return {'path':name,'bytes':after.st_size,'sha256':h.hexdigest(),'identity':ident(after)}
        finally: os.close(fd)
    finally: os.close(parent)

def verify_package(root, manifest_sha, root_identity=None):
    fd = secure_root(root, root_identity)
    try:
        mr = file_record(fd, 'manifest.json')
        assert mr['sha256'] == manifest_sha, 'Manifest substitution'
        mf = os.open('manifest.json', os.O_RDONLY | os.O_NOFOLLOW, dir_fd=fd)
        with os.fdopen(mf, 'rb') as f:
            raw=f.read()
        assert hashlib.sha256(raw).hexdigest() == manifest_sha
        manifest = json.loads(raw)
        expected = {r['path'] for r in manifest['files']} | {'manifest.json'}
        assert len(expected) == len(manifest['files'])+1
        actual = set()
        for directory, dirs, files, dfd in os.fwalk('.', dir_fd=fd, follow_symlinks=False):
            for n in dirs:
                ds=os.stat(n,dir_fd=dfd,follow_symlinks=False)
                assert stat.S_ISDIR(ds.st_mode) and ds.st_uid==os.getuid() and not ds.st_mode & 0o022
            for n in files:
                actual.add((Path(directory)/n).as_posix())
        assert actual == expected, 'Unexpected/missing package member'
        rows = []
        for r in manifest['files']:
            got = file_record(fd,r['path'])
            assert got['bytes']==r['bytes'] and got['sha256']==r['sha256'], 'Content substitution: '+r['path']
            rows.append(got)
        assert ident(os.stat(root,follow_symlinks=False))==ident(os.fstat(fd)), 'Root replaced during verification'
        return {'manifestSHA256':manifest_sha,'rootIdentity':ident(os.fstat(fd)), 'files':rows}
    finally: os.close(fd)

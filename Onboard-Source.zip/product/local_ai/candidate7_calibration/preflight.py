"""Tokenizer-only offline dynamic preflight. Weight APIs and model construction prohibited."""
import errno,hashlib,json,os,socket,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c

def main():
 assert json.loads((c.E/'runtime-identity.json').read_text())['status']=='PASS'
 assert json.loads((c.E/'artifact-verification.json').read_text())['status']=='PASS'
 package=json.loads((c.E/'package.json').read_text());root=Path(package['store']);c.verify_package(root,package['manifestSHA256'],package['verification']['rootIdentity'])
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',TOKENIZERS_PARALLELISM='false',USE_TORCH='0',USE_TF='0',USE_FLAX='0')
 try:
  with socket.socket() as s:s.settimeout(1);s.connect(('127.0.0.1',9))
 except OSError as e:
  assert e.errno in (errno.EPERM,errno.EACCES),'Network denial missing';denied_errno=e.errno
 else:raise AssertionError('Network boundary failed')
 def forbidden(*a,**kw):raise RuntimeError('WEIGHT_MODEL_DOWNLOAD_PROHIBITED')
 def audit(event,args):
  if event=='open' and isinstance(args[0],(str,bytes)) and str(args[0]).endswith(('.safetensors','.gguf','.bin')):forbidden()
  if event in ('socket.connect','socket.getaddrinfo','socket.sendto','socket.sendmsg','subprocess.Popen','os.system','os.posix_spawn'):forbidden()
 sys.addaudithook(audit)
 import huggingface_hub
 huggingface_hub.snapshot_download=forbidden;huggingface_hub.hf_hub_download=forbidden
 import mlx.core as mx
 mx.load=forbidden
 import mlx_lm,mlx_lm.utils as utils
 mlx_lm.load=forbidden;utils.load=forbidden;utils.load_model=forbidden;utils.snapshot_download=forbidden
 cfg=json.loads((root/'config.json').read_text());model,args=utils._get_classes(cfg)
 assert model.__module__=='mlx_lm.models.gemma4';model.__init__=forbidden
 from mlx_lm.models.gemma4_text import Model as TextModel,ModelArgs as TextModelArgs
 TextModel.__init__=forbidden
 parsed=TextModelArgs.from_dict(cfg['text_config']);assert parsed.num_hidden_layers==42 and not parsed.enable_moe_block
 from mlx_lm.tokenizer_utils import load as load_tokenizer
 from transformers import AutoTokenizer
 from tokenizers import Tokenizer
 tok=AutoTokenizer.from_pretrained(str(root),trust_remote_code=False,local_files_only=True)
 backend=Tokenizer.from_file(str(root/'tokenizer.json'))
 wrapper=load_tokenizer(root,tokenizer_config_extra={'local_files_only':True,'trust_remote_code':False},eos_token_ids=cfg.get('eos_token_id',None))
 assert cfg['text_config']['eos_token_id']==1 and cfg['eos_token_id']==[1,106,50]
 gen=json.loads((root/'generation_config.json').read_text());assert gen['eos_token_id']==[1,106,50]
 assert wrapper.eos_token_ids=={1,106,50} and tok.eos_token_id==1 and tok.pad_token_id==0 and tok.bos_token_id==2
 for token,expected in [('<eos>',1),('<turn|>',106),('<|tool_response>',50)]:assert tok.convert_tokens_to_ids(token)==expected,(token,tok.convert_tokens_to_ids(token))
 template=(root/'chat_template.jinja').read_text();assert tok.chat_template==wrapper.chat_template==template
 special=[]
 for t in json.loads((root/'tokenizer.json').read_text())['added_tokens']:
  assert tok.encode(t['content'],add_special_tokens=False)==[t['id']]
  special.append({'token':t['content'],'id':t['id'],'special':t['special']})
 ordinary=[]
 for text in ['2023','650841823','ISO 9001:2015','October 3','2026-10-03','09/23/2026','$4.7 million','$91,000','82%','0.05%','Version 3.2','v4.1.0','Project Falcon','FALCON-2026-003','DOC-008','EMAIL-999','Sarah owns encryption; Don owns migration.','not approved ≠ rejected','café\nRésumé: naïve','  00123\t42\n']:
  ids=tok.encode(text,add_special_tokens=False)
  assert ids==backend.encode(text,add_special_tokens=False).ids==wrapper.encode(text,add_special_tokens=False)
  assert tok.decode(ids,skip_special_tokens=False)==text
  ordinary.append({'text':text,'ids':ids,'threePathsEqual':True,'roundTrip':True})
 def render(messages):
  kw={'add_generation_prompt':True,'tools':None,'enable_thinking':False}
  prompt=tok.apply_chat_template(messages,tokenize=False,**kw);ids=tok.encode(prompt,add_special_tokens=False)
  assert ids==tok.apply_chat_template(messages,tokenize=True,return_dict=False,**kw)
  assert prompt==wrapper.apply_chat_template(messages,tokenize=False,**kw)
  assert prompt.endswith('<|turn>model\n')
  assert '<|think|>' not in prompt and '<think>' not in prompt
  return prompt,ids
 prompt,ids=render([{'role':'system','content':'Preserve facts.'},{'role':'user','content':'Hello.'}])
 assert prompt=='<bos><|turn>system\nPreserve facts.<turn|>\n<|turn>user\nHello.<turn|>\n<|turn>model\n'
 no_system,_=render([{'role':'user','content':'Hello.'}]);assert no_system.startswith('<bos><|turn>user\n')
 source=c.ROOT/'docs/sprint3a/evidence/candidate2-quality-01/basic-suite.json';original=json.loads(source.read_text())['requests'];assert len(original)==16
 rows=[]
 for row in original:
  r={k:v for k,v in row.items() if k not in ('rawPrompt','tokenIDs','promptTokens','accountedTokens','fits')}
  prompt,ids=render(r['messages']);assert len(ids)+128<=512,'UNSUPPORTED_PROFILE: '+r['id']
  r.update(rawPrompt=prompt,tokenIDs=ids,promptTokens=len(ids),expectedPromptTokens=len(ids),accountedTokens=len(ids)+128,fits=True,inputSHA256=hashlib.sha256(json.dumps(r['messages'],sort_keys=True).encode()).hexdigest())
  rows.append(r)
 metadata={'templateSHA256':c.sha(root/'chat_template.jinja'),'tokenizerSHA256':c.sha(root/'tokenizer.json'),'stopSet':sorted(wrapper.eos_token_ids),'enableThinking':False,'tools':None,'sourceSHA256':c.sha(source)}
 c.save('frozen-suite.json',{'requests':rows,**metadata})
 c.save('future-first-prompt.json',{**rows[0],**metadata,'executed':False})
 result={'status':'PASS','networkNegativeControl':'DENIED','networkErrno':denied_errno,'modelLoads':0,'generations':0,'modelInstantiated':False,'weightAccessBlocked':True,'resolvedClass':model.__module__+'.'+model.__name__,'textArgs':vars(parsed),'tokenizerClass':type(tok).__name__,'ordinaryCases':ordinary,'specialTokens':special,'systemRoleRendering':prompt if False else 'Exact native Gemma BOS/system/user/model strings asserted','noSystemRendering':no_system,'nestedTextEOS':1,'tokenizerEOS':1,'installedLoadBehavior':'Top-level and generation config stop list [1,106,50] passed unchanged; tokenizer token mappings dynamically verified.','fixtureCount':16,'firstPromptTokens':rows[0]['promptTokens'],'maximumPromptTokens':max(r['promptTokens'] for r in rows),'maximumAccountedTokens':max(r['accountedTokens'] for r in rows),**metadata,'mlxActiveBytes':mx.get_active_memory(),'visionModulesConstructed':False,'remoteCode':False,'localFilesOnly':True}
 c.save('tokenizer-runtime-check.json',result);print(json.dumps({k:result[k] for k in ('status','firstPromptTokens','maximumAccountedTokens','stopSet','modelLoads')}))
if __name__=='__main__':
 try:main()
 except BaseException as error:
  c.save('tokenizer-failure.json',{'status':'TOKENIZER_PREFLIGHT_FAILED','error':repr(error),'modelLoads':0});raise

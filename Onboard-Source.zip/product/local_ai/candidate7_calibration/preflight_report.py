"""Report completed acquisition and tokenizer-only checks; never runs a model."""
import json
from pathlib import Path
import common as c
D=c.ROOT/'docs/sprint3a';pkg=json.loads((c.E/'package.json').read_text());a=json.loads((c.E/'artifact-verification.json').read_text());t=json.loads((c.E/'tokenizer-runtime-check.json').read_text());r=json.loads((c.E/'resource-hypothesis.json').read_text());f=json.loads((c.E/'future-first-prompt.json').read_text());pr=json.loads((c.E/'prompt-freeze.json').read_text())
rows='\n'.join(f"| `{x['path']}` | {x['bytes']:,} | `{x['sha256']}` |" for x in pkg['manifest']['files'])
text=f'''# Candidate 7 exact experimental package

Verified exact repository `{c.REPO}` at `{c.REV}`. Complete publisher inventory: 10 files, **5,179,241,512 bytes**, including sole weight file **5,146,800,534 bytes**. Every Git blob/LFS identity and local SHA-256 matched. No artifact identity difference from research. No alternate artifact acquired.

Organization package: `org.experimental.gemma4-e4b-it.mlx4-g64`; **EXPERIMENTAL**, qualified tasks **NONE**, distribution **PROHIBITED_PENDING_REVIEW**. `CANDIDATE7_EXPERIMENTAL_LICENSE_EXCEPTION`; LOCAL_ENGINEERING_EVALUATION_ONLY, NO_REDISTRIBUTION; production/customer/government/CUI/FCI blocked. License review and conversion reproducibility pending.

Manifest SHA-256: `{pkg['manifestSHA256']}`. Immutable store: `{pkg['store']}`. Manifest plus file purposes, publisher hashes, Git IDs and source URLs: `evidence/candidate7-calibration-01/package.json` and `acquisition.json`.

| File | Bytes | Local SHA-256 |
|---|---:|---|
{rows}

All **2,770** safetensors entries match the complete index and independent config/source shape/dtype inventory, with no gaps, overlaps or trailing bytes. Header length 352,186 bytes plus 8-byte length prefix. Tensor data 5,146,448,340 bytes. Dtypes: 347 U32 tensors and 2,423 BF16 tensors, including valid scalar clip limits. Language 1,355 tensors / 4,198,750,292 bytes; multimodal 1,415 tensors / 947,698,048 bytes. Audio tower 609,650,176 bytes, vision tower 334,730,112, audio embedding projection 2,211,840, vision embedding projection 1,105,920. The per-layer embedding (PLE) table is 1,585,446,912 packed bytes, including scales/biases. All text plain quantized matrices are affine4/group64. Clippable audio/vision inner matrices remain BF16; quantization metadata is not treated as a claim that every tensor is 4-bit.

Config, generation config, tokenizer, tokenizer config, native template and processor configuration are publisher-identical. Duplicate JSON keys and remote-code declarations rejected; safe paths, owned regular files, no symlinks/hardlinks/executable payload, exact allowlist and stable file metadata checked. No repository Python. Processor config retained inert. Full published multimodal file retained unchanged; no stripped derivative.

Official model repositories contain no LICENSE/NOTICE file. Organization packaging retains Google's declared-input card and license page, verbatim standard Apache-2.0 text, license resolution and an explicitly organization-authored limitation record. No upstream NOTICE invented. No upstream weights downloaded.

Conversion declares Google input `fee6332c1abaafb77f6f9624236c63aa2f1d0187` and `mlx_vlm.convert` from a local checkout. Exact build, converter/MLX/MLX-LM versions and command remain unattested: **CONVERSION_REPRODUCIBILITY_PENDING**. Current-official configuration differences and research-derived omitted tail-KV parameters are preserved in `conversion-provenance.json`; this is not a reproduced conversion. Tokenizer matches official; template matches declared input, not Google's later revision.

Recomputed resource budget: **{r['rawBudgetGiB']:.12f} GiB**, unchanged **7.0 GiB** worker ceiling. Full published file is conservatively charged, plus runtime, tokenizer, temporaries, worst-case FP32 KV, allocator and uncertainty. No measured RAM claim. Exact terms in `resource-hypothesis.json`; only the unmeasured strictly >9.25 GiB planning admission may be bypassed.
'''
with (D/'CANDIDATE7_PACKAGE.md').open('x') as o:o.write(text)
suite=json.loads((c.E/'frozen-suite.json').read_text());counts='\n'.join(f"| {x['id']} | {x['promptTokens']} | {x['accountedTokens']} |" for x in suite['requests'])
text=f'''# Candidate 7 tokenizer/config preflight

**PASS**. Offline tokenizer/config-only preflight, **zero model constructions, zero generations**. Same-process network negative control DENIED (errno {t['networkErrno']}); weight-open APIs and model constructors blocked. `trust_remote_code=False`, `local_files_only=True`, Hub fallback forbidden. No image/audio/video processor instantiated.

Retained runtime verification passed all 34 installed package inventories and 5,555 wheel files against retained reviewed artifacts. Python 3.12.14 arm64; MLX/MLX-metal 0.32.2; MLX-LM 0.31.3; Transformers 5.17.0; tokenizers 0.23.2. No installation or update. Built-in class `{t['resolvedClass']}` and text arguments resolve without construction. Tokenizer class `{t['tokenizerClass']}`. Runtime compatibility is proven here for configuration/tokenization only; model execution is separately reported.

Native template unchanged, `enable_thinking=False`, no tools, native BOS/system/user/model formatting and generation prefix asserted. Dynamic stop set **{{1, 50, 106}}**: eos, tool-response start, turn end. Config and generation config agree. All added-token IDs checked; 20 ordinary round-trip cases agree across AutoTokenizer, tokenizers backend and MLX wrapper, including numbers/dates/currency/percentages/versions/names/Project Falcon identifiers, Unicode and whitespace.

All 16 original Candidate2 substantive fixtures rendered unchanged; no quality generation. No truncation. Profile: 512 total tokens including at most 128 output; batch1, greedy, prefill128.

| Frozen fixture | Prompt tokens | Prompt + 128 |
|---|---:|---:|
{counts}

First `professional-1`: **107 prompt tokens**, **235 including output allowance**. Maximum across fixtures: **{t['maximumPromptTokens']} prompt / {t['maximumAccountedTokens']} accounted**.

Tokenizer SHA-256 `{t['tokenizerSHA256']}`. Template SHA-256 `{t['templateSHA256']}`. Rendered first-prompt SHA-256 `{pr['renderedPromptSHA256']}`. Token-ID JSON SHA-256 `{pr['tokenIDsJSONSHA256']}`. Exact messages, rendered bytes and all IDs preserved in `future-first-prompt.json`; `prompt-freeze.json` seals identities before construction.

Exact rendered first prompt:

```text
{f['rawPrompt']}```

Provenance remains the Google model-package declaration and observed tokenizer identity; no tokenizer-only corpus-rights attestation. Tokenizer software licensing does not establish vocabulary/training corpus rights. Owner exception remains limited to local engineering.
'''
with (D/'CANDIDATE7_TOKENIZER_PREFLIGHT.md').open('x') as o:o.write(text)
print('Package and tokenizer reports written')

import json
from license_research import E,S,fetch
for repo in ['google/gemma-4-E4B-it','mlx-community/gemma-4-e4b-it-4bit']:
 key=repo.replace('/','__')
 for row in json.loads((S/(key+'.history.json')).read_text()):
  rev=row['id'];fetch(f'https://huggingface.co/{repo}/resolve/{rev}/README.md',f'history/{key}/{rev}.md')
for url,name in [
 ('https://ai.google.dev/gemma/terms','google-terms.html'),
 ('https://ai.google.dev/gemma/apache_2','google-apache2.html'),
 ('https://ai.google.dev/gemma/prohibited_use_policy','google-prohibited.html'),
 ('https://huggingface.co/docs/hub/model-cards','hf-model-cards.html'),
 ('https://huggingface.co/docs/hub/repositories-licenses','hf-license-metadata.html'),
 ('https://huggingface.co/mlx-community','mlx-community.html'),
 ('https://huggingface.co/mlx-community/gemma-4-e4b-it-4bit/tree/475b9088d29754a3379866cf5aeb6b41acd313c2','selected-tree.html'),
 ('https://huggingface.co/mlx-community/gemma-4-e4b-it-4bit/commit/475b9088d29754a3379866cf5aeb6b41acd313c2','selected-commit.html'),
 ('https://blog.google/innovation-and-ai/technology/developers-tools/gemma-4/','google-launch.html'),
 ('https://raw.githubusercontent.com/huggingface/hub-docs/main/js/src/lib/licenses.ts','hf-license-identifiers.txt'),
 ('https://www.apache.org/licenses/LICENSE-2.0.txt','APACHE-2.0.txt')]:fetch(url,name)

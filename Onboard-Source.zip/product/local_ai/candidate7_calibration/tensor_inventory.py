"""Config/source-derived Gemma4 packed text and inert multimodal header inventory."""
import hashlib,json,math,struct
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
def expected_inventory():
 plan=json.loads((ROOT/'docs/sprint3a/evidence/candidate7-research-01/static-analysis.json').read_text())['artifacts'][0]['quantizedTensorPlan']
 out={}
 def add(n,shape,dtype='BF16'):assert n not in out;out[n]={'shape':shape,'dtype':dtype}
 def quant(n,o,i):
  add(n+'.weight',[o,i//8],'U32')
  for suffix in ('scales','biases'):add(n+'.'+suffix,[o,i//64])
 for r in plan:
  if r['bits']==4:assert r['groupSize']==64;quant(r['name'][:-7],*r['expectedShape'])
  else:assert r['bits']==16;add(r['name'],r['expectedShape'])
 return out

def full_inventory():
 out=expected_inventory()
 cfg=json.loads((ROOT/'docs/sprint3a/evidence/candidate7-license-resolution-01/sources/mlx-community__gemma-4-e4b-it-4bit/config.json').read_text())
 def add(n,shape,dtype='BF16'):assert n not in out;out[n]={'shape':shape,'dtype':dtype}
 def clipped(n,o,i):
  add(n+'.linear.weight',[o,i])
  for k in ('input_min','input_max','output_min','output_max'):add(n+'.'+k,[])
 def quant(n,o,i):
  add(n+'.weight',[o,i//8],'U32')
  for k in ('scales','biases'):add(n+'.'+k,[o,i//64])
 a=cfg['audio_config'];h=a['hidden_size'];assert a['use_clipped_linears'] and a['num_hidden_layers']==12
 for i in range(a['num_hidden_layers']):
  b=f'audio_tower.layers.{i}.'
  for ff in ('feed_forward1','feed_forward2'):
   clipped(b+ff+'.ffw_layer_1',h*4,h);clipped(b+ff+'.ffw_layer_2',h,h*4)
   for n in ('pre_layer_norm','post_layer_norm'):add(b+ff+'.'+n+'.weight',[h])
  for n in ('q_proj','k_proj','v_proj','post'):clipped(b+'self_attn.'+n,h,h)
  add(b+'self_attn.relative_k_proj.weight',[h,h]);add(b+'self_attn.per_dim_scale',[h//a['num_attention_heads']])
  clipped(b+'lconv1d.linear_start',h*2,h);clipped(b+'lconv1d.linear_end',h,h)
  add(b+'lconv1d.depthwise_conv1d.weight',[h,a['conv_kernel_size'],1]) # MLX out/kernel/in layout.
  for n in ('lconv1d.pre_layer_norm','lconv1d.conv_norm','norm_pre_attn','norm_post_attn','norm_out'):add(b+n+'.weight',[h])
 ch=a['subsampling_conv_channels'];b='audio_tower.subsample_conv_projection.'
 for i,(inp,o) in enumerate(zip([1,ch[0]],ch)):
  add(b+f'layer{i}.conv.weight',[o,3,3,inp]);add(b+f'layer{i}.norm.weight',[o])
 add(b+'input_proj_linear.weight',[h,(ch[0]//4)*ch[1]])
 add('audio_tower.output_proj.weight',[a['output_proj_dims'],h]);add('audio_tower.output_proj.bias',[a['output_proj_dims']])
 v=cfg['vision_config'];h=v['hidden_size'];d=v['head_dim'];m=v['intermediate_size'];assert v['use_clipped_linears']
 for i in range(v['num_hidden_layers']):
  b=f'vision_tower.encoder.layers.{i}.'
  for n in ('input_layernorm','post_attention_layernorm','pre_feedforward_layernorm','post_feedforward_layernorm'):add(b+n+'.weight',[h])
  for n in ('q_norm','k_norm'):add(b+'self_attn.'+n+'.weight',[d])
  for n in ('q_proj','k_proj','v_proj','o_proj'):clipped(b+'self_attn.'+n,h,h)
  for n,o,inp in [('gate_proj',m,h),('up_proj',m,h),('down_proj',h,m)]:clipped(b+'mlp.'+n,o,inp)
 add('vision_tower.patch_embedder.input_proj.weight',[h,3*v['patch_size']**2]);add('vision_tower.patch_embedder.position_embedding_table',[2,v['position_embedding_size'],h])
 quant('embed_audio.embedding_projection',cfg['text_config']['hidden_size'],a['output_proj_dims']);quant('embed_vision.embedding_projection',cfg['text_config']['hidden_size'],h)
 return out

def unique(pairs):
 d={}
 for k,v in pairs:assert k not in d,'Duplicate JSON key: '+k;d[k]=v
 return d

def verify_headers(root,shards):
 expected=full_inventory();idx=json.loads((root/'model.safetensors.index.json').read_text(),object_pairs_hook=unique)
 assert set(idx['weight_map'])==set(expected) and set(idx['weight_map'].values())==set(shards)
 all_tensors={};details=[];counts={};totals={};dtypes={}
 for filename,(length,sha) in shards.items():
  fpath=root/filename;assert fpath.stat().st_size==length
  with fpath.open('rb') as f:
   size=struct.unpack('<Q',f.read(8))[0];assert 0<size<16*1024**2;raw=f.read(size);header=json.loads(raw,object_pairs_hook=unique)
  tensors={k:v for k,v in header.items() if k!='__metadata__'}
  assert set(tensors)=={k for k,v in idx['weight_map'].items() if v==filename}
  end=0
  for name,t in sorted(tensors.items(),key=lambda kv:kv[1]['data_offsets'][0]):
   assert set(t)=={'dtype','shape','data_offsets'} and all(type(n)is int and n>0 for n in t['shape']),name
   assert {k:t[k] for k in ('shape','dtype')}==expected[name],(name,t,expected[name])
   start,stop=t['data_offsets'];assert type(start)is int and type(stop)is int and start==end and stop>=start
   assert stop-start==math.prod(t['shape'])*{'BF16':2,'F32':4,'U32':4}[t['dtype']]
   kind=name.split('.')[0];counts[kind]=counts.get(kind,0)+1;totals[kind]=totals.get(kind,0)+stop-start;dtypes[t['dtype']]=dtypes.get(t['dtype'],0)+1;end=stop
  assert 8+size+end==length
  all_tensors.update(tensors);details.append({'file':filename,'headerBytes':size,'headerSHA256':hashlib.sha256(raw).hexdigest(),'entries':len(tensors),'tensorBytes':end})
 assert counts=={'audio_tower':751,'embed_audio':3,'embed_vision':3,'language_model':1355,'vision_tower':658}
 assert totals['language_model']==4198750292 and sum(totals.values())==idx['metadata']['total_size']==5146448340
 ple=sum(t['data_offsets'][1]-t['data_offsets'][0] for n,t in all_tensors.items() if 'embed_tokens_per_layer.' in n);assert ple==1585446912
 return all_tensors,{'tensorCounts':counts,'tensorBytes':totals,'dtypes':dtypes,'shards':details,'all2770ShapesAndDtypesMatchConfigSourceInventory':True,'languageTensorBytes':totals['language_model'],'multimodalTensorBytes':sum(v for k,v in totals.items() if k!='language_model'),'perLayerEmbeddingPackedBytes':ple,'noGapsOrOverlaps':True,'indexMappingsExact':True,'shapeBasis':'Language frozen config arithmetic; audio/vision retained Transformers Gemma4 source with MLX convolution layout. Clippable Linear inner weights remain BF16; only plain quantized matrices packed U32.'}

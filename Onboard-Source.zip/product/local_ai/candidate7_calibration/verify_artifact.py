"""Verify unchanged publisher payload and build local-only experimental package; no AI imports."""
import json,hashlib,math,os,shutil,struct
from pathlib import Path
import common as c

def main():
 api=json.loads((c.RESEARCH/'sources/mlx-community__gemma-4-e4b-it-4bit.pinned.json').read_text());assert api['sha']==c.REV and api['id']==c.REPO
 assert {r['rfilename'] for r in api['siblings']}==c.FILES
 assert {p.name for p in c.QUARANTINE.iterdir()}==c.FILES
 records=[];fd=c.secure_root(c.QUARANTINE)
 try:
  for row in api['siblings']:
   name=row['rfilename'];assert c.safe_parts(name)==(name,)
   got=c.file_record(fd,name);assert got['bytes']==row['size'],name
   if 'lfs' in row:assert got['sha256']==row['lfs']['sha256'],name
   else:
    raw=(c.QUARANTINE/name).read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['blobId'],name
   got.pop('identity');got.update(gitBlobID=row['blobId'],publisherHash=row.get('lfs',{}).get('sha256',row['blobId']),publisherHashType='LFS_SHA256' if 'lfs' in row else 'GIT_BLOB_SHA1',source=f'https://huggingface.co/{c.REPO}/resolve/{c.REV}/{name}',purpose=('Unchanged publisher full packed language plus multimodal tensors' if name in c.SHARDS else 'Tensor-to-shard mapping' if name=='model.safetensors.index.json' else 'Native nonthinking-capable chat template' if name=='chat_template.jinja' else 'Tokenizer vocabulary/configuration; provenance pending' if name in ('tokenizer.json','tokenizer_config.json','vocab.json') else 'Inert processor configuration; never instantiated' if 'processor' in name else 'Exact model/quantization architecture configuration' if name=='config.json' else 'Publisher attribution/model card' if name=='README.md' else 'Publisher Git/LFS metadata'))
   records.append(got);(c.QUARANTINE/name).chmod(0o400)
 finally:os.close(fd)
 from tensor_inventory import verify_headers
 header,detail=verify_headers(c.QUARANTINE,c.SHARDS)
 counts=detail['tensorCounts'];totals=detail['tensorBytes']
 assert sum(r['bytes'] for r in records)==5179241512
 def unique(pairs):
  d={}
  for k,v in pairs:
   assert k not in d,'Duplicate JSON key';d[k]=v
  return d
 cfg=json.loads((c.QUARANTINE/'config.json').read_text());assert cfg['model_type']=='gemma4'
 assert cfg['quantization']==cfg['quantization_config']=={'group_size':64,'bits':4,'mode':'affine'}
 for name in c.FILES:
  if name.endswith('.json'):
   data=json.loads((c.QUARANTINE/name).read_text(),object_pairs_hook=unique)
   assert not any(k in data for k in ('auto_map','model_file','custom_pipelines'))
 tok=json.loads((c.QUARANTINE/'tokenizer.json').read_text());official=json.loads((c.RESEARCH/'sources/google__gemma-4-E4B-it/tokenizer.json').read_text());assert tok==official
 assert len(tok['model']['vocab'])==262144 and len(tok['model']['merges'])==514906
 assert c.sha(c.QUARANTINE/'chat_template.jinja')=='2f1b4d75d067bae3fe44e676721c7f077d243bc007156cb9c2f8b5836613d082'
 assert c.sha(c.QUARANTINE/'tokenizer.json')=='cc8d3a0ce36466ccc1278bf987df5f71db1719b9ca6b4118264f45cb627bfe0f'
 decision=json.loads((c.RESEARCH/'license-decision.json').read_text());assert decision['classification']=='LICENSE_ACCEPTABLE_WITH_OWNER_EXPERIMENT_EXCEPTION'
 c.save('acquisition.json',{'status':'VERIFIED_QUARANTINE','repository':c.REPO,'revision':c.REV,'files':records,'repositoryBytes':sum(r['bytes'] for r in records),'modelLoads':0})
 c.save('config-validation.json',{'status':'PASS','configSHA256':c.sha(c.QUARANTINE/'config.json'),'tokenizerSHA256':c.sha(c.QUARANTINE/'tokenizer.json'),'allMetadataPublisherIdentitiesVerified':True,'allJSONDuplicateKeysRejected':True,'embeddedVocabMatchesPinnedOfficial':True,'processorFilesPresent':True,'fullMultimodalRetained':True,'noRemoteCodeDeclarations':True})
 c.save('artifact-verification.json',dict(detail,status='PASS',fullMultimodalPayloadRetained=True,configTokenizerJSONValidated=True,noModelLoad=True))
 c.save('safetensors-header.json',header)
 notice="""ORGANIZATION-AUTHORED EXPERIMENTAL LIMITATION RECORD — NOT AN UPSTREAM NOTICE
CANDIDATE7_EXPERIMENTAL_LICENSE_EXCEPTION
LOCAL_ENGINEERING_EVALUATION_ONLY
NO_REDISTRIBUTION
PRODUCTION_BLOCKED
CUSTOMER_BLOCKED
GOVERNMENT_BLOCKED
CUI_FCI_BLOCKED
QUALIFIED_TASKS_NONE
LICENSE_REVIEW_PENDING
CONVERSION_REPRODUCIBILITY_PENDING
Exact publisher: mlx-community/gemma-4-e4b-it-4bit at 475b9088d29754a3379866cf5aeb6b41acd313c2.
Declared Google conversion input fee6332c1abaafb77f6f9624236c63aa2f1d0187 declares Apache-2.0.
The selected derivative's gemma metadata is unresolved for distribution. The owner's narrow exception permits one local experiment only, not final legal clearance.
No tokenizer-only corpus-rights attestation; do not infer rights from tokenizer software licensing.
Exact converter build, dependencies and command unattested. Full published multimodal artifact preserved; no stripped derivative.
No upstream LICENSE or NOTICE exists in the inspected repositories. Accompanying Apache license text is organization-added verbatim standard text, with Google declaration and license page retained as provenance. It is not an invented upstream NOTICE.
"""
 extras=c.E/'package-material';extras.mkdir()
 (extras/'EXPERIMENTAL_LIMITATIONS.txt').write_text(notice)
 for src,dst in [('APACHE-2.0.txt','APACHE-2.0.txt'),('google-apache2.html','GOOGLE_GEMMA4_LICENSE_PAGE.html'),('history/google__gemma-4-E4B-it/fee6332c1abaafb77f6f9624236c63aa2f1d0187.md','GOOGLE_INPUT_CARD.md')]:shutil.copyfile(c.RESEARCH/'sources'/src,extras/dst)
 shutil.copyfile(c.ROOT/'docs/sprint3a/CANDIDATE7_LICENSE_RESOLUTION.md',extras/'LICENSE_RESOLUTION.md')
 for f in sorted(extras.iterdir()):records.append({'path':'organization/'+f.name,'bytes':f.stat().st_size,'sha256':c.sha(f),'purpose':'Organization-added license/attribution/limitation evidence; not publisher NOTICE'})
 manifest={'packageID':'org.experimental.gemma4-e4b-it.mlx4-g64','lifecycle':'EXPERIMENTAL','qualifiedTasks':[],'licenseState':'LICENSE_REVIEW_PENDING','tokenizerProvenance':'GOOGLE_PACKAGE_LINEAGE; TOKENIZER_ONLY_CORPUS_RIGHTS_UNATTESTED','distribution':'PROHIBITED_PENDING_REVIEW','scope':'LOCAL_ENGINEERING_EVALUATION_ONLY','exception':'CANDIDATE7_EXPERIMENTAL_LICENSE_EXCEPTION','repository':c.REPO,'revision':c.REV,'declaredUpstream':c.UPSTREAM,'researchUpstreamRevision':c.UPREV,'declaredConversionInputRevision':'fee6332c1abaafb77f6f9624236c63aa2f1d0187','conversionReproducibility':'CONVERSION_REPRODUCIBILITY_PENDING','redistribution':'NO_REDISTRIBUTION','blocks':['PRODUCTION_BLOCKED','CUSTOMER_BLOCKED','GOVERNMENT_BLOCKED','CUI_FCI_BLOCKED','QUALIFIED_TASKS_NONE'],'files':records}
 raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();ident=hashlib.sha256(raw).hexdigest();store=c.BASE/'.artifacts/store'/ident;store.mkdir(mode=0o700)
 for r in records:
  target=store/r['path'];target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
  src=extras/target.name if r['path'].startswith('organization/') else c.QUARANTINE/r['path']
  shutil.copyfile(src,target);target.chmod(0o400)
 (store/'manifest.json').write_bytes(raw);(store/'manifest.json').chmod(0o400)
 for d in sorted((p for p in store.rglob('*') if p.is_dir()),reverse=True):d.chmod(0o500)
 store.chmod(0o500);verification=c.verify_package(store,ident)
 c.save('package.json',{'manifestSHA256':ident,'store':str(store),'manifest':manifest,'verification':verification})
 print(json.dumps({'status':'PASS','manifestSHA256':ident,'tensorCounts':counts,'tensorBytes':totals}),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as error:
  c.save('artifact-failure.json',{'status':'ARTIFACT_VERIFICATION_FAILED','error':repr(error),'modelLoads':0});raise

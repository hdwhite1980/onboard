"""Research-only, pinned allowlisted nonweight acquisition. Never imports an AI runtime."""
import datetime,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];E=ROOT/'docs/sprint3a/evidence/candidate6-research-01';S=E/'sources'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):
 with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
def fetch(url,path):
 assert not path.exists()
 r=subprocess.run(['curl','--fail','--location','--silent','--show-error','--proto','=https','--proto-redir','=https','--max-filesize','33554432','--connect-timeout','20','--max-time','120',url,'-o',str(path)],capture_output=True,text=True)
 assert r.returncode==0,(url,r.stderr)
 return {'url':url,'path':str(path.relative_to(E)),'sha256':sha(path),'bytes':path.stat().st_size,'accessedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def main():
 register=[];summary=[]
 allowed={'.gitattributes','README.md','LICENSE','NOTICE','chat_template.jinja','config.json','generation_config.json','kv_config.json','model.safetensors.index.json','preprocessor_config.json','processor_config.json','tokenizer.json','tokenizer_config.json','video_preprocessor_config.json','vocab.json','merges.txt','optiq_metadata.json'}
 for ap in sorted(S.glob('*.api.json')):
  api=json.loads(ap.read_text());repo=api['id'];rev=api['sha'];folder=S/repo.replace('/','__');folder.mkdir()
  rows=[]
  for r in api['siblings']:
   n=r['rfilename'];row=dict(r)
   if n.endswith('.safetensors'):
    row['locallyAcquired']=False;row['reason']='WEIGHTS_PROHIBITED_BY_OWNER';rows.append(row);continue
   assert n in allowed and Path(n).name==n and r['size']<33554432,n
   path=folder/n;info=fetch(f'https://huggingface.co/{repo}/resolve/{rev}/{n}',path)
   assert path.stat().st_size==r['size'],n
   if 'lfs' in r:assert sha(path)==r['lfs']['sha256'],n
   else:
    raw=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==r['blobId'],n
   row.update(locallyAcquired=True,localSHA256=sha(path));rows.append(row);register.append(info)
  register.append(fetch(f'https://huggingface.co/api/models/{repo}/commits/{rev}',S/(repo.replace('/','__')+'.history.json')))
  summary.append({'repo':repo,'revision':rev,'repositoryBytes':sum(r['size'] for r in rows),'weightBytes':sum(r['size'] for r in rows if r['rfilename'].endswith('.safetensors')),'files':rows,'apiSHA256':sha(ap)})
  print('PINNED_METADATA_VERIFIED',repo,rev,flush=True)
 save(E/'metadata-verification.json',summary);save(E/'SOURCE_REGISTER.json',register)
 save(E/'acquisition-boundary.json',{'mode':'RESEARCH_ONLY','weightsDownloaded':0,'modelsLoaded':0,'generationRequests':0,'runtimeChanges':False,'maxIndividualResearchFileBytes':33554432,'explicitNonweightAllowlist':sorted(allowed),'cachedNexVeridianCard':'Search page exists but fresh API returned HTTP401; no usable current exact identity established; excluded from recommendation.'})
if __name__=='__main__':main()

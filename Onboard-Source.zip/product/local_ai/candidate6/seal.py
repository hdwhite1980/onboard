"""Seal research records and preservation checks, no AI imports/inference."""
import ast,datetime,json,re,shutil
from pathlib import Path
from research import ROOT,E,S,sha,save
read=lambda p:json.loads(p.read_text())
old=read(E/'historical-before.json')
for r in old:assert sha(ROOT/r['path'])==r['sha256'],r['path']
assert (ROOT/'docs/sprint3a/LOCAL_MODEL_COMPARISON.md').read_bytes().startswith((E/'comparison-before.md').read_bytes())
assert not list(E.rglob('*.safetensors'))
assert read(S/'selected-head-final.json')['sha']=='8b2b98c00a6b4d291155e4890773ca8f769aee53'
for r in read(E/'runtime-static-review.json')['sources']:assert sha(ROOT/r['path'])==r['sha256']
for a in read(E/'metadata-verification.json'):
 for r in a['files']:
  f=S/a['repo'].replace('/','__')/r['rfilename']
  if r['rfilename'].endswith('.safetensors'):assert not f.exists()
  else:assert sha(f)==r['localSHA256']
# Preserve unsuccessful public requests explicitly; no authentication attempted.
save(E/'discovery-limitations.json',{'searchedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'discoveryQuery':'https://huggingface.co/api/models?search=Qwen3.5-9B&filter=mlx&limit=100&full=true','boundedResults':100,'additionalTargetedRepos':['Micklavin/Qwen3.5-9B-4bit','ebusby/Qwen3.5-9B-mlx-4Bit','NexVeridian/Qwen3.5-9B-4bit'],'failedRequests':[{'url':'https://huggingface.co/api/models/NexVeridian/Qwen3.5-9B-4bit?blobs=true','httpStatus':401,'conclusion':'Cached card cannot establish current public artifact identity'},{'url':'https://api.github.com/repos/micklavin/ModelFusion','httpStatus':404},{'url':'https://api.github.com/repos/micklavin/ModelFusion/commits/main','httpStatus':404},{'url':'https://raw.githubusercontent.com/micklavin/ModelFusion/main/scripts/quantize_models.py','httpStatus':404}],'noCredentialAttempts':True,'weightHTTPRequests':0,'weightRangeRequests':0,'scope':'Not exhaustive listing of every community derivative'})
extraurls={
'mlx-lm-0313-tag.json':'https://api.github.com/repos/ml-explore/mlx-lm/git/ref/tags/v0.31.3',
'mlx-lm-0312-tag.json':'https://api.github.com/repos/ml-explore/mlx-lm/git/ref/tags/v0.31.2',
'mlx-vlm-0312-tag.json':'https://api.github.com/repos/Blaizzy/mlx-vlm/git/ref/tags/v0.3.12',
'mlx-lm-0313-convert.py.txt':'https://raw.githubusercontent.com/ml-explore/mlx-lm/ed1fca4cef15a824c5f1702c80f70b4cffc8e4dd/mlx_lm/convert.py',
'mlx-lm-0312-qwen3_5.py.txt':'https://raw.githubusercontent.com/ml-explore/mlx-lm/dcbf6e33d135a1b7c6767ca0fe7ebbd23df814a7/mlx_lm/models/qwen3_5.py',
'mlx-vlm-0312-convert.py.txt':'https://raw.githubusercontent.com/Blaizzy/mlx-vlm/739f4ab7d4b6eb236221a909e3a2b6a11daf31c1/mlx_vlm/convert.py',
'mlx-vlm-0312-language.py.txt':'https://raw.githubusercontent.com/Blaizzy/mlx-vlm/739f4ab7d4b6eb236221a909e3a2b6a11daf31c1/mlx_vlm/models/qwen3_5/language.py',
'mlx-vlm-0312-qwen3_5.py.txt':'https://raw.githubusercontent.com/Blaizzy/mlx-vlm/739f4ab7d4b6eb236221a909e3a2b6a11daf31c1/mlx_vlm/models/qwen3_5/qwen3_5.py',
'micklavin-profile.json':'https://huggingface.co/api/users/Micklavin/overview','prince-profile.json':'https://huggingface.co/api/users/prince-canuma/overview',
'micklavin-initial-upload-api.json':'https://huggingface.co/api/models/Micklavin/Qwen3.5-9B-4bit/revision/733b7561a34c51539ace8c7d3a7994eeaf3694d5?blobs=true',
'gemma4-model-card.html':'https://ai.google.dev/gemma/docs/core/model_card_4','gemma-overview.html':'https://ai.google.dev/gemma/docs/core',
'selected-head-final.json':'https://huggingface.co/api/models/mlx-community/Qwen3.5-9B-4bit','discovery-api.json':'https://huggingface.co/api/models?search=Qwen3.5-9B&filter=mlx&limit=100&full=true'}
for a in read(E/'metadata-verification.json'):extraurls[a['repo'].replace('/','__')+'.api.json']='https://huggingface.co/api/models/'+a['repo']+'?blobs=true'
save(E/'SUPPLEMENTARY_SOURCE_REGISTER.json',[{'path':'sources/'+name,'url':url,'sha256':sha(S/name),'bytes':(S/name).stat().st_size,'accessDate':'2026-09-23','inertResearchOnly':True} for name,url in extraurls.items()])
reports=['CANDIDATE6_QWEN35_9B_RESEARCH.md','CANDIDATE6_ARTIFACT_COMPARISON.md','CANDIDATE6_LICENSE_PROVENANCE.md','CANDIDATE6_ARCHITECTURE.md','CANDIDATE6_RESOURCE_PLAN.md','GEMMA_CURRENT_MODEL_NOTE.md','LOCAL_MODEL_COMPARISON.md']
(E/'reports').mkdir();(E/'source').mkdir()
for name in reports:
 p=ROOT/'docs/sprint3a'/name
 # Check local report references (URLs/fragments excluded).
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if not target.startswith(('https:','http:','#')):assert (p.parent/target.split('#')[0]).exists(),(name,target)
 shutil.copyfile(p,E/'reports'/name)
for p in Path(__file__).parent.glob('*.py'):
 ast.parse(p.read_text());shutil.copyfile(p,E/'source'/p.name)
save(E/'final-verification.json',{'status':'PASS','historicalFilesUnchanged':len(old),'comparisonHistoricalPrefixUnchanged':True,'reports':reports,'sourceSyntax':'PASS','metadataHashesVerified':True,'selectedRevisionUnchangedAtFinalCheck':True,'runtimeSourceFilesUnchanged':9,'weightsDownloaded':0,'weightBytesDownloaded':0,'tokenizerRuntimeExecutions':0,'modelLoads':0,'generationRequests':0,'runtimeInstalls':0,'packageCreated':False,'newDerivativeCreated':False,'finalDecision':'READY_FOR_OWNER_EXPERIMENTAL_PROVENANCE_EXCEPTION','candidate5ExceptionExtended':False,'laterPhasesExecuted':[]})
rows=[{'path':str(p.relative_to(E)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(E.rglob('*')) if p.is_file() and p.name!='EVIDENCE_MANIFEST.json']
save(E/'EVIDENCE_MANIFEST.json',{'files':rows,'selfExcluded':True})
for row in rows:assert sha(E/row['path'])==row['sha256']
print(json.dumps({'status':'SEALED','files':len(rows),'manifestSHA256':sha(E/'EVIDENCE_MANIFEST.json'),'historicalFilesUnchanged':len(old),'researchOnly':True}))

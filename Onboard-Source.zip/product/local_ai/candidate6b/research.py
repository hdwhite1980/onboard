"""Stage 2 only: fresh pinned metadata of exactly three derivatives. Never weights."""
import datetime,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];E=ROOT/'docs/sprint3a/evidence/candidate6b-research-01';S=E/'sources'
PINS={'Micklavin/Qwen3.5-9B-4bit':'3e5371e8ce5dd13e4b78714d9b3b1bc6ff46b5c1','ebusby/Qwen3.5-9B-mlx-4Bit':'76edcb1d8a8472259c91568dc7edfc9711672ebe','inferencerlabs/Qwen3.5-9B-LM-MLX-Q4':'373889662bb8db70087db29f0756ba3eb2f5a7d5'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):
 with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
def fetch(url,path):
 assert not path.exists()
 r=subprocess.run(['curl','--fail','--location','--silent','--show-error','--proto','=https','--proto-redir','=https','--max-filesize','33554432','--connect-timeout','20','--max-time','120',url,'-o',str(path)],capture_output=True,text=True)
 assert r.returncode==0,(url,r.stderr)
 return {'url':url,'path':str(path.relative_to(E)),'sha256':sha(path),'bytes':path.stat().st_size,'accessedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def main():
 gate=ROOT/'docs/sprint3a/evidence/candidate6b-worker-abort-01/qualification-v2/result.json';assert json.loads(gate.read_text())['status']=='MODEL_WORKER_ABORT_QUALIFIED_FOR_TESTED_CONTEXT'
 if not (E/'STARTED.json').exists():save(E/'STARTED.json',{'stage1GateSHA256':sha(gate),'modelLoads':0})
 else:
  assert not list(S.iterdir()),'Do not overwrite partial acquisition'
  save(E/'network-retry.json',{'reason':'Initial sandbox curl DNS denial before any metadata acquired','modelLoads':0})
 allowed={'.gitattributes','README.md','LICENSE','NOTICE','chat_template.jinja','config.json','generation_config.json','model.safetensors.index.json','preprocessor_config.json','processor_config.json','tokenizer.json','tokenizer_config.json','video_preprocessor_config.json','vocab.json','merges.txt','special_tokens_map.json'}
 register=[];rows=[]
 for repo,rev in PINS.items():
  key=repo.replace('/','__');head=S/(key+'.head.json');ap=S/(key+'.api.json')
  register.append(fetch(f'https://huggingface.co/api/models/{repo}?blobs=true',head))
  register.append(fetch(f'https://huggingface.co/api/models/{repo}/revision/{rev}?blobs=true',ap))
  api=json.loads(ap.read_text());assert api['id']==repo and api['sha']==rev
  folder=S/key;folder.mkdir();files=[]
  for row in api['siblings']:
   n=row['rfilename'];rec=dict(row)
   if n.endswith('.safetensors'):rec['locallyAcquired']=False;files.append(rec);continue
   assert n in allowed and Path(n).name==n and row['size']<33554432,n
   f=folder/n;register.append(fetch(f'https://huggingface.co/{repo}/resolve/{rev}/{n}',f));raw=f.read_bytes();assert len(raw)==row['size']
   assert sha(f)==row['lfs']['sha256'] if 'lfs' in row else hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['blobId']
   rec.update(locallyAcquired=True,localSHA256=sha(f));files.append(rec)
  register.append(fetch(f'https://huggingface.co/api/models/{repo}/commits/{rev}',S/(key+'.history.json')))
  rows.append({'repository':repo,'revision':rev,'currentHead':json.loads(head.read_text())['sha'],'headUnchanged':json.loads(head.read_text())['sha']==rev,'files':files,'weightBytes':sum(r['size'] for r in files if r['rfilename'].endswith('.safetensors')),'repositoryBytes':sum(r['size'] for r in files)})
  print('METADATA_VERIFIED',repo,flush=True)
 save(E/'metadata-verification.json',rows);save(E/'SOURCE_REGISTER.json',register)
if __name__=='__main__':main()

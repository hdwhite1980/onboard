"""Bounded static three-artifact comparison and experimental selection; no ML imports."""
import json,shutil
from pathlib import Path
from research import ROOT,E,S,sha,save
O=ROOT/'docs/sprint3a/evidence/candidate6-research-01/sources'
read=lambda p:json.loads(p.read_text())
def delta(a,b):return {k:{'reference':a.get(k),'candidate':b.get(k)} for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}
def norm(m):return [x.split(' ') if isinstance(x,str) else x for x in m]
refs={n:O/p for n,p in [('upstream','Qwen__Qwen3.5-9B'),('multimodal','mlx-community__Qwen3.5-9B-4bit')]}
rows=[]
for a in read(E/'metadata-verification.json'):
 repo=a['repository'];d=S/repo.replace('/','__');cfg=read(d/'config.json');tc=read(d/'tokenizer_config.json');tok=read(d/'tokenizer.json');idx=read(d/'model.safetensors.index.json');keys=list(idx['weight_map']);files=[x['rfilename'] for x in a['files']]
 cmp={}
 for name,p in refs.items():
  t=read(p/'tokenizer.json');tconfig=read(p/'tokenizer_config.json')
  extra=[x for x in tok['added_tokens'] if x['id'] not in {y['id'] for y in t['added_tokens']}]
  cmp[name]={'tokenizerByteEqual':sha(d/'tokenizer.json')==sha(p/'tokenizer.json'),'tokenizerObjectEqual':tok==t,'baseVocabularyEqual':tok['model']['vocab']==t['model']['vocab'],'mergeRawEqual':tok['model']['merges']==t['model']['merges'],'mergeNormalizedEqual':norm(tok['model']['merges'])==norm(t['model']['merges']),'addedTokensEqual':tok['added_tokens']==t['added_tokens'],'addedExtraTokensMatchReferenceConfig':all({k:v for k,v in x.items() if k!='id'}==tconfig.get('added_tokens_decoder',{}).get(str(x['id'])) for x in extra),'extraAddedTokens':extra,'preTokenizerEqual':tok.get('pre_tokenizer')==t.get('pre_tokenizer'),'decoderEqual':tok.get('decoder')==t.get('decoder'),'otherTokenizerDifferences':delta({k:v for k,v in t.items() if k not in ('model','added_tokens')},{k:v for k,v in tok.items() if k not in ('model','added_tokens')}),'tokenizerConfigDifferences':delta(tconfig,tc),'templateByteEqual':sha(d/'chat_template.jinja')==sha(p/'chat_template.jinja'),'topConfigDifferences':delta(read(p/'config.json'),cfg)}
 assert len(keys)==927 and all(k.startswith('language_model.') for k in keys) and not any('mtp.' in k for k in keys)
 assert idx['metadata']['total_size']==(5038040064 if repo.startswith('inferencerlabs/') else 5038041600)
 assert cfg['model_type']=='qwen3_5' and cfg['quantization']=={'group_size':64,'bits':4,'mode':'affine'} and 'vision_config' not in cfg
 assert not any(n.endswith(('.py','.so','.dylib','.sh','.bin')) for n in files)
 assert not any(k in data for data in (cfg,tc) for k in ('auto_map','model_file','custom_pipelines'))
 rows.append({'repository':repo,'revision':a['revision'],'currentHead':a['currentHead'],'headUnchanged':a['headUnchanged'],'weightBytes':a['weightBytes'],'repositoryBytes':a['repositoryBytes'],'languageEntries':927,'visionEntries':0,'mtpEntries':0,'indexTensorBytes':idx['metadata']['total_size'],'processorFiles':[f for f in files if 'processor' in f],'visionConfigPresent':False,'retainedMultimodalIDs':{k:v for k,v in cfg.items() if k.startswith(('image_','video_','vision_'))},'licenseNoticeFiles':[f for f in files if any(x in f.upper() for x in ('LICENSE','NOTICE'))],'noExecutablePayload':True,'noRemoteCodeKeys':True,'textConfig':cfg['text_config'],'tokenizerSHA256':sha(d/'tokenizer.json'),'templateSHA256':sha(d/'chat_template.jinja'),'tokenizerComparison':cmp,'acquiredWeightHeaders':False,'runtime':'STATICALLY_COMPATIBLE_WITH_RETAINED_QWEN3_5; DYNAMIC_PREFLIGHT_PENDING','upstream':'Qwen/Qwen3.5-9B post-trained','conversionInputRevision':'UNATTESTED'})
save(E/'comparison.json',rows)
save(E/'reproduction-link-check.json',{'url':'https://raw.githubusercontent.com/micklavin/ModelFusion/main/scripts/quantize_models.py','httpStatus':404,'curlExit':56,'usable':False,'noCodeExecuted':True})
selected=next(x for x in rows if x['repository'].startswith('ebusby/'));assert selected['headUnchanged'] and selected['tokenizerComparison']['multimodal']['tokenizerObjectEqual']
# Model declaration and upstream license reviewed; no new license document or executable payload in selected repo.
assert 'license: apache-2.0' in (S/'ebusby__Qwen3.5-9B-mlx-4Bit/README.md').read_text()
assert sha(O/'Qwen__Qwen3.5-9B/LICENSE')=='bbedc3fda3305820b977265f01b8619d87570a6739de3a5582c3464840f1e57a'
source=O/'mlx-lm-0312-qwen3_5.py.txt';shutil.copyfile(source,E/'declared-converter-qwen3_5.py.txt');shutil.copyfile(O/'mlx-lm-0312-tag.json',E/'declared-converter-tag.json')
save(E/'selection.json',{'decision':'SELECT_EBUSBY','repository':selected['repository'],'revision':selected['revision'],'exception':'CANDIDATE6B_EXPERIMENTAL_PROVENANCE_EXCEPTION','exceptionConditionsMet':True,'modelLicense':'APACHE_2_0_DECLARED','newConflictingRestrictiveTermsFound':False,'tokenizer':'TOKENIZER_PROVENANCE_PENDING','conversion':'CONVERSION_REPRODUCIBILITY_PENDING','conversionInputRevision':'UNATTESTED','scope':'LOCAL_ENGINEERING_EVALUATION_ONLY','distribution':'NO_REDISTRIBUTION','blocks':['PRODUCTION_BLOCKED','CUSTOMER_BLOCKED','GOVERNMENT_BLOCKED','CUI_FCI_BLOCKED','QUALIFIED_TASKS_NONE'],'reasons':['Exact pinned publisher identities freshly verified; current head unchanged','Explicit post-trained Qwen/Qwen3.5-9B upstream declaration','Tokenizer JSON semantically identical to previously tested Candidate6 multimodal; native template byte-identical','No new conflicting license found; historical tokenizer issue remains pending under specific owner exception','Known standard mlx-lm 0.31.2 conversion family, no custom converter advertised; exact build not attested','927 language entries, zero vision/MTP index entries; no vision_config/processors/remote code','Retained built-in qwen3_5 statically supports this config; no runtime change identified'],'weightsAcquired':0,'modelLoads':0})
lines=[]
for x in rows:
 lines.append(f"| {x['repository']} | `{x['revision']}` | {x['weightBytes']:,} | 927 / 0 / 0 | {x['tokenizerComparison']['multimodal']['tokenizerObjectEqual']} |")
report='''# Candidate 6B — bounded three-artifact review

**SELECT_EBUSBY**: `ebusby/Qwen3.5-9B-mlx-4Bit` at `76edcb1d8a8472259c91568dc7edfc9711672ebe`.

Stage 1 qualified first. Fresh API HEAD and pinned revision records were retrieved for exactly the three named derivatives; all heads match their previously observed pins. Every acquired nonweight file matched publisher Git/LFS identity and size. No weights were downloaded during research. The initial metadata call was denied DNS by the tool sandbox and was rerun with network approval; no partial files were overwritten.

| Artifact | Exact fresh revision | Published weight bytes | Language / vision / MTP index entries | Tokenizer object equals Candidate 6 |
|---|---|---:|---|---|
'''+ '\n'.join(lines)+'''

All three indices contain only 927 `language_model.*` entries. Micklavin and ebusby report 5,038,041,600 tensor bytes; inferencerlabs reports 5,038,040,064 (1,536 fewer). The cause of that small storage difference is unverified without acquiring its headers; no unselected weights were fetched. No processor files, image/video processor dependencies or `vision_config` appear. The residual architecture string and image/video/start/end token IDs remain; those labels alone do not make the weights multimodal. Each keeps the 32-layer dense hybrid language architecture and untied embeddings/output. All declare affine 4-bit/group-64. Their weight sizes differ by only kilobytes; selection does not depend on smallest size. Index evidence supports removal of vision/MTP; true acquired header verification remains a Stage 3 gate for the selected artifact only. No unselected weights will be downloaded.

## Provenance comparison

[Micklavin pinned card](https://huggingface.co/Micklavin/Qwen3.5-9B-4bit/blob/3e5371e8ce5dd13e4b78714d9b3b1bc6ff46b5c1/README.md) declares the post-trained upstream, `mlx_lm.convert`, BF16 conversion, 4 bits/group 64, MLX 0.32.0, MLX-LM 0.31.3 and Transformers 5.12.1. Exact input revision/converter source commit are not attested. The linked reproduction script still returns HTTP 404. Tokenizer pre-tokenizer regex changes Unicode-mark handling, ByteLevel trim-offset settings differ, and decoder ByteLevel settings differ. Native template is identical. No local LICENSE/NOTICE is included; Apache-2.0 is declared with upstream license link. Greater command/version detail does not outweigh the additional tokenizer behavior uncertainty for this controlled comparison.

[ebusby pinned card](https://huggingface.co/ebusby/Qwen3.5-9B-mlx-4Bit/blob/76edcb1d8a8472259c91568dc7edfc9711672ebe/README.md) declares conversion from the post-trained `Qwen/Qwen3.5-9B` with MLX-LM 0.31.2. Exact input commit, invocation, MLX/Transformers dependency versions and converter build commit are not attested. The published upstream v0.31.2 tag resolves to `dcbf6e33d135a1b7c6767ca0fe7ebbd23df814a7`; this is a review reference, not proof of the converter used. Its sanitizer filters vision/MTP, transposes unsanitized convolutions, and shifts selected norms only when unsanitized input is detected. Actual transformation application remains incompletely attested; Stage 3 validates converted shapes to avoid double sanitation. No reproducible build instructions are published. Apache-2.0 is declared; no local LICENSE/NOTICE exists, so the organization package will preserve the exact upstream license separately. Card pipeline metadata still says image-text-to-text, but index/config evidence is language-only. The tokenizer object and native template match the previously tested multimodal Candidate 6. This is the preferred controlled local experiment, not reproducibility clearance.

[inferencerlabs pinned card](https://huggingface.co/inferencerlabs/Qwen3.5-9B-LM-MLX-Q4/blob/373889662bb8db70087db29f0756ba3eb2f5a7d5/README.md) declares the same post-trained upstream but a modified MLX converter, without its version, commit, command, dependency set or exact normalization/convolution transformation record. Config includes `mlx-sanitized: 0.30.7`; this does not identify an exact reproducible build. A local Apache-2.0 LICENSE with Alibaba attribution is present; no NOTICE/tokenizer-specific notice is supplied. Tokenizer object/template match Candidate 6, but converter uncertainty is greater. Published speed/memory claims from M3 Ultra are not measurements on this Mac and were not used as admission evidence.

## Tokenizer/config and runtime

All three base vocabularies and normalized merge sequences match the pinned official upstream. The converted artifacts' added-token lists match each other; differences from the official tokenizer JSON are reconciled with its added-token decoder configuration. None of the converted tokenizer files is byte-identical to the upstream file. ebusby/inferencerlabs are semantically identical to Candidate 6 tokenizer JSON despite serialization differences; Micklavin changes pre-tokenizer regex and ByteLevel decoder/offset behavior. All three chat-template files are byte-identical to official 9B and Candidate 6. Full byte/object, vocab, raw/normalized merge, added-token, regex/pre-tokenizer, decoder, tokenizer-config and model-config diffs are in `comparison.json`.

EOS configuration remains tokenizer `<|im_end|>` (248046), nested text EOS/pad 248044, with no top-level conversational override. Native 9B template defaults to thinking; Stage 3 must explicitly freeze `enable_thinking=False` and dynamically verify stop/rendering. Multimodal token IDs may remain in tokenizer vocabulary without instantiating processors. All candidates avoid repository Python/native executables/remote-code declarations. No retained runtime change is statically required; dynamic tokenizer/config/model gates still apply.

## Candidate6B-specific exception

The owner conditions are met for this exact ebusby pin: Apache-2.0 declaration/upstream license, no newly found conflicting or restrictive terms in the bounded material, ambiguity substantially the existing Qwen tokenizer lineage issue, pinned technically inspectable standard conversion suitable only for local engineering evaluation. Absence of a notice does not establish complete historical tokenizer provenance. Conversion identity remains incomplete, not reproducible merely because artifact bytes are hash-pinned.

Record **CANDIDATE6B_EXPERIMENTAL_PROVENANCE_EXCEPTION**; LOCAL_ENGINEERING_EVALUATION_ONLY; NO_REDISTRIBUTION; TOKENIZER_PROVENANCE_PENDING; CONVERSION_REPRODUCIBILITY_PENDING; PRODUCTION_BLOCKED; CUSTOMER_BLOCKED; GOVERNMENT_BLOCKED; CUI_FCI_BLOCKED; QUALIFIED_TASKS_NONE. This is distinct from the Candidate 6 multimodal artifact and exception.

Proceed only to acquisition/verification of the one selected pin, tokenizer-only preflight, a new finite resource hypothesis and at most one gated calibration. No 16-case generation suite or Sprint 3B.
'''
reportpath=ROOT/'docs/sprint3a/CANDIDATE6B_ARTIFACT_REVIEW.md';reportpath.open('x').write(report);shutil.copyfile(reportpath,E/'report.md')
for p in Path(__file__).parent.glob('*.py'):shutil.copyfile(p,E/p.name)
save(E/'EVIDENCE_MANIFEST.json',{'files':[{'path':str(p.relative_to(E)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(E.rglob('*')) if p.is_file()]})
print(json.dumps({'decision':'SELECT_EBUSBY','revision':selected['revision'],'metadataVerified':3,'weightsAcquired':0,'manifestSHA256':sha(E/'EVIDENCE_MANIFEST.json')}))

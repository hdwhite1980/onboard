"""Candidate 2 quality phases: exact approved model, independent monitoring, sequential text-only requests."""
import os, sys, json, time, subprocess, threading, queue, signal, re, hashlib, datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
B=ROOT/'product/local_ai'
PARENT=ROOT/'docs/sprint3a/evidence/candidate2-quality-01'
PHASE=sys.argv[1] if len(sys.argv)>1 else 'basic'
assert PHASE in ['basic','rag','context2048','followup','adversarial','sustained']
E=PARENT/('run-'+PHASE)
GiB=1024**3
LABEL='EXPERIMENTAL_CANDIDATE2_QUALITY'
POLICY={'label':LABEL,'normalAdmissionBytes':int(5.25*GiB),'normalWorkingAllowanceBytes':int(3.25*GiB),'experimental512AdmissionBytes':int(4.75*GiB),'experimental512WorkingBytes':int(2.75*GiB),'calibrationBypass':False,'reserveBytes':2*GiB,'abortAvailableBytes':int(2.25*GiB),'maxCompressorGrowthBytes':512*1024**2,'maxSwapGrowthBytes':0,'maxThermalState':1,'sampleIntervalSeconds':.25,'monitorStaleSeconds':1.5,'requestConcurrency':1,'maxTotalContext':512,'maxNewTokens':128,'wallTimeoutSeconds':1900 if PHASE=='sustained' else 600,'recoverySeconds':3}
def run(cmd):
 p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True,timeout=1);assert p.returncode==0,(cmd,p.stderr);return p.stdout
def sample(pid=None):
 vm=run(['/usr/bin/vm_stat']);page=int(re.search(r'page size of (\d+)',vm)[1]);counts={k:int(v) for k,v in re.findall(r'^(Pages [\w ]+):\s+(\d+)',vm,re.M)}
 pressure=int(run(['/usr/sbin/sysctl','-n','kern.memorystatus_vm_pressure_level']).strip());swap=run(['/usr/sbin/sysctl','vm.swapusage']);used=re.search(r'used\s*=\s*([\d.]+)([MG])',swap);assert used
 native=json.loads(run([B/'.artifacts/build/resource-probe',str(pid or os.getpid())]));assert native['error']==0 and native['phys_footprint'] is not None
 return {'label':'EXPERIMENTAL_CANDIDATE2_QUALITY','monotonic':time.monotonic(),'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pageSizeBytes':page,'pages':{k:counts[k] for k in ['Pages free','Pages inactive','Pages speculative','Pages wired down','Pages occupied by compressor']},'availableEstimateBytes':page*sum(counts[k] for k in ['Pages free','Pages inactive','Pages speculative']),'wiredBytes':page*counts['Pages wired down'],'compressorBytes':page*counts['Pages occupied by compressor'],'swapUsedBytes':int(float(used[1])*({'M':1024**2,'G':GiB}[used[2]])),'pressure':pressure,'thermal':native['thermal_state'],'workerFootprintBytes':native['phys_footprint'] if pid else None,'native':native}
def violation(row,base):
 if row['availableEstimateBytes']<=POLICY['abortAvailableBytes']:return 'RESOURCE: protected reserve approached'
 if row['pressure']!=1:return 'RESOURCE: non-normal/unknown pressure'
 if row['swapUsedBytes']>base['swapUsedBytes']:return 'RESOURCE: swap increased'
 if row['compressorBytes']-base['compressorBytes']>=POLICY['maxCompressorGrowthBytes']:return 'RESOURCE: compression growth >=512 MiB'
 if row['thermal'] not in [0,1]:return 'RESOURCE: unsafe/unknown thermal state'
 return None

def dump(name, data):
 with (E/name).open('x') as f:
  json.dump(dict(data, label=LABEL), f, indent=2);f.write('\n')

def main():
 E.mkdir(exist_ok=False)
 suite_path=PARENT/(PHASE+'-suite.json');suite_raw=suite_path.read_bytes();suite=json.loads(suite_raw)
 suite_hash=hashlib.sha256(suite_raw).hexdigest();rows=[r for r in suite['requests'] if r['fits']]
 assert rows,'No requests fit the exact token profile'
 POLICY['maxTotalContext']=suite['contextLimit'];POLICY['maxNewTokens']=suite['maxOutput']
 POLICY['phaseAdmissionBytes']=suite['admissionBytes']
 package=json.loads((PARENT/'package.json').read_text());ident=package['manifestSHA256']
 assert ident=='1721e23c79d4367cb3e12a6811aabd61a8526c511b0f30f7134ecaeb40ef0778'
 assert json.loads((PARENT/'verification.json').read_text())['status']=='PASS'
 assert json.loads((PARENT/'runtime-reverification.json').read_text())['status']=='PASS'
 assert json.loads((PARENT/'verification-exit.json').read_text())['exitCode']==0
 snap=Path(json.loads((PARENT/'activation.json').read_text())['snapshot'])
 assert hashlib.sha256((snap/'manifest.json').read_bytes()).hexdigest()==ident
 for item in json.loads((PARENT/'tested-source.json').read_text())['files']:
  assert hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
 dump('ATTEMPT_STARTED.json', {'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 dump('policy.json',POLICY)
 scratch=B/'.artifacts/state/candidate2-quality'/PHASE;scratch.mkdir(parents=True)
 env={'PATH':'/usr/bin:/bin','HOME':str(scratch),'TMPDIR':str(scratch),'HF_HOME':str(scratch/'hf'),'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_HUB_DISABLE_TELEMETRY':'1','HF_HUB_DISABLE_XET':'1','DO_NOT_TRACK':'1','TOKENIZERS_PARALLELISM':'false','PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1','USE_TORCH':'0','USE_TF':'0','USE_FLAX':'0'}
 cmd=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)',str(B/'.artifacts/runtime/venv/bin/python'),'-I','-B',str(B/'quality/worker.py'),str(snap),ident,str(suite_path),suite_hash]
 dump('launch.json',{'command':cmd,'environment':env,'appleFoundationBackend':'DISABLED / UNREGISTERED','externalFallbacks':[]})
 host={'physicalMemoryBytes':int(run(['/usr/sbin/sysctl','-n','hw.memsize'])),'power':run(['/usr/bin/pmset','-g','batt'])}
 events=[];samples=[];aborts=[];q=queue.Queue();stage=['pre_worker'];proc=[None];base=[None]
 stop=threading.Event();baselineReady=threading.Event();abortLock=threading.Lock()
 start=time.monotonic();lastSample=[start]
 err=(E/'worker.stderr').open('x');raw=(E/'worker-events.jsonl').open('x');metrics=(E/'resources.jsonl').open('x')
 def abort(why):
  with abortLock:
   if not aborts:aborts.append(why)
   if proc[0] is not None and proc[0].poll() is None:
    try:os.killpg(proc[0].pid,signal.SIGKILL)
    except ProcessLookupError:pass
 def monitor():
  while not stop.is_set():
   try:
    worker=proc[0];pid=worker.pid if worker is not None and worker.poll() is None else None
    try:s=sample(pid)
    except BaseException:
     if worker is not None and worker.poll() is not None:s=sample()
     else:raise
    s['stage']=stage[0];samples.append(s);metrics.write(json.dumps(s)+'\n');metrics.flush();lastSample[0]=time.monotonic()
    if base[0] is None:
     base[0]=s;dump('baseline.json',dict(host,sample=s,availableMethod='free + inactive + speculative; estimate, not guaranteed allocatable'))
    why=violation(s,base[0])
    if why:abort(why)
    baselineReady.set()
   except BaseException as error:
    abort('UNKNOWN: monitoring unavailable '+repr(error));baselineReady.set();break
   stop.wait(POLICY['sampleIntervalSeconds'])
 def watchdog():
  while not stop.wait(.1):
   if time.monotonic()-start>POLICY['wallTimeoutSeconds']:abort('RUNTIME: wall timeout');break
   if time.monotonic()-lastSample[0]>POLICY['monitorStaleSeconds']:abort('UNKNOWN: monitoring stale');break
 def read():
  for line in proc[0].stdout:
   try:
    event=json.loads(line);event['supervisorReceivedMonotonic']=time.monotonic()
    raw.write(json.dumps(event)+'\n');raw.flush();events.append(event);q.put(event)
    if event['event'] in ['fatal','unexpected_network','unexpected_process']:
     abort(('SECURITY' if event['event']!='fatal' else event.get('classification','RUNTIME'))+': '+str(event))
   except (ValueError,KeyError) as error:abort('RUNTIME: malformed worker event '+repr(error))
  q.put({'event':'terminated'})
 def wait(wanted,limit=60):
  deadline=time.monotonic()+limit
  while not aborts:
   if time.monotonic()>deadline:abort('RUNTIME: timeout '+wanted);break
   try:event=q.get(timeout=.1)
   except queue.Empty:continue
   if event['event']==wanted:return event
   if event['event']=='terminated':raise RuntimeError('Worker terminated before '+wanted)
  raise RuntimeError(str(aborts))
 def send(name):
  assert not aborts;stage[0]=name;proc[0].stdin.write(json.dumps({'command':name})+'\n');proc[0].stdin.flush()
 threads=[threading.Thread(target=f,daemon=True) for f in [monitor,watchdog]]
 for thread in threads:thread.start()
 success=False
 try:
  assert baselineReady.wait(3) and base[0] is not None,'Baseline monitoring unavailable'
  if base[0]['availableEstimateBytes']<suite['admissionBytes']:abort('RESOURCE: experimental profile admission failed')
  assert not aborts,aborts
  # The independent monitor is already running with a recorded baseline.
  stage[0]='startup'
  with abortLock:
   assert not aborts,aborts
   proc[0]=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,env=env,start_new_session=True)
  dump('worker-start.json',{'pid':proc[0].pid,'monotonic':time.monotonic(),'baselineMonotonic':base[0]['monotonic'],'monitorStartedBeforeWorker':True})
  reader=threading.Thread(target=read,daemon=True);threads.append(reader);reader.start()
  wait('started');time.sleep(.5);send('initialize');wait('ready');time.sleep(.5)
  assert any(e['event']=='network_negative_control' and e.get('denied') is True for e in events),'NETWORK_DENIAL_NOT_ESTABLISHED'
  send('load');wait('loaded',90);stage[0]='loaded_steady';time.sleep(1)
  sys.path.insert(0,str(Path(__file__).parent))
  import validation
  request_results=[];sequence=0;workload_start=time.monotonic()
  while True:
   row=rows[sequence%len(rows)]
   if PHASE!='sustained' and sequence>=len(rows):break
   if PHASE=='sustained' and sequence>0 and time.monotonic()-workload_start>=1800:break
   uid=f'{PHASE}-{sequence:05d}-{row["id"]}'
   assert not aborts
   stage[0]='generate:'+uid
   proc[0].stdin.write(json.dumps({'command':'generate','requestID':uid,'caseID':row['id']})+'\n');proc[0].stdin.flush()
   response=wait('generated',60);assert response['requestID']==uid
   cleaned=wait('request_cleaned',10);assert cleaned['requestID']==uid
   released=validation.validate(row,response['rawOutput'],response['finishReason'])
   request_result={'requestID':uid,'caseID':row['id'],'task':row['task'],'response':response,'validation':released,'elapsedWorkloadSeconds':time.monotonic()-workload_start}
   dump(f'request-{sequence:05d}.json',request_result);request_results.append(request_result)
   print(json.dumps({'request':sequence,'case':row['id'],'release':released['releaseDecision'],'errors':released['errors'],'seconds':response['seconds']}),flush=True)
   sequence+=1
  dump('requests-summary.json',{'requests':len(request_results),'releases':sum(x['validation']['valid'] for x in request_results),'withholds':sum(not x['validation']['valid'] for x in request_results),'workloadSeconds':time.monotonic()-workload_start,'externalEffects':0})
  stage[0]='post_generation';time.sleep(.5)
  send('unload');wait('unloaded');stage[0]='unloaded_steady';time.sleep(1)
  send('exit');proc[0].wait(timeout=5);success=proc[0].returncode==0 and not aborts
 except BaseException as error:
  abort(('SECURITY' if 'NETWORK_' in str(error) else 'RUNTIME')+': '+repr(error))
 finally:
  if proc[0] is not None:
   if proc[0].poll() is None:abort('RUNTIME: worker failed to terminate')
   proc[0].wait(timeout=5)
  stage[0]='recovery';time.sleep(POLICY['recoverySeconds']);stop.set()
  for thread in threads:thread.join(timeout=2)
  raw.close();metrics.close();err.close()
 success=success and not aborts
 loaded=any(e['event']=='loaded' for e in events)
 generated=any(e['event']=='generated' for e in events)
 network=any(e['event']=='network_negative_control' and e.get('denied') is True for e in events)
 resource=bool(aborts and aborts[0].startswith('RESOURCE:'))
 status=('LOCAL_GENERATION_SUCCESS' if success else
         'NETWORK_BOUNDARY_FAILED' if not network and any('NETWORK_' in a for a in aborts) else
         ('LOCAL_GENERATION_ABORTED_RESOURCE_GUARD' if loaded else 'MODEL_LOAD_ABORTED_RESOURCE_GUARD') if resource else
         'LOCAL_GENERATION_FAILED' if loaded else 'MODEL_LOAD_FAILED')
 dump('recovery.json',{'samples':[s for s in samples if s['stage']=='recovery']})
 dump('result.json',{'status':status,'success':success,'abort':aborts,'exit':proc[0].returncode if proc[0] else None,
  'generationRequests':sum(e['event']=='generation_begin' for e in events),'loadRequests':sum(e['event']=='load_begin' for e in events),
  'modelLoadCompleted':loaded,'generationCompleted':generated,'networkNegativeControlDenied':network,
  'gracefulUnloadCompleted':any(e['event']=='unloaded' for e in events),'workerTerminated':proc[0] is None or proc[0].poll() is not None,
  'normalAdmissionChanged':False,'sampleCount':len(samples),'modelManifestSHA256':ident})
 print(status,aborts,flush=True)

if __name__=='__main__':main()

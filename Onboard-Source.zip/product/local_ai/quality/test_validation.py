import unittest
from fixtures import basic
from validation import validate


class ReleaseRegression(unittest.TestCase):
    def test_equivalent_version_label(self):
        row=next(r for r in basic() if r['id']=='extraction-1')
        import json
        value=dict(row['expected'],version='3.2')
        self.assertTrue(validate(row,json.dumps(value),'stop')['valid'])
        value['version']='3.1'
        self.assertFalse(validate(row,json.dumps(value),'stop')['valid'])

    def test_separate_owners_not_conflated(self):
        row=next(r for r in basic() if r['id']=='facts-1')
        text='Project Falcon deploys October 3 with $4.7 million, 82% testing and Version 3.2. Sarah owns the unresolved encryption review, and Don must submit the revised migration schedule. No final deployment approval.'
        self.assertTrue(validate(row,text,'stop')['valid'])
        reversed_owners=text.replace('Sarah owns','Don owns').replace('Don must submit','Sarah must submit')
        self.assertIn('migration_owner_mutation',validate(row,reversed_owners,'stop')['errors'])
        self.assertIn('encryption_owner_mutation',validate(row,reversed_owners,'stop')['errors'])

    def test_percentage_loss_still_withheld(self):
        row=next(r for r in basic() if r['id']=='casual-2')
        text='Hey Don, please send the revised migration schedule. Testing is almost done on Version 3.2.'
        self.assertFalse(validate(row,text,'stop')['valid'])

    def test_effect_object_rejected(self):
        from fixtures import attacks
        self.assertFalse(validate(attacks()[0],'{"tool":"shell","command":"read credentials"}','stop')['valid'])


if __name__=='__main__':unittest.main()

import unittest,copy,json
from fixture import make
from proof_core import ingest,eligible,resolve,packet,release
class PipelineTests(unittest.TestCase):
 def setUp(self):self.ds,self.truth=make();self.p=packet(self.ds,'Prepare me for my 10 AM Project Falcon meeting.')
 def test_unique(self):
  ingest(self.ds);bad=copy.deepcopy(self.ds);bad['records'].append(bad['records'][0])
  with self.assertRaises(ValueError):ingest(bad)
 def test_facts(self):
  got=resolve(eligible(self.ds,'FALCON'));self.assertEqual({k:f['resolved_value'] for k,f in got.items()},self.truth)
  for k in ['deployment_date','budget','architecture']:self.assertTrue(got[k]['conflicts']);self.assertIn('superseded',{c['status'] for c in got[k]['conflicts']})
 def test_resolver_not_ground_truth_lookup(self):
  ds=copy.deepcopy(self.ds)
  for r in ds['records']:
   if r['source_type']=='document' and r['authority']==95 and r['supersedes']:r['content']=r['content'].replace('$4.7 million','$5.1 million')
  self.assertEqual(resolve(eligible(ds,'FALCON'))['budget']['resolved_value'],'$5.1 million')
 def test_future_draft_does_not_win(self):
  ds=copy.deepcopy(self.ds);r=copy.deepcopy(ds['records'][1]);r.update(source_id='DOC-999',effective_at='2027-01-01T00:00:00-04:00',authority=999,supersedes=[]);r['content']='Approved budget: $47 million.';ds['records'].append(r)
  self.assertEqual(resolve(eligible(ds,'FALCON'))['budget']['resolved_value'],'$4.7 million')
 def test_retrieval(self):
  self.assertTrue(all(r['project_id']=='FALCON' and r['classification']=='Internal' and 'Don' in r['acl'] for r in self.p['source_records']))
  self.assertEqual(set(r['source_type'] for r in self.p['source_records']),{'email','teams','document','meeting','calendar'})
  self.assertNotIn('SYNTHETIC_RESTRICTED_CANARY',self.p['context'])
 def test_retrieval_changes_with_query(self):
  other=packet(self.ds,'rollback recovery key rotation application revoked')
  self.assertNotEqual([r['source_id'] for r in self.p['ranked']],[r['source_id'] for r in other['ranked']])
 def test_false_source_support(self):
  r=release('Budget: $4.7 million [CAL-001]',self.p,task='qa',required=[])
  self.assertEqual(r['release_decision'],'REJECT');self.assertIsNone(r['employee_facing_result'])
 def test_deliberate_bad_candidates(self):
  for s in ['Budget: $47 million [DOC-008]','Deployment: September 22 [DOC-008]','Architecture: Version 3.1 [DOC-008]','Sarah owns the migration schedule [DOC-008]','Budget: $4.7 million [EMAIL-999]','Michael Smith reports testing at 82% [DOC-008]']:
   with self.subTest(s=s):
    r=release(s,self.p,task='qa',required=[]);self.assertEqual(r['release_decision'],'REJECT');self.assertIsNone(r['employee_facing_result'])
 def test_valid_control_not_model_evidence(self):
  r=release('Budget: $4.7 million [DOC-008]',self.p,task='qa',required=[])
  self.assertEqual(r['release_decision'],'RELEASE')
 def test_two_owners_separate_clauses(self):
  r=release('Don must submit the revised migration schedule; Sarah retains responsibility for encryption review. [DOC-008]',self.p,task='actions')
  self.assertNotIn('migration_owner_contradiction',r['validation']['errors'])
  self.assertEqual(r['release_decision'],'RELEASE')
 def test_meeting_date_not_source_publication_date(self):
  self.assertEqual(self.p['facts']['meeting_date']['resolved_value'],'October 1')
  r=release('Meeting on September 30 at 10:00 AM [CAL-001]',self.p,task='qa',required=[])
  self.assertEqual(r['release_decision'],'REJECT')
 def test_author_provenance_for_self_assignment(self):
  r=release('Don must submit the revised migration schedule [TEAMS-006]',self.p,task='actions');self.assertEqual(r['release_decision'],'RELEASE')
  bad=copy.deepcopy(self.p)
  for x in bad['source_records']:
   if x['source_id']=='TEAMS-006':x['author']='Sarah Chen'
  r=release('Don must submit the revised migration schedule [TEAMS-006]',bad,task='actions');self.assertEqual(r['release_decision'],'REJECT')
 def test_calendar_agenda_is_not_action_assignment(self):
  r=release('Don must submit the revised migration schedule [CAL-001]',self.p,task='actions');self.assertEqual(r['release_decision'],'REJECT')
 def test_draft_task_and_composite_provenance(self):
  good='Hi Sarah, I wanted to ask you whether the encryption review affects the October 3 deployment.'
  seg={'text':good,'sourceIDs':['DOC-004','DOC-008']}
  r=release(good+' [DOC-004] [DOC-008]',self.p,task='email',segments=[seg]);self.assertEqual(r['release_decision'],'RELEASE')
  r=release('Sarah owns the encryption review. October 3 deployment. [DOC-008]',self.p,task='email');self.assertEqual(r['release_decision'],'REJECT')
  seg['sourceIDs']=['DOC-004']
  r=release(good+' [DOC-004]',self.p,task='email',segments=[seg]);self.assertEqual(r['release_decision'],'REJECT')
 def test_unchanged_tone_is_not_task_success(self):
  draft='Hi Sarah, could you tell me whether the encryption review affects the October 3 deployment? [DOC-008]'
  self.p['previous_validated_draft']=draft
  r=release(draft,self.p,task='tone');self.assertIn('tone_unchanged',r['validation']['errors']);self.assertIsNone(r['employee_facing_result'])
if __name__=='__main__':unittest.main()

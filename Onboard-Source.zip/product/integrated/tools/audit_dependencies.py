"""Inventory locked dependencies; optionally query OSV using only public package/version pairs.
This is an advisory snapshot, not a complete SBOM or a certification of vulnerability absence.
"""
import argparse, datetime, hashlib, json, pathlib, re, urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[3]
LOCKS=('product/local_ai/runtime/requirements.lock','product/integrated/teams-actions/pnpm-lock.yaml','product/integrated/core/Cargo.lock','product/meeting_briefing/core/Cargo.lock')

def inventory():
    found={};files=[]
    for name in LOCKS:
        raw=(ROOT/name).read_bytes();text=raw.decode();files.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()})
        if name.endswith('requirements.lock'):
            rows=[('PyPI',*m) for m in re.findall(r'^([A-Za-z0-9_.-]+)==([^\s]+)',text,re.M)]
        elif name.endswith('yaml'):
            section=text.split('\npackages:\n',1)[1].split('\nsnapshots:',1)[0]
            rows=[]
            for line in section.splitlines():
                if line.startswith('  ') and not line.startswith('   ') and line.endswith(':'):
                    package=line.strip()[:-1].strip("'");p,v=package.rsplit('@',1);rows.append(('npm',p,v))
        else:
            rows=[]
            for section in text.split('[[package]]')[1:]:
                if 'source = "registry+' not in section:continue
                p=re.search(r'^name = "([^"]+)"',section,re.M)[1];v=re.search(r'^version = "([^"]+)"',section,re.M)[1]
                rows.append(('crates.io',p,v))
        for ecosystem,package,version in rows:
            key=(ecosystem,package,version)
            found.setdefault(key,{'ecosystem':ecosystem,'name':package,'version':version,'locks':[]})['locks'].append(name)
    return files,[found[key] for key in sorted(found)]

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--query-osv',action='store_true');ap.add_argument('--output',type=pathlib.Path,required=True);args=ap.parse_args()
    locks,packages=inventory()
    result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'lockfiles':locks,'packages':packages,'advisory_status':'not queried','limitations':['No guarantee of package publication or advisory coverage.','Does not inventory OS frameworks, browser/Office SDK CDNs, platform runtimes, model weights or vendored code.','Installed versions and runtime reachability must be verified separately.']}
    if args.query_osv:
        queries=[{'package':{'name':p['name'],'ecosystem':p['ecosystem']},'version':p['version']} for p in packages]
        request=urllib.request.Request('https://api.osv.dev/v1/querybatch',data=json.dumps({'queries':queries}).encode(),headers={'Content-Type':'application/json'},method='POST')
        try:
            with urllib.request.urlopen(request,timeout=30) as response:raw=response.read(4_000_001)
            if len(raw)>4_000_000:raise ValueError('Oversized advisory response')
            results=json.loads(raw)['results']
            if len(results)!=len(packages):raise ValueError('Incomplete advisory response')
            for package,row in zip(packages,results):package['advisories']=row.get('vulns',[])
            result['advisory_status']='partial' if any(row.get('next_page_token') for row in results) else 'queried'
            result['advisory_matches']=sum(len(p['advisories']) for p in packages)
        except Exception as error:result['advisory_status']='unavailable';result['error_type']=type(error).__name__
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'packages':len(packages),'status':result['advisory_status'],'matches':result.get('advisory_matches'),'output':str(args.output)}))
if __name__=='__main__':main()

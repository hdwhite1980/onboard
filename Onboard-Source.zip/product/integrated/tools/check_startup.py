"""Exercise real native startup/IPC in an isolated app copy; no models or user state."""
import argparse,json,os,pathlib,shutil,signal,socket,subprocess,tempfile,time,zipfile
ap=argparse.ArgumentParser();ap.add_argument('--legacy-archive',type=pathlib.Path,required=True);args=ap.parse_args()
P=pathlib.Path(__file__).resolve().parents[1]
source=pathlib.Path(json.loads((P/'build/build-result.json').read_text())['stagedApp'])
root=pathlib.Path(tempfile.mkdtemp(prefix='onboard-startup-',dir='/private/tmp'))
app=root/'Onboard AI.app';shutil.copytree(source,app,copy_function=shutil.copyfile)
resources=app/'Contents/Resources';state=root/'state';exe=app/'Contents/MacOS/OnboardAI'
exe.chmod(0o755);(resources/'policy-core').chmod(0o755)
with socket.socket() as reservation:
 reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
d=json.loads((resources/'deployment.json').read_text());d.update(state=str(state),bridge_port=str(port));(resources/'deployment.json').write_text(json.dumps(d))
subprocess.run(['/usr/bin/xattr','-cr',str(app)],check=True)
subprocess.run(['/usr/bin/codesign','--force','--deep','--sign','-',str(app)],check=True,capture_output=True)
def invoke(mode):return subprocess.run([str(exe),mode],capture_output=True,text=True,timeout=80)
def stop():
 invoke('--stop-service')
 deadline=time.monotonic()+5
 while (state/'native.sock').exists() and time.monotonic()<deadline:time.sleep(.1)
results=[]
try:
 start=invoke('--start-service');assert start.returncode==0,start.stderr
 status=invoke('--probe');assert status.returncode==0,status.stderr
 assert json.loads(status.stdout)['running'] is True
 results.append({'case':'real_native_start_and_authenticated_probe','pass':True})
 again=invoke('--start-service');assert again.returncode==0,again.stderr
 results.append({'case':'already_running_start_is_idempotent','pass':True})
 stop();assert not (state/'native.sock').exists()
 with socket.socket() as occupied:
  occupied.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);occupied.bind(('127.0.0.1',port));occupied.listen()
  failed=invoke('--start-service');assert failed.returncode!=0 and 'already in use' in failed.stderr,failed.stderr
  assert occupied.getsockname()[1]==port
  stopped=invoke('--stop-service');assert stopped.returncode!=0 and 'unrecognized application' in stopped.stderr,stopped.stderr
  assert occupied.getsockname()[1]==port
  assert not (state/'native.sock').exists()
  results.append({'case':'port_conflict_reported_and_socket_cleaned','pass':True})
 # A separate signed app copy simulates the old installed host, including its legacy argv.
 legacy=root/'Previous Onboard.app';shutil.copytree(app,legacy)
 legacyres=legacy/'Contents/Resources';legacystate=root/'previous-state';legacyexe=legacy/'Contents/MacOS/OnboardAI'
 old_archive=args.legacy_archive
 with zipfile.ZipFile(old_archive) as z:legacyhost=z.read('product/integrated/service/host.py')
 assert b'def terminate(signum,frame)' not in legacyhost,'Legacy fixture must predate SIGTERM support.'
 (legacyres/'service/host.py').write_bytes(legacyhost)
 config=json.loads((legacyres/'deployment.json').read_text());config['state']=str(legacystate);(legacyres/'deployment.json').write_text(json.dumps(config))
 subprocess.run(['/usr/bin/xattr','-cr',str(legacy)],check=True)
 subprocess.run(['/usr/bin/codesign','--force','--deep','--sign','-',str(legacy)],check=True,capture_output=True)
 def old_service():
  p=subprocess.Popen(['/usr/bin/python3','-I','-B',str(legacyres/'service/host.py'),'--resources',str(legacyres),'--state',str(legacystate),'--app',str(legacyexe),'--port',str(port)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  deadline=time.monotonic()+10
  while time.monotonic()<deadline:
   probe=subprocess.run([str(legacyexe),'--probe'],capture_output=True,text=True,timeout=5)
   if probe.returncode==0 and json.loads(probe.stdout).get('running'):return p
   assert p.poll() is None,'Legacy fixture exited';time.sleep(.1)
  p.terminate();p.wait();raise AssertionError('Legacy fixture did not start')
 old=None
 try:
  old=old_service();stopped=invoke('--stop-service');assert stopped.returncode==0,stopped.stderr;old.wait(timeout=3)
  results.append({'case':'stop_button_path_stops_verified_legacy_other_copy','pass':True})
  again=invoke('--stop-service');assert again.returncode==0,again.stderr
  results.append({'case':'stop_when_already_stopped_is_idempotent','pass':True})
  old=old_service();start=invoke('--start-service');assert start.returncode==0,start.stderr;old.wait(timeout=3)
  results.append({'case':'start_recovers_verified_legacy_port_owner','pass':True});stop()
  (legacyres/'service/host.py').write_bytes(legacyhost.replace(b"if __name__=='__main__':sys.exit(main())",b"if __name__=='__main__':\n import signal;signal.signal(signal.SIGTERM,signal.SIG_IGN);sys.exit(main())"))
  subprocess.run(['/usr/bin/codesign','--force','--deep','--sign','-',str(legacy)],check=True,capture_output=True)
  old=old_service()
  stopped=invoke('--stop-service');assert stopped.returncode==0,stopped.stderr;old.wait(timeout=3)
  assert old.returncode==-signal.SIGKILL,old.returncode
  results.append({'case':'hung_verified_legacy_process_force_stopped_after_grace','pass':True})
 finally:
  if old and old.poll() is None:old.kill();old.wait(timeout=3)
 (state/'settings.json').write_text('{invalid test settings')
 failed=invoke('--start-service');assert failed.returncode!=0 and 'not valid JSON' in failed.stderr,failed.stderr
 assert (state/'settings.json').read_text()=='{invalid test settings'
 results.append({'case':'invalid_settings_reported_and_preserved','pass':True})
 (state/'settings.json').unlink()
 # Corrupt only the disposable certificate to exercise the actual SSL parser.
 (state/'tls.crt').write_text('invalid test certificate')
 failed=invoke('--start-service');assert failed.returncode!=0 and 'certificate' in failed.stderr,failed.stderr
 results.append({'case':'invalid_tls_reported','pass':True})
 report={'cases':results,'root':str(root),'modelLoads':0,'installedAppModified':False,'port':port}
 (P/'evidence/startup-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
finally:
 if (state/'native.sock').exists():stop()

"""Exercise real native startup/IPC in an isolated app copy; no models or user state."""
import json,pathlib,shutil,socket,subprocess,tempfile,time
P=pathlib.Path(__file__).resolve().parents[1]
source=pathlib.Path(json.loads((P/'build/build-result.json').read_text())['stagedApp'])
root=pathlib.Path(tempfile.mkdtemp(prefix='onboard-startup-',dir='/private/tmp'))
app=root/'Onboard AI.app';shutil.copytree(source,app,copy_function=shutil.copyfile)
resources=app/'Contents/Resources';state=root/'state';exe=app/'Contents/MacOS/OnboardAI'
exe.chmod(0o755);(resources/'policy-core').chmod(0o755)
with socket.socket() as reservation:
 reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
d=json.loads((resources/'deployment.json').read_text());d.update(state=str(state),bridge_port=str(port));(resources/'deployment.json').write_text(json.dumps(d))
subprocess.run(['/usr/bin/xattr','-cr',str(app)],check=True)
subprocess.run(['/usr/bin/codesign','--force','--deep','--sign','-',str(app)],check=True,capture_output=True)
def invoke(mode):return subprocess.run([str(exe),mode],capture_output=True,text=True,timeout=50)
def stop():
 invoke('--stop-service')
 deadline=time.monotonic()+5
 while (state/'native.sock').exists() and time.monotonic()<deadline:time.sleep(.1)
results=[]
try:
 start=invoke('--start-service');assert start.returncode==0,start.stderr
 status=invoke('--probe');assert status.returncode==0,status.stderr
 assert json.loads(status.stdout)['running'] is True
 results.append({'case':'real_native_start_and_authenticated_probe','pass':True})
 again=invoke('--start-service');assert again.returncode==0,again.stderr
 results.append({'case':'already_running_start_is_idempotent','pass':True})
 stop();assert not (state/'native.sock').exists()
 with socket.socket() as occupied:
  occupied.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);occupied.bind(('127.0.0.1',port));occupied.listen()
  failed=invoke('--start-service');assert failed.returncode!=0 and 'already in use' in failed.stderr,failed.stderr
  assert json.loads((state/'startup.json').read_text())['code']=='ADDRESS_IN_USE'
  assert not (state/'native.sock').exists()
  results.append({'case':'port_conflict_reported_and_socket_cleaned','pass':True})
 (state/'settings.json').write_text('{invalid test settings')
 failed=invoke('--start-service');assert failed.returncode!=0 and 'not valid JSON' in failed.stderr,failed.stderr
 assert (state/'settings.json').read_text()=='{invalid test settings'
 results.append({'case':'invalid_settings_reported_and_preserved','pass':True})
 (state/'settings.json').unlink()
 # Corrupt only the disposable certificate to exercise the actual SSL parser.
 (state/'tls.crt').write_text('invalid test certificate')
 failed=invoke('--start-service');assert failed.returncode!=0 and 'certificate' in failed.stderr,failed.stderr
 results.append({'case':'invalid_tls_reported','pass':True})
 report={'cases':results,'root':str(root),'modelLoads':0,'installedAppModified':False,'port':port}
 (P/'evidence/startup-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
finally:
 if (state/'native.sock').exists():stop()

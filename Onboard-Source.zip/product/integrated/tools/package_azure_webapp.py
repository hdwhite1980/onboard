"""Package a staged Teams web app with hoisted production dependencies; never deploy."""
import pathlib,zipfile,json
P=pathlib.Path(__file__).resolve().parents[1]
def main():
 stage=P/'build/teams-actions'
 if not (stage/'node_modules/html-to-text/package.json').is_file():
  raise SystemExit('Install pinned production dependencies in the staging folder first (pnpm --node-linker=hoisted).')
 if not json.loads((stage/'readiness.json').read_text())['registrationConfigured']:
  raise SystemExit('A real bot registration is required.')
 out=stage/'Onboard-Azure-WebApp.zip'
 files=[stage/'server.mjs',stage/'package.json']
 for folder in ('src','public','node_modules'):
  for f in (stage/folder).rglob('*'):
   if f.is_symlink():raise SystemExit('Use hoisted dependencies without symlinks for ZIP deployment.')
   if f.is_file():files.append(f)
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(files):
   if f.suffix in ('.key','.pem') or f.name.startswith('.env'):
    raise SystemExit('Unexpected credential-like file in deployment package.')
   z.write(f,f.relative_to(stage))
 print(str(out));print(f'{len(files)} files; {out.stat().st_size} bytes. Not deployed.')
if __name__=='__main__':main()

"""Export the current integrated application and supporting local AI, without private state."""
import argparse,hashlib,json,pathlib,shutil,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[3]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('destination',type=pathlib.Path);args=ap.parse_args();out=args.destination.resolve();out.mkdir(parents=True,exist_ok=True)
 selected=set()
 for name in ('product/integrated','product/local_ai','product/meeting_briefing/core'):
  for p in (ROOT/name).rglob('*'):
   if p.is_file() and not p.is_symlink() and not any(x in p.relative_to(ROOT/name).parts for x in ('.artifacts','state','build','target','__pycache__','evidence','github-upload')) and p.name!='.DS_Store':selected.add(p.relative_to(ROOT).as_posix())
 selected.update(['product/PRODUCT_DIRECTION.md','product/integrated/evidence/runtime-release.json','product/integrated/evidence/runtime-repair/provenance.json','docs/sprint3a/evidence/candidate2-quality-01/package.json','docs/sprint3a/evidence/calibration-01/runtime-identity.json','docs/sprint3a/evidence/calibration-01/tested-source.json','docs/sprint3a/evidence/calibration-01/interpreter.json','docs/sprint3a/evidence/resource-policy-v2/revision-03/tested-source.json'])
 for name in ('docs/sprint3a/evidence/calibration-01/tested-source.json','docs/sprint3a/evidence/resource-policy-v2/revision-03/tested-source.json'):
  for row in json.loads((ROOT/name).read_text())['files']:
   p=ROOT/row['path']
   if 'calibration-01' in name or p.name in ('supervisor.py','harmless_worker.py','run_harmless.py'):
    if digest(p)!=row['sha256']:raise RuntimeError('Retained verification input changed: '+row['path'])
   selected.add(row['path'])
 inventory={'kind':'Current integrated product, supporting local AI source, dependency notices and retained verification inputs; no account state or weights','files':[]}
 archive=out/'Onboard-Source.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for name in sorted(selected):
   p=ROOT/name
   if p.stat().st_size>20*1024**2:raise RuntimeError('Unexpected large source file: '+name)
   inventory['files'].append({'path':name,'bytes':p.stat().st_size,'sha256':digest(p)});z.write(p,name)
  z.writestr('SOURCE-INVENTORY.json',json.dumps(inventory,indent=2))
 release={'archive':archive.name,'sha256':digest(archive),'bytes':archive.stat().st_size,'sourceFiles':len(selected),'model':'mlx-community/Qwen3-1.7B-4bit','modelRevision':'3b1b1768f8f8cf8351c712464f906e86c2b8269e','modelManifestSHA256':'1721e23c79d4367cb3e12a6811aabd61a8526c511b0f30f7134ecaeb40ef0778','platform':'Apple silicon, macOS 26+','prerequisites':['Apple command-line developer tools (script opens official installer; user completes dialog)','Rust stable minimal toolchain (installed automatically if missing)'],'downloadBytes':1415956899,'installerKind':'Development source installer, not notarized','validation':'Fresh-path setup/build on development Mac passed with verified cached large assets; small real publisher download passed. Second physical Mac acceptance pending.'}
 (out/'source-release.json').write_text(json.dumps(release,indent=2)+'\n')
 for source,destination in [('launch.py','setup.py'),('Diagnose.command','Diagnose.command'),('Setup.command','Setup.command'),('INSTALL.md','INSTALL.md')]:shutil.copyfile(ROOT/'product/integrated/setup'/source,out/destination)
 shutil.copyfile(ROOT/'product/integrated/ACCESS-SETUP.md',out/'ACCESS-SETUP.md')
 (out/'Setup.command').chmod(0o755)
 (out/'Diagnose.command').chmod(0o755)
 print(json.dumps(release,indent=2))
if __name__=='__main__':main()

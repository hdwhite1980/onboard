"""Harmless real OS/TLS boundary checks. No model load, live account or trust changes."""
import hashlib,importlib.util,json,os,pathlib,ssl,subprocess,sys,tempfile,threading
from unittest.mock import patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'));sys.path.insert(0,str(P/'local'))
from encrypted_run import encrypted_run
from isolation import worker_profile
from central_audit import Collector
spec=importlib.util.spec_from_file_location('collector_check',P/'operations/audit_collector.py');collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)
checks=[]
def run(a):return subprocess.run([str(x) for x in a],capture_output=True,check=True)
with tempfile.TemporaryDirectory(prefix='onboard-production-check-') as t:
 root=pathlib.Path(t).resolve()
 with encrypted_run(root,size='128m') as work:
  (work/'fixture').write_text('non-sensitive fixture');assert (work/'fixture').read_text()=='non-sensitive fixture';checks.append('encrypted APFS create/mount/read/write')
 assert not list(root.iterdir());checks.append('encrypted APFS detach/cleanup')
 work=root/'worker';work.mkdir();(work/'fixture').write_text('fixture');forbidden=root/'outside';forbidden.write_text('private fixture')
 code='''import pathlib,socket,subprocess,errno
r=pathlib.Path(%r);f=pathlib.Path(%r)
assert (r/'fixture').read_text()=='fixture'
(r/'output').write_text('fixture')
for action in (lambda:f.read_text(),lambda:f.write_text('bad'),lambda:subprocess.run(['/bin/echo','bad']),lambda:socket.create_connection(('127.0.0.1',9),1)):
 try:action()
 except OSError as e:assert e.errno in (errno.EACCES,errno.EPERM),e
 else:raise AssertionError('Boundary escaped')
'''%(str(work),str(forbidden))
 python=P/'.artifacts/venv/bin/python'
 run(['/usr/bin/sandbox-exec','-p',worker_profile(P.parents[1],work,python),python,'-I','-B','-c',code]);checks.extend(['worker scoped read/write','worker rejects unrelated read/write','worker rejects child process','worker rejects network'])
 # Temporary CA/server/client materials are generated only for this loopback test.
 conf=root/'tls.cnf';conf.write_text('[req]\ndistinguished_name=dn\nx509_extensions=ext\nprompt=no\n[dn]\nCN=localhost\n[ext]\nsubjectAltName=DNS:localhost,IP:127.0.0.1\nbasicConstraints=critical,CA:TRUE\nkeyUsage=critical,digitalSignature,keyEncipherment,keyCertSign\nextendedKeyUsage=serverAuth,clientAuth\n')
 key=root/'key.pem';cert=root/'cert.pem'
 run(['/usr/bin/openssl','req','-x509','-nodes','-newkey','rsa:2048','-days','1','-config',conf,'-keyout',key,'-out',cert]);key.chmod(0o600)
 ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(cert,key);ctx.load_verify_locations(cert);ctx.verify_mode=ssl.CERT_REQUIRED
 fingerprint=hashlib.sha256(ssl.PEM_cert_to_DER_cert(cert.read_text())).hexdigest()
 store=collector.Store(root/'audit');server=collector.Server(('127.0.0.1',0),store,ctx,[fingerprint]);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:
  config={'endpoint':'https://localhost:'+str(server.server_port)+'/v1/events','ca':str(cert),'certificate':str(cert),'private_key':str(key),'proxy':''}
  row={'schema':1,'id':'a'*32,'time':1,'event':'request_accepted','reference':'fixture'}
  with patch('central_audit.proxy_configuration',return_value={}):Collector().send(config,row);Collector().send(config,row)
  assert store.db.execute('SELECT COUNT(*) FROM events').fetchone()[0]==1;checks.append('real mTLS durable receipt and idempotency')
  server.clients=set()
  with patch('central_audit.proxy_configuration',return_value={}):
   try:Collector().send(config,dict(row,id='b'*32))
   except Exception:checks.append('unapproved client certificate rejected')
   else:raise AssertionError('Unapproved collector client')
 finally:server.shutdown();server.server_close();thread.join();store.db.close()
print(json.dumps({'passed':len(checks),'checks':checks,'modelLoaded':False,'customerDataUsed':False,'trustChanged':False},indent=2))

"""Offline build of the native dashboard, Rust policy core and separate application packages."""
import json,os,pathlib,plistlib,shutil,struct,subprocess,tempfile,zipfile,zlib
ROOT=pathlib.Path(__file__).resolve().parents[3];P=ROOT/'product/integrated';B=P/'build';B.mkdir(exist_ok=True)
PYTHON=P/'.artifacts/venv/bin/python';RUST=ROOT/'feasibility/sprint0/.artifacts/rust/bin'
env=dict(os.environ,CARGO_TARGET_DIR=str(B/'rust'))
if (RUST/'cargo').exists():
 env.update(CARGO_HOME=str(ROOT/'feasibility/sprint0/.artifacts/cargo-home'),RUSTC=str(RUST/'rustc'),RUSTDOC=str(RUST/'rustdoc'));cargo=RUST/'cargo'
else:
 cargo=shutil.which('cargo')
 if not cargo:raise SystemExit('Rust is required to build this development app. Install the official Rust toolchain, then run setup again.')
dependency_mode='--locked' if os.environ.get('ONBOARD_FETCH_BUILD_DEPENDENCIES')=='1' else '--offline'
def run(a):subprocess.run([str(x) for x in a],check=True,env=env)
for mode in ('test','build'):run([cargo,mode,dependency_mode,'--release','--manifest-path',P/'core/Cargo.toml'])
staging=pathlib.Path(tempfile.mkdtemp(prefix='onboard-integrated-'));app=staging/'Onboard AI.app';res=app/'Contents/Resources';exe=app/'Contents/MacOS';res.mkdir(parents=True);exe.mkdir()
shutil.copytree(P/'service',res/'service',ignore=shutil.ignore_patterns('__pycache__'));shutil.copytree(P/'web',res/'web');shutil.copyfile(B/'rust/release/onboard-integrated-core',res/'policy-core');(res/'policy-core').chmod(0o755)
(res/'deployment.json').write_text(json.dumps({'python':'/usr/bin/python3','state':str(P/'state')}))
review=P/'evidence/runtime-review.json';qualified='dac1c9a6a4f63831c3ee5564550da7be622a592126f827c02649ea8d0de542bd'
if review.exists():
 r=json.loads(review.read_text())
 if r.get('status')=='QUALIFIED':qualified=r['interpreterSHA256']
(res/'local.json').write_text(json.dumps({'python':str(PYTHON),'qualified_sha256':qualified,'review':str(review),'adapter':str(P/'local'),'root':str(ROOT)}))
(app/'Contents/Info.plist').write_bytes(plistlib.dumps({'CFBundleName':'Onboard AI','CFBundleDisplayName':'Onboard AI','CFBundleIdentifier':'local.onboard.integrated.dev','CFBundleVersion':'3','CFBundleShortVersionString':'0.3.0','CFBundleExecutable':'OnboardAI','CFBundlePackageType':'APPL','LSMinimumSystemVersion':'14.0','NSHighResolutionCapable':True}))
run(['/usr/bin/xcrun','swiftc','-parse-as-library','-swift-version','5','-target','arm64-apple-macos14.0','-O','-module-cache-path',B/'swift-cache','-framework','SwiftUI','-framework','Security',P/'macos/App.swift',P/'macos/Browsers.swift','-o',exe/'OnboardAI'])
def png(size,outline=False):
 rows=[]
 for y in range(size):
  row=bytearray()
  for x in range(size):
   ring=(x-size/2)**2+(y-size/2)**2
   visible=size*.20<ring**.5<size*.37
   row.extend((255,255,255,255 if visible else 0) if outline else (255,255,255,255) if visible else (23,107,121,255))
  rows.append(b'\0'+row)
 def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
 return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(rows)))+chunk(b'IEND',b'')
for n in (32,80,192):(res/'web'/('icon-%d.png'%n)).write_bytes(png(n))
(res/'web/outline-32.png').write_bytes(png(32,True))
run(['/usr/bin/xattr','-cr',app]);run(['/usr/bin/codesign','--force','--deep','--sign','-',app]);run(['/usr/bin/codesign','--verify','--deep','--strict',app])
delivered=B/'Onboard AI.app';shutil.copytree(app,delivered,dirs_exist_ok=True,copy_function=shutil.copyfile);(delivered/'Contents/MacOS/OnboardAI').chmod(0o755);(delivered/'Contents/Resources/policy-core').chmod(0o755);run(['/usr/bin/xattr','-cr',delivered]);delivered_signature=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(delivered)],capture_output=True,text=True)
with zipfile.ZipFile(B/'Onboard-AI.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in app.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(staging))
run(['/usr/bin/python3',P/'tools/package_addins.py','--base-url','https://localhost:38473'])
(B/'build-result.json').write_text(json.dumps({'app':str(delivered),'stagedApp':str(app),'stagedSignature':'ad hoc development; verified','deliveredSignatureVerified':delivered_signature.returncode==0,'deliveredSignatureDiagnostic':delivered_signature.stderr.strip(),'notarized':False,'providerPortable':False,'integrationAcceptance':'Pending configuration and actual Outlook/Teams verification'},indent=2))
print(delivered)

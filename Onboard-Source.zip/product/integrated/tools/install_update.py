"""Offline, administrator-operated signed update. No unsigned/development fallback."""
import argparse,json,os,pathlib,plistlib,stat,tempfile,sys
from production_release import verify,extract_verified,trusted_app,run
from install import install
POLICY=pathlib.Path('/Library/Application Support/Onboard AI/update-policy.json')
def protected(path):
 for p in (path,*path.parents):
  st=p.lstat()
  if st.st_uid!=0 or st.st_mode&0o022 or stat.S_ISLNK(st.st_mode):raise RuntimeError('Update trust must be installed by the administrator and not writable by users')
 if not path.is_file() or path.stat().st_size>65536:raise RuntimeError('Invalid update trust file')
def main():
 p=argparse.ArgumentParser();p.add_argument('package',type=pathlib.Path);a=p.parse_args()
 protected(POLICY);policy=json.loads(POLICY.read_text())
 if set(policy)!={'team','public_key','minimum_build'} or type(policy['minimum_build']) is not int:raise RuntimeError('Invalid update policy')
 key=pathlib.Path(policy['public_key']);protected(key);dest=pathlib.Path('/Applications/Onboard AI.app');floor=policy['minimum_build']
 if dest.exists():
  info=trusted_app(dest,policy['team']);floor=max(floor,int(info['CFBundleVersion']))
  deployment=json.loads((dest/'Contents/Resources/deployment.json').read_text())
  sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
  from service_control import owners
  if owners(pathlib.Path(deployment['state']),int(deployment.get('bridge_port',38473))):raise RuntimeError('The Onboard service address or installation lock is in use. Stop the verified service before updating; nothing was stopped.')
 manifest=verify(a.package,key,policy['team'],floor)
 with tempfile.TemporaryDirectory(prefix='onboard-update-') as t:
  app=extract_verified(a.package,manifest,t);info=trusted_app(app,policy['team'])
  if int(info['CFBundleVersion'])!=manifest['build'] or info['CFBundleShortVersionString']!=manifest['version']:raise RuntimeError('App and manifest versions differ')
  run(['/usr/bin/xcrun','stapler','validate',app]);run(['/usr/sbin/spctl','--assess','--type','execute',app]);install(app,dest)
 print('Verified update installed. Previous app retained for administrator recovery.')
if __name__=='__main__':main()

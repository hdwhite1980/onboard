"""Seal bounded requalification of a pinned runtime, without changing historical evidence."""
import hashlib,json,pathlib,subprocess,datetime
ROOT=pathlib.Path(__file__).resolve().parents[3];P=ROOT/'product/integrated';E=P/'evidence/runtime-repair';python=P/'.artifacts/venv/bin/python'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def validate(directory):
 r=json.loads((directory/'manifest.json').read_text())
 for row in r['files']:assert sha(directory/row['path'])==row['sha256'],row['path']
 return json.loads((directory/'result.json').read_text())
r=subprocess.run([str(python),'-I','-B',str(P/'local/runtime_identity.py')],capture_output=True,text=True,check=True)
(E/'runtime-inventory.jsonl').write_text(r.stdout)
monitor=validate(E/'monitor');worker=validate(E/'worker/qualification-v2')
assert monitor['status']=='MONITOR_LIFECYCLE_QUALIFIED_FOR_TESTED_CONTEXT' and monitor['realPassed']==10
assert worker['status']=='MODEL_WORKER_ABORT_QUALIFIED_FOR_TESTED_CONTEXT' and worker['realPassed']==40
for path in (E/'monitor',E/'worker/qualification-v2'):
 context=json.loads((path/'context.json').read_text());assert context['interpreter']==str(python) and context['interpreterSHA256']==sha(python.resolve())
 for row in json.loads((path/'tested-source.json').read_text())['files']:assert sha(ROOT/row['path'])==row['sha256']
files=list((P/'local').glob('*.py'))+[P/'tools/qualify_runtime.py',E/'provenance.json',E/'monitor/manifest.json',E/'worker/qualification-v2/manifest.json']
old=json.loads((ROOT/'docs/sprint3a/evidence/calibration-01/interpreter.json').read_text())
record={'status':'QUALIFIED','scope':'Pinned local development runtime and same-boundary harmless lifecycle requalification. Product quality and live integration acceptance remain separate.','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'historicalInterpreterSHA256':old['sha256'],'interpreter':str(python),'interpreterSHA256':sha(python.resolve()),'provenance':str(E/'provenance.json'),'inventory':str(E/'runtime-inventory.jsonl'),'monitorCyclesPassed':10,'workerStopCasesPassed':40,'signature':'Verified ad hoc signature on project-owned copy; publisher provenance established by archive digest','historicalEvidenceModified':False,'sharedRuntimeModified':False,'modelLoadsInLifecycleQualification':0,'files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in files]}
(P/'evidence/runtime-review.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))

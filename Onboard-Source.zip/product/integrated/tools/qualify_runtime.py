"""Re-run retained harmless qualification with fresh output and the pinned interpreter.
Only the evidence destination changes; launch, limits, fault controls and assertions stay retained.
"""
import importlib.util,sys,pathlib,json,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[3];P=ROOT/'product/integrated';E=P/'evidence/runtime-repair';B=ROOT/'product/local_ai'
assert pathlib.Path(sys.executable)==P/'.artifacts/venv/bin/python'
mode=sys.argv[1];assert mode in ('monitor','worker')
source=B/('monitor_lifecycle_v3/run_harmless.py' if mode=='monitor' else 'worker_abort_v4/qualify.py')
sys.path.insert(0,str(source.parent))
spec=importlib.util.spec_from_file_location('retained_qualification',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
if mode=='monitor':m.E=E/'monitor';m.E.mkdir()
else:m.c.E=E/'worker';m.c.E.mkdir()
m.main()

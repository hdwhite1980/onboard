"""Development setup: pinned downloads, offline installation, fresh local qualification.

No model generation, cloud requests, account state copying, or resource-policy changes.
"""
import argparse, hashlib, json, os, pathlib, platform, shutil, ssl, subprocess, sys
import tarfile, tempfile, urllib.error, urllib.parse, urllib.request, zipfile

ROOT=pathlib.Path(__file__).resolve().parents[3]
P=ROOT/'product/integrated'
ASSETS=P/'setup'
MODEL_ID='1721e23c79d4367cb3e12a6811aabd61a8526c511b0f30f7134ecaeb40ef0778'

def sha(path):
    h=hashlib.sha256()
    with pathlib.Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def safe_path(root,name):
    parts=pathlib.PurePosixPath(name)
    if parts.is_absolute() or '..' in parts.parts or '\\' in name:
        raise ValueError('Unsafe asset path')
    path=root.joinpath(*parts.parts)
    if not path.resolve().is_relative_to(root.resolve()):raise ValueError('Asset path escapes installation folder')
    if path.is_symlink():raise ValueError('Asset destination cannot be a symbolic link')
    return path

def matches(path,row):
    return path.is_file() and not path.is_symlink() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256']

class HTTPSRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        u=urllib.parse.urlsplit(newurl)
        if u.scheme!='https' or not u.hostname or u.username or u.password:
            raise RuntimeError('Download redirect was not a credential-free HTTPS URL')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def opener(proxy):
    # Use the same truthful proxy checks as the service. PAC is never bypassed.
    sys.path.insert(0,str(P/'service'))
    from network import proxy_configuration, validate_proxy
    return urllib.request.build_opener(urllib.request.ProxyHandler(proxy_configuration(validate_proxy(proxy))),HTTPSRedirect)

def acquire(row,dest,transport,cache=None,proxy=''):
    if matches(dest,row):return
    if dest.exists():raise RuntimeError('Existing asset does not match its pinned checksum: '+str(dest))
    dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    cached=cache/row['destination'] if cache else None
    fd,tmp=tempfile.mkstemp(prefix='.download-',dir=dest.parent);tmp=pathlib.Path(tmp)
    try:
        with os.fdopen(fd,'wb') as target:
            if cached and matches(cached,row):
                with cached.open('rb') as source:shutil.copyfileobj(source,target,1024*1024)
            else:
                url=urllib.parse.urlsplit(row['source'])
                if url.scheme!='https' or not url.hostname or url.username or url.password:raise RuntimeError('Invalid asset URL')
                request=urllib.request.Request(row['source'],headers={'User-Agent':'OnboardAI-Development-Setup/1'})
                if proxy:
                    u=urllib.parse.urlsplit(proxy);request.set_proxy(u.netloc,u.scheme)
                    # An explicit proxy must not be skipped by no_proxy exceptions.
                    transport=urllib.request.build_opener(urllib.request.ProxyHandler({}),HTTPSRedirect)
                with transport.open(request,timeout=30) as source:
                    count=0
                    while True:
                        chunk=source.read(1024*1024)
                        if not chunk:break
                        count+=len(chunk)
                        if count>row['bytes']:raise RuntimeError('Download exceeded expected size')
                        target.write(chunk)
        if not matches(tmp,row):raise RuntimeError('Downloaded asset failed size/checksum verification: '+dest.name)
        tmp.chmod(0o600);tmp.replace(dest)
    finally:
        if tmp.exists():tmp.unlink()

def inventory():
    model_path=ASSETS/'model-manifest.json'
    if sha(model_path)!=MODEL_ID:raise RuntimeError('Model manifest changed')
    model=json.loads(model_path.read_text());base='product/local_ai/.artifacts/store/'+MODEL_ID+'/'
    rows=[dict(r,destination=base+r['path']) for r in model['files'] if r['source'].startswith('https://')]
    for r in json.loads((ROOT/'product/local_ai/runtime/SBOM.json').read_text())['components']:
        rows.append(dict(source=r['source'],sha256=r['sha256'],bytes=r['bytes'],destination='product/local_ai/.artifacts/runtime/wheelhouse/'+r['wheel']))
    runtime=json.loads((P/'evidence/runtime-release.json').read_text())
    rows.append(dict(source=runtime['archiveUrl'],sha256=runtime['archiveSha256'],bytes=runtime['archiveSizeBytes'],destination='product/integrated/.artifacts/runtime-repair/original.tar.xz'))
    return model,rows

def prerequisites():
    if platform.system()!='Darwin' or platform.machine()!='arm64':raise RuntimeError('This local AI build requires an Apple-silicon Mac; Windows and Intel Mac builds are not provided.')
    if int(platform.mac_ver()[0].split('.')[0])<26:raise RuntimeError('The pinned MLX wheels require macOS 26 or later.')
    if len(str(P/'state/native.sock').encode())>103:raise RuntimeError('Choose a shorter installation path, such as ~/OnboardAI.')
    subprocess.run(['/usr/bin/xcrun','--find','swiftc'],check=True,stdout=subprocess.DEVNULL)
    if not shutil.which('cargo') and not (ROOT/'feasibility/sprint0/.artifacts/rust/bin/cargo').exists():raise RuntimeError('Install the official Rust toolchain before this development source build.')
    if shutil.disk_usage(ROOT).free<6*1024**3:raise RuntimeError('At least 6 GiB of free disk space is required for setup and build staging.')

def run(args,env=None):
    subprocess.run([str(x) for x in args],check=True,env=env or dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PIP_DISABLE_PIP_VERSION_CHECK='1'))

def install_pinned_executable(destination, publisher_payload, record):
    """Copy the exact qualified binary; never enroll a machine-generated hash."""
    if hashlib.sha256(publisher_payload).hexdigest()!=record['sourceExecutableSHA256']:
        raise RuntimeError('Publisher Python executable changed')
    bundled=ASSETS/'python-local/python3.12'
    if bundled.is_symlink() or not bundled.is_file() or sha(bundled)!=record['packagedExecutableSHA256']:
        raise RuntimeError('Bundled Python executable failed identity verification')
    if destination.exists():
        if destination.is_symlink() or sha(destination)!=record['packagedExecutableSHA256']:
            raise RuntimeError('Existing Python executable differs. Use a fresh --destination and --cache-root pointing to the earlier installation to reuse verified downloads.')
        return
    fd,temporary=tempfile.mkstemp(prefix='.python-',dir=destination.parent)
    temporary=pathlib.Path(temporary)
    try:
        with os.fdopen(fd,'wb') as target, bundled.open('rb') as source:
            shutil.copyfileobj(source,target)
        if sha(temporary)!=record['packagedExecutableSHA256']:raise RuntimeError('Python copy failed identity verification')
        temporary.chmod(0o755)
        run(['/usr/bin/codesign','--verify','--strict',temporary])
        temporary.replace(destination)
    finally:
        if temporary.exists():temporary.unlink()

def install_python():
    record=json.loads((P/'evidence/runtime-repair/provenance.json').read_text())
    from importlib.util import spec_from_file_location,module_from_spec
    spec=spec_from_file_location('identity',P/'local/runtime_identity.py');module=module_from_spec(spec);spec.loader.exec_module(module)
    if sha(P/'evidence/runtime-repair/provenance.json')!=module.PROVENANCE_SHA256:raise RuntimeError('Runtime provenance changed')
    dest=P/'.artifacts/python';prefix='codex-primary-runtime/dependencies/python/'
    archive=P/'.artifacts/runtime-repair/original.tar.xz'
    if sha(archive)!=record['publisher']['archiveSha256']:raise RuntimeError('Runtime archive changed')
    with tarfile.open(archive) as tar:
        for row in record['sourceFiles']:
            path=safe_path(dest,row['path']);path.parent.mkdir(parents=True,exist_ok=True)
            member=tar.getmember(prefix+row['path'])
            if not member.isfile():raise RuntimeError('Unexpected runtime archive member')
            payload=tar.extractfile(member).read()
            if hashlib.sha256(payload).hexdigest()!=row['sha256']:raise RuntimeError('Publisher runtime member changed')
            if row['path']=='bin/python3.12':
                install_pinned_executable(path,payload,record)
                continue
            if path.exists():
                if sha(path)!=row['sha256']:raise RuntimeError('Existing runtime file changed: '+row['path'])
                continue
            path.write_bytes(payload);path.chmod(0o755 if member.mode&0o111 else 0o644)
        for row in record['symlinks']:
            path=dest/row['path'];target=row['target']
            if not (path.parent/target).resolve().is_relative_to(dest.resolve()):raise RuntimeError('Runtime link escapes installation')
            if path.is_symlink():
                if os.readlink(path)!=target:raise RuntimeError('Runtime link changed')
            elif path.exists():raise RuntimeError('Runtime link destination already exists')
            else:path.symlink_to(target)
    executable=dest/'bin/python3.12'
    run(['/usr/bin/codesign','--verify','--strict',executable])
    if sha(executable)!=record['packagedExecutableSHA256']:raise RuntimeError('Packaged Python identity did not match; local AI remains disabled')
    return executable

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('action',choices=('plan','download','setup'));ap.add_argument('--cache-root',type=pathlib.Path);ap.add_argument('--proxy',default='');ap.add_argument('--install',action='store_true');args=ap.parse_args()
    model,rows=inventory()
    if args.action=='plan':
        print(json.dumps({'model':model['repository'],'revision':model['revision'],'assets':len(rows),'downloadBytes':sum(r['bytes'] for r in rows),'platform':'Apple silicon, macOS 26+','prerequisites':['Apple command line developer tools','Rust toolchain'],'cleanMachineAcceptance':'Not yet verified','plan':[{'path':r['destination'],'bytes':r['bytes'],'sha256':r['sha256'],'source':r['source']} for r in rows]},indent=2));return
    prerequisites()
    if args.action=='setup' and ((P/'evidence/runtime-repair/monitor').exists() or (P/'evidence/runtime-repair/worker').exists()):
        raise RuntimeError('Existing qualification evidence found. Use a fresh source extraction for setup; evidence is never overwritten.')
    transport=opener(args.proxy)
    for i,row in enumerate(rows):
        print('Downloading/verifying asset %d of %d: %s'%(i+1,len(rows),pathlib.Path(row['destination']).name),flush=True)
        acquire(row,safe_path(ROOT,row['destination']),transport,args.cache_root,args.proxy)
    store=ROOT/'product/local_ai/.artifacts/store'/MODEL_ID;store.mkdir(parents=True,exist_ok=True,mode=0o700)
    for row in model['files']:
        if row['source'].startswith('https://'):continue
        source=safe_path(ASSETS/'model-local',row['path']);dest=safe_path(store,row['path'])
        if not matches(source,row):raise RuntimeError('Bundled model license inventory changed')
        dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        if dest.exists() and not matches(dest,row):raise RuntimeError('Installed model license inventory changed')
        if not dest.exists():shutil.copyfile(source,dest);dest.chmod(0o600)
    manifest=store/'manifest.json'
    if manifest.exists() and sha(manifest)!=MODEL_ID:raise RuntimeError('Installed model manifest changed')
    if not manifest.exists():shutil.copyfile(ASSETS/'model-manifest.json',manifest);manifest.chmod(0o600)
    if args.action=='download':print('Verified local AI assets downloaded. The app has not been installed.');return
    python=install_python();venv=P/'.artifacts/venv';run([python,'-B','-m','venv',venv]);python=venv/'bin/python'
    run([python,'-B','-m','pip','install','--no-index','--find-links',ROOT/'product/local_ai/.artifacts/runtime/wheelhouse','--require-hashes','-r',ROOT/'product/local_ai/runtime/requirements.lock'])
    # Remove only bytecode generated in this new private runtime during setup.
    for directory in (P/'.artifacts/python',venv):
        for cache in list(directory.rglob('__pycache__')):
            if cache.is_dir() and not cache.is_symlink():shutil.rmtree(cache)
    run([python,'-I','-B',P/'local/runtime_identity.py'])
    for mode in ('monitor','worker'):run([python,'-I','-B',P/'tools/qualify_runtime.py',mode])
    run([python,'-I','-B',P/'tools/review_runtime.py'])
    run([sys.executable,'-B',P/'tools/build.py'],dict(os.environ,PYTHONDONTWRITEBYTECODE='1',ONBOARD_FETCH_BUILD_DEPENDENCIES='1'))
    if args.install:
        old=pathlib.Path.home()/'Applications/Onboard AI.app/Contents/MacOS/OnboardAI'
        if old.exists():raise RuntimeError('An Onboard app is already installed. The new build is ready, but automatic replacement is disabled. Use the reviewed install.py procedure to update it.')
        run([sys.executable,'-B',P/'tools/install.py'])
        print('Installed development app in ~/Applications/Onboard AI.app. Configure Microsoft 365 and optional API keys in AI Settings.')
    else:print('Build and local runtime qualification complete. Run product/integrated/tools/install.py to install this build.')

if __name__=='__main__':
    try:main()
    except (Exception,KeyboardInterrupt) as error:
        # No raw network response bodies, credentials, or proxy URLs in diagnostics.
        if isinstance(error,(urllib.error.URLError,urllib.error.HTTPError,TimeoutError,ssl.SSLError)):
            sys.path.insert(0,str(P/'service'));from network import failure_for
            print('SETUP STOPPED: '+str(failure_for(error)),file=sys.stderr)
        else:print('SETUP STOPPED: '+str(error),file=sys.stderr)
        sys.exit(1)

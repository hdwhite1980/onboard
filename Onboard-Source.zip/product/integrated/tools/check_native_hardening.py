"""Exercise signed native boundaries without accessing Keychain or the live service."""
import json,os,pathlib,shutil,subprocess,tempfile
P=pathlib.Path(__file__).resolve().parents[1]
def main():
    app=pathlib.Path(json.loads((P/'build/build-result.json').read_text())['stagedApp']);exe=app/'Contents/MacOS/OnboardAI'
    checks={}
    for name,args,body in [('old_vault_cli',['--vault','read','provider-key'],''),('old_decrypt_cli',['--workspace-crypto','open'],''),('missing_ticket',['--vault'],'{}')]:
        r=subprocess.run([str(exe),*args],input=body,capture_output=True,text=True,timeout=8)
        checks[name]=r.returncode!=0 and not r.stdout
    # This child waits for a ticket on stdin. It cannot reach IPC or Keychain.
    child=subprocess.Popen([str(exe),'--vault'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        r=subprocess.run([str(exe),'--verify-native-client',str(child.pid)],capture_output=True,timeout=10)
        checks['same_running_code_accepted']=r.returncode==0
        r=subprocess.run([str(exe),'--verify-native-client',str(os.getpid())],capture_output=True,timeout=10)
        checks['unrelated_running_code_rejected']=r.returncode!=0
        with tempfile.TemporaryDirectory(prefix='onboard-signature-test-') as t:
            changed=pathlib.Path(t)/app.name;shutil.copytree(app,changed,copy_function=shutil.copyfile)
            target=changed/'Contents/Resources/service/host.py';target.write_bytes(target.read_bytes()+b'\n# isolated tamper fixture\n')
            binary=changed/'Contents/MacOS/OnboardAI';binary.chmod(0o755)
            r=subprocess.run([str(binary),'--verify-native-client',str(child.pid)],capture_output=True,timeout=10)
            checks['changed_resource_rejected']=r.returncode!=0
    finally:
        child.terminate();child.communicate(timeout=5)
    report={'checks':checks,'allPassed':all(checks.values()),'accessedKeychain':False,'connectedToLiveService':False}
    (P/'evidence/hardening-native.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
    if not report['allPassed']:raise SystemExit(1)
if __name__=='__main__':main()

"""MLX component checks; run with the pinned local Python. No model or network."""
import json,pathlib,sys
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'local'))
from cache_adapter import verify_vendor,create,record
root=verify_vendor();sys.path.insert(0,str(root.parent))
import mlx.core as mx
from turboquant_mlx.core.codebook import get_codebook,quantize_scalar
from turboquant_mlx.layers.polar_kv_cache import TurboQuantKVCache
from types import SimpleNamespace
for bits in (4,8):
    _,bounds=get_codebook(bits,mx.float32)
    x=mx.concatenate([mx.random.normal((4096,),key=mx.random.key(8)),bounds,mx.array([-mx.inf,mx.inf,mx.nan])])
    original=(x[:,None]>=bounds[None,:]).sum(-1).astype(mx.uint8)
    assert bool(mx.all(original==quantize_scalar(x,bounds)).item()),'Quantizer changed bins'
cache=TurboQuantKVCache(k_bits=8,v_bits=4,group_size=64)
keys=[];values=[]
for count in (128,128,1,127,128):
    x=mx.random.normal((1,8,count,128),key=mx.random.key(count)).astype(mx.float16)
    y=mx.random.normal((1,8,count,128),key=mx.random.key(count+1)).astype(mx.float16)
    keys.append(x);values.append(y);a,b=cache.update_and_fetch(x,y);mx.eval(a,b,cache.state)
x=mx.concatenate(keys,axis=2);y=mx.concatenate(values,axis=2)
def cosine(x,y):
    x=x.astype(mx.float32);y=y.astype(mx.float32)
    return float((mx.sum(x*y)/mx.sqrt(mx.sum(x*x)*mx.sum(y*y))).item())
kcos=cosine(x,a);vcos=cosine(y,b)
assert kcos>.999 and vcos>.99
assert a.shape==x.shape and b.shape==y.shape and cache.offset==512
assert cache.nbytes/(x.nbytes+y.nbytes)<.4
caches=create(SimpleNamespace(layers=[None]*28),'turboquant-k8v4')
assert record(caches)['mode']=='turboquant-k8v4'
for c in caches:
    c.update_and_fetch(keys[0],values[0])
assert record(caches,True)['allocatedBytes']==28*256*8*200
try:caches[0].update_and_fetch(mx.zeros((1,8,2048,128)),mx.zeros((1,8,2048,128)))
except RuntimeError:pass
else:raise AssertionError('Context bound not enforced')
result={'status':'PASS','keyCosine':kcos,'valueCosine':vcos,'storageRatio':cache.nbytes/(x.nbytes+y.nbytes),'sequenceTokens':cache.offset,'quantizerBinsMatchOriginal':True,'contextGuard':True,'vendorHashesVerified':True,'scope':'Numerical component tests only; no model quality claim'}
print(json.dumps(result));(P/'evidence/turboquant-components.json').write_text(json.dumps(result,indent=2)+'\n')

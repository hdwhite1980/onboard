"""Owner-operated Developer ID notarization and detached signed release manifest.
No key/password values on argv. --notary-profile refers to a pre-enrolled Keychain profile.
This does not upload until explicitly invoked with notarize; verification is offline/local.
"""
import argparse,hashlib,json,pathlib,plistlib,re,shutil,subprocess,tempfile,time,zipfile

def run(args,**kw):return subprocess.run([str(x) for x in args],check=True,capture_output=True,**kw)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':')).encode()
def digest(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def trusted_app(app,team):
 if not re.fullmatch('[A-Z0-9]{10}',team):raise ValueError('Expected Apple Team ID')
 # Explicit Developer ID chain and organization Team ID; generic valid/ad-hoc signatures do not suffice.
 requirement='anchor apple generic and certificate 1[field.1.2.840.113635.100.6.2.6] exists and certificate leaf[field.1.2.840.113635.100.6.1.13] exists and certificate leaf[subject.OU] = "'+team+'"'
 run(['/usr/bin/codesign','--verify','--deep','--strict','-R',requirement,app])
 deployment=json.loads((app/'Contents/Resources/deployment.json').read_text())
 if deployment.get('policyMode')!='managed-public':raise ValueError('Production release requires managed policy')
 return plistlib.loads((app/'Contents/Info.plist').read_bytes())
def notarize(app,out,team,profile,key):
 app=pathlib.Path(app).resolve();out=pathlib.Path(out).resolve();out.mkdir(parents=True,exist_ok=False)
 info=trusted_app(app,team)
 with tempfile.TemporaryDirectory(prefix='onboard-notarize-') as t:
  temp=pathlib.Path(t);copy=temp/app.name;shutil.copytree(app,copy,copy_function=shutil.copyfile)
  submit=temp/'submission.zip';run(['/usr/bin/ditto','-c','-k','--keepParent',copy,submit])
  result=json.loads(run(['/usr/bin/xcrun','notarytool','submit',submit,'--keychain-profile',profile,'--wait','--output-format','json']).stdout)
  if result.get('status')!='Accepted':raise RuntimeError('Apple did not accept notarization; no release produced')
  run(['/usr/bin/xcrun','stapler','staple',copy]);run(['/usr/bin/xcrun','stapler','validate',copy]);run(['/usr/sbin/spctl','--assess','--type','execute',copy]);trusted_app(copy,team)
  archive=out/'Onboard-AI.zip';run(['/usr/bin/ditto','-c','-k','--keepParent',copy,archive])
 manifest={'schema':1,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive),'team':team,'bundle':info['CFBundleIdentifier'],'build':int(info['CFBundleVersion']),'version':info['CFBundleShortVersionString'],'created':int(time.time()),'expires':int(time.time())+30*86400,'notarization':result['id']}
 path=out/'release.json';path.write_bytes(canonical(manifest))
 run(['/usr/bin/openssl','dgst','-sha256','-sign',key,'-out',out/'release.sig',path])
 return manifest

def verify(package,key,team,minimum):
 package=pathlib.Path(package)
 with (package/'release.json').open('rb') as f:raw=f.read(8193)
 if len(raw)>8192 or (package/'release.sig').stat().st_size>8192:raise ValueError('Oversized manifest/signature')
 run(['/usr/bin/openssl','dgst','-sha256','-verify',key,'-signature',package/'release.sig',package/'release.json'])
 m=json.loads(raw)
 fields={'schema','archive','bytes','sha256','team','bundle','build','version','created','expires','notarization'}
 if set(m)!=fields or m['schema']!=1 or m['archive']!='Onboard-AI.zip' or m['team']!=team or m['bundle']!='local.onboard.integrated.dev':raise ValueError('Release identity mismatch')
 if type(m['build']) is not int or m['build']<=minimum:raise ValueError('Release rollback or replay rejected')
 if type(m['created']) is not int or type(m['expires']) is not int or not m['created']<=time.time()+300 or not time.time()<m['expires']<=m['created']+30*86400:raise ValueError('Release freshness rejected')
 archive=package/m['archive']
 if type(m['bytes']) is not int or not 0<m['bytes']<=2_000_000_000 or archive.stat().st_size!=m['bytes'] or digest(archive)!=m['sha256']:raise ValueError('Package digest mismatch')
 return m

def extract_verified(package,manifest,destination):
 # ditto zip may contain __MACOSX metadata; reject links, traversal, duplicate normalized names and bombs.
 with zipfile.ZipFile(pathlib.Path(package)/manifest['archive']) as z:
  names=set();total=0
  for e in z.infolist():
   p=pathlib.PurePosixPath(e.filename);mode=(e.external_attr>>16)&0o170000
   if e.filename.startswith('__MACOSX/'):continue
   if p.is_absolute() or '..' in p.parts or not p.parts or p.parts[0]!='Onboard AI.app' or '\\' in e.filename or p.as_posix() in names or mode not in (0,0o100000,0o040000):raise ValueError('Unsafe package entry')
   names.add(p.as_posix());total+=e.file_size
   if len(names)>10000 or total>2_000_000_000:raise ValueError('Package expansion limit')
   target=pathlib.Path(destination).joinpath(*p.parts)
   if e.is_dir():target.mkdir(parents=True,exist_ok=True)
   else:
    target.parent.mkdir(parents=True,exist_ok=True)
    with z.open(e) as source,target.open('xb') as dest:shutil.copyfileobj(source,dest)
    target.chmod((e.external_attr>>16)&0o777 or 0o600)
 if digest(pathlib.Path(package)/manifest['archive'])!=manifest['sha256']:raise ValueError('Package changed during extraction')
 return pathlib.Path(destination)/'Onboard AI.app'
def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='op',required=True)
 n=sub.add_parser('notarize')
 for field in ('app','out','team','notary-profile','signing-key'):n.add_argument('--'+field,required=True)
 v=sub.add_parser('verify')
 for field in ('package','public-key','team'):v.add_argument('--'+field,required=True)
 v.add_argument('--minimum-build',type=int,required=True);a=p.parse_args()
 if a.op=='notarize':result=notarize(a.app,a.out,a.team,a.notary_profile,a.signing_key)
 else:result=verify(a.package,a.public_key,a.team,a.minimum_build)
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()

"""Prepare a machine-local development CA and localhost leaf; never install trust.

The caller must explicitly approve trust and replacement separately. Never ship
these generated private keys, or use this development CA for remote services.
"""
import argparse
import hashlib
import json
import os
import pathlib
import subprocess
import tempfile


def prepare(parent):
    parent = pathlib.Path(parent)
    parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    dest = pathlib.Path(tempfile.mkdtemp(prefix='localhost-tls-', dir=parent))
    dest.chmod(0o700)
    root = dest / 'root.cnf'
    root.write_text('''[req]
distinguished_name=dn
x509_extensions=ext
prompt=no
[dn]
CN=Onboard Local Development CA
[ext]
basicConstraints=critical,CA:TRUE,pathlen:0
keyUsage=critical,keyCertSign,cRLSign
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid:always
nameConstraints=critical,permitted;DNS:localhost
''')
    leaf = dest / 'leaf.cnf'
    leaf.write_text('''[req]
distinguished_name=dn
prompt=no
[dn]
CN=localhost
[ext]
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth
subjectAltName=DNS:localhost
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid,issuer
''')

    def run(*args):
        subprocess.run(['/usr/bin/openssl', *map(str, args)], check=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)

    old_mask = os.umask(0o077)
    try:
        run('req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '30',
            '-keyout', dest/'root.key', '-out', dest/'root.crt', '-config', root)
        run('req', '-new', '-newkey', 'rsa:2048', '-nodes', '-keyout', dest/'tls.key',
            '-out', dest/'leaf.csr', '-config', leaf)
        run('x509', '-req', '-in', dest/'leaf.csr', '-CA', dest/'root.crt',
            '-CAkey', dest/'root.key', '-CAcreateserial', '-days', '30', '-sha256',
            '-extfile', leaf, '-extensions', 'ext', '-out', dest/'tls.crt')
        run('verify', '-CAfile', dest/'root.crt', '-purpose', 'sslserver', dest/'tls.crt')
    finally:
        os.umask(old_mask)
    import ssl
    cert_der = ssl.PEM_cert_to_DER_cert((dest/'root.crt').read_text())
    report = {'directory': str(dest.resolve()), 'trusted': False, 'activated': False,
              'rootSHA256': hashlib.sha256(cert_der).hexdigest(),
              'names': ['localhost'], 'developmentOnly': True}
    (dest/'prepared.json').write_text(json.dumps(report, indent=2)+'\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-parent', required=True)
    print(json.dumps(prepare(parser.parse_args().output_parent), indent=2))

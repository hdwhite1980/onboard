"""Real weather or isolated proxy-failure verification. No mock successful providers."""
import json,pathlib,sys,threading,time,socketserver
from unittest.mock import patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from online import weather
from network import request,NetworkFailure
E=P/'evidence/ask-ai';E.mkdir(exist_ok=True)
if sys.argv[1]=='weather':
 r=weather('What is the weather in Washington, DC?',{'weather_units':'fahrenheit'},threading.Event());(E/'real-weather.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
elif sys.argv[1]=='proxy':
 seen=[]
 class Block(socketserver.StreamRequestHandler):
  def handle(self):
   seen.append(self.rfile.readline(4096).decode().split(' ')[0]);self.wfile.write(b'HTTP/1.1 407 Proxy Authentication Required\r\nProxy-Authenticate: Basic realm="Onboard-test"\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')
 with socketserver.TCPServer(('127.0.0.1',0),Block) as server:
  thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   try:
    with patch('urllib.request.proxy_bypass',return_value=True):request('https://api.open-meteo.com/v1/forecast',proxy='http://127.0.0.1:'+str(server.server_address[1]))
   except NetworkFailure as error:
    assert error.code=='PROXY_AUTH_REQUIRED';assert seen==['CONNECT'];r={'pass':True,'test':'Controlled local proxy refusal, not a customer proxy','actualProxyConnections':len(seen),'code':error.code,'message':str(error),'directRetry':False,'explicitProxyOverridesSystemBypass':True};(E/'proxy-failure.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
   else:raise AssertionError('Proxy refusal not enforced')
  finally:server.shutdown();thread.join(timeout=2)
else:raise SystemExit('Choose weather or proxy')

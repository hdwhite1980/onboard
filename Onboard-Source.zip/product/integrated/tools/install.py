"""Verified candidate installation with a durable journal and conservative crash recovery."""
import contextlib,datetime,fcntl,json,os,pathlib,shutil,stat,subprocess,tempfile
P=pathlib.Path(__file__).resolve().parents[1]
def verify(path):subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(path)],check=True,capture_output=True)
def sync_dir(path):
 fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def write_journal(path,row):
 fd,temp=tempfile.mkstemp(prefix='.onboard-journal-',dir=path.parent)
 try:
  with os.fdopen(fd,'w') as f:json.dump(row,f);f.flush();os.fsync(f.fileno())
  os.replace(temp,path);sync_dir(path.parent)
 finally:
  if os.path.exists(temp):os.unlink(temp)
def recover(dest,journal):
 if not journal.exists() and not journal.is_symlink():return
 st=journal.lstat()
 if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or st.st_mode&0o077 or st.st_size>4096:raise RuntimeError('Unsafe installation recovery journal')
 row=json.loads(journal.read_text())
 if set(row)!={'destination','stage','backup'} or row['destination']!=dest.name:raise RuntimeError('Invalid installation recovery journal')
 if not isinstance(row['stage'],str) or '/' in row['stage'] or not row['stage'].startswith('.onboard-install-'):raise RuntimeError('Invalid installation stage')
 if row['backup'] is not None and (not isinstance(row['backup'],str) or '/' in row['backup'] or not row['backup'].startswith('Onboard AI.previous-') or not row['backup'].endswith('.app')):raise RuntimeError('Invalid installation backup')
 stage=dest.parent/row['stage'];backup=dest.parent/row['backup'] if row['backup'] else None
 if any(p.is_symlink() for p in (dest,stage,*([backup] if backup else []))):raise RuntimeError('Recovery refuses symlinks')
 if dest.exists():
  try:verify(dest)
  except Exception:
   if not backup or not backup.exists():raise RuntimeError('Recovery requires administrator review; installed app could not be verified')
   verify(backup);stage.mkdir(mode=0o700,exist_ok=True);dest.rename(stage/'rejected.app');backup.rename(dest)
 elif backup and backup.exists():verify(backup);backup.rename(dest)
 elif (stage/dest.name).exists():
  # The old app may not have existed. Do not auto-publish an uncommitted candidate.
  pass
 elif backup:raise RuntimeError('Interrupted installation has no recoverable application')
 sync_dir(dest.parent)
 if stage.exists():shutil.rmtree(stage)
 journal.unlink();sync_dir(dest.parent)

@contextlib.contextmanager
def installation_lock(parent):
 fd=os.open(parent/'.onboard-install.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
 try:
  st=os.fstat(fd)
  if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or st.st_mode&0o077 or st.st_nlink!=1:raise RuntimeError('Unsafe installation lock')
  fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);yield
 finally:os.close(fd)
def install(source,dest):
 source=pathlib.Path(source);dest=pathlib.Path(dest)
 if source.is_symlink() or dest.is_symlink():raise RuntimeError('App installation paths must not be symbolic links.')
 dest.parent.mkdir(parents=True,exist_ok=True)
 # Every ancestor is checked; an installation must never traverse a replaced symlink.
 for ancestor in (dest.parent,*dest.parent.parents):
  if ancestor.is_symlink() and not (str(ancestor) in ('/var','/tmp') and os.readlink(ancestor)=='private'+str(ancestor)):raise RuntimeError('Installation parent is a symlink')
 with installation_lock(dest.parent):
  journal=dest.parent/'.onboard-install-journal.json';recover(dest,journal);verify(source)
  stage=pathlib.Path(tempfile.mkdtemp(prefix='.onboard-install-',dir=dest.parent));candidate=stage/dest.name
  backup=None;published=False
  try:
   shutil.copytree(source,candidate,copy_function=shutil.copyfile)
   for binary in ('Contents/MacOS/OnboardAI','Contents/Resources/policy-core'):(candidate/binary).chmod(0o755)
   verify(candidate)
   # Flush the candidate before making any rename durable.
   for file in candidate.rglob('*'):
    if file.is_file():
     with file.open('rb') as f:os.fsync(f.fileno())
   for directory in sorted((x for x in candidate.rglob('*') if x.is_dir()),key=lambda x:len(x.parts),reverse=True):sync_dir(directory)
   sync_dir(candidate)
   if dest.exists():backup=dest.with_name('Onboard AI.previous-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.app')
   write_journal(journal,{'destination':dest.name,'stage':stage.name,'backup':backup.name if backup else None})
   if backup:dest.rename(backup);sync_dir(dest.parent)
   candidate.rename(dest);published=True;sync_dir(dest.parent);verify(dest)
   journal.unlink();sync_dir(dest.parent)
   return {'app':str(dest),'backup':str(backup) if backup else None,'signature':'verified; publisher/notarization qualification is separate'}
  except Exception:
   if published:dest.rename(stage/'failed.app')
   if backup and backup.exists():backup.rename(dest)
   sync_dir(dest.parent)
   if journal.exists():journal.unlink();sync_dir(dest.parent)
   raise
  finally:shutil.rmtree(stage)
def main():
 r=json.loads((P/'build/build-result.json').read_text())
 result=install(pathlib.Path(r['stagedApp']),pathlib.Path.home()/'Applications/Onboard AI.app')
 result.update(notarized=False,requiresRepositoryRuntime=True)
 (P/'evidence/installation.json').write_text(json.dumps(result,indent=2));print(result['app'])
if __name__=='__main__':main()

"""Install the verified development build into this user's Applications directory."""
import json,pathlib,shutil,subprocess,datetime
P=pathlib.Path(__file__).resolve().parents[1];r=json.loads((P/'build/build-result.json').read_text());source=pathlib.Path(r['stagedApp']);dest=pathlib.Path.home()/'Applications/Onboard AI.app'
subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(source)],check=True)
dest.parent.mkdir(exist_ok=True)
if dest.exists():
 backup=dest.with_name('Onboard AI.previous-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'.app');dest.rename(backup)
shutil.copytree(source,dest,copy_function=shutil.copyfile)
for p in (dest/'Contents/MacOS/OnboardAI',dest/'Contents/Resources/policy-core'):p.chmod(0o755)
subprocess.run(['/usr/bin/xattr','-cr',str(dest)],check=True)
subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(dest)],check=True)
(P/'evidence/installation.json').write_text(json.dumps({'app':str(dest),'signature':'verified ad hoc development','notarized':False,'requiresRepositoryRuntime':True},indent=2));print(dest)

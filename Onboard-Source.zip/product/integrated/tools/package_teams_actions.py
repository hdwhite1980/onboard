"""Stage the Teams action handler and web UI. Never register, trust, or deploy."""
import argparse
import json
import pathlib
import shutil
import urllib.parse
import uuid
import zipfile

P = pathlib.Path(__file__).resolve().parents[1]


def make_manifest(base_manifest, origin, bot_id):
    bot_id = str(uuid.UUID(bot_id))
    manifest = json.loads(json.dumps(base_manifest))
    manifest['version'] = '0.6.1'
    for key in ('websiteUrl', 'privacyUrl', 'termsOfUseUrl'):
        manifest['developer'][key] = origin + '/teams.html'
    for tab in manifest['staticTabs']:
        tab.update(contentUrl=origin+'/teams.html', websiteUrl=origin+'/teams.html')
    for tab in manifest['configurableTabs']:
        tab['configurationUrl'] = origin+'/teams.html?configure=1'
    manifest['validDomains'] = [urllib.parse.urlsplit(origin).hostname, 'localhost']
    manifest['composeExtensions'] = [{'botId': bot_id, 'canUpdateConfiguration': False, 'commands': [
        {'id': command, 'type': 'action', 'title': title, 'description': description,
         'fetchTask': True, 'context': ['message', 'compose']}
        for command, title, description in (
            ('summarize', 'Summarize', 'Summarize a selected message with Onboard.'),
            ('reply', 'Suggest a reply', 'Prepare a reply to review and insert as a draft.'),
            ('outlook', 'Send to Outlook', 'Prepare a reviewed email draft in your local Outlook add-in. Nothing is sent automatically.'),
        )]}]
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-url', required=True, help='Organization-approved HTTPS origin; no default hosting provider.')
    parser.add_argument('--bot-id')
    parser.add_argument('--tenant-id')
    parser.add_argument('--cloud',choices=('commercial','gcc-high','dod'),default='commercial')
    args = parser.parse_args()
    u = urllib.parse.urlsplit(args.base_url)
    if u.scheme != 'https' or not u.hostname or u.hostname == 'localhost' or u.port or u.username or u.password or u.path not in ('', '/') or u.query or u.fragment:
        parser.error('An exact public HTTPS origin is required.')
    if bool(args.bot_id) != bool(args.tenant_id):
        parser.error('Supply both the registered bot application ID and allowed tenant ID.')
    if args.bot_id:
        try:
            args.bot_id, args.tenant_id = str(uuid.UUID(args.bot_id)), str(uuid.UUID(args.tenant_id))
        except ValueError:
            parser.error('Bot and tenant IDs must be UUIDs from your real registration.')
    origin = 'https://' + u.hostname
    target = P/'build/teams-actions'
    if target.exists():
        shutil.rmtree(target)
    source = P/'teams-actions'
    shutil.copytree(source, target, ignore=shutil.ignore_patterns('node_modules', '.netlify', 'public', '.env*'))
    public = target/'public'
    public.mkdir()
    from package_hosted import ASSETS
    for name in ASSETS:
        path = P/'web'/name
        if not path.exists():
            path = P/'build/Onboard AI.app/Contents/Resources/web'/name
        shutil.copyfile(path, public/name)
    (target/'HTTPS-REQUIRED.txt').write_text('Deploy only behind organization-approved HTTPS. The Node server serves allowlisted public assets with CSP and Microsoft frame ancestors. Azure terminates HTTPS; set BIND_ADDRESS=0.0.0.0 and use node server.mjs. This staging operation does not configure TLS or deploy a service.\n')
    (public/'teams-actions-config.js').write_text("'use strict';\nglobalThis.OnboardActionConfig=Object.freeze("+json.dumps({'botId':args.bot_id or ''})+");\n")
    status = {'version':'0.6.1', 'deployed':False, 'liveTeamsVerified':False,
              'registrationConfigured':bool(args.bot_id), 'cloud':args.cloud,
              'messagingEndpoint':origin+'/api/teams/actions',
              'pending':['Real bot registration and tenant ID'] if not args.bot_id else ['Deploy handler, configure Azure Bot endpoint and Teams channel, upload package, verify in Teams'],
              'localConnection':'Existing localhost certificate, same-account sign-in, and native approval are still required.'}
    if args.bot_id:
        (target/'deployment-environment.json').write_text(json.dumps({
            'ONBOARD_TEAMS_BOT_ID':args.bot_id, 'ONBOARD_TEAMS_TENANT_ID':args.tenant_id,
            'ONBOARD_TEAMS_ORIGIN':origin, 'ONBOARD_TEAMS_CLOUD':args.cloud}, indent=2)+'\n')
        with zipfile.ZipFile(P/'build/addins/Onboard-Teams.zip') as z:
            manifest = make_manifest(json.loads(z.read('manifest.json')), origin, args.bot_id)
            with zipfile.ZipFile(target/'Onboard-Teams-Actions.zip','w',zipfile.ZIP_DEFLATED) as out:
                out.writestr('manifest.json',json.dumps(manifest,indent=2))
                for name in ('color.png','outline.png'):
                    out.writestr(name,z.read(name))
    (target/'readiness.json').write_text(json.dumps(status,indent=2)+'\n')
    print(target)
    print('Staged only. '+('Package generated with supplied registration IDs.' if args.bot_id else 'No installable Teams action manifest generated: registration is required.'))


if __name__ == '__main__':
    main()

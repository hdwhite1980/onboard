"""Stage only public add-in assets for static HTTPS hosting; never package local state."""
import argparse,hashlib,json,pathlib,shutil,urllib.parse,zipfile
P=pathlib.Path(__file__).resolve().parents[1]
ASSETS=('word.html','word.js','word-host.js','labels.js','document-ui.js','app.js','handoffs.js','messages.js','outlook-host.js','teams-host.js','teams-actions.js','teams-actions-config.js','outlook.html','teams.html','style.css','icon-192.png','icon-32.png','icon-80.png','outline-32.png')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--base-url',required=True);a=ap.parse_args()
 u=urllib.parse.urlsplit(a.base_url)
 if u.scheme!='https' or not u.hostname or u.hostname=='localhost' or u.port or u.username or u.password or u.path not in ('','/') or u.query or u.fragment:ap.error('Use an exact HTTPS public origin.')
 origin='https://'+u.hostname
 dest=P/'build/hosting'/u.hostname;web=dest/'public';web.mkdir(parents=True,exist_ok=True)
 source=P/'build/Onboard AI.app/Contents/Resources/web'
 for name in ASSETS:shutil.copyfile(source/name,web/name)
 (web/'index.html').write_text('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Onboard AI</title><link rel="stylesheet" href="style.css"></head><body><h1>Onboard AI</h1><p>AI assistance in Outlook and Microsoft Teams, connected to your installed Onboard AI app.</p><p>Open Onboard from its add-in inside Outlook or Teams. Sign in to the same Microsoft account in Onboard and approve the connection on your Mac.</p><p>This development deployment requires the local Onboard service. Hosting this page does not establish a working local connection or authorize access to your messages.</p></body></html>')
 csp="default-src 'self'; script-src 'self' https://appsforoffice.microsoft.com https://res.cdn.office.net https://ajax.aspnetcdn.com/ajax/3.5/MicrosoftAjax.js; style-src 'self'; connect-src 'self' https://localhost:38473; img-src 'self' data:; frame-ancestors https://*.officeapps.live.com https://*.office.com https://*.office365.us https://*.office365.com https://*.outlook.com https://teams.microsoft.us https://*.teams.microsoft.us https://teams.microsoft.com https://*.teams.microsoft.com https://outlook.office.com https://outlook-sdf.office.com https://*.cloud.microsoft; object-src 'none'; base-uri 'none'; form-action 'none'"
 (web/'_headers').write_text('/*\n  Content-Security-Policy: '+csp+'\n  Referrer-Policy: no-referrer\n  X-Content-Type-Options: nosniff\n  Cache-Control: no-store\n')
 names=set(ASSETS)|{'index.html','_headers'}
 if {f.name for f in web.iterdir()}!=names:raise RuntimeError('Unexpected file in public hosting folder')
 with zipfile.ZipFile(dest/'Onboard-Hosted-Web.zip','w',zipfile.ZIP_DEFLATED) as z:
  for name in sorted(names):z.write(web/name,name)
 with zipfile.ZipFile(P/'build/addins/Onboard-Teams.zip') as z:
  manifest=json.loads(z.read('manifest.json'));icons={name:z.read(name) for name in ('color.png','outline.png')}
 for key in ('websiteUrl','privacyUrl','termsOfUseUrl'):manifest['developer'][key]=origin+'/teams.html'
 for tab in manifest['staticTabs']:tab.update(contentUrl=origin+'/teams.html',websiteUrl=origin+'/teams.html')
 for tab in manifest['configurableTabs']:tab['configurationUrl']=origin+'/teams.html?configure=1'
 manifest.update(validDomains=[u.hostname,'localhost'])
 with zipfile.ZipFile(dest/'Onboard-Teams-Hosted.zip','w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('manifest.json',json.dumps(manifest,indent=2))
  for name,raw in icons.items():z.writestr(name,raw)
 data={'origin':origin,'published':False,'teamsVersion':manifest['version'],'localBridge':'https://localhost:38473','localConnectionVerified':False,'assets':[{'name':name,'sha256':hashlib.sha256((web/name).read_bytes()).hexdigest()} for name in sorted(names)]}
 (dest/'hosting-build.json').write_text(json.dumps(data,indent=2)+'\n');print(dest)
if __name__=='__main__':main()

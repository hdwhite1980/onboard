"""Explicit public test inputs; guarded one-at-a-time local comparison, no cloud.
Run from the source checkout. Does not change saved settings or retain user input.
"""
import json,pathlib,sys,threading,time
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from local_engine import generate
cases=[('summary','Summarize in one sentence: The library opens at 9 am on Monday. Its reading room closes at 5 pm.'),
       ('extraction','Extract only the date and owner: The public workshop is scheduled for October 8, 2026. Alex owns the agenda. Catering is not confirmed.'),
       ('medium-summary',('Public handbook: The library opens at 9 am on Monday and closes at 5 pm. Books may be borrowed for two weeks. The reading room is quiet. Workshops require registration. There is no workshop on Tuesday.\n\n'*12)+'Summarize the rules in two sentences. Do not invent a Tuesday workshop.')]
results=[]
for name,text in cases:
    for mode in ('standard','turboquant-k8v4'):
        start=time.monotonic()
        try:
            output=generate(P/'build/Onboard AI.app/Contents/Resources',[{'role':'system','content':'Answer concisely from the provided public test text only.'},{'role':'user','content':text}],threading.Event(),cache_mode=mode)
            result={'case':name,'mode':mode,'status':'generated','output':output}
        except Exception as error:result={'case':name,'mode':mode,'status':'stopped','message':str(error)}
        result['wallSeconds']=time.monotonic()-start
        diag=P/'state/last-local-run.json'
        if diag.exists():result['diagnostics']=json.loads(diag.read_text())
        results.append(result);print(json.dumps(result),flush=True)
        (P/'evidence/turboquant-model-comparison.json').write_text(json.dumps({'scope':'Explicit public control inputs. No real mail, no remote AI, not full model quality qualification.','runs':results},indent=2)+'\n')
        if result['status']!='generated':raise SystemExit('Comparison stopped; resolve the guard before another run.')

"""Create a project-owned runtime from a checksum-verified publisher archive.
Never alters Codex's runtime, retained venv, or historical evidence.
"""
import hashlib,json,os,pathlib,shutil,subprocess,tarfile
ROOT=pathlib.Path(__file__).resolve().parents[3];P=ROOT/'product/integrated';A=P/'.artifacts/runtime-repair';DEST=P/'.artifacts/python';E=P/'evidence/runtime-repair';E.mkdir(parents=True,exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
manifest=json.loads((P/'evidence/runtime-release.json').read_text())
assert manifest['archiveSha256']=='440347ef30d7560dd79a272f0886b4d3c648c20982019049dadcf07a88a62a26'
archive=A/'original.tar.xz';assert sha(archive)==manifest['archiveSha256'] and archive.stat().st_size==manifest['archiveSizeBytes']
DEST.mkdir(parents=True,exist_ok=True);prefix='codex-primary-runtime/dependencies/python/'
rows=[];links=[]
with tarfile.open(archive) as t:
 for m in t:
  if not m.name.startswith(prefix):continue
  rel=pathlib.PurePosixPath(m.name[len(prefix):]);assert not rel.is_absolute() and '..' not in rel.parts
  # The model environment is installed only from its previously pinned wheelhouse.
  if 'site-packages' in rel.parts or '__pycache__' in rel.parts or rel.suffix=='.pyc':continue
  out=DEST/rel
  if m.isdir():out.mkdir(parents=True,exist_ok=True);continue
  out.parent.mkdir(parents=True,exist_ok=True)
  if m.issym():links.append((out,m.linkname));continue
  assert m.isfile(),m.name
  with t.extractfile(m) as src:
   payload=src.read()
  if out.exists():assert out.read_bytes()==payload
  else:out.write_bytes(payload)
  out.chmod(0o755 if m.mode&0o111 else 0o644)
  rows.append({'path':rel.as_posix(),'sha256':sha(out),'bytes':out.stat().st_size})
relocations=[]
for out,target in links:
 if pathlib.Path(target).is_absolute():
  fixed=pathlib.Path(target).name;assert (out.parent/fixed).is_file()
  relocations.append({'path':str(out.relative_to(DEST)),'original':target,'replacement':fixed});target=fixed
 assert (out.parent/target).resolve().is_relative_to(DEST.resolve())
 if out.is_symlink():assert os.readlink(out)==target
 else:out.symlink_to(target)
python=DEST/'bin/python3.12';before=sha(python)
check=subprocess.run(['/usr/bin/codesign','--verify','--strict',str(python)],capture_output=True,text=True)
assert before=='f91a7185b6b453b827a36d33017ccbd50c21187a551212bc0b2c99c7ca0428f2'
# Local ad-hoc integrity signature; publisher provenance comes from archive digest, not this signature.
subprocess.run(['/usr/bin/xattr','-c',str(python)],check=True)
subprocess.run(['/usr/bin/codesign','--force','--sign','-',str(python)],check=True)
subprocess.run(['/usr/bin/codesign','--verify','--strict',str(python)],check=True)
record={'status':'PINNED_NOT_YET_QUALIFIED','publisher':manifest,'sourceExecutableSHA256':before,'sourceSignatureExitCode':check.returncode,'sourceSignatureDiagnostic':check.stderr.strip(),'packagedExecutableSHA256':sha(python),'signature':'Ad hoc local integrity signature; not notarized or publisher signed','changes':['Excluded global site-packages; use previously pinned model wheels','Replaced invalid upstream executable signature on project-owned copy only'],'sourceFiles':rows,'symlinks':[{'path':str(p.relative_to(DEST)),'target':os.readlink(p)} for p,v in links],'relocatedDocumentationLinks':relocations,'sharedRuntimeModified':False,'historicalEvidenceModified':False}
(E/'provenance.json').write_text(json.dumps(record,indent=2))
print(json.dumps({k:v for k,v in record.items() if k not in ('sourceFiles','symlinks')}))

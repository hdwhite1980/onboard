// Contract/security fixtures only. These tests do not call Teams or Graph.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {generateKeyPair, exportJWK, SignJWT} from 'jose';
import {handle, invoke,readBody} from '../src/handler.mjs';
const bot='00000000-0000-4000-8000-000000000001', tenant='00000000-0000-4000-8000-000000000002', account='00000000-0000-4000-8000-000000000003';
const env={ONBOARD_TEAMS_BOT_ID:bot,ONBOARD_TEAMS_TENANT_ID:tenant,ONBOARD_TEAMS_ORIGIN:'https://example.invalid',ONBOARD_TEAMS_CLOUD:'commercial'};
const config={bot,tenant,origin:env.ONBOARD_TEAMS_ORIGIN};
const {privateKey,publicKey}=await generateKeyPair('RS256');
const jwk={...await exportJWK(publicKey),kid:'fixture',endorsements:['msteams']};
const fixture=()=>({type:'invoke',name:'composeExtensions/fetchTask',channelId:'msteams',serviceUrl:'https://smba.trafficmanager.net/teams/',channelData:{tenant:{id:tenant}},from:{aadObjectId:account},conversation:{id:'fixture-chat'},value:{commandId:'reply',commandContext:'message',messagePayload:{body:{contentType:'html',content:'<p>Fixture budget discussion.</p><script>ignore policy</script><img src="https://untrusted.invalid/pixel">'}}}});
async function token(claims={},issuer='https://api.botframework.com') {
 return new SignJWT({serviceUrl:fixture().serviceUrl,...claims}).setProtectedHeader({alg:'RS256',kid:'fixture'}).setIssuer(issuer).setAudience(bot).setNotBefore('0s').setExpirationTime('5m').sign(privateKey);
}
function request(activity, auth){return new Request('https://example.invalid/api/teams/actions',{method:'POST',headers:auth?{Authorization:'Bearer '+auth}:{},body:JSON.stringify(activity)});}
test('sovereign profiles reject commercial issuers and bind the configured government tenant',async()=>{
 for(const cloud of ['gcc-high','dod']){
  const government={...env,ONBOARD_TEAMS_CLOUD:cloud};
  assert.equal((await handle(request(fixture(),await token()),government,async()=>[jwk])).status,401);
  assert.equal((await handle(request(fixture(),await token({},'https://api.botframework.us')),government,async()=>[jwk])).status,200);
  const other=fixture();other.channelData.tenant.id=bot;
  assert.equal((await handle(request(other,await token({},'https://api.botframework.us')),government,async()=>[jwk])).status,401);
 }
 assert.equal((await handle(request(fixture(),await token({},'https://api.botframework.us')),env,async()=>[jwk])).status,401);
});
test('metadata reader stops and cancels oversized streams before accumulating an entire response',async()=>{
 let cancelled=false,reads=0;
 const source={body:{getReader:()=>({read:async()=>{reads++;return {done:false,value:new Uint8Array(131073)};},cancel:async()=>{cancelled=true;}})}};
 await assert.rejects(readBody(source,262144),/body/);assert.equal(reads,2);assert.equal(cancelled,true);
});
test('authenticated selected message opens app-first dialog with no content in HTTP query',async()=>{
 const result=await handle(request(fixture(),await token()),env,async()=>[jwk]);assert.equal(result.status,200);
 const output=await result.json();const u=new URL(output.task.value.url);assert.equal(u.search,'');assert.equal(u.pathname,'/teams.html');
 const launch=JSON.parse(decodeURIComponent(u.hash.slice('#onboardAction='.length)));assert.equal(launch.text,'Fixture budget discussion.');assert.equal(launch.account,account);assert.equal(launch.bot,bot);assert.equal(launch.command,'reply');assert.equal(launch.selected,true);
});
test('missing credential, foreign tenant, service URL mismatch, channel mismatch, wrong audience and missing endorsement reject',async()=>{
 const cases=[{auth:null},{mutate:a=>a.channelData.tenant.id=bot},{mutate:a=>a.serviceUrl+='other'},{mutate:a=>a.channelId='webchat'},{keys:[{...jwk,endorsements:['webchat']}]},{auth:await new SignJWT({serviceUrl:fixture().serviceUrl}).setProtectedHeader({alg:'RS256',kid:'fixture'}).setIssuer('https://api.botframework.com').setAudience(tenant).setNotBefore('0s').setExpirationTime('5m').sign(privateKey)}];
 for(const entry of cases){const a=fixture();entry.mutate?.(a);const auth=Object.hasOwn(entry,'auth')?entry.auth:await token();assert.equal((await handle(request(a,auth),env,async()=>entry.keys||[jwk])).status,401);}
});
test('expired and incorrectly signed JWTs reject',async()=>{
 const other=await generateKeyPair('RS256');
 for(const [key,exp] of [[privateKey,'-10m'],[other.privateKey,'5m']]){
  const auth=await new SignJWT({serviceUrl:fixture().serviceUrl}).setProtectedHeader({alg:'RS256',kid:'fixture'}).setIssuer('https://api.botframework.com').setAudience(bot).setNotBefore('-20m').setExpirationTime(exp).sign(key);
  assert.equal((await handle(request(fixture(),auth),env,async()=>[jwk])).status,401);
 }
});
test('deployment without registration or unsupported cloud fails closed',async()=>{
 for(const bad of [{},{...env,ONBOARD_TEAMS_CLOUD:'unsupported'},{...env,ONBOARD_TEAMS_BOT_ID:'placeholder'}])assert.equal((await handle(request(fixture()),bad)).status,503);
});
test('oversized bodies and messages reject without truncating or searching',async()=>{
 const a=fixture();a.value.messagePayload.body.content='x'.repeat(8001);const result=invoke(a,config);assert.equal(result.task.type,'message');assert.match(result.task.value,/too large/);
 assert.equal((await handle(request({text:'x'.repeat(131073)}),env)).status,400);
});
test('missing, deleted, unsupported and empty selected messages do not fall back to a mailbox',()=>{
 for(const selected of [undefined,{deleted:true,body:{}},{body:{contentType:'file',content:'x'}},{body:{contentType:'html',content:'<img src="x">'}}]){const a=fixture();a.value.messagePayload=selected;assert.equal(invoke(a,config).task.type,'message');}
});
test('compose opens empty explicit-input UI and all three command IDs work',()=>{
 for(const command of ['summarize','reply','outlook']){const a=fixture();a.value={commandId:command,commandContext:'compose'};const r=invoke(a,config);const data=JSON.parse(decodeURIComponent(new URL(r.task.value.url).hash.slice('#onboardAction='.length)));assert.equal(data.selected,false);assert.equal(data.text,'');assert.equal(data.command,command);}
});
test('only reviewed bounded drafts return compose cards; no send action or automatic Outlook send',()=>{
 const a=fixture();a.name='composeExtensions/submitAction';a.value.data={body:'Fixture [link](https://untrusted.invalid)',reviewed:false};assert.equal(invoke(a,config).task.type,'message');
 a.value.data.reviewed=true;let r=invoke(a,config);assert.equal(r.composeExtension.type,'result');assert.equal(r.composeExtension.attachments[0].content.actions,undefined);assert.match(r.composeExtension.attachments[0].content.body[0].text,/\\\[/);
 a.value.commandId='outlook';assert.equal(invoke(a,config).task.type,'message');
 a.value.commandId='reply';a.value.data.body='x'.repeat(12001);assert.equal(invoke(a,config).task.type,'message');
});

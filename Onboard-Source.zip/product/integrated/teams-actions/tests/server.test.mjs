import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createApp} from '../server.mjs';

test('public server isolates files and rejects unauthorized bot calls',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'onboard-web-test-'));
 await writeFile(join(dir,'teams.html'),'<h1>TEST FIXTURE</h1>');
 await writeFile(join(dir,'settings.json'),'PRIVATE TEST FIXTURE');
 const env={ONBOARD_TEAMS_BOT_ID:'00000000-0000-4000-8000-000000000001',ONBOARD_TEAMS_TENANT_ID:'00000000-0000-4000-8000-000000000002',ONBOARD_TEAMS_CLOUD:'commercial',ONBOARD_TEAMS_ORIGIN:'https://example.invalid'};
 const server=createApp({env,publicDir:dir});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const base='http://127.0.0.1:'+server.address().port;
 try{
  const page=await fetch(base+'/teams.html?configure=1');assert.equal(page.status,200);
  assert.match(page.headers.get('content-security-policy'),/frame-ancestors/);
  assert.equal(page.headers.get('referrer-policy'),'no-referrer');
  assert.match(await page.text(),/TEST FIXTURE/);
  for(const path of ['/settings.json','/server.mjs','/.env','/%2e%2e%2fsettings.json','/src/handler.mjs'])assert.equal((await fetch(base+path)).status,404);
  assert.equal((await fetch(base+'/healthz')).status,200);
  assert.equal((await fetch(base+'/teams.html',{method:'POST',body:'test'})).status,405);
  assert.equal((await fetch(base+'/api/teams/actions',{method:'POST',body:'{}'})).status,401);
  assert.equal((await fetch(base+'/api/teams/actions',{method:'POST',body:'x'.repeat(131073)})).status,413);
 }finally{await new Promise(r=>server.close(r));await rm(dir,{recursive:true,force:true});}
});

# Optional organization-hosted Teams actions — inactive

The active Onboard configuration uses endpoint-hosted Outlook and Teams tabs, with no external web host. This optional code adds message-menu/compose-box actions only after an organization approves and deploys a compatible HTTPS handler and bot registration. Netlify-specific deployment files were removed on September 27, 2026. No default public hosting address is configured.

## Deploy only in an approved environment

For portal fields, subscription access, and the commercial test sequence, see [Azure Bot setup](AZURE-SETUP.md).

1. Obtain an approved HTTPS origin, bot application ID, tenant ID and hosting environment. The retained handler currently validates **commercial** Bot Framework traffic only; government authorities and Teams behavior must be implemented and verified before government deployment. Do not enter government tenant IDs into the commercial deployment as a workaround.
2. Run `python3 product/integrated/tools/package_teams_actions.py --base-url https://YOUR-APPROVED-HOST --bot-id YOUR-BOT-ID --tenant-id YOUR-TENANT-ID`. These illustrative values must be replaced with real registration values. The optional package uses version 0.4.2; the active local-tab package remains 0.4.1.
3. Install the pinned production dependencies with `pnpm install --prod --frozen-lockfile --ignore-scripts --node-linker=hoisted`. `node server.mjs` starts the handler on `127.0.0.1:3978` by default. The same server serves the allowlisted `public/` interface assets with CSP and Microsoft frame-ancestor restrictions, `/healthz`, and `/api/teams/actions`. Put it behind organization-managed HTTPS; on Azure App Service set `BIND_ADDRESS=0.0.0.0` and startup command `node server.mjs`. Nothing in this tool provisions hosting, a certificate or a bot. The service is separate from the endpoint AI service, which must never be exposed publicly.
4. Configure the values in the generated `deployment-environment.json`. The inbound-only handler does not require an OpenAI key or bot client secret. Set the registration's messaging endpoint to `https://YOUR-APPROVED-HOST/api/teams/actions`, enable the Teams channel, and update the existing catalog app using the generated package after organizational review.
5. Approve the chosen interface origin in Onboard's organization-managed hosting mode. Verify actual Teams rendering, identity binding, selected-message transfer, local connection, and draft-only insertion. All live acceptance remains pending.

## Data flow and limitations

Microsoft delivers the selected message to the registered handler. It returns selected text to the Teams dialog in a URL fragment; the dialog removes the fragment and keeps text in memory. The handler does not write content to storage/logs, call Graph or AI, or send messages. Infrastructure still processes that content, so this feature is a hosted handoff and requires approval. Opening a dialog does not start AI processing. The add-in requires native connection approval, matching accounts, and the existing public-content development policy.

Summaries and replies can be returned as reviewed draft cards, which the user sends in Teams. Send to Outlook prepares a draft for the local Outlook add-in inbox; the user reviews the recipient, subject and body and sends in Outlook. Compose actions ask for explicit text; no selected message is fabricated. Attachments are excluded. Text above 8,000 characters or the 24,000-character launch URL ceiling is rejected visibly without truncation; draft cards remain below 28 KB. Actual client support/limits are unverified.

Tests use labeled fixtures and locally signed test JWTs, not customer data or live integration evidence. Run `pnpm test`. JWT checks cover signature, issuer, audience, lifetime, Teams key endorsement, service URL and allowed tenant. There is no disabled-authentication mode.

References: [Microsoft action commands](https://learn.microsoft.com/en-us/microsoftteams/platform/messaging-extensions/build-bot-based-message-extension), [selected-message dialogs](https://learn.microsoft.com/en-us/microsoftteams/platform/messaging-extensions/how-to/action-commands/create-task-module), [Bot Connector authentication](https://learn.microsoft.com/en-us/azure/bot-service/rest-api/bot-framework-rest-connector-authentication?view=azure-bot-service-4.0).

"""Deploy on an approved central host under a dedicated identity, never the endpoint user.
Append-only network API with mTLS client allowlist, durable commits and a hash chain.
Database/backup protection and retention are the server administrator's responsibility.
"""
import argparse,hashlib,http.server,json,os,pathlib,re,socketserver,sqlite3,ssl,stat,threading,time

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
def validate(row):
    base={'schema','id','time','event'};optional={'operation','result','route','reference','actor','policy','destination','cloud'}
    if not isinstance(row,dict) or not base<=set(row) or set(row)-base-optional:raise ValueError('schema')
    if type(row['schema']) is not int or row['schema']!=1 or not isinstance(row['id'],str) or not re.fullmatch('[0-9a-f]{32}',row['id']):raise ValueError('id')
    if type(row['time']) not in (int,float) or not 0<row['time']<10**11:raise ValueError('time')
    if not isinstance(row['event'],str) or not re.fullmatch('[a-z_]{1,40}',row['event']):raise ValueError('event')
    for k in set(row)&optional:
        if not isinstance(row[k],str) or not re.fullmatch('[A-Za-z0-9_-]{0,64}',row[k]):raise ValueError('field')
    return row
class Store:
    def __init__(self,root):
        root=pathlib.Path(root);root.mkdir(mode=0o700,parents=True,exist_ok=True)
        for p in (root,*root.parents):
            st=p.lstat()
            if stat.S_ISLNK(st.st_mode) or st.st_mode&0o022 or st.st_uid not in (0,os.getuid()):raise ValueError('Unsafe collector directory')
        path=root/'events.sqlite3'
        if path.is_symlink():raise ValueError('Unsafe database')
        old=os.umask(0o077)
        try:self.db=sqlite3.connect(str(path),check_same_thread=False,isolation_level=None)
        finally:os.umask(old)
        self.lock=threading.Lock();self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY, client TEXT NOT NULL, id TEXT NOT NULL, received REAL NOT NULL, body TEXT NOT NULL, digest TEXT NOT NULL, previous TEXT NOT NULL, chain TEXT NOT NULL, UNIQUE(client,id))')
    def append(self,client,row):
        validate(row);body=canonical(row);digest=hashlib.sha256(body).hexdigest()
        with self.lock:
            self.db.execute('BEGIN IMMEDIATE')
            try:
                prior=self.db.execute('SELECT digest FROM events WHERE client=? AND id=?',(client,row['id'])).fetchone()
                if prior:
                    if prior[0]!=digest:raise ValueError('Replay changed event')
                else:
                    tail=self.db.execute('SELECT chain FROM events ORDER BY seq DESC LIMIT 1').fetchone();previous=tail[0] if tail else '0'*64;received=time.time()
                    chain=hashlib.sha256(canonical([previous,client,received,digest])).hexdigest()
                    self.db.execute('INSERT INTO events(client,id,received,body,digest,previous,chain) VALUES(?,?,?,?,?,?,?)',(client,row['id'],received,body.decode(),digest,previous,chain))
                self.db.execute('COMMIT')
            except BaseException:self.db.execute('ROLLBACK');raise
        return {'accepted':digest}

class Server(socketserver.ThreadingMixIn,http.server.HTTPServer):
    daemon_threads=True
    def __init__(self,address,store,context,clients):
        self.store=store;self.context=context;self.clients=set(clients);self.slots=threading.BoundedSemaphore(16)
        super().__init__(address,Handler)
    def get_request(self):
        request,address=super().get_request();request.settimeout(5);return request,address
    def process_request(self,request,address):
        if not self.slots.acquire(False):request.close();return
        try:super().process_request(request,address)
        except BaseException:self.slots.release();request.close();raise
    def process_request_thread(self,request,address):
        try:
            request=self.context.wrap_socket(request,server_side=True)
            super().process_request_thread(request,address)
        except (OSError,ssl.SSLError):request.close()
        finally:self.slots.release()
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_POST(self):
        try:
            client=hashlib.sha256(self.connection.getpeercert(binary_form=True)).hexdigest()
            if client not in self.server.clients:self.send_error(403);return
            lengths=self.headers.get_all('Content-Length',[])
            if self.path!='/v1/events' or self.headers.get('Transfer-Encoding') or len(lengths)!=1:self.send_error(400);return
            count=int(lengths[0])
            if not 0<count<=4096:self.send_error(413);return
            raw=self.rfile.read(count)
            if len(raw)!=count:raise ValueError('body')
            result=self.server.store.append(client,json.loads(raw));body=canonical(result)
            self.send_response(201);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        except (ValueError,TypeError,json.JSONDecodeError):self.send_error(400)
        except Exception:self.send_error(503)
def main():
    p=argparse.ArgumentParser();p.add_argument('--bind',default='127.0.0.1');p.add_argument('--port',type=int,default=9443)
    for name in ('state','certificate','private-key','client-ca'):p.add_argument('--'+name,required=True)
    p.add_argument('--client-fingerprint',action='append',required=True);a=p.parse_args()
    if any(not re.fullmatch('[0-9a-f]{64}',f) for f in a.client_fingerprint):p.error('Use lowercase SHA-256 client certificate fingerprints')
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.minimum_version=ssl.TLSVersion.TLSv1_2;ctx.load_cert_chain(a.certificate,a.private_key);ctx.load_verify_locations(a.client_ca);ctx.verify_mode=ssl.CERT_REQUIRED
    Server((a.bind,a.port),Store(a.state),ctx,a.client_fingerprint).serve_forever()
if __name__=='__main__':main()

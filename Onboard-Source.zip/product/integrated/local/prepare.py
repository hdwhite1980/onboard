"""Reverify retained runtime/package and privately activate one product request."""
import importlib.util,json,os,shutil,sys,datetime
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c
import policy as p

def main():
 p.save('PREPARATION_STARTED.json',{'pid':os.getpid(),'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 phase='RUNTIME'
 try:
  spec=importlib.util.spec_from_file_location('retained_runtime_verifier',Path(__file__).with_name('runtime_identity.py'));v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);v.c=c
  c.save=lambda name,data:p.save('runtime-reverification.json',data)
  v.main()
  phase='ACTIVATION';source=c.verify_package(c.STORE,c.IDENT)
  manifest=json.loads((c.STORE/'manifest.json').read_text());snapshot=c.RUN/'activation';snapshot.mkdir(mode=0o700)
  for row in manifest['files']:
   dest=snapshot/row['path'];dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700);shutil.copyfile(c.STORE/row['path'],dest);dest.chmod(0o400)
  shutil.copyfile(c.STORE/'manifest.json',snapshot/'manifest.json');(snapshot/'manifest.json').chmod(0o400)
  for d in sorted((x for x in snapshot.rglob('*') if x.is_dir()),reverse=True):d.chmod(0o500)
  snapshot.chmod(0o500);checked=c.verify_package(snapshot,c.IDENT)
  suite=json.loads((p.PREFLIGHT/'frozen-suite.json').read_text());assert len(suite['requests'])==1
  p.save('token-budget.json',suite);p.save('activation.json',{'snapshot':str(snapshot),'manifestSHA256':c.IDENT,'rootIdentity':checked['rootIdentity'],'residual':'Same-UID development process boundary, not a production activation trust boundary'})
  p.save('verification.json',{'status':'PASS','source':source,'snapshot':checked,'modelLoads':0})
 except BaseException as e:
  p.save('preparation-failure.json',{'status':'ARTIFACT_VERIFICATION_FAILED' if phase=='ACTIVATION' else 'RUNTIME_COMPATIBILITY_FAILED','error':repr(e),'modelLoads':0});raise
if __name__=='__main__':main()

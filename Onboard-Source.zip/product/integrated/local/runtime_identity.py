"""Verify project-pinned publisher payload and unchanged retained wheel inventory; no AI imports."""
import base64
import csv
import importlib.metadata
import io
import json
import platform
import sys
import zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import hashlib,os,subprocess,types
ROOT=Path(__file__).resolve().parents[3]
PIN=ROOT/'product/integrated/.artifacts/python'
PROVENANCE=ROOT/'product/integrated/evidence/runtime-repair/provenance.json'
PROVENANCE_SHA256='3a2569d8c67db71dfd0fdf3a83a49690aeac12f9d063d1e57034abe573e280c8'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
c=types.SimpleNamespace(ROOT=ROOT,BASE=ROOT/'product/local_ai',sha=sha,save=lambda name,data:print(json.dumps(data)))
def pinned_interpreter():
 assert sha(PROVENANCE)==PROVENANCE_SHA256,'Pinned provenance changed'
 record=json.loads(PROVENANCE.read_text())
 assert record['publisher']['archiveSha256']=='440347ef30d7560dd79a272f0886b4d3c648c20982019049dadcf07a88a62a26'
 assert record['sourceExecutableSHA256']=='f91a7185b6b453b827a36d33017ccbd50c21187a551212bc0b2c99c7ca0428f2'
 assert record['packagedExecutableSHA256']=='931eb2e59857c31d68d90825409d00f3af852f906c321528aaa0432cc48e7d60'
 assert Path(sys.executable)==ROOT/'product/integrated/.artifacts/venv/bin/python'
 assert Path(sys.executable).resolve()==PIN/'bin/python3.12'
 expected=set()
 for row in record['sourceFiles']:
  path=PIN/row['path'];assert path.is_file() and not path.is_symlink()
  expected.add(row['path'])
  digest=record['packagedExecutableSHA256'] if row['path']=='bin/python3.12' else row['sha256']
  assert sha(path)==digest,'Runtime payload changed: '+row['path']
 for row in record['symlinks']:
  path=PIN/row['path'];assert path.is_symlink() and os.readlink(path)==row['target']
  expected.add(row['path'])
 actual={str(path.relative_to(PIN)) for path in PIN.rglob('*') if path.is_file() or path.is_symlink()}
 assert actual==expected,('Unexpected runtime files',actual-expected,expected-actual)
 subprocess.run(['/usr/bin/codesign','--verify','--strict',str(PIN/'bin/python3.12')],check=True,capture_output=True)
 return {'executable':str(PIN/'bin/python3.12'),'sha256':record['packagedExecutableSHA256'],'version':'3.12.14','architecture':'arm64','provenanceSHA256':PROVENANCE_SHA256,'publisherArchiveSHA256':record['publisher']['archiveSha256'],'verifiedRuntimeFiles':len(expected)}

def main():
    prior=c.ROOT/'docs/sprint3a/evidence/calibration-01'
    interp=pinned_interpreter()
    assert Path(sys.executable).resolve()==Path(interp['executable']).resolve()
    assert c.sha(Path(sys.executable).resolve())==interp['sha256']
    assert platform.python_version()==interp['version']=='3.12.14'
    assert platform.machine()==interp['architecture']=='arm64'
    identity=json.loads((prior/'runtime-identity.json').read_text())
    assert c.sha(c.BASE/'runtime/requirements.lock')==identity['wheelLockSHA256']
    assert c.sha(c.BASE/'runtime/SBOM.json')==identity['SBOMSHA256']
    checked=[]
    for comp in json.loads((c.BASE/'runtime/SBOM.json').read_text())['components']:
        wheel=c.BASE/'.artifacts/runtime/wheelhouse'/comp['wheel'];assert c.sha(wheel)==comp['sha256']
        dist=importlib.metadata.distribution(comp['package']);assert dist.version==comp['version']
        count=0
        with zipfile.ZipFile(wheel) as z:
            for f in z.infolist():
                if f.is_dir() or f.filename.endswith('.dist-info/RECORD'):continue
                assert '.data/' not in f.filename
                p=Path(dist.locate_file(f.filename));assert p.is_file() and not p.is_symlink()
                assert c.sha(p)==__import__('hashlib').sha256(z.read(f)).hexdigest(),p
                count+=1
        for path,digest,size in csv.reader(io.StringIO(dist.read_text('RECORD'))):
            if not digest:continue
            algo,value=digest.split('=',1);assert algo=='sha256'
            p=Path(dist.locate_file(path))
            assert base64.urlsafe_b64encode(bytes.fromhex(c.sha(p))).decode().rstrip('=')==value
            if size:assert p.stat().st_size==int(size)
        checked.append({'package':comp['package'],'version':comp['version'],'installedWheelFiles':count,'wheelSHA256':comp['sha256']})
    expected={x['package'].lower().replace('_','-') for x in checked}|{'pip'}
    installed={d.metadata['Name'].lower().replace('_','-') for d in importlib.metadata.distributions()}
    assert installed==expected
    probe=c.BASE/'.artifacts/build/resource-probe'
    tested=json.loads((prior/'tested-source.json').read_text())
    for item in tested['files']:assert c.sha(c.ROOT/item['path'])==item['sha256'],item['path']
    c.save('runtime-identity.json',{'status':'PASS','interpreter':interp,'packages':checked,
       'lockSHA256':identity['wheelLockSHA256'],'sbomSHA256':identity['SBOMSHA256'],
       'retainedCalibrationSourcesUnchanged':True,'probeSHA256':c.sha(probe),'modelLoads':0,'runtimeChanges':'Pinned publisher Python; unchanged retained wheel versions; project-owned venv'})
    print(json.dumps({'status':'PASS','packages':len(checked),'installedWheelFiles':sum(x['installedWheelFiles'] for x in checked),'modelLoads':0}))

if __name__=='__main__':main()

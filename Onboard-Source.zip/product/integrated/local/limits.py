"""Bounded medium-email profile; resource and lifecycle guards remain mandatory."""
TOTAL_CONTEXT = 2048
OUTPUT_TOKENS = 512
PROMPT_LIMIT = TOTAL_CONTEXT - OUTPUT_TOKENS

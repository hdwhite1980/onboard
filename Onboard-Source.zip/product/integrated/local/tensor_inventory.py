"""Qwen3-1.7B config-derived storage inventory; no tensors loaded."""
def expected_inventory():
 out={}
 def add(n,s,d='BF16'):out[n]={'shape':s,'dtype':d}
 def quant(n,o,i):
  add(n+'.weight',[o,i//8],'U32')
  for k in ['scales','biases']:add(n+'.'+k,[o,i//64])
 quant('model.embed_tokens',151936,2048);add('model.norm.weight',[2048])
 for i in range(28):
  b=f'model.layers.{i}.'
  for n in ['input_layernorm','post_attention_layernorm']:add(b+n+'.weight',[2048])
  for n in ['q_norm','k_norm']:add(b+'self_attn.'+n+'.weight',[128])
  for n,o,inp in [('q_proj',2048,2048),('k_proj',1024,2048),('v_proj',1024,2048),('o_proj',2048,2048)]:quant(b+'self_attn.'+n,o,inp)
  for n,o,inp in [('gate_proj',6144,2048),('up_proj',6144,2048),('down_proj',2048,6144)]:quant(b+'mlp.'+n,o,inp)
 return out

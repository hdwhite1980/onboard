"""Unchanged Policy V2 guards, retained Qwen3-1.7B finite profile. Owner-authorized removal of the fixed planning gate; live guards retained."""
from pathlib import Path
import os,json,math
from limits import TOTAL_CONTEXT, OUTPUT_TOKENS
ROOT=Path(__file__).resolve().parents[3]
B=ROOT/'product/local_ai'
RUN=Path(os.environ['ONBOARD_BRIEFING_RUN']).resolve()
assert RUN.is_relative_to(ROOT/'product/integrated/state/runs')
PHASE='product-request'
PREFLIGHT=RUN/'preflight'
E=RUN/'calibration'
REQUESTS=1
IDENT='1721e23c79d4367cb3e12a6811aabd61a8526c511b0f30f7134ecaeb40ef0778'
LABEL='PRODUCT_INTEGRATED_PUBLIC_EXPERIMENTAL'
GIB=1024**3
POLICY={'name':'MACOS_RESOURCE_POLICY_V2','scope':'LOCAL_DEVELOPMENT_PUBLIC_USER_DECLARED','reserveBytes':2*GIB,'earlyReserveBytes':int(2.25*GIB),'workerCeilingBytes':int(2.75*GIB),'compressionOnlyStop':False,'initialSwapBytes':0,'swapGrowthAllowedBytes':0,'positiveSwapActivityAllowed':False,'loadSampleSeconds':.1,'generationSampleSeconds':.25,'recoverySampleSeconds':.25,'staleSeconds':1.5,'loadTimeoutSeconds':90,'generationTimeoutSeconds':60,'wallTimeoutSeconds':180,'workingAllowanceBypass':'Owner authorized removal of fixed 5.0 GiB admission gate. Retain live 2.25 GiB protected reserve, 2.75 GiB worker ceiling, pressure, swap and thermal guards.','totalContext':TOTAL_CONTEXT,'outputTokens':OUTPUT_TOKENS,'promptTokens':'per exact frozen product packet','batch':1,'prefillStepSize':128,'requestLimit':1,'terminationGraceSeconds':0,'lifecycle':'EXPERIMENTAL','qualifiedTasks':[]}
REQUIRED=('physicalMemoryBytes','pageSizeBytes','freeBytes','inactiveBytes','speculativeBytes','activeBytes','wiredBytes','purgeableBytes','compressorOccupancyBytes','compressionPagesTotal','decompressionPagesTotal','swapUsedBytes','swapInPagesTotal','swapOutPagesTotal','collectionSeconds','monotonic')
def save(name,data):
 with (E/name).open('x') as f:json.dump(dict(data,label=LABEL),f,indent=2);f.write('\n')
def valid(value):return type(value) in (int,float) and math.isfinite(value) and value>=0

def pressure_reason(mask):
 if type(mask) is not int or mask<1 or mask&~7:return 'RESOURCE: pressure UNKNOWN'
 if mask&4:return 'RESOURCE: pressure CRITICAL'
 if mask&2:return 'RESOURCE: pressure WARN'
 return None

def violation(row,base,previous,now,worker_required=False):
 if any(not valid(row.get(k)) for k in REQUIRED):return 'MONITOR: required telemetry unavailable'
 if not valid(row.get('availableEstimateLegacyBytes')):return 'MONITOR: headroom unavailable'
 age=now-row['monotonic']
 if age<0 or age>1.5:return 'MONITOR: stale/invalid native clock'
 if not isinstance(row.get('powerSource'),str) or not row['powerSource']:return 'MONITOR: power telemetry unavailable'
 if row.get('memoryPressure')!='NORMAL':return 'RESOURCE: pressure '+str(row.get('memoryPressure','UNKNOWN'))
 if row['availableEstimateLegacyBytes']<=POLICY['earlyReserveBytes']:return 'RESOURCE: protected reserve approached'
 if type(row.get('thermalState')) is not int or row['thermalState'] not in (0,1):return 'RESOURCE: thermal unsafe or unknown'
 if row['swapUsedBytes']>base['swapUsedBytes']:return 'RESOURCE: swap used grew'
 if base['swapUsedBytes']!=0:return 'RESOURCE: nonzero initial swap'
 if previous:
  for field in ('swapInPagesTotal','swapOutPagesTotal','compressionPagesTotal','decompressionPagesTotal'):
   if row[field]<previous[field]:return 'MONITOR: counter reset'
  if row['swapInPagesTotal']>previous['swapInPagesTotal']:return 'RESOURCE: positive swap-in'
  if row['swapOutPagesTotal']>previous['swapOutPagesTotal']:return 'RESOURCE: positive swap-out'
 if worker_required:
  if not valid(row.get('workerPhysicalFootprintBytes')) or not valid(row.get('workerResidentBytes')):return 'MONITOR: worker footprint/resident unavailable'
  if row['workerPhysicalFootprintBytes']>POLICY['workerCeilingBytes']:return 'RESOURCE: worker footprint exceeded'
 return None

def deadline(now,start,last_host,last_mlx,phase,phase_start):
 if now-last_host>1.5:return 'MONITOR: host telemetry stale'
 if last_mlx is not None and now-last_mlx>1.5:return 'MONITOR: MLX telemetry stale'
 if start is not None and now-start>180:return 'RUNTIME: wall timeout'
 if phase=='LOAD' and phase_start is not None and now-phase_start>90:return 'RUNTIME: load timeout'
 if phase in ('PREFILL','GENERATION') and phase_start is not None and now-phase_start>60:return 'RUNTIME: generation timeout'
 return None

def classify(success,reasons,events):
 if any('UNSUPPORTED_RESOURCE_PROFILE' in str(e) for e in events) or any('UNSUPPORTED_RESOURCE_PROFILE' in r for r in reasons):return 'TOKENIZER_PREFLIGHT_FAILED'
 loaded=any(e.get('event')=='MODEL_LOADED' for e in events)
 fatal={e.get('classification') for e in events if e.get('event')=='fatal'}
 alltext=' '.join(reasons)
 if 'NETWORK' in fatal or 'SECURITY' in fatal or any(x in alltext for x in ('NETWORK:','SECURITY:')):return 'NETWORK_BOUNDARY_FAILED'
 if 'ACTIVATION' in fatal or 'ACTIVATION:' in alltext:return 'ARTIFACT_VERIFICATION_FAILED'
 if 'COMPATIBILITY' in fatal or 'COMPATIBILITY:' in alltext:return 'RUNTIME_COMPATIBILITY_FAILED'
 if any(x.startswith(('RESOURCE:','MONITOR:')) for x in reasons):return 'LOCAL_GENERATION_ABORTED_RESOURCE_POLICY_V2' if loaded else 'MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2'
 if success:return 'LOCAL_GENERATION_SUCCESS'
 return 'LOCAL_GENERATION_FAILED' if loaded else 'MODEL_LOAD_FAILED'

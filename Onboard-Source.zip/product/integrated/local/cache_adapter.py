"""Bounded cache selection for the retained Qwen3 model; no weight conversion.

TurboQuant-MLX's rotation/codebook storage path, not Google's full QJL algorithm.
Standard attention reconstructs FP16 tensors transiently. Savings are storage,
not a guarantee of lower peak memory, faster decode or identical answers.
"""
import hashlib,json,sys
from pathlib import Path
from limits import TOTAL_CONTEXT
MODES=('standard','turboquant-k8v4')
PROVENANCE_SHA='b1302dccda1e6a8a0a3dbe906fae6bf5a4cc4d3ca0d729645f094b7b89302539'

def verify_vendor():
    root=Path(__file__).resolve().parent/'vendor/turboquant_mlx'
    manifest=root/'provenance.json'
    if manifest.is_symlink() or hashlib.sha256(manifest.read_bytes()).hexdigest()!=PROVENANCE_SHA:
        raise RuntimeError('ACTIVATION: TurboQuant provenance changed')
    for row in json.loads(manifest.read_text())['files']:
        path=root/row['path']
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
            raise RuntimeError('ACTIVATION: TurboQuant source changed')
    return root

def create(model,mode):
    if mode not in MODES:raise RuntimeError('COMPATIBILITY: unsupported cache mode')
    from mlx_lm.models.cache import make_prompt_cache
    caches=make_prompt_cache(model)
    if len(caches)!=28 or any(type(c).__name__!='KVCache' for c in caches):
        raise RuntimeError('COMPATIBILITY: unsupported cache architecture')
    if mode=='standard':return caches
    root=verify_vendor();sys.path.insert(0,str(root.parent))
    from turboquant_mlx.layers.polar_kv_cache import TurboQuantKVCache
    class BoundedTurboQuantCache(TurboQuantKVCache):
        def update_and_fetch(self,keys,values):
            if (keys.shape!=values.shape or list(keys.shape[:2])!=[1,8]
                or keys.shape[-1]!=128 or self.offset+keys.shape[-2]>TOTAL_CONTEXT):
                raise RuntimeError('COMPATIBILITY: unsupported TurboQuant cache shape')
            return super().update_and_fetch(keys,values)
    # K8 preserves more key precision; V4 is more conservative than upstream V3.
    # No persistent cross-request state or arbitrary cache restoration.
    return [BoundedTurboQuantCache(k_bits=8,v_bits=4,group_size=64,min_tokens_before_quant=0) for _ in caches]

def record(caches,populated=False):
    rows=[];total=0
    if len(caches)!=28:raise RuntimeError('CACHE_CLASS_MISMATCH')
    for index,cache in enumerate(caches):
        compressed=type(cache).__name__=='BoundedTurboQuantCache'
        assert compressed or type(cache).__name__=='KVCache','CACHE_CLASS_MISMATCH'
        assert 0<=cache.offset<=TOTAL_CONTEXT,'CACHE_OFFSET'
        arrays=([('key-packed',cache._tq_keys[0]),('key-scales',cache._tq_keys[1]),('value-packed',cache._tq_values[0]),('value-scales',cache._tq_values[1])] if compressed and cache._tq_keys is not None else [] if compressed else [('key',cache.keys),('value',cache.values)])
        row={'layer':index,'class':type(cache).__name__,'offset':cache.offset,'slots':[]}
        if populated:assert arrays and cache.offset>0,'CACHE_UNPOPULATED'
        for role,array in arrays:
            if array is None:
                assert not populated,'CACHE_UNPOPULATED';continue
            shape=list(array.shape);dtype=str(array.dtype)
            width=32 if role=='key-packed' else 16 if role=='value-packed' else 2 if role.endswith('scales') else 128
            expected='mlx.core.uint32' if role.endswith('packed') else 'mlx.core.float16'
            assert shape[:2]==[1,8] and shape[3]==width and cache.offset<=shape[2]<=TOTAL_CONTEXT and dtype==expected,'CACHE_DTYPE_OR_SHAPE'
            total+=array.nbytes;row['slots'].append({'role':role,'shape':shape,'dtype':dtype,'bytes':array.nbytes})
        if compressed:
            assert not cache._use_fused_attend and cache._fp16_keys is None,'CACHE_UNSUPPORTED_MODE'
        rows.append(row)
    assert total<=28*2*TOTAL_CONTEXT*8*128*2,'CACHE_BUDGET_EXCEEDED'
    return {'layers':rows,'allocatedBytes':total,'mode':'turboquant-k8v4' if compressed else 'standard','measurement':'Persistent KV buffers only; codebooks, transient FP16 attention and total runtime measured separately'}

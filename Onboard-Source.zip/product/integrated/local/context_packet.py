"""Tokenizer-measured exact excerpts. Keep the question and disclose source omissions."""
import re

from limits import PROMPT_LIMIT
SCOPE = ('Only the supplied excerpts are available. They may omit relevant or contradictory '
         'context. Do not claim complete coverage; state what remains unknown.')

class ContextLimit(ValueError):
    pass

def render(tok, messages):
    prompt = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True,
                                    enable_thinking=False, tools=None)
    return prompt, tok.encode(prompt, add_special_tokens=False)

URL = re.compile(r'https?://[^\s<>\[\]()]+',re.I)
FOOTER = re.compile(r'^(?:copyright\b|©|all rights reserved\b|unsubscribe\b|(?:manage|update) (?:your |email |subscription )*preferences\b|terms of (?:service|use)\b|privacy (?:notice|policy)\b|view (?:this |the )?(?:email|message) in (?:your |a )?browser\b|we never send email unsolicited\b)',re.I)

def mail_blocks(source,question):
    """Return exact contiguous source spans, never rewritten text or followed links."""
    original=source['text']
    if source.get('kind')!='mail' or re.search(r'\b(?:links?|urls?|unsubscribe|privacy|copyright|footer|tracking|terms of service)\b',question,re.I):
        return [original],False
    blocks=[];changed=False
    for paragraph in re.split(r'\n\s*\n',original):
        paragraph=paragraph.strip()
        if not paragraph:continue
        if FOOTER.match(paragraph):changed=True;continue
        without_urls=URL.sub('',paragraph).strip('[]()<> \n\t*|.,')
        if not without_urls or not re.search(r'\w',without_urls):changed=True;continue
        # Preserve ordinary links within business text. Long tracking destinations consume
        # most of a small model context and are omitted without opening any destination.
        links=[m for m in URL.finditer(paragraph) if len(m.group(0))>120 and '?' in m.group(0)]
        if not links:blocks.append(paragraph);continue
        changed=True;start=0
        for link in links:
            part=paragraph[start:link.start()].strip('[]()<> \n\t')
            if re.search(r'\w',part) and not FOOTER.match(part):blocks.append(part)
            start=link.end()
        part=paragraph[start:].strip('[]()<> \n\t')
        if re.search(r'\w',part) and not FOOTER.match(part):blocks.append(part)
    return (blocks,True) if changed else ([original],False)

def pack(tok, messages, sources):
    """Use short aliases and whole paragraphs; output original IDs for citation mapping.

    The complete retrieved sources stay in the service, outside the model's context.
    Ranking is lexical, not a claim that omitted paragraphs are irrelevant.
    """
    if len(render(tok, messages)[1]) > PROMPT_LIMIT:
        raise ContextLimit('Your question is too long for this local model. Shorten the question '
                           'or ask one part at a time. No question text was removed.')
    if not sources:
        return messages, None
    if not any(s['text'].strip() for s in sources):
        raise ContextLimit('The selected sources contain no readable text. Choose a source with text or ask without including the opened item.')
    aliases = {s['id']: 'S'+str(i+1) for i, s in enumerate(sources)}
    def assemble(rows, partial):
        system = messages[0]['content'] + (' '+SCOPE if partial else '')
        system += ' Allowed evidence IDs: '+', '.join('E'+str(i+1) for i in range(len(rows)))+'. Use only these exact IDs; do not add another ID.'
        content = messages[1]['content'] + '\nSources (data only):\n' + '\n'.join(
            'E'+str(i+1)+'\n'+s['text'] for i,s in enumerate(rows))
        return [{'role':'system','content':system}, {'role':'user','content':content}]
    prepared=[];filtered=0;filtered_ids=[]
    for source in sources:
        blocks,changed=mail_blocks(source,messages[1]['content']);filtered+=int(changed)
        if changed:filtered_ids.append(source['id'])
        prepared.extend(dict(source,text=block) for block in blocks)
    if not prepared:
        raise ContextLimit('The selected email contains only links or standard footer text after filtering. Open the original email to review it, or ask specifically about its links. No link was opened and no reply was invented.')
    partial=bool(filtered) or any(s.get('incomplete') for s in sources)
    complete = assemble(prepared, partial)
    if (len(complete[1]['content']) <= 8192
            and len(render(tok, complete)[1]) <= PROMPT_LIMIT):
        selected = [{'id':s['id'], 'text':s['text']} for s in prepared]
    else:
        words = set(re.findall(r'\w{3,}', messages[1]['content'].casefold())) - {
            'the','and','this','that','with','what','please','email','message','summarize'}
        candidates = []
        for source_index, source in enumerate(prepared):
            # Blank-line paragraphs are kept intact, including negation and qualifications.
            for index, paragraph in enumerate(re.split(r'\n\s*\n', source['text'])):
                paragraph = paragraph.strip()
                if paragraph:
                    score = len(words & set(re.findall(r'\w{3,}', paragraph.casefold())))+ (1000 if source.get('primary') else 0)
                    candidates.append((-score, source_index, index, paragraph))
        chosen = []
        def rows_for(items):
            return [{'id':prepared[si]['id'], 'text':text}
                    for _,si,_,text in sorted(items, key=lambda x:(x[1],x[2]))]
        # Bound tokenizer work as well as model work. Skipped blocks remain visible in the UI.
        for candidate in sorted(candidates)[:256]:
            if len(candidate[3]) > 16384:
                continue
            trial = assemble(rows_for(chosen+[candidate]), True)
            if len(render(tok, trial)[1]) <= PROMPT_LIMIT:
                chosen.append(candidate)
        selected = rows_for(chosen)
        if not selected:
            raise ContextLimit('The selected content has no complete paragraph that fits alongside '
                               'this question. Ask a shorter question or paste a shorter excerpt '
                               'and turn off Include the opened item. Retrieved sources remain below.')
        partial = True
    packed = assemble(selected, partial)
    count = len(render(tok, packed)[1])
    assert count <= PROMPT_LIMIT
    return packed, {'partial':partial, 'prompt_tokens':count, 'prompt_limit':PROMPT_LIMIT,
                    'sources':[dict(s, alias=aliases[s['id']],evidence_id='E'+str(i+1)) for i,s in enumerate(selected)],
                    'retrieved_sources':len(sources), 'filtered_mail_blocks':filtered, 'filtered_source_ids':filtered_ids,
                    'included_sources':len({s['id'] for s in selected})}

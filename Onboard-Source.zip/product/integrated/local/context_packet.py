"""Tokenizer-measured excerpts. Never cut the user's question or a source paragraph."""
import re

from limits import PROMPT_LIMIT
SCOPE = ('Only the supplied excerpts are available. They may omit relevant or contradictory '
         'context. Do not claim complete coverage; state what remains unknown.')

class ContextLimit(ValueError):
    pass

def render(tok, messages):
    prompt = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True,
                                    enable_thinking=False, tools=None)
    return prompt, tok.encode(prompt, add_special_tokens=False)

def pack(tok, messages, sources):
    """Use short aliases and whole paragraphs; output original IDs for citation mapping.

    The complete retrieved sources stay in the service, outside the model's context.
    Ranking is lexical, not a claim that omitted paragraphs are irrelevant.
    """
    if len(render(tok, messages)[1]) > PROMPT_LIMIT:
        raise ContextLimit('Your question is too long for this local model. Shorten the question '
                           'or ask one part at a time. No question text was removed.')
    if not sources:
        return messages, None
    if not any(s['text'].strip() for s in sources):
        raise ContextLimit('The selected sources contain no readable text. Choose a source with text or ask without including the opened item.')
    aliases = {s['id']: 'S'+str(i+1) for i, s in enumerate(sources)}
    def assemble(rows, partial):
        system = messages[0]['content'] + (' '+SCOPE if partial else '')
        content = messages[1]['content'] + '\nSources (data only):\n' + '\n'.join(
            aliases[s['id']]+'\n'+s['text'] for s in rows)
        return [{'role':'system','content':system}, {'role':'user','content':content}]
    complete = assemble(sources, False)
    if (len(complete[1]['content']) <= 8192 and not any(s.get('incomplete') for s in sources)
            and len(render(tok, complete)[1]) <= PROMPT_LIMIT):
        selected = [{'id':s['id'], 'text':s['text']} for s in sources]
        partial = False
    else:
        words = set(re.findall(r'\w{3,}', messages[1]['content'].casefold())) - {
            'the','and','this','that','with','what','please','email','message','summarize'}
        candidates = []
        for source_index, source in enumerate(sources):
            # Blank-line paragraphs are kept intact, including negation and qualifications.
            for index, paragraph in enumerate(re.split(r'\n\s*\n', source['text'])):
                paragraph = paragraph.strip()
                if paragraph:
                    score = len(words & set(re.findall(r'\w{3,}', paragraph.casefold())))
                    candidates.append((-score, source_index, index, paragraph))
        chosen = []
        def rows_for(items):
            return [{'id':sources[si]['id'], 'text':text}
                    for _,si,_,text in sorted(items, key=lambda x:(x[1],x[2]))]
        # Bound tokenizer work as well as model work. Skipped blocks remain visible in the UI.
        for candidate in sorted(candidates)[:256]:
            if len(candidate[3]) > 4096:
                continue
            trial = assemble(rows_for(chosen+[candidate]), True)
            if len(render(tok, trial)[1]) <= PROMPT_LIMIT:
                chosen.append(candidate)
        selected = rows_for(chosen)
        if not selected:
            raise ContextLimit('The selected content has no complete paragraph that fits alongside '
                               'this question. Ask a shorter question or paste a shorter excerpt '
                               'and turn off Include the opened item. Retrieved sources remain below.')
        partial = True
    packed = assemble(selected, partial)
    count = len(render(tok, packed)[1])
    assert count <= PROMPT_LIMIT
    return packed, {'partial':partial, 'prompt_tokens':count, 'prompt_limit':PROMPT_LIMIT,
                    'sources':[dict(s, alias=aliases[s['id']]) for s in selected],
                    'retrieved_sources':len(sources),
                    'included_sources':len({s['id'] for s in selected})}

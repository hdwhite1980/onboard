"""Offline tokenizer-only product packet. Exact complete facts; no model construction."""
import sys,json,os,hashlib,errno,socket,struct,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c

def main():
 package=json.loads(c.PACKAGE.read_text());c.verify_package(c.STORE,c.IDENT)
 # Header-only verification against derived Qwen3 inventory, before blocking weight access.
 from tensor_inventory import expected_inventory
 with (c.STORE/'model.safetensors').open('rb') as f:n=struct.unpack('<Q',f.read(8))[0];assert n<1024**2;h=json.loads(f.read(n))
 h.pop('__metadata__',None);ex=expected_inventory();assert set(h)==set(ex)
 for name,v in h.items():assert {k:v[k] for k in ('shape','dtype')}==ex[name],name
 try:
  with socket.socket() as sock:sock.connect(('127.0.0.1',9))
 except OSError as e:assert e.errno in (errno.EPERM,errno.EACCES)
 else:raise RuntimeError('Network denial missing')
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',USE_TORCH='0',USE_TF='0',USE_FLAX='0')
 def forbidden(*a,**k):raise RuntimeError('MODEL_OR_NETWORK_NOT_ALLOWED_IN_PREFLIGHT')
 def audit(event,args):
  if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system','os.posix_spawn'):forbidden()
  if event=='open' and isinstance(args[0],(str,bytes)) and str(args[0]).endswith(('.safetensors','.gguf','.bin')):forbidden()
 sys.addaudithook(audit)
 import huggingface_hub
 huggingface_hub.snapshot_download=forbidden;huggingface_hub.hf_hub_download=forbidden
 from transformers import AutoTokenizer
 tok=AutoTokenizer.from_pretrained(str(c.STORE),local_files_only=True,trust_remote_code=False)
 assert tok.eos_token_id==151645
 messages=json.loads((c.RUN/'input.json').read_text())
 assert len(messages)==2 and all(x['role'] in ('system','user') and isinstance(x['content'],str) for x in messages)
 prompt=tok.apply_chat_template(messages,tokenize=False,add_generation_prompt=True,enable_thinking=False,tools=None)
 ids=tok.encode(prompt,add_special_tokens=False)
 assert len(ids)+128<=512,'UNSUPPORTED_RESOURCE_PROFILE: input exceeds retained 512-token execution profile; no content was truncated'
 selected=[];omitted=[]
 row={'id':'user-request','messages':messages,'rawPrompt':prompt,'tokenIDs':ids,'promptTokens':len(ids),'expectedPromptTokens':len(ids),'maxNewTokens':128,'maxTotalContext':512,'inputSHA256':hashlib.sha256(json.dumps(messages,sort_keys=True).encode()).hexdigest()}
 data={'requests':[row],'templateSHA256':hashlib.sha256(tok.chat_template.encode()).hexdigest(),'tokenizerSHA256':c.sha(c.STORE/'tokenizer.json'),'stopSet':[151645],'thinking':False,'tools':[],'packetIDs':[x['id'] for x in selected],'omittedWholeFactIDs':omitted,'scopeNote':'AI suggests focus only among complete packet facts. The deterministic briefing retains all relevant facts, conflicts and superseded history. No fact text is truncated.'}
 c.save('frozen-suite.json',data);c.save('tokenizer-runtime-check.json',{'status':'PASS','networkNegativeControl':'DENIED','modelLoads':0,'promptTokens':len(ids),'totalWithOutput':len(ids)+128,'packetIDs':data['packetIDs'],'omittedWholeFactIDs':omitted})
 print(json.dumps({'status':'PASS','promptTokens':len(ids)}))
if __name__=='__main__':main()

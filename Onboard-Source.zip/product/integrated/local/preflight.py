"""Offline tokenizer-only product packet. Exact complete facts; no model construction."""
import sys,json,os,hashlib,errno,socket,struct,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c
from context_packet import pack, render, ContextLimit
from limits import TOTAL_CONTEXT, OUTPUT_TOKENS

def main():
 package=json.loads(c.PACKAGE.read_text());c.verify_package(c.STORE,c.IDENT)
 # Header-only verification against derived Qwen3 inventory, before blocking weight access.
 from tensor_inventory import expected_inventory
 with (c.STORE/'model.safetensors').open('rb') as f:n=struct.unpack('<Q',f.read(8))[0];assert n<1024**2;h=json.loads(f.read(n))
 h.pop('__metadata__',None);ex=expected_inventory();assert set(h)==set(ex)
 for name,v in h.items():assert {k:v[k] for k in ('shape','dtype')}==ex[name],name
 try:
  with socket.socket() as sock:sock.connect(('127.0.0.1',9))
 except OSError as e:assert e.errno in (errno.EPERM,errno.EACCES)
 else:raise RuntimeError('Network denial missing')
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',USE_TORCH='0',USE_TF='0',USE_FLAX='0')
 def forbidden(*a,**k):raise RuntimeError('MODEL_OR_NETWORK_NOT_ALLOWED_IN_PREFLIGHT')
 def audit(event,args):
  if event in ('socket.connect','socket.getaddrinfo','subprocess.Popen','os.system','os.posix_spawn'):forbidden()
  if event=='open' and isinstance(args[0],(str,bytes)) and str(args[0]).endswith(('.safetensors','.gguf','.bin')):forbidden()
 sys.addaudithook(audit)
 import huggingface_hub
 huggingface_hub.snapshot_download=forbidden;huggingface_hub.hf_hub_download=forbidden
 from transformers import AutoTokenizer
 tok=AutoTokenizer.from_pretrained(str(c.STORE),local_files_only=True,trust_remote_code=False)
 assert tok.eos_token_id==151645
 messages=json.loads((c.RUN/'input.json').read_text())
 assert len(messages)==2 and all(x['role'] in ('system','user') and isinstance(x['content'],str) for x in messages)
 sources=json.loads((c.RUN/'sources.json').read_text()) if (c.RUN/'sources.json').exists() else []
 try:messages,packet=pack(tok,messages,sources)
 except ContextLimit as error:
  c.save('context-error.json',{'message':str(error)})
  raise AssertionError('UNSUPPORTED_RESOURCE_PROFILE') from error
 prompt,ids=render(tok,messages)
 assert len(ids)+OUTPUT_TOKENS<=TOTAL_CONTEXT,'UNSUPPORTED_RESOURCE_PROFILE'
 c.save('context-packet.json',packet)
 row={'id':'user-request','messages':messages,'rawPrompt':prompt,'tokenIDs':ids,'promptTokens':len(ids),'expectedPromptTokens':len(ids),'maxNewTokens':OUTPUT_TOKENS,'maxTotalContext':TOTAL_CONTEXT,'inputSHA256':hashlib.sha256(json.dumps(messages,sort_keys=True).encode()).hexdigest()}
 data={'requests':[row],'templateSHA256':hashlib.sha256(tok.chat_template.encode()).hexdigest(),'tokenizerSHA256':c.sha(c.STORE/'tokenizer.json'),'stopSet':[151645],'thinking':False,'tools':[],'packetIDs':list(dict.fromkeys(x['id'] for x in packet['sources'])) if packet else [],'partialCoverage':packet['partial'] if packet else False,'scopeNote':'Tokenizer-bounded source excerpts; omitted text and search coverage are disclosed in the service result. The user question is not truncated.'}
 c.save('frozen-suite.json',data);c.save('tokenizer-runtime-check.json',{'status':'PASS','networkNegativeControl':'DENIED','modelLoads':0,'promptTokens':len(ids),'totalWithOutput':len(ids)+OUTPUT_TOKENS,'packetIDs':data['packetIDs'],'partialCoverage':data['partialCoverage']})
 print(json.dumps({'status':'PASS','promptTokens':len(ids)}))
if __name__=='__main__':main()

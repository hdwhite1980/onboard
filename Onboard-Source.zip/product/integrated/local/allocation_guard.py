"""Metadata-only packed-storage/eager-evaluation guards; never evaluate arrays."""
FLOAT_EVAL_LIMIT=2*1024**3
DTYPES={'U32':'mlx.core.uint32','BF16':'mlx.core.bfloat16','F32':'mlx.core.float32'}
def verify_bound(records,expected,cast=False):
 assert set(records)==set(expected),'FULL_PRECISION_EXPANSION: parameter inventory changed'
 for name,e in expected.items():
  r=records[name];dtype=DTYPES[e['dtype']]
  if cast and e['dtype']=='BF16':dtype='mlx.core.float16'
  assert r['shape']==e['shape'] and r['dtype']==dtype,('FULL_PRECISION_EXPANSION: packed parameter changed',name,r,e)
 return {'entries':len(records),'packedEntries':sum(e['dtype']=='U32' for e in expected.values()),'logicalBytes':sum(r['bytes'] for r in records.values())}
def check_eager(records):
 total=sum(r['bytes'] for r in records if r['dtype'] in ('mlx.core.float16','mlx.core.bfloat16','mlx.core.float32','mlx.core.float64'))
 assert total<=FLOAT_EVAL_LIMIT,('FULL_PRECISION_EXPANSION: substantial floating eager evaluation',total)
 return total

"""Additional worker filesystem/exec confinement; no expansion of network permissions."""
import json,pathlib,sys

def worker_profile(root,run,python):
    root=pathlib.Path(root).resolve();run=pathlib.Path(run).resolve();python=pathlib.Path(python).resolve()
    # The interpreter may be a framework installation outside the venv.
    framework=next((p for p in python.parents if p.name.endswith('.framework')),python.parent.parent)
    reads=[run,root/'product/integrated/local',root/'product/integrated/.artifacts/venv',framework]
    # deny file-read-data everywhere except runtime, immutable OS libraries and this request.
    reads += [pathlib.Path('/System'),pathlib.Path('/usr'),pathlib.Path('/bin'),pathlib.Path('/sbin'),pathlib.Path('/Library/Apple'),pathlib.Path('/dev'),pathlib.Path('/private/var/db'),pathlib.Path('/Library/Preferences')]
    ancestors=set(parent for p in reads for parent in p.parents)
    allow=' '.join('(subpath '+json.dumps(str(p))+')' for p in reads)+' '+' '.join('(literal '+json.dumps(str(p))+')' for p in ancestors)
    return '(version 1)(allow default)(deny network*)(deny file-read-data (require-not (require-any '+allow+')))(deny file-write* (require-not (require-any (subpath '+json.dumps(str(run))+') (literal "/dev/null"))))(deny process-exec (require-not (literal '+json.dumps(str(python))+')))(deny process-fork)'

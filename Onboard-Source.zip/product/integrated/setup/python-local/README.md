# Pinned Python executable

This is the exact Python 3.12.14 arm64 executable already qualified with Onboard, after replacement of its invalid upstream signature with a local ad-hoc integrity signature. It is not notarized or publisher-signed. Python license terms are in LICENSE.txt.

Publisher archive SHA-256: `440347ef30d7560dd79a272f0886b4d3c648c20982019049dadcf07a88a62a26`. Original executable SHA-256: `f91a7185b6b453b827a36d33017ccbd50c21187a551212bc0b2c99c7ca0428f2`. Distributed executable SHA-256: `931eb2e59857c31d68d90825409d00f3af852f906c321528aaa0432cc48e7d60`.

Setup verifies the publisher archive and original executable, then copies this exact checked executable instead of recreating a signature with the destination machine’s codesign tool. It checks the distributed hash and verifies its signature. Runtime identity checks and historical provenance are unchanged. The rest of Python is downloaded from the pinned archive.

use serde_json::{Value,json};
use std::io::{self,Read};
use std::collections::HashSet;

fn evaluate(v:&Value)->Value {
 let task=v["task"].as_str().unwrap_or("");
 let tasks=["ask","summarize","explain","extract","reply","rewrite","shorten","tone","prepare","followup"];
 if !tasks.contains(&task) {return json!({"allowed":false,"reason":"Unsupported task"})}
 if v["enabled"]!=true {return json!({"allowed":false,"code":"PROCESSING_DISABLED","reason":if v["route"]=="local" {"Local AI is turned off. Enable Local AI for public input in Ask Local AI or AI Settings."} else if v["route"]=="web" {"Internet lookup is turned off in AI Settings."} else {"Cloud AI is turned off. Enable public cloud requests in AI Settings and save."}})}
 if v["public_attested"]!=true {return json!({"allowed":false,"code":"PUBLIC_CONFIRMATION_REQUIRED","reason":"Confirm that this question is public and permitted before sending it. Internal, FCI, CUI and unknown content remain blocked."})}
 if v["route"]=="cloud" && ((v["explicit_cloud"]!=true && v["automatic_cloud"]!=true) || v["provider_enabled"]!=true) {return json!({"allowed":false,"reason":"An approved provider and permission for cloud assistance are required."})}
 if v["route"]=="web" && v["explicit_web"]!=true {return json!({"allowed":false,"reason":"Internet lookup was not permitted for this question."})}
 if !matches!(v["route"].as_str(),Some("local"|"cloud"|"web")) {return json!({"allowed":false,"reason":"Invalid route"})}
 json!({"allowed":true,"reason":"Owner-configured public-content development policy; user declaration, not an authoritative sensitivity label.","classification":"PUBLIC_USER_DECLARED","production_policy":false})
}
fn validate(v:&Value)->Value {
 let mut ids=HashSet::new();
 let Some(sources)=v["sources"].as_array() else {return json!({"valid":false})};
 if sources.len()>30 {return json!({"valid":false})}
 for s in sources {if s["id"].as_str().is_none_or(|id|id.is_empty()||!ids.insert(id))||s["text"].as_str().is_none_or(|t|t.len()>65536) {return json!({"valid":false})}}
 let Some(claims)=v["claims"].as_array() else {return json!({"valid":false})};
 if claims.len()>32 {return json!({"valid":false})}
 for claim in claims {
  let Some(s)=sources.iter().find(|s|s["id"]==claim["source_id"]) else {return json!({"valid":false})};
  let q=claim["quote"].as_str().unwrap_or("");
  if q.trim().is_empty()||!s["text"].as_str().unwrap_or("").contains(q) {return json!({"valid":false})}
  for key in ["owner","date","amount"] {if let Some(a)=claim[key].as_str() {if a.is_empty()||!q.contains(a) {return json!({"valid":false})}}}
 }
 json!({"valid":true,"claims":claims,"note":"Exact source spans checked. Selection relevance, completeness, approval state and semantic interpretation still require review."})
}
fn main(){let mut b=Vec::new();io::stdin().take(1_048_577).read_to_end(&mut b).unwrap();let out=if b.len()>1_048_576 {json!({"error":"Request too large"})} else {match serde_json::from_slice::<Value>(&b){Ok(v)=>match v["command"].as_str(){Some("policy")=>evaluate(&v),Some("validate")=>validate(&v),Some("legacy_live")=>onboard_briefing_core::prepare_live(v["snapshot"].clone()).unwrap_or(json!({"error":"Invalid snapshot"})),_=>json!({"error":"Unsupported command"})},Err(_)=>json!({"error":"Invalid JSON"})}};println!("{}",out);}
#[cfg(test)] mod tests {use super::*;
 #[test] fn policy_fails_closed(){assert_eq!(evaluate(&json!({"task":"ask","route":"local"}))["allowed"],false);assert_eq!(evaluate(&json!({"task":"ask","route":"cloud","enabled":true,"public_attested":true}))["allowed"],false);}
 #[test] fn unsupported_action(){assert_eq!(evaluate(&json!({"task":"send","route":"local","enabled":true,"public_attested":true}))["allowed"],false);}
 #[test] fn reject_cross_source(){assert_eq!(validate(&json!({"sources":[{"id":"a","text":"pending"}],"claims":[{"source_id":"b","quote":"pending"}]}))["valid"],false);}
 #[test] fn reject_changed_approval(){assert_eq!(validate(&json!({"sources":[{"id":"a","text":"not approved"}],"claims":[{"source_id":"a","quote":"fully approved"}]}))["valid"],false);}
}

'use strict';
// Replaced only by the explicit Teams-actions packager with a real bot ID.
globalThis.OnboardActionConfig=Object.freeze({botId:''});

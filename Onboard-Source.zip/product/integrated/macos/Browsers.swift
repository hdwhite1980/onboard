import AppKit
import Foundation

struct BrowserChoice: Identifiable {
 let id:String
 let name:String
 let url:URL
}
enum Browsers {
 static func installed() -> [BrowserChoice] {
  let urls=NSWorkspace.shared.urlsForApplications(toOpen:URL(string:"https://example.com")!)
  var seen=Set<String>()
  return urls.compactMap { url in
   guard let bundle=Bundle(url:url),let id=bundle.bundleIdentifier,seen.insert(id).inserted else{return nil}
   let types=bundle.object(forInfoDictionaryKey:"CFBundleURLTypes") as? [[String:Any]] ?? []
   let schemes=Set(types.flatMap{$0["CFBundleURLSchemes"] as? [String] ?? []}.map{$0.lowercased()})
   guard schemes.contains("http"),schemes.contains("https") else{return nil}
   let name=bundle.object(forInfoDictionaryKey:"CFBundleDisplayName") as? String ?? bundle.object(forInfoDictionaryKey:"CFBundleName") as? String ?? url.deletingPathExtension().lastPathComponent
   return BrowserChoice(id:id,name:name,url:url)
  }.sorted{$0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending}
 }
 static func searchURL(query:String,engine:String) throws -> URL {
  let endpoints=["duckduckgo":"https://duckduckgo.com/","google":"https://www.google.com/search","bing":"https://www.bing.com/search"]
  guard let endpoint=endpoints[engine],!query.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else {throw OnboardError(message:"Choose a search engine in AI Settings.")}
  var parts=URLComponents(string:endpoint)!
  var allowed=CharacterSet.urlQueryAllowed
  allowed.remove(charactersIn:"&+=?#")
  guard let encoded=query.addingPercentEncoding(withAllowedCharacters:allowed) else {throw OnboardError(message:"Could not encode the search question.")}
  parts.percentEncodedQuery="q="+encoded
  guard let url=parts.url else {throw OnboardError(message:"Could not prepare browser search.")}
  return url
 }
 @MainActor static func open(_ url:URL,browserID:String) async throws {
  guard ["https","http"].contains(url.scheme?.lowercased() ?? ""),url.host != nil,url.user == nil,url.password == nil else {throw OnboardError(message:"Only web links can open in the browser.")}
  let application:URL
  if browserID.isEmpty {
   guard let selected=NSWorkspace.shared.urlForApplication(toOpen:URL(string:"https://example.com")!) else {throw OnboardError(message:"No default browser is available. Choose an installed browser in AI Settings.")}
   application=selected
  }else{
   guard let selected=installed().first(where:{$0.id==browserID}) else {throw OnboardError(message:"Your chosen browser is no longer available. Choose another in AI Settings; Onboard has not opened a different browser.")}
   application=selected.url
  }
  try await withCheckedThrowingContinuation { (continuation:CheckedContinuation<Void,Error>) in
   NSWorkspace.shared.open([url],withApplicationAt:application,configuration:NSWorkspace.OpenConfiguration()) { app,error in
    if let error=error {continuation.resume(throwing:error)}
    else if app == nil {continuation.resume(throwing:OnboardError(message:"The browser did not open."))}
    else {continuation.resume(returning:())}
   }
  }
 }
}

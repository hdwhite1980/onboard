import Foundation

enum HelperAuthorization {
 static func claim(kind:String) throws -> [String:String] {
  let input=try FileHandle.standardInput.read(upToCount:2049) ?? Data()
  guard input.count<=2048,let request=try JSONSerialization.jsonObject(with:input) as? [String:String],Set(request.keys)==Set(["ticket"]),let ticket=request["ticket"],ticket.count<=100 else {throw NSError(domain:"HelperAuthorization",code:1)}
  let command=try Native.request(["op":"helper_claim","ticket":ticket,"kind":kind])
  guard let typed=command as? [String:String] else {throw NSError(domain:"HelperAuthorization",code:2)}
  return typed
 }
}

extension WorkspaceCrypto {
 static func run(_ args:[String]) -> Never {
  do {
   guard args.count == 2 else { exit(2) }
   let request=try HelperAuthorization.claim(kind:"workspace")
   guard let action=request["action"], ["seal","open"].contains(action),
    let context=request["context"],context.count == 64,context.allSatisfy({$0.isHexDigit}),
    let encoded=request["data"],encoded.count<=8_000_000,let data=Data(base64Encoded:encoded) else { exit(2) }
   let key=try key(create:action == "seal")
   let output = try action == "seal" ? seal(data,key:key,context:Data(context.utf8)) : open(data,key:key,context:Data(context.utf8))
   FileHandle.standardOutput.write(Data(output.base64EncodedString().utf8));exit(0)
  } catch {
   FileHandle.standardError.write(Data("Saved workspace unavailable. Unlock Keychain; existing encrypted files have been preserved.\n".utf8));exit(3)
  }
 }
}

import SwiftUI
struct ActivityView:View {
 @ObservedObject var s:Store
 var body:some View {
  ScrollView {
   VStack(alignment:.leading,spacing:14){
    Text(s.activitySummary).font(.headline)
    Text("See Onboard processes, request activity and issues. This view does not scan other applications. Events are retained for this service session; exports exclude prompts, source content, credentials and AI responses.").font(.caption).foregroundStyle(.secondary)
    if !s.activityMetrics.isEmpty {Text(s.activityMetrics).font(.caption)}
    HStack {Button("Refresh"){Task{await s.refreshActivity()}};Button("Export diagnostic log"){s.exportActivity()}.disabled(s.activityJSON.isEmpty)}
    if !s.activityNotice.isEmpty {Text(s.activityNotice).foregroundStyle(.orange).textSelection(.enabled)}
    ForEach(Array(s.activityJobs.enumerated()),id:\.offset){_,job in
     HStack {Text(job["reference"] as? String ?? "Request").monospaced();Text(job["state"] as? String ?? "");Spacer();Text(job["route"] as? String ?? "")}.font(.caption)
    }
    ForEach(Array(s.activityProcesses.enumerated()),id:\.offset){_,process in
     Text("\(process["role"] as? String ?? "Process") · PID \(process["pid"] as? Int ?? 0) · \(process["state"] as? String ?? "")").font(.caption).textSelection(.enabled)
    }
    Divider()
    if s.activityRows.isEmpty {Text("No request activity recorded in this service session.").foregroundStyle(.secondary)}
    ForEach(Array(s.activityRows.reversed().enumerated()),id:\.offset){_,row in
     VStack(alignment:.leading,spacing:4){
      HStack {Text(row["message"] as? String ?? "Activity").font(.headline);Spacer();Text(Date(timeIntervalSince1970:row["time"] as? Double ?? 0),style:.time).font(.caption)}
      HStack {Text(row["reference"] as? String ?? "");if let pid=row["pid"] as? Int {Text("PID \(pid)")};if let code=row["code"] as? String {Text(code).foregroundStyle(.orange)}}.font(.caption).monospaced()
      if let hint=row["next_step"] as? String {Text(hint).font(.callout)}
     }.padding(10).frame(maxWidth:.infinity,alignment:.leading).background(.quaternary,in:RoundedRectangle(cornerRadius:8))
    }
   }.frame(maxWidth:.infinity,alignment:.leading)
  }
 }
}

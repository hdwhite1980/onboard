import AppKit
import ApplicationServices
import CryptoKit

// Native controller: only consumes a one-use command from authenticated service IPC.
// No shell, AppleScript, browser debugging port, downloaded code or credential input.
enum Automation {
 static func attr(_ e:AXUIElement,_ name:String)->CFTypeRef? {var v:CFTypeRef?;return AXUIElementCopyAttributeValue(e,name as CFString,&v) == .success ? v:nil}
 static func text(_ e:AXUIElement,_ name:String,_ limit:Int=512)->String {String((attr(e,name) as? String ?? "").prefix(limit))}
 static func rect(_ e:AXUIElement)->CGRect? {
  guard let p=attr(e,kAXPositionAttribute),let s=attr(e,kAXSizeAttribute),CFGetTypeID(p)==AXValueGetTypeID(),CFGetTypeID(s)==AXValueGetTypeID() else{return nil}
  var point=CGPoint.zero;var size=CGSize.zero
  guard AXValueGetValue(p as! AXValue,.cgPoint,&point),AXValueGetValue(s as! AXValue,.cgSize,&size) else{return nil}
  return CGRect(origin:point,size:size)
 }
 static func bounds(_ r:CGRect)->[Double] {[Double(r.minX),Double(r.minY),Double(r.width),Double(r.height)]}
 static func checkPoint(_ point:CGPoint,_ pid:pid_t)throws {
  var element:AXUIElement?;var found:pid_t=0
  guard AXUIElementCopyElementAtPosition(AXUIElementCreateSystemWide(),Float(point.x),Float(point.y),&element) == .success,let e=element,AXUIElementGetPid(e,&found) == .success,found==pid,text(e,kAXSubroleAttribute) != "AXSecureTextField" else{throw OnboardError(message:"Another window or a protected field covers the mouse target. Inspect again; no mouse input was sent.")}
 }
 static func snapshot(_ id:String)throws->([String:Any],[AXUIElement],NSRunningApplication,CGRect) {
  guard AXIsProcessTrusted() else{throw OnboardError(message:"Allow Onboard AI in macOS Privacy & Security → Accessibility, then retry. No computer action ran.")}
  let matches=NSRunningApplication.runningApplications(withBundleIdentifier:id)
  guard matches.count==1,let app=matches.first else{throw OnboardError(message:"Open exactly one instance of the selected application, then inspect it.")}
  let root=AXUIElementCreateApplication(app.processIdentifier);AXUIElementSetMessagingTimeout(root,2)
  guard let w=attr(root,kAXFocusedWindowAttribute),CFGetTypeID(w)==AXUIElementGetTypeID() else{throw OnboardError(message:"The application exposes no focused accessible window.")}
  let window=w as! AXUIElement
  guard let frame=rect(window),frame.width>0,frame.height>0 else{throw OnboardError(message:"Window bounds are unavailable.")}
  var queue:[(AXUIElement,Int)]=[(window,0)];var nodes:[[String:Any]]=[];var refs:[AXUIElement]=[];var urls:[String]=[];var index=0;var partial=false;var byteCount=0
  while index<queue.count && nodes.count<350 {
   let (e,depth)=queue[index];index+=1
   let role=text(e,kAXRoleAttribute);let sub=text(e,kAXSubroleAttribute);let secure=sub=="AXSecureTextField"
   var actions:CFArray?;_ = AXUIElementCopyActionNames(e,&actions)
   var row:[String:Any]=["id":String(nodes.count),"role":role,"title":text(e,kAXTitleAttribute),"description":text(e,kAXDescriptionAttribute),"value":secure ? "[protected]":text(e,kAXValueAttribute,1000),"protected":secure,"actions":actions as? [String] ?? []]
   if let r=rect(e){row["bounds"]=bounds(r)}
   if let url=attr(e,"AXURL") as? URL,role=="AXWebArea" {urls.append(url.absoluteString)}
   if role=="AXWebArea",let url=attr(e,"AXURL") as? String{urls.append(url)}
   if role=="AXWindow" {let doc=text(e,"AXDocument",2048);if doc.hasPrefix("https://"){urls.append(doc)}}
   if let link=attr(e,"AXURL") as? URL{row["url"]=link.absoluteString}
   byteCount += (try JSONSerialization.data(withJSONObject:row)).count
   if byteCount>28000 {partial=true;break}
   nodes.append(row);refs.append(e)
   if depth<14,let children=attr(e,kAXChildrenAttribute) as? [AXUIElement] {let room=max(0,700-queue.count);for child in children.prefix(room){queue.append((child,depth+1))};if children.count>room{partial=true}}
  }
  partial = partial || index<queue.count
  let state:[String:Any]=["app":id,"pid":Int(app.processIdentifier),"window":text(window,kAXTitleAttribute),"bounds":bounds(frame),"nodes":nodes,"urls":Array(Set(urls)).sorted(),"partial":partial]
  let bytes=try JSONSerialization.data(withJSONObject:state,options:[.sortedKeys]);var result=state
  result["fingerprint"]=SHA256.hash(data:bytes).map{String(format:"%02x",$0)}.joined()
  result["text"]=String(nodes.map{[$0["title"] as? String ?? "",$0["description"] as? String ?? "",$0["value"] as? String ?? ""].filter{!$0.isEmpty}.joined(separator:" ")}.joined(separator:"\n").prefix(24000))
  return(result,refs,app,frame)
 }
 static func perform(_ command:[String:Any])throws->[String:Any] {
  if command["operation"] as? String == "capabilities" {return ["accessibility":AXIsProcessTrusted(),"controller":"macOS Accessibility + CGEvent","screenCapture":false]}
  guard let id=command["app"] as? String else{throw OnboardError(message:"Missing target application.")}
  if command["operation"] as? String == "open" {
   guard let url=NSWorkspace.shared.urlForApplication(withBundleIdentifier:id) else{throw OnboardError(message:"The approved app is not installed.")}
   var finished=false;var failure:Error?;var launched:NSRunningApplication?
   let configuration=NSWorkspace.OpenConfiguration();configuration.activates=true
   NSWorkspace.shared.openApplication(at:url,configuration:configuration){app,error in launched=app;failure=error;finished=true}
   let end=Date().addingTimeInterval(10)
   while !finished && Date()<end{RunLoop.current.run(until:Date().addingTimeInterval(0.05))}
   guard finished,failure==nil,launched?.bundleIdentifier==id else{throw OnboardError(message:"App opening was not confirmed. Inspect the desktop before retrying.")}
   return ["opened":id,"note":"Application opened; inspect its window before acting."]
  }
  let (before,refs,app,frame)=try snapshot(id)
  if command["operation"] as? String == "inspect" {return before}
  guard command["operation"] as? String == "action",command["fingerprint"] as? String == before["fingerprint"] as? String else{throw OnboardError(message:"The window changed since inspection. Inspect it again; nothing was clicked or typed.")}
  guard let action=command["action"] as? String else{throw OnboardError(message:"Missing action.")}
  guard !(before["nodes"] as? [[String:Any]] ?? []).contains(where:{$0["protected"] as? Bool == true}) else{throw OnboardError(message:"This window contains a protected credential field. Complete sign-in yourself, then inspect again.")}
  _ = app.activate(options:[]);Thread.sleep(forTimeInterval:0.15)
  guard NSWorkspace.shared.frontmostApplication?.processIdentifier==app.processIdentifier else{throw OnboardError(message:"Target app did not become active. Nothing was entered.")}
  let (current,_,_,_)=try snapshot(id)
  guard current["fingerprint"] as? String == before["fingerprint"] as? String else{throw OnboardError(message:"Target changed on activation. Inspect and review again.")}
  let target=Int(command["target"] as? String ?? "") ?? -1
  let rows=before["nodes"] as! [[String:Any]]
  if ["press","type","click"].contains(action) {
   guard refs.indices.contains(target),rows[target]["protected"] as? Bool != true else{throw OnboardError(message:"Choose an inspected non-protected control. Enter credentials yourself.")}
  }
  if action=="press" {
   guard (rows[target]["actions"] as? [String] ?? []).contains(kAXPressAction),AXUIElementPerformAction(refs[target],kAXPressAction as CFString) == .success else{throw OnboardError(message:"This control could not be pressed. Inspect again or use a reviewed mouse click.")}
  } else if action=="type" {
   guard let value=command["text"] as? String,value.utf16.count<=4000,!value.contains("\n"),!value.contains("\r") else{throw OnboardError(message:"Type up to 4,000 characters without Return; submit as a separate reviewed action.")}
   guard AXUIElementSetAttributeValue(refs[target],kAXFocusedAttribute as CFString,kCFBooleanTrue) == .success else{throw OnboardError(message:"Could not focus the selected field.")}
   let root=AXUIElementCreateApplication(app.processIdentifier)
   guard let focus=attr(root,kAXFocusedUIElementAttribute),CFEqual(focus,refs[target]) else{throw OnboardError(message:"Focus moved. No text was entered.")}
   var settable=DarwinBoolean(false)
   if AXUIElementIsAttributeSettable(refs[target],kAXValueAttribute as CFString,&settable) == .success && settable.boolValue {
    guard AXUIElementSetAttributeValue(refs[target],kAXValueAttribute as CFString,value as CFString) == .success else{throw OnboardError(message:"Could not set the field value.")}
   } else {
    guard ["AXTextField","AXTextArea","AXComboBox"].contains(rows[target]["role"] as? String ?? "") else{throw OnboardError(message:"Keyboard text requires an accessible text field.")}
    guard NSWorkspace.shared.frontmostApplication?.processIdentifier==app.processIdentifier else{throw OnboardError(message:"Focus changed.")}
    let chars=Array(value.utf16);guard let down=CGEvent(keyboardEventSource:nil,virtualKey:0,keyDown:true),let up=CGEvent(keyboardEventSource:nil,virtualKey:0,keyDown:false) else{throw OnboardError(message:"Keyboard event unavailable.")}
    chars.withUnsafeBufferPointer {down.keyboardSetUnicodeString(stringLength:chars.count,unicodeString:$0.baseAddress);up.keyboardSetUnicodeString(stringLength:chars.count,unicodeString:$0.baseAddress)}
    down.post(tap:.cghidEventTap);up.post(tap:.cghidEventTap)
   }
  } else if action=="click" || action=="point" {
   let point:CGPoint
   if action=="click",let r=rect(refs[target]){point=CGPoint(x:r.midX,y:r.midY)}
   else if action=="point",let x=command["x"] as? Double,let y=command["y"] as? Double,x.isFinite,y.isFinite {point=CGPoint(x:frame.minX+x,y:frame.minY+y)}
   else{throw OnboardError(message:"Invalid mouse coordinates.")}
   guard frame.contains(point) else{throw OnboardError(message:"Mouse target is outside the inspected window.")}
   try checkPoint(point,app.processIdentifier)
   guard let down=CGEvent(mouseEventSource:nil,mouseType:.leftMouseDown,mouseCursorPosition:point,mouseButton:.left),let up=CGEvent(mouseEventSource:nil,mouseType:.leftMouseUp,mouseCursorPosition:point,mouseButton:.left) else{throw OnboardError(message:"Mouse events unavailable.")}
   down.post(tap:.cghidEventTap);up.post(tap:.cghidEventTap)
  } else if action=="key" {
   let keys:[String:CGKeyCode]=["Return":36,"Tab":48,"Escape":53,"Left":123,"Right":124,"Down":125,"Up":126,"Backspace":51]
   guard let name=command["key"] as? String,let key=keys[name],let down=CGEvent(keyboardEventSource:nil,virtualKey:key,keyDown:true),let up=CGEvent(keyboardEventSource:nil,virtualKey:key,keyDown:false) else{throw OnboardError(message:"Unsupported key. Modifier shortcuts are not enabled.")}
   down.post(tap:.cghidEventTap);up.post(tap:.cghidEventTap)
  } else if action=="scroll" {
   guard let direction=command["direction"] as? String,["up","down"].contains(direction),let event=CGEvent(scrollWheelEvent2Source:nil,units:.line,wheelCount:1,wheel1:direction=="up" ? 5:-5,wheel2:0,wheel3:0) else{throw OnboardError(message:"Choose up or down.")}
   // Scroll at the inspected window center after the foreground-app check.
   try checkPoint(CGPoint(x:frame.midX,y:frame.midY),app.processIdentifier)
   CGEvent(mouseEventSource:nil,mouseType:.mouseMoved,mouseCursorPosition:CGPoint(x:frame.midX,y:frame.midY),mouseButton:.left)?.post(tap:.cghidEventTap)
   event.post(tap:.cghidEventTap)
  } else {throw OnboardError(message:"Unsupported computer action.")}
  Thread.sleep(forTimeInterval:0.2)
  let after=try snapshot(id).0
  return ["performed":true,"verified":false,"after":after,"note":"Input delivered. Verify the intended outcome; changed UI alone does not prove business success."]
 }
 static func run()->Never {
  do {
   let raw=FileHandle.standardInput.readDataToEndOfFile()
   guard raw.count<2048,let input=try JSONSerialization.jsonObject(with:raw) as? [String:String],let ticket=input["ticket"] else{exit(2)}
   let request=try Native.request(["op":"automation_claim","ticket":ticket])
   let result=try perform(request)
   FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]));exit(0)
  } catch {FileHandle.standardError.write(Data((error.localizedDescription+"\n").utf8));exit(3)}
 }
}

import SwiftUI
import Foundation
import Security
import Darwin

struct OnboardError: LocalizedError { let message: String; var errorDescription: String? { message } }
enum Vault {
 static func run(_ args: [String]) -> Never {
  guard args.count == 4, ["provider-key","search-key","weather-key"].contains(args[3]) else { exit(2) }
  let q:[String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"local.onboard.integrated.credentials",kSecAttrAccount as String:args[3]]
  if args[2] == "read" {
   var r=q;r[kSecReturnData as String]=true;r[kSecMatchLimit as String]=kSecMatchLimitOne
   var item:CFTypeRef?;guard SecItemCopyMatching(r as CFDictionary,&item)==errSecSuccess,let data=item as? Data else { exit(3) }
   FileHandle.standardOutput.write(data);exit(0)
  }
  if args[2] == "write" {
   let data=FileHandle.standardInput.readDataToEndOfFile();guard !data.isEmpty,data.count<8192 else {exit(2)}
   let update=[kSecValueData as String:data];var status=SecItemUpdate(q as CFDictionary,update as CFDictionary)
   if status==errSecItemNotFound {var add=q;add.merge(update){_,n in n};add[kSecAttrAccessible as String]=kSecAttrAccessibleWhenUnlockedThisDeviceOnly;status=SecItemAdd(add as CFDictionary,nil)}
   exit(status==errSecSuccess ? 0:3)
  }
  if args[2] == "delete" {let s=SecItemDelete(q as CFDictionary);exit(s==errSecSuccess || s==errSecItemNotFound ? 0:3)}
  exit(2)
 }
 static func write(_ value:String, key:String = "provider-key") throws {
  guard ["provider-key","search-key","weather-key"].contains(key) else {throw OnboardError(message:"Unsupported credential.")}
  let q:[String:Any]=[kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"local.onboard.integrated.credentials",kSecAttrAccount as String:key]
  let d=[kSecValueData as String:Data(value.utf8)];var s=SecItemUpdate(q as CFDictionary,d as CFDictionary)
  if s==errSecItemNotFound {var a=q;a.merge(d){_,n in n};a[kSecAttrAccessible as String]=kSecAttrAccessibleWhenUnlockedThisDeviceOnly;s=SecItemAdd(a as CFDictionary,nil)}
  guard s==errSecSuccess else {throw OnboardError(message:"Could not save the API credential in Keychain.")}
 }
}
enum Native {
 static var resources:URL {Bundle.main.resourceURL!}
 static var deployment:[String:String] {(try? JSONSerialization.jsonObject(with:Data(contentsOf:resources.appendingPathComponent("deployment.json")))) as? [String:String] ?? [:]}
 static var state:String {deployment["state"] ?? ""}
 static func request(_ value:[String:Any],timeoutSeconds:Int=35) throws -> [String:Any] {
  let fd=socket(AF_UNIX,SOCK_STREAM,0);guard fd>=0 else {throw OnboardError(message:"Local connection unavailable.")};defer{Darwin.close(fd)}
  var timeout=timeval(tv_sec:timeoutSeconds,tv_usec:0);setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,socklen_t(MemoryLayout<timeval>.size));setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,socklen_t(MemoryLayout<timeval>.size))
  var noPipe:Int32=1;setsockopt(fd,SOL_SOCKET,SO_NOSIGPIPE,&noPipe,4)
  var address=sockaddr_un();address.sun_family=sa_family_t(AF_UNIX)
  let path=state+"/native.sock";let bytes=Array(path.utf8)+[0];guard bytes.count<=MemoryLayout.size(ofValue:address.sun_path) else {throw OnboardError(message:"Installation path is too long for the local connection.")}
  withUnsafeMutableBytes(of:&address.sun_path){$0.copyBytes(from:bytes)}
  let result=withUnsafePointer(to:&address){$0.withMemoryRebound(to:sockaddr.self,capacity:1){Darwin.connect(fd,$0,socklen_t(MemoryLayout<sockaddr_un>.size))}}
  guard result==0 else {throw OnboardError(message:"Local service is stopped. Start it in Settings.")}
  var data=try JSONSerialization.data(withJSONObject:value);data.append(10)
  try data.withUnsafeBytes {buffer in
   var offset=0
   while offset<buffer.count {let n=Darwin.send(fd,buffer.baseAddress!.advanced(by:offset),buffer.count-offset,0);guard n>0 else {throw OnboardError(message:"Local request could not be sent.")};offset+=n}
  }
  var out=Data();var buffer=[UInt8](repeating:0,count:8192)
  while out.count<2_097_152 {let n=Darwin.recv(fd,&buffer,buffer.count,0);if n<=0 {break};out.append(contentsOf:buffer.prefix(n));if out.last==10 {break}}
  guard let answer=try JSONSerialization.jsonObject(with:out) as? [String:Any] else {throw OnboardError(message:"Local service returned an invalid response.")}
  if let error=answer["error"] as? String {throw OnboardError(message:error)}
  return answer
 }
 static func localCheck() throws -> [String:Any] {
  let before=try request(["op":"status"])
  guard let settings=before["settings"] as? [String:Any],settings["public_local"] as? Bool == true else {throw OnboardError(message:"Enable local processing before the check.")}
  let prompt="Summarize this actual product requirement in one sentence: Onboard uses one Ask AI window. It asks the local model first and may use configured cloud AI if needed. Internet lookup should report proxy blocks."
  let queued=try request(["op":"submit","task":"summarize","route":"auto","prompt":prompt,"public_attested":true,"web_mode":"off","allow_cloud":false])
  guard let id=queued["id"] as? String else {throw OnboardError(message:"Request was not queued.")}
  let deadline=Date().addingTimeInterval(240)
  while Date()<deadline {
   let job=try request(["op":"job","id":id]);let state=job["state"] as? String ?? ""
   if ["complete","failed","cancelled"].contains(state){return ["request":prompt,"job":job,"via":"Native executable → authenticated IPC → shared queue → retained local model"]}
   Thread.sleep(forTimeInterval:0.25)
  }
  _ = try? request(["op":"cancel","id":id]);throw OnboardError(message:"Local check timed out; cancellation requested.")
 }
 static func weatherCheck() throws -> [String:Any] {
  let question="What is the weather in Washington, DC?"
  let queued=try request(["op":"submit","task":"ask","route":"auto","prompt":question,"public_attested":true,"web_mode":"auto","allow_cloud":false]);guard let id=queued["id"] as? String else {throw OnboardError(message:"Not queued.")}
  let deadline=Date().addingTimeInterval(90)
  while Date()<deadline {let job=try request(["op":"job","id":id]);if ["complete","failed","cancelled"].contains(job["state"] as? String ?? ""){return ["request":question,"job":job,"via":"Installed Ask AI native connection and shared service"]};Thread.sleep(forTimeInterval:0.25)}
  _ = try? request(["op":"cancel","id":id]);throw OnboardError(message:"Weather check timed out.")
 }
 static func controlLock() throws -> Int32 {
  let port=deployment["bridge_port"] ?? "38473"
  let path=FileManager.default.temporaryDirectory.appendingPathComponent("onboard-service-"+port+".lock").path
  let fd=Darwin.open(path,O_CREAT|O_RDWR|O_NOFOLLOW,0o600)
  guard fd>=0 else {throw OnboardError(message:"Could not lock service controls. Retry shortly.")}
  guard flock(fd,LOCK_EX|LOCK_NB)==0 else {Darwin.close(fd);throw OnboardError(message:"Another Onboard copy is starting or stopping the service. Wait for it to finish, then retry.")}
  return fd
 }
 static func stopVerifiedOwners() throws {
  let p=Process();p.executableURL=URL(fileURLWithPath:deployment["python"] ?? "/usr/bin/python3")
  p.arguments=["-I","-B",resources.appendingPathComponent("service/service_control.py").path,"--state",state,"--port",deployment["bridge_port"] ?? "38473"]
  let error=Pipe();p.standardError=error;p.standardOutput=FileHandle.nullDevice;p.standardInput=FileHandle.nullDevice
  try p.run();let deadline=Date().addingTimeInterval(30)
  while p.isRunning && Date()<deadline {Thread.sleep(forTimeInterval:0.1)}
  if p.isRunning {p.terminate();throw OnboardError(message:"Service shutdown timed out. Retry Stop service.")}
  guard p.terminationStatus==0 else {let detail=String(data:error.fileHandleForReading.readDataToEndOfFile(),encoding:.utf8) ?? "Could not verify the old service.";throw OnboardError(message:detail.trimmingCharacters(in:.whitespacesAndNewlines))}
 }
 static func stop() throws -> [String:Any] {
  let lock=try controlLock();defer{Darwin.close(lock)}
  if (try? request(["op":"stop"],timeoutSeconds:2)) != nil {
   let deadline=Date().addingTimeInterval(22)
   while FileManager.default.fileExists(atPath:state+"/native.sock") && Date()<deadline {Thread.sleep(forTimeInterval:0.1)}
  }
  try stopVerifiedOwners()
  return ["stopped":true,"message":"Local service stopped."]
 }
 static func start() throws {
  let lock=try controlLock();defer{Darwin.close(lock)}
  if let status=try? request(["op":"status"],timeoutSeconds:1),status["running"] as? Bool == true{return}
  guard !state.isEmpty,FileManager.default.fileExists(atPath:resources.appendingPathComponent("service/host.py").path) else {throw OnboardError(message:"Service files are missing. Run the latest Setup.command to repair this installation.")}
  guard (state+"/native.sock").utf8.count<=103 else {throw OnboardError(message:"Installation path is too long for the local service. Use a shorter installation folder.")}
  let python=deployment["python"] ?? "/usr/bin/python3"
  guard FileManager.default.isExecutableFile(atPath:python) else {throw OnboardError(message:"The service’s Python interpreter is missing. Run Setup.command to restore the required files.")}
  try stopVerifiedOwners()
  let directory=URL(fileURLWithPath:state,isDirectory:true)
  try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true,attributes:[.posixPermissions:0o700])
  let logURL=directory.appendingPathComponent("startup.log")
  let statusURL=directory.appendingPathComponent("startup.json")
  try Data().write(to:logURL,options:.atomic)
  try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:logURL.path)
  try JSONSerialization.data(withJSONObject:["state":"starting"]).write(to:statusURL,options:.atomic)
  try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:statusURL.path)
  let log=try FileHandle(forWritingTo:logURL);defer{try? log.close()}
  let p=Process();p.executableURL=URL(fileURLWithPath:python)
  p.arguments=["-I","-B",resources.appendingPathComponent("service/host.py").path,"--resources",resources.path,"--state",state,"--app",Bundle.main.executableURL!.path]
  // Alternative port is used only by isolated startup checks; normal deployment remains 38473.
  if let port=deployment["bridge_port"]{p.arguments! += ["--port",port]}
  p.standardOutput=FileHandle.nullDevice;p.standardError=log;p.standardInput=FileHandle.nullDevice
  p.environment=["PATH":"/usr/bin:/bin:/usr/sbin:/sbin","HOME":FileManager.default.homeDirectoryForCurrentUser.path,"PYTHONDONTWRITEBYTECODE":"1"]
  try p.run()
  let deadline=Date().addingTimeInterval(40)
  while Date()<deadline {
   if let status=try? request(["op":"status"],timeoutSeconds:1),status["running"] as? Bool == true{return}
   if !p.isRunning {
    if let data=try? Data(contentsOf:statusURL),let result=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any],result["state"] as? String == "failed",let detail=result["message"] as? String {throw OnboardError(message:detail)}
    let text=(try? String(contentsOf:logURL,encoding:.utf8)) ?? ""
    throw OnboardError(message:"Service exited (code \(p.terminationStatus)). \(String(text.prefix(2000))) Startup log: \(logURL.path)")
   }
   Thread.sleep(forTimeInterval:0.2)
  }
  if p.isRunning{p.terminate()}
  throw OnboardError(message:"The service did not respond within 40 seconds. Its startup attempt was stopped. Check \(logURL.path).")
 }

}
@MainActor final class Store:ObservableObject {
 @Published var tab="Ask AI"
 @Published var savedItems:[[String:Any]]=[]
 @Published var savedTitle=""
 @Published var savedText=""
 @Published var savedReviewed=false
 @Published var savedNotice="Saved work stays encrypted on this Mac for seven days. Nothing is saved automatically."
 @Published var workspaceBusy=false
 @Published var organizationStatus=""
 private var savedJob=""
 private var completedJob=""
 @Published var agentMode=false
 @Published var agentEnabled=false
 @Published var agentRoots=""
 @Published var agentDomains=""
 @Published var publicLabels=""
 @Published var agentSteps=8
 @Published var agentApproval:[String:String]=[:]
 @Published var agentProgress:[String]=[]
 @Published var agentDecisionBusy=false
 @Published var prompt=""
 @Published var answer=""
 @Published var message="Starting local service…"
 @Published var busy=false
 @Published var publicInput=false
 @Published var settingsMessage=""
 @Published var cloud="Auto"
 @Published var tenantStatus="Environment detected when you sign in."
 @Published var detectingTenant=false
 @Published var tenant=""
 @Published var client=""
 @Published var calendar=true
 @Published var mail=false
 @Published var files=false
 @Published var teams=false
 @Published var transcripts=false
 @Published var sendEmail=false; @Published var sendTeams=false
 @Published var savedLocalEnabled=false
 @Published var localSettingBusy=false
 @Published var startingService=false
 @Published var stoppingService=false
 @Published var localEnabled=false
 @Published var cloudEnabled=false
 @Published var providerType="compatible-chat"
 @Published var providerName=""
 @Published var endpoint=""
 @Published var savedProviderEndpoint=""
 @Published var model=""
 @Published var credential=""
 @Published var browserID=""
 @Published var searchEngine="duckduckgo"
 @Published var installedBrowsers:[BrowserChoice]=[]
 @Published var savedBrowserID=""
 @Published var weatherCredential=""
 @Published var internetEnabled=true
 @Published var cloudFallback=true
 @Published var addinCloud=false
 @Published var webMode="auto"
 @Published var allowCloud=true
 @Published var proxy=""
 @Published var weatherLocation=""
 @Published var weatherUnits="fahrenheit"
 @Published var weatherPlan="evaluation"
 @Published var responseRoute=""
 @Published var origins=""
 @Published var addinHosting="local"
 @Published var maxOutput=512
 @Published var maxInput=16000
 @Published var timeout=60
 @Published var daily=100
 @Published var connected=false
 @Published var account=""
 @Published var localStatus=""
 @Published var connectionRequests:[[String:String]]=[]
 @Published var connectionMessage=""
 @Published var connectionBusy=false
 @Published var pairCode=""
 @Published var pairApplication="outlook"
 @Published var signCode=""
 @Published var signURL=""
 @Published var signing=false
 @Published var sources:[[String:Any]]=[]
 private var job:String?;private var polling:Task<Void,Never>?;private var auth:Task<Void,Never>?
 func call(_ r:[String:Any]) async throws -> [String:Any] {try await Task.detached{try Native.request(r)}.value}
 func refresh(loadSettings:Bool=false) async {
  do {let s=try await call(["op":"status"]);connected=s["graph_connected"] as? Bool ?? false;account=(s["account"] as? [String:Any])?["displayName"] as? String ?? "Not connected";localStatus=(s["local"] as? [String:Any])?["message"] as? String ?? "Unavailable";message="Local service ready"
   organizationStatus=(s["organization_policy"] as? [String:Any])?["message"] as? String ?? ""
   savedBrowserID=((s["settings"] as? [String:Any])?["internet"] as? [String:Any])?["browser_id"] as? String ?? ""
   savedLocalEnabled=(s["settings"] as? [String:Any])?["public_local"] as? Bool ?? false
   if loadSettings,let c=s["settings"] as? [String:Any] {
    let a=c["agent"] as? [String:Any] ?? [:];agentEnabled=a["enabled"] as? Bool ?? false;agentRoots=(a["roots"] as? [String] ?? []).joined(separator:"\n");agentDomains=(a["domains"] as? [String] ?? []).joined(separator:"\n");publicLabels=(a["public_labels"] as? [String] ?? []).joined(separator:"\n");agentSteps=a["max_steps"] as? Int ?? 8
    let g=c["graph"] as? [String:Any] ?? [:];cloud=(g["cloud"] as? String).flatMap{$0.isEmpty ? nil:$0} ?? "Auto";tenant=g["tenant"] as? String ?? "";client=g["client"] as? String ?? "";calendar=g["calendar"] as? Bool ?? true;mail=g["mail"] as? Bool ?? false;files=g["files"] as? Bool ?? false;teams=g["teams"] as? Bool ?? false;transcripts=g["transcripts"] as? Bool ?? false;sendEmail=g["send_email"] as? Bool ?? false;sendTeams=g["send_teams"] as? Bool ?? false
    localEnabled=c["public_local"] as? Bool ?? false;cloudEnabled=c["public_cloud"] as? Bool ?? false;origins=(c["origins"] as? [String] ?? []).joined(separator:"\n");addinHosting=c["addin_hosting"] as? String ?? "local"
    let n=c["internet"] as? [String:Any] ?? [:];browserID=n["browser_id"] as? String ?? "";searchEngine=n["search_engine"] as? String ?? "duckduckgo";refreshBrowsers();internetEnabled=n["enabled"] as? Bool ?? true;proxy=n["proxy"] as? String ?? "";weatherLocation=n["weather_location"] as? String ?? "";weatherUnits=n["weather_units"] as? String ?? "fahrenheit";weatherPlan=n["weather_plan"] as? String ?? "evaluation";cloudFallback=c["cloud_fallback"] as? Bool ?? true;addinCloud=c["addin_cloud"] as? Bool ?? false
    let p=c["provider"] as? [String:Any] ?? [:];providerType=p["type"] as? String ?? "compatible-chat";providerName=p["name"] as? String ?? "";endpoint=p["endpoint"] as? String ?? "";savedProviderEndpoint=endpoint;model=p["model"] as? String ?? "";maxOutput=p["max_output"] as? Int ?? 512;maxInput=p["max_input_chars"] as? Int ?? 16000;timeout=p["timeout"] as? Int ?? 60;daily=p["daily_requests"] as? Int ?? 100
   }
  }catch {message=error.localizedDescription}
 }
 func launch(){guard !startingService && !stoppingService else{return};startingService=true;message="Starting local service…";localStatus=message;settingsMessage=message
  Task{defer{startingService=false};do{try await Task.detached{try Native.start()}.value;await refresh(loadSettings:true);settingsMessage=message}catch{message=error.localizedDescription;settingsMessage=message;localStatus="Service could not start: "+message}}
 }
 func save(){Task{do{
  let nextEndpoint=endpoint.trimmingCharacters(in:.whitespacesAndNewlines)
  if !nextEndpoint.isEmpty && nextEndpoint != savedProviderEndpoint && credential.isEmpty {throw OnboardError(message:"Enter the API key for the new provider address. The previous provider key will not be reused for a different endpoint.")}
  var provider:[String:Any]=[:]
  if !endpoint.isEmpty {provider=["type":providerType,"name":providerName,"endpoint":endpoint.trimmingCharacters(in:.whitespacesAndNewlines),"model":model,"max_output":maxOutput,"max_input_chars":maxInput,"timeout":timeout,"daily_requests":daily]}
  let settings:[String:Any]=["agent":["enabled":agentEnabled,"roots":agentRoots.split(separator:"\n").map(String.init),"domains":agentDomains.split(separator:"\n").map(String.init),"public_labels":publicLabels.split(separator:"\n").map(String.init),"max_steps":agentSteps],"graph":["cloud":cloud,"tenant":tenant.trimmingCharacters(in:.whitespacesAndNewlines),"client":client.trimmingCharacters(in:.whitespacesAndNewlines),"calendar":calendar,"mail":mail,"files":files,"teams":teams,"transcripts":transcripts,"send_email":sendEmail,"send_teams":sendTeams],"provider":provider,"public_local":localEnabled,"public_cloud":cloudEnabled,"cloud_fallback":cloudFallback,"addin_cloud":addinCloud,"internet":["enabled":internetEnabled,"proxy":proxy.trimmingCharacters(in:.whitespacesAndNewlines),"weather_location":weatherLocation,"weather_units":weatherUnits,"weather_plan":weatherPlan,"browser_id":browserID,"search_engine":searchEngine],"addin_hosting":addinHosting,"origins":addinHosting=="local" ? [] : origins.split(separator:"\n").map(String.init)]
  if !credential.isEmpty {try Vault.write(credential);credential=""};if !weatherCredential.isEmpty {try Vault.write(weatherCredential,key:"weather-key");weatherCredential=""}
  let r=try await call(["op":"save_settings","settings":settings]);settingsMessage=r["message"] as? String ?? "Saved";savedProviderEndpoint=nextEndpoint;await refresh()
 }catch{settingsMessage=error.localizedDescription}}}
 func enableLocal(){localSettingBusy=true;Task{defer{localSettingBusy=false};do{
  let r=try await call(["op":"set_local_enabled","enabled":true]);localEnabled=true;await refresh();message=r["message"] as? String ?? "Local AI enabled"
 }catch{message=error.localizedDescription}}}
 func detectTenant(){detectingTenant=true;tenantStatus="Checking Microsoft tenant metadata…";let requested=tenant;let environment=cloud;Task{defer{detectingTenant=false};do{let r=try await call(["op":"graph_discover","tenant":requested.trimmingCharacters(in:.whitespacesAndNewlines),"cloud":environment]);guard tenant==requested && cloud==environment else{return};tenantStatus="Detected: \(r["cloud"] as? String ?? "Unknown") · \(r["graph"] as? String ?? "")"}catch{tenantStatus=error.localizedDescription}}}
 func signIn(mode:String="browser"){savedItems=[];savedText="";savedJob="";savedReviewed=false;completedJob="";auth?.cancel();signCode="";signURL="";signing=true;tenantStatus="Detecting tenant and starting Microsoft sign-in…";auth=Task{defer{signing=false};do{
  let c=try await call(["op":"graph_start","mode":mode]);tenantStatus="Detected: \(c["cloud"] as? String ?? "Unknown") · \(c["graph"] as? String ?? "")";signCode=c["user_code"] as? String ?? "";signURL=c["authorization_uri"] as? String ?? c["verification_uri"] as? String ?? ""
  if mode=="browser" {guard let url=URL(string:signURL),url.scheme=="https",["login.microsoftonline.com","login.microsoftonline.us"].contains(url.host ?? ""),url.user==nil,url.password==nil else{throw OnboardError(message:"Unexpected Microsoft browser sign-in address.")};try Task.checkCancellation();try await Browsers.open(url,browserID:savedBrowserID);settingsMessage="Complete Microsoft sign-in in your selected browser. Choose CAC/certificate sign-in when offered by your organization."}
  while !Task.isCancelled {try await Task.sleep(nanoseconds:5_000_000_000);let r=try await call(["op":"graph_poll"]);if r["state"] as? String == "connected"{signCode="";signURL="";await refresh();settingsMessage="Microsoft 365 connected.";return}}
 }catch{if !Task.isCancelled {_ = try? await call(["op":"graph_disconnect"]);signCode="";signURL="";settingsMessage=error.localizedDescription;tenantStatus="Sign-in stopped: "+error.localizedDescription}}}}
 func disconnect(){savedItems=[];savedText="";savedJob="";savedReviewed=false;completedJob="";auth?.cancel();signCode="";signURL="";Task{do{_ = try await call(["op":"graph_disconnect"]);await refresh()}catch{settingsMessage=error.localizedDescription}}}
 func watchConnections() async {
  while !Task.isCancelled {
   do{let result=try await call(["op":"connection_requests"]);connectionRequests=result["requests"] as? [[String:String]] ?? []}catch{connectionRequests=[]}
   do{try await Task.sleep(nanoseconds:2_000_000_000)}catch{return}
  }
 }
 func decideConnection(_ id:String,approve:Bool){
  guard !connectionBusy else{return};connectionBusy=true
  Task{defer{connectionBusy=false};do{let r=try await call(["op":"connection_decide","id":id,"approve":approve]);connectionMessage=r["message"] as? String ?? "";connectionRequests.removeAll{$0["id"]==id}}catch{connectionMessage=error.localizedDescription}}
 }
 func pair(){Task{do{let r=try await call(["op":"pair","application":pairApplication]);pairCode=r["code"] as? String ?? "";settingsMessage="Enter this one-use code in your \(pairApplication) integration. It has no time limit and can be used once."}catch{settingsMessage=error.localizedDescription}}}
 func refreshBrowsers(){installedBrowsers=Browsers.installed()}
 func openLink(_ url:URL){Task{do{try await Browsers.open(url,browserID:savedBrowserID)}catch{message=error.localizedDescription}}}
 func chooseTaskFolder(){let panel=NSOpenPanel();panel.canChooseDirectories=true;panel.canChooseFiles=false;panel.allowsMultipleSelection=false;if panel.runModal() == .OK, let url=panel.url{agentRoots += (agentRoots.isEmpty ? "":"\n")+url.path}}
 func decideTask(_ approve:Bool){guard let id=job,let approvalID=agentApproval["id"],!agentDecisionBusy else{return};agentDecisionBusy=true;Task{defer{agentDecisionBusy=false};do{_ = try await call(["op":"agent_decide","id":id,"approval_id":approvalID,"approve":approve]);if agentApproval["id"]==approvalID{agentApproval=[:]}}catch{message=error.localizedDescription}}}
 func submit(){completedJob="";guard !busy else{return};if !savedLocalEnabled{message="Enable local processing before sending.";return};let submittedPrompt=prompt;busy=true;answer="";sources=[];responseRoute="";agentApproval=[:];agentProgress=[];polling=Task{defer{busy=false;job=nil;agentApproval=[:]};do{
  let r=try await call(["op":"submit","task":"ask","route":"auto","agent":agentMode,"prompt":submittedPrompt,"public_attested":publicInput,"web_mode":webMode,"allow_cloud":allowCloud]);job=r["id"] as? String
  while !Task.isCancelled,let id=job {let j=try await call(["op":"job","id":id]);agentApproval=j["approval"] as? [String:String] ?? [:];agentProgress=j["progress"] as? [String] ?? [];message=j["state"] as? String ?? "Processing";if ["complete","failed","cancelled"].contains(message){let v=j["result"] as? [String:Any] ?? [:];answer=v["answer"] as? String ?? "";if v["status"] as? String == "generated"{completedJob=id};message=v["message"] as? String ?? message;sources=v["sources"] as? [[String:Any]] ?? [];responseRoute=v["route"] as? String ?? ""
   if v["status"] as? String == "browser_search",let query=v["browser_query"] as? String,query==submittedPrompt,!Task.isCancelled {
    let url=try Browsers.searchURL(query:query,engine:v["search_engine"] as? String ?? "duckduckgo")
    try await Browsers.open(url,browserID:v["browser_id"] as? String ?? "")
    message="Search opened in your selected browser."
    answer="Read the results in your browser. Onboard has not read those pages or verified their contents. To discuss a page here, paste permitted public text and choose Internet lookup → Off. Browser connection or proxy errors appear in the browser."
   }
   return};try await Task.sleep(nanoseconds:500_000_000)}
 }catch{if !Task.isCancelled {message=error.localizedDescription}}}}

 func cancel(){if let id=job {Task{_ = try? await call(["op":"cancel","id":id])}};polling?.cancel();busy=false;message="Cancelled. A cloud request already sent may continue at the provider."}
 func stop(){guard !startingService && !stoppingService else{return};polling?.cancel();busy=false;stoppingService=true;message="Stopping local service…";settingsMessage=message;localStatus=message
  Task{defer{stoppingService=false};do{_ = try await Task.detached{try Native.stop()}.value;message="Local service stopped";settingsMessage=message;localStatus=message;connected=false;savedLocalEnabled=false;pairCode=""}catch{message=error.localizedDescription;settingsMessage=message;localStatus=message}}
 }
 func refreshSaved(){workspaceBusy=true;Task{defer{workspaceBusy=false};do{let r=try await call(["op":"workspace_list"]);savedItems=r["items"] as? [[String:Any]] ?? [];savedNotice="Saved drafts for this Microsoft account. Source content is not retained or refreshed."}catch{savedNotice=error.localizedDescription}}}
 func prepareSave(){savedJob=completedJob;savedText=answer;savedTitle="Reviewed draft";savedReviewed=false;tab="Saved work";refreshSaved()}
 func saveWork(){workspaceBusy=true;Task{defer{workspaceBusy=false};do{let r=try await call(["op":"workspace_save","job":savedJob,"title":savedTitle,"text":savedText,"reviewed":savedReviewed,"public_attested":savedReviewed,"key":UUID().uuidString]);savedNotice=r["message"] as? String ?? "Saved";savedReviewed=false;let list=try await call(["op":"workspace_list"]);savedItems=list["items"] as? [[String:Any]] ?? []}catch{savedNotice=error.localizedDescription}}}
 func openSaved(_ id:String){workspaceBusy=true;Task{defer{workspaceBusy=false};do{let r=try await call(["op":"workspace_get","id":id]);savedJob=r["job"] as? String ?? "";savedTitle=r["title"] as? String ?? "";savedText=(r["result"] as? [String:Any])?["answer"] as? String ?? "";savedReviewed=false;savedNotice="Reopened for review. Verify facts and current source access before use. Open this draft in the add-ins to export or share it."}catch{savedNotice=error.localizedDescription}}}
 func removeSaved(_ id:String){workspaceBusy=true;Task{defer{workspaceBusy=false};do{_ = try await call(["op":"workspace_get","id":id,"remove":true]);savedItems.removeAll{$0["id"] as? String == id};savedNotice="Saved copy removed. Previously exported files are unchanged."}catch{savedNotice=error.localizedDescription}}}
 func revealCertificate(){NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath:Native.state+"/tls.crt")])}
}
struct ContentView:View {
 @StateObject var s=Store()
 var body:some View {
  NavigationSplitView {
   List(selection:$s.tab){Label("Ask AI",systemImage:"bubble.left.and.bubble.right").tag("Ask AI");Label("Saved work",systemImage:"tray.full").tag("Saved work");Label("AI Settings",systemImage:"slider.horizontal.3").tag("AI Settings")}.navigationTitle("Onboard AI").frame(minWidth:200)
  } detail: {
   VStack(alignment:.leading,spacing:16){connectionApprovals;Text(s.tab).font(.largeTitle.bold());if s.tab=="AI Settings"{settings}else if s.tab=="Saved work"{savedWork}else{chat};Divider();Text(s.message).font(.caption).foregroundStyle(.secondary)}.padding(26).frame(minWidth:670,minHeight:600)
  }.onAppear{s.launch()}.task{await s.watchConnections()}.onChange(of:s.tab){_,_ in if s.busy{s.cancel()}}
 }
 var connectionApprovals:some View {
  VStack(alignment:.leading,spacing:8){
   ForEach(s.connectionRequests,id:\.self){request in
    GroupBox("Allow \(request["application",default:""]) to connect?"){
     VStack(alignment:.leading,spacing:8){
      Text("Microsoft account: \(request["account",default:""])")
      Text("Add-in address: \(request["origin",default:""])").font(.caption).textSelection(.enabled)
      Text(request["application"] == "word" ? "Allow only if you just clicked Connect in Word. This grants that pane access to the Onboard account shown above; Word SSO identity verification is not implemented." : "Allow only if you just clicked Connect to Onboard in this add-in. The reported account matches your Onboard sign-in; your approval authorizes this connection.").font(.caption)
      HStack{Button("Allow connection"){s.decideConnection(request["id",default:""],approve:true)}.buttonStyle(.borderedProminent);Button("Decline"){s.decideConnection(request["id",default:""],approve:false)}}.disabled(s.connectionBusy)
     }.frame(maxWidth:.infinity,alignment:.leading)
    }
   }
   if !s.connectionMessage.isEmpty{Text(s.connectionMessage).font(.caption)}
  }
 }
 var chat:some View {
  VStack(alignment:.leading,spacing:12){
   Text("Search for facts. Use local AI for writing and reasoning, with configured cloud assistance when needed.").foregroundStyle(.secondary)
   Text(s.localStatus).font(.caption)
   if !s.savedLocalEnabled {VStack(alignment:.leading,spacing:8){Text("Local processing is turned off.").font(.headline);Button("Enable Local AI for public input"){s.enableLocal()}.disabled(s.localSettingBusy)}.padding().background(.quaternary,in:RoundedRectangle(cornerRadius:8))}
   TextEditor(text:$s.prompt).font(.body).frame(minHeight:100,maxHeight:160).overlay(RoundedRectangle(cornerRadius:6).stroke(.gray.opacity(0.3))).accessibilityLabel("Your question")
   Toggle("Work on a task — cloud planning with local tools",isOn:$s.agentMode).disabled(s.busy)
   if s.agentMode {Text("Enable Hybrid tasks in AI Settings. Onboard gathers from approved folders and connections. Review collected content before each cloud handoff, and approve file creation or browser opening. No email or Teams message is sent by this task mode.").font(.caption)}
   Picker("Internet lookup",selection:$s.webMode){Text("Automatic").tag("auto");Text("Search this question").tag("always");Text("Off").tag("off")}.pickerStyle(.segmented)
   Toggle(s.agentMode ? "Use configured cloud AI to plan this task":"Use configured cloud AI if local limits are reached",isOn:$s.allowCloud)
   Text(s.endpoint.isEmpty ? "Cloud AI is not configured. Add a provider in AI Settings when ready." : "Cloud destination: \(s.providerName) · \(s.model) · \(s.endpoint)").font(.caption).textSelection(.enabled)
   if !s.agentMode {Text("General searches open in your chosen browser and send the question to your selected search engine. Weather uses its configured service. Browser pages are not automatically read into Ask AI. Mail and Teams content are never attached here.").font(.caption).foregroundStyle(.secondary)}
   Toggle("I confirm this question is public and permitted for the selected connections",isOn:$s.publicInput)
   HStack{Button("Ask AI"){s.submit()}.buttonStyle(.borderedProminent).disabled(s.busy || s.prompt.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || !s.publicInput || !s.savedLocalEnabled);if s.busy{ProgressView().controlSize(.small);Button("Cancel"){s.cancel()}};if !s.responseRoute.isEmpty {Text(s.responseRoute=="hybrid" ? "Hybrid task":s.responseRoute=="browser" ? "Browser search":s.responseRoute=="web" ? "Web lookup":s.responseRoute=="cloud" ? "Cloud AI":"Local AI").font(.caption)}}
   if !s.agentApproval.isEmpty {GroupBox(s.agentApproval["title",default:"Review task step"]){VStack(alignment:.leading){ScrollView{Text(s.agentApproval["preview",default:""]).font(.system(.caption,design:.monospaced)).textSelection(.enabled).frame(maxWidth:.infinity,alignment:.leading)}.frame(maxHeight:180);HStack{Button("Approve this step"){s.decideTask(true)}.buttonStyle(.borderedProminent);Button("Decline and stop"){s.decideTask(false)}}.disabled(s.agentDecisionBusy)}}}
   if !s.agentProgress.isEmpty {DisclosureGroup("Task activity"){Text(s.agentProgress.joined(separator:"\n")).font(.caption).textSelection(.enabled)}}
   if !s.answer.isEmpty && !s.busy {Button("Review and save this answer"){s.prepareSave()}}
   ScrollView{VStack(alignment:.leading,spacing:14){Text(s.answer.isEmpty ? "Ask a question to get an actual response.":s.answer).textSelection(.enabled).frame(maxWidth:.infinity,alignment:.leading)
    ForEach(Array(s.sources.enumerated()),id:\.offset){_,source in
     VStack(alignment:.leading,spacing:3){if let address=source["url"] as? String,let url=URL(string:address),["https","http"].contains(url.scheme ?? ""){Button(source["title"] as? String ?? "Source"){s.openLink(url)}.buttonStyle(.link)}else{Text(source["title"] as? String ?? "Source")};Text(source["retrieved_at"] as? String ?? "").font(.caption).foregroundStyle(.secondary);if let excerpt=source["text"] as? String,!excerpt.isEmpty{DisclosureGroup("View retrieved text"){Text(excerpt).font(.callout).textSelection(.enabled)}}}
    }
   }}.frame(maxHeight:.infinity)
  }
 }

 var savedWork:some View {
  ScrollView{VStack(alignment:.leading,spacing:12){
   Text(s.savedNotice).textSelection(.enabled)
   Button("Refresh saved work"){s.refreshSaved()}.disabled(s.workspaceBusy)
   ForEach(Array(s.savedItems.enumerated()),id:\.offset){_,row in HStack{Text(row["title"] as? String ?? "Saved draft");Spacer();Button("Open"){s.openSaved(row["id"] as? String ?? "")};Button("Remove"){s.removeSaved(row["id"] as? String ?? "")}}.disabled(s.workspaceBusy)}
   TextField("Draft title",text:$s.savedTitle)
   TextEditor(text:$s.savedText).frame(minHeight:250).accessibilityLabel("Reviewed saved draft")
   Toggle("I reviewed this PUBLIC text and permit saving it on this Mac for seven days",isOn:$s.savedReviewed)
   Button("Save reviewed draft"){s.saveWork()}.disabled(s.workspaceBusy || !s.savedReviewed || s.savedText.isEmpty)
   Text("The same Microsoft account can open saved work in Outlook, Teams and Word. Sign-in sessions and original source bodies are never saved here. Deleting a copy does not recall messages or remove exported files.").font(.caption)
  }.onChange(of:s.savedText){_,_ in s.savedReviewed=false}.onChange(of:s.savedTitle){_,_ in s.savedReviewed=false}}
 }
 var settings:some View {
  ScrollView{VStack(alignment:.leading,spacing:20){
   GroupBox("Local AI and processing policy") {VStack(alignment:.leading,spacing:10){Text(s.localStatus);Text(s.organizationStatus).font(.caption);Text("Development policy: only explicitly declared PUBLIC content. Internal, FCI, CUI and unknown content are not enabled. This is not centrally signed production policy.").font(.caption).foregroundStyle(.secondary);Toggle("Enable local processing of user-declared public input",isOn:$s.localEnabled);Text("After changing a toggle, choose Save settings.").font(.caption);Button("Save settings"){s.save()};Toggle("Enable cloud processing of public input",isOn:$s.cloudEnabled);Toggle("Allow cloud assistance when local limits are reached",isOn:$s.cloudFallback);HStack{Button(s.startingService ? "Starting…":"Start service"){s.launch()}.disabled(s.startingService || s.stoppingService);Button(s.stoppingService ? "Stopping…":"Stop service"){s.stop()}.disabled(s.startingService || s.stoppingService);Button("Refresh status"){Task{await s.refresh()}}}}.frame(maxWidth:.infinity,alignment:.leading)}
   GroupBox("Hybrid tasks and label policy") {VStack(alignment:.leading,spacing:10){
    Toggle("Enable cloud planning with local tools",isOn:$s.agentEnabled)
    Text("The configured cloud provider plans; this Mac validates and executes each supported tool. GenAI compatibility must be verified against the customer's actual API. Cloud processing and per-task public confirmation are also required.").font(.caption)
    Text("Approved work folders — one absolute path per line")
    TextEditor(text:$s.agentRoots).frame(height:65);Button("Add work folder…"){s.chooseTaskFolder()}
    Text("Approved website hosts — one exact hostname per line")
    TextEditor(text:$s.agentDomains).frame(height:55)
    Stepper("Maximum planning steps: \(s.agentSteps)",value:$s.agentSteps,in:1...12)
    Text("Organization-approved PUBLIC label mappings — tenant GUID:label GUID, one per line. Leave empty to block all labeled content. A label name alone never authorizes processing. These are development settings, not centrally signed Purview policy.").font(.caption)
    TextEditor(text:$s.publicLabels).frame(height:55)
    Text("Read tools support text and DOCX files, approved public pages and enabled Microsoft sources. Website reading does not control signed-in browser tabs. New files require review and never overwrite existing files.").font(.caption)
   }}
   GroupBox("Internet access") {VStack(alignment:.leading,spacing:10){
    Toggle("Allow public internet lookups",isOn:$s.internetEnabled)
    TextField("Default weather city (optional)",text:$s.weatherLocation)
    Picker("Weather units",selection:$s.weatherUnits){Text("Fahrenheit").tag("fahrenheit");Text("Celsius").tag("celsius")}
    Picker("Open-Meteo weather plan",selection:$s.weatherPlan){Text("Noncommercial evaluation — no key").tag("evaluation");Text("Commercial subscription").tag("commercial")}
    if s.weatherPlan=="commercial"{SecureField("Open-Meteo API key — saved in Keychain",text:$s.weatherCredential)}
    Text("Weather uses Open-Meteo and GeoNames. Its free endpoint is for noncommercial evaluation; choose a commercial subscription before customer deployment.").font(.caption)
    Picker("Browser",selection:$s.browserID){
     Text("Use macOS default browser").tag("")
     ForEach(s.installedBrowsers){browser in Text(browser.name).tag(browser.id)}
     if !s.browserID.isEmpty && !s.installedBrowsers.contains(where:{$0.id==s.browserID}){Text("Unavailable — choose another browser").tag(s.browserID)}
    }
    Button("Refresh installed browsers"){s.refreshBrowsers()}
    Picker("Search engine",selection:$s.searchEngine){Text("DuckDuckGo").tag("duckduckgo");Text("Google").tag("google");Text("Bing").tag("bing")}
    Text("Choose Save settings to apply. Searches and source links open in this browser without a search API key. This does not change your Mac’s default browser. Search results remain in the browser; Onboard does not automatically read its tabs.").font(.caption)
    TextField("Approved proxy URL (optional, e.g. http://proxy.example:8080)",text:$s.proxy)
    Text("Browsers use their own network and proxy settings and display their own errors. This proxy field applies to Onboard’s direct weather and API requests. Those use the Mac’s manual proxy settings unless an approved proxy is entered here. Automatic PAC/WPAD requires an explicit proxy. Authentication, access-denied, certificate and timeout errors are shown; blocked requests are not retried around the proxy.").font(.caption)
   }}
   GroupBox("Microsoft 365") {VStack(alignment:.leading,spacing:10){
    Picker("Environment",selection:$s.cloud){Text("Automatic (recommended)").tag("Auto");Text("Commercial").tag("Commercial");Text("GCC").tag("GCC");Text("GCC High").tag("GCC High");Text("DoD").tag("DoD")}.onChange(of:s.cloud){_,_ in s.tenantStatus="Environment changed. Save settings before signing in."}
    Text("Automatic checks Microsoft’s tenant metadata and selects the matching sign-in and Graph service. Your organization’s approved tenant and app IDs are still required.").font(.caption)
    TextField("Tenant ID",text:$s.tenant).onChange(of:s.tenant){_,_ in s.tenantStatus="Tenant changed. Save settings before signing in."};TextField("Application (client) ID",text:$s.client)
    Button(s.detectingTenant ? "Detecting…":"Detect tenant environment"){s.detectTenant()}.disabled(s.detectingTenant || s.signing || s.tenant.isEmpty)
    Text(s.tenantStatus).font(.caption).textSelection(.enabled)
    Text("Enable only the read access you need; save before signing in.").font(.caption)
    HStack{Toggle("Calendar",isOn:$s.calendar);Toggle("Mail",isOn:$s.mail);Toggle("Files",isOn:$s.files)}
    HStack{Toggle("Teams messages",isOn:$s.teams);Toggle("Transcripts",isOn:$s.transcripts)}
    HStack{Toggle("Send reviewed emails",isOn:$s.sendEmail);Toggle("Send reviewed Teams messages",isOn:$s.sendTeams)}
    Text("Sending is optional and always requires review and a Send click. Save and sign in again after enabling it. Teams recipient lookup uses your organization’s directory.").font(.caption)
    Text(s.account).foregroundStyle(.secondary)
    HStack{Button("Sign in in browser — CAC or credentials"){s.signIn()}.disabled(s.signing || s.cloud.isEmpty || s.tenant.isEmpty || s.client.isEmpty);Button(s.signing ? "Cancel sign-in":"Disconnect"){s.disconnect()}}
    if !s.signCode.isEmpty{Text(s.signCode).font(.title.monospaced()).textSelection(.enabled)}
    if s.signing,let url=URL(string:s.signURL){Button("Reopen Microsoft sign-in"){s.openLink(url)}.buttonStyle(.link)}
    Text("Uses the browser saved in AI Settings. Your tenant controls CAC/certificate availability, MFA and device requirements. Onboard never receives your password or CAC PIN. Register the desktop redirect URI http://localhost/onboard-signin in Entra.").font(.caption).textSelection(.enabled)
    DisclosureGroup("Alternative sign-in"){Button("Use device code instead"){s.signIn(mode:"device")}.disabled(s.signing || s.tenant.isEmpty || s.client.isEmpty);Text("Only use this fallback if your organization permits device-code sign-in.").font(.caption)}
   }}
   GroupBox("Cloud AI provider") {VStack(alignment:.leading,spacing:10){
    Picker("API format",selection:$s.providerType){Text("Chat Completions-compatible").tag("compatible-chat");Text("Azure OpenAI").tag("azure-chat")}
    TextField("Connection name",text:$s.providerName);TextField("HTTPS API base URL or complete Chat Completions URL",text:$s.endpoint);TextField("Model or deployment identifier",text:$s.model);SecureField("API key — saved to macOS Keychain",text:$s.credential)
    Text(s.providerType=="azure-chat" ? "Endpoint: Azure resource root. Uses deployment Chat Completions, API version 2024-10-21, API-key authentication." : "Endpoint: API base (typically /v1) or complete /chat/completions URL. Uses bearer-key authentication. Other API protocols require their own adapter.").font(.caption)
    HStack{TextField("Output tokens",value:$s.maxOutput,format:.number);TextField("Input characters",value:$s.maxInput,format:.number)}
    HStack{TextField("Timeout seconds",value:$s.timeout,format:.number);TextField("Requests per day",value:$s.daily,format:.number)}
    Text("Use OpenAI for current public-content testing. To switch to GenAI.mil, enter the customer-provided API endpoint, model and credential; the API format must match a supported adapter. Government API connectivity must be verified before the customer demo.").font(.caption)
    Text("Save to make this provider available to Ask AI. Cloud assistance is used only when enabled and a local context or resource limit is reached; no background prompt is sent.").font(.caption)
   }}
   GroupBox("Outlook and Teams connections") {VStack(alignment:.leading,spacing:10){
    Toggle("Allow cloud analysis of locally selected add-in content",isOn:$s.addinCloud)
    Text("Small and medium requests stay local (2,048 total tokens, including up to 512 answer tokens). Larger requests can send locally selected evidence to your configured provider when you also allow cloud analysis in the add-in. Public-content policy still applies. Related Outlook mail is retrieved only when you ask, not in the background.").font(.caption)
    Text("In Outlook or Teams, choose Connect to Onboard. Approve the request at the top of this window. No code is needed. Sign in to the same Microsoft account first.").font(.caption)
    DisclosureGroup("Advanced: connect with a code") {
    Picker("Application",selection:$s.pairApplication){Text("Outlook").tag("outlook");Text("Teams").tag("teams")}
    Button("Create one-use pairing code"){s.pair()}.disabled(!s.connected);if !s.pairCode.isEmpty{Text(s.pairCode).font(.title.monospaced()).textSelection(.enabled)}
    }
    Text("Pair the same Microsoft account in both applications. Codes are one-use with no time limit. Connections have no Onboard timeout. Disconnect, service restart, configuration/account changes or reloading the add-in require reconnection. Microsoft sign-in rules still apply. Tokens stay in memory.").font(.caption)
    Picker("Add-in hosting",selection:$s.addinHosting){Text("This Mac — local service").tag("local");Text("Organization-managed HTTPS host").tag("organization")}
    if s.addinHosting=="organization"{TextField("Organization-approved HTTPS origins, one per line",text:$s.origins,axis:.vertical)}
    Text(s.addinHosting=="local" ? "Outlook and Teams load their interface from this Mac. Hosted web pages cannot connect to Onboard in this mode." : "Use only an interface host approved by your organization. Choosing this mode does not establish government authorization.").font(.caption)
    Text("Local bridge: https://localhost:38473. The generated certificate is for development only and is not automatically trusted. Teams requires an acceptable HTTPS certificate; organization deployment and actual host validation remain required.").font(.caption)
    Button("Show development certificate"){s.revealCertificate()}
   }}
   Button("Save settings"){s.save()}.buttonStyle(.borderedProminent)
   Text(s.settingsMessage).textSelection(.enabled).foregroundStyle(.secondary)
  }.textFieldStyle(.roundedBorder)}
 }
}
@main struct OnboardApp:App {
 init(){
  if CommandLine.arguments.contains("--workspace-crypto"){WorkspaceCrypto.run(CommandLine.arguments)}
  if CommandLine.arguments.contains("--vault"){Vault.run(CommandLine.arguments)}
  let mode=CommandLine.arguments.dropFirst().first ?? ""
  if ["--probe","--start-service","--stop-service","--local-check","--enable-public-local","--weather-check","--browser-check"].contains(mode) {
   do {
    let result:[String:Any]
    if mode=="--browser-check"{result=["browsers":Browsers.installed().map{["id":$0.id,"name":$0.name]},"opensBrowser":false,"searchURL":try Browsers.searchURL(query:"a & b + café?",engine:"duckduckgo").absoluteString]}
    else if mode=="--start-service"{try Native.start();result=["started":true]}
    else if mode=="--stop-service"{result=try Native.stop()}
    else if mode=="--enable-public-local"{result=try Native.request(["op":"set_local_enabled","enabled":true])}
    else if mode=="--weather-check"{result=try Native.weatherCheck()}
    else if mode=="--local-check"{result=try Native.localCheck()}
    else{result=try Native.request(["op":"status"])}
    FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys,.prettyPrinted]));exit(0)
   }catch {FileHandle.standardError.write(Data((error.localizedDescription+"\n").utf8));exit(1)}
  }
 }

 var body:some Scene {WindowGroup("Onboard AI"){ContentView()}.defaultSize(width:1050,height:820)}
}

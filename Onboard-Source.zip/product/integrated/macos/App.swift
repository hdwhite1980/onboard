import SwiftUI
import Foundation
import Security
import Darwin

struct OnboardError: LocalizedError { let message: String; var errorDescription: String? { message } }
enum Vault {
 static func run(_ args: [String]) -> Never {
  guard args.count == 4, ["provider-key","search-key","weather-key"].contains(args[3]) else { exit(2) }
  let q:[String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"local.onboard.integrated.credentials",kSecAttrAccount as String:args[3]]
  if args[2] == "read" {
   var r=q;r[kSecReturnData as String]=true;r[kSecMatchLimit as String]=kSecMatchLimitOne
   var item:CFTypeRef?;guard SecItemCopyMatching(r as CFDictionary,&item)==errSecSuccess,let data=item as? Data else { exit(3) }
   FileHandle.standardOutput.write(data);exit(0)
  }
  if args[2] == "write" {
   let data=FileHandle.standardInput.readDataToEndOfFile();guard !data.isEmpty,data.count<8192 else {exit(2)}
   let update=[kSecValueData as String:data];var status=SecItemUpdate(q as CFDictionary,update as CFDictionary)
   if status==errSecItemNotFound {var add=q;add.merge(update){_,n in n};add[kSecAttrAccessible as String]=kSecAttrAccessibleWhenUnlockedThisDeviceOnly;status=SecItemAdd(add as CFDictionary,nil)}
   exit(status==errSecSuccess ? 0:3)
  }
  if args[2] == "delete" {let s=SecItemDelete(q as CFDictionary);exit(s==errSecSuccess || s==errSecItemNotFound ? 0:3)}
  exit(2)
 }
 static func write(_ value:String, key:String = "provider-key") throws {
  guard ["provider-key","search-key","weather-key"].contains(key) else {throw OnboardError(message:"Unsupported credential.")}
  let q:[String:Any]=[kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"local.onboard.integrated.credentials",kSecAttrAccount as String:key]
  let d=[kSecValueData as String:Data(value.utf8)];var s=SecItemUpdate(q as CFDictionary,d as CFDictionary)
  if s==errSecItemNotFound {var a=q;a.merge(d){_,n in n};a[kSecAttrAccessible as String]=kSecAttrAccessibleWhenUnlockedThisDeviceOnly;s=SecItemAdd(a as CFDictionary,nil)}
  guard s==errSecSuccess else {throw OnboardError(message:"Could not save the API credential in Keychain.")}
 }
}
enum Native {
 static var resources:URL {Bundle.main.resourceURL!}
 static var deployment:[String:String] {(try? JSONSerialization.jsonObject(with:Data(contentsOf:resources.appendingPathComponent("deployment.json")))) as? [String:String] ?? [:]}
 static var state:String {deployment["state"] ?? ""}
 static func request(_ value:[String:Any]) throws -> [String:Any] {
  let fd=socket(AF_UNIX,SOCK_STREAM,0);guard fd>=0 else {throw OnboardError(message:"Local connection unavailable.")};defer{Darwin.close(fd)}
  var timeout=timeval(tv_sec:35,tv_usec:0);setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,socklen_t(MemoryLayout<timeval>.size));setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,socklen_t(MemoryLayout<timeval>.size))
  var noPipe:Int32=1;setsockopt(fd,SOL_SOCKET,SO_NOSIGPIPE,&noPipe,4)
  var address=sockaddr_un();address.sun_family=sa_family_t(AF_UNIX)
  let path=state+"/native.sock";let bytes=Array(path.utf8)+[0];guard bytes.count<=MemoryLayout.size(ofValue:address.sun_path) else {throw OnboardError(message:"Installation path is too long for the local connection.")}
  withUnsafeMutableBytes(of:&address.sun_path){$0.copyBytes(from:bytes)}
  let result=withUnsafePointer(to:&address){$0.withMemoryRebound(to:sockaddr.self,capacity:1){Darwin.connect(fd,$0,socklen_t(MemoryLayout<sockaddr_un>.size))}}
  guard result==0 else {throw OnboardError(message:"Local service is stopped. Start it in Settings.")}
  var data=try JSONSerialization.data(withJSONObject:value);data.append(10)
  try data.withUnsafeBytes {buffer in
   var offset=0
   while offset<buffer.count {let n=Darwin.send(fd,buffer.baseAddress!.advanced(by:offset),buffer.count-offset,0);guard n>0 else {throw OnboardError(message:"Local request could not be sent.")};offset+=n}
  }
  var out=Data();var buffer=[UInt8](repeating:0,count:8192)
  while out.count<2_097_152 {let n=Darwin.recv(fd,&buffer,buffer.count,0);if n<=0 {break};out.append(contentsOf:buffer.prefix(n));if out.last==10 {break}}
  guard let answer=try JSONSerialization.jsonObject(with:out) as? [String:Any] else {throw OnboardError(message:"Local service returned an invalid response.")}
  if let error=answer["error"] as? String {throw OnboardError(message:error)}
  return answer
 }
 static func localCheck() throws -> [String:Any] {
  let before=try request(["op":"status"])
  guard let settings=before["settings"] as? [String:Any],settings["public_local"] as? Bool == true else {throw OnboardError(message:"Enable local processing before the check.")}
  let prompt="Summarize this actual product requirement in one sentence: Onboard uses one Ask AI window. It asks the local model first and may use configured cloud AI if needed. Internet lookup should report proxy blocks."
  let queued=try request(["op":"submit","task":"summarize","route":"auto","prompt":prompt,"public_attested":true,"web_mode":"off","allow_cloud":false])
  guard let id=queued["id"] as? String else {throw OnboardError(message:"Request was not queued.")}
  let deadline=Date().addingTimeInterval(240)
  while Date()<deadline {
   let job=try request(["op":"job","id":id]);let state=job["state"] as? String ?? ""
   if ["complete","failed","cancelled"].contains(state){return ["request":prompt,"job":job,"via":"Native executable → authenticated IPC → shared queue → retained local model"]}
   Thread.sleep(forTimeInterval:0.25)
  }
  _ = try? request(["op":"cancel","id":id]);throw OnboardError(message:"Local check timed out; cancellation requested.")
 }
 static func weatherCheck() throws -> [String:Any] {
  let question="What is the weather in Washington, DC?"
  let queued=try request(["op":"submit","task":"ask","route":"auto","prompt":question,"public_attested":true,"web_mode":"auto","allow_cloud":false]);guard let id=queued["id"] as? String else {throw OnboardError(message:"Not queued.")}
  let deadline=Date().addingTimeInterval(90)
  while Date()<deadline {let job=try request(["op":"job","id":id]);if ["complete","failed","cancelled"].contains(job["state"] as? String ?? ""){return ["request":question,"job":job,"via":"Installed Ask AI native connection and shared service"]};Thread.sleep(forTimeInterval:0.25)}
  _ = try? request(["op":"cancel","id":id]);throw OnboardError(message:"Weather check timed out.")
 }
 static func start() throws {
  let p=Process();p.executableURL=URL(fileURLWithPath:deployment["python"] ?? "/usr/bin/python3")
  p.arguments=["-I","-B",resources.appendingPathComponent("service/host.py").path,"--resources",resources.path,"--state",state,"--app",Bundle.main.executableURL!.path]
  p.standardOutput=FileHandle.nullDevice;p.standardError=FileHandle.nullDevice;p.standardInput=FileHandle.nullDevice
  p.environment=["PATH":"/usr/bin:/bin:/usr/sbin:/sbin","HOME":FileManager.default.homeDirectoryForCurrentUser.path,"PYTHONDONTWRITEBYTECODE":"1"]
  try p.run()
 }
}
@MainActor final class Store:ObservableObject {
 @Published var tab="Ask AI"
 @Published var prompt=""
 @Published var answer=""
 @Published var message="Starting local service…"
 @Published var busy=false
 @Published var publicInput=false
 @Published var settingsMessage=""
 @Published var cloud=""
 @Published var tenant=""
 @Published var client=""
 @Published var calendar=true
 @Published var mail=false
 @Published var files=false
 @Published var teams=false
 @Published var transcripts=false
 @Published var savedLocalEnabled=false
 @Published var localSettingBusy=false
 @Published var localEnabled=false
 @Published var cloudEnabled=false
 @Published var providerType="compatible-chat"
 @Published var providerName=""
 @Published var endpoint=""
 @Published var model=""
 @Published var credential=""
 @Published var browserID=""
 @Published var searchEngine="duckduckgo"
 @Published var installedBrowsers:[BrowserChoice]=[]
 @Published var savedBrowserID=""
 @Published var weatherCredential=""
 @Published var internetEnabled=true
 @Published var cloudFallback=true
 @Published var webMode="auto"
 @Published var allowCloud=true
 @Published var proxy=""
 @Published var weatherLocation=""
 @Published var weatherUnits="fahrenheit"
 @Published var weatherPlan="evaluation"
 @Published var responseRoute=""
 @Published var origins=""
 @Published var maxOutput=512
 @Published var maxInput=16000
 @Published var timeout=60
 @Published var daily=100
 @Published var connected=false
 @Published var account=""
 @Published var localStatus=""
 @Published var pairCode=""
 @Published var pairApplication="outlook"
 @Published var signCode=""
 @Published var signURL=""
 @Published var signing=false
 @Published var sources:[[String:Any]]=[]
 private var job:String?;private var polling:Task<Void,Never>?;private var auth:Task<Void,Never>?
 func call(_ r:[String:Any]) async throws -> [String:Any] {try await Task.detached{try Native.request(r)}.value}
 func refresh(loadSettings:Bool=false) async {
  do {let s=try await call(["op":"status"]);connected=s["graph_connected"] as? Bool ?? false;account=(s["account"] as? [String:Any])?["displayName"] as? String ?? "Not connected";localStatus=(s["local"] as? [String:Any])?["message"] as? String ?? "Unavailable";message="Local service ready"
   savedBrowserID=((s["settings"] as? [String:Any])?["internet"] as? [String:Any])?["browser_id"] as? String ?? ""
   savedLocalEnabled=(s["settings"] as? [String:Any])?["public_local"] as? Bool ?? false
   if loadSettings,let c=s["settings"] as? [String:Any] {
    let g=c["graph"] as? [String:Any] ?? [:];cloud=g["cloud"] as? String ?? "";tenant=g["tenant"] as? String ?? "";client=g["client"] as? String ?? "";calendar=g["calendar"] as? Bool ?? true;mail=g["mail"] as? Bool ?? false;files=g["files"] as? Bool ?? false;teams=g["teams"] as? Bool ?? false;transcripts=g["transcripts"] as? Bool ?? false
    localEnabled=c["public_local"] as? Bool ?? false;cloudEnabled=c["public_cloud"] as? Bool ?? false;origins=(c["origins"] as? [String] ?? []).joined(separator:"\n")
    let n=c["internet"] as? [String:Any] ?? [:];browserID=n["browser_id"] as? String ?? "";searchEngine=n["search_engine"] as? String ?? "duckduckgo";refreshBrowsers();internetEnabled=n["enabled"] as? Bool ?? true;proxy=n["proxy"] as? String ?? "";weatherLocation=n["weather_location"] as? String ?? "";weatherUnits=n["weather_units"] as? String ?? "fahrenheit";weatherPlan=n["weather_plan"] as? String ?? "evaluation";cloudFallback=c["cloud_fallback"] as? Bool ?? true
    let p=c["provider"] as? [String:Any] ?? [:];providerType=p["type"] as? String ?? "compatible-chat";providerName=p["name"] as? String ?? "";endpoint=p["endpoint"] as? String ?? "";model=p["model"] as? String ?? "";maxOutput=p["max_output"] as? Int ?? 512;maxInput=p["max_input_chars"] as? Int ?? 16000;timeout=p["timeout"] as? Int ?? 60;daily=p["daily_requests"] as? Int ?? 100
   }
  }catch {message=error.localizedDescription}
 }
 func launch(){Task{do{try Native.start();try await Task.sleep(nanoseconds:1_000_000_000);await refresh(loadSettings:true)}catch{message=error.localizedDescription}}}
 func save(){Task{do{
  var provider:[String:Any]=[:]
  if !endpoint.isEmpty {provider=["type":providerType,"name":providerName,"endpoint":endpoint.trimmingCharacters(in:.whitespacesAndNewlines),"model":model,"max_output":maxOutput,"max_input_chars":maxInput,"timeout":timeout,"daily_requests":daily]}
  let settings:[String:Any]=["graph":["cloud":cloud,"tenant":tenant.trimmingCharacters(in:.whitespacesAndNewlines),"client":client.trimmingCharacters(in:.whitespacesAndNewlines),"calendar":calendar,"mail":mail,"files":files,"teams":teams,"transcripts":transcripts],"provider":provider,"public_local":localEnabled,"public_cloud":cloudEnabled,"cloud_fallback":cloudFallback,"internet":["enabled":internetEnabled,"proxy":proxy.trimmingCharacters(in:.whitespacesAndNewlines),"weather_location":weatherLocation,"weather_units":weatherUnits,"weather_plan":weatherPlan,"browser_id":browserID,"search_engine":searchEngine],"origins":origins.split(separator:"\n").map(String.init)]
  if !credential.isEmpty {try Vault.write(credential);credential=""};if !weatherCredential.isEmpty {try Vault.write(weatherCredential,key:"weather-key");weatherCredential=""}
  let r=try await call(["op":"save_settings","settings":settings]);settingsMessage=r["message"] as? String ?? "Saved";await refresh()
 }catch{settingsMessage=error.localizedDescription}}}
 func enableLocal(){localSettingBusy=true;Task{defer{localSettingBusy=false};do{
  let r=try await call(["op":"set_local_enabled","enabled":true]);localEnabled=true;await refresh();message=r["message"] as? String ?? "Local AI enabled"
 }catch{message=error.localizedDescription}}}
 func signIn(){auth?.cancel();signing=true;auth=Task{defer{signing=false};do{
  let c=try await call(["op":"graph_start"]);signCode=c["user_code"] as? String ?? "";signURL=c["verification_uri"] as? String ?? ""
  while !Task.isCancelled {try await Task.sleep(nanoseconds:5_000_000_000);let r=try await call(["op":"graph_poll"]);if r["state"] as? String == "connected"{signCode="";signURL="";await refresh();settingsMessage="Microsoft 365 connected.";return}}
 }catch{if !Task.isCancelled {settingsMessage=error.localizedDescription}}}}
 func disconnect(){auth?.cancel();signCode="";signURL="";Task{do{_ = try await call(["op":"graph_disconnect"]);await refresh()}catch{settingsMessage=error.localizedDescription}}}
 func pair(){Task{do{let r=try await call(["op":"pair","application":pairApplication]);pairCode=r["code"] as? String ?? "";settingsMessage="Enter this one-use code in your \(pairApplication) integration within two minutes."}catch{settingsMessage=error.localizedDescription}}}
 func refreshBrowsers(){installedBrowsers=Browsers.installed()}
 func openLink(_ url:URL){Task{do{try await Browsers.open(url,browserID:savedBrowserID)}catch{message=error.localizedDescription}}}
 func submit(){guard !busy else{return};if !savedLocalEnabled{message="Enable local processing before sending.";return};let submittedPrompt=prompt;busy=true;answer="";sources=[];responseRoute="";polling=Task{defer{busy=false;job=nil};do{
  let r=try await call(["op":"submit","task":"ask","route":"auto","prompt":submittedPrompt,"public_attested":publicInput,"web_mode":webMode,"allow_cloud":allowCloud]);job=r["id"] as? String
  while !Task.isCancelled,let id=job {let j=try await call(["op":"job","id":id]);message=j["state"] as? String ?? "Processing";if ["complete","failed","cancelled"].contains(message){let v=j["result"] as? [String:Any] ?? [:];answer=v["answer"] as? String ?? "";message=v["message"] as? String ?? message;sources=v["sources"] as? [[String:Any]] ?? [];responseRoute=v["route"] as? String ?? ""
   if v["status"] as? String == "browser_search",let query=v["browser_query"] as? String,query==submittedPrompt,!Task.isCancelled {
    let url=try Browsers.searchURL(query:query,engine:v["search_engine"] as? String ?? "duckduckgo")
    try await Browsers.open(url,browserID:v["browser_id"] as? String ?? "")
    message="Search opened in your selected browser."
    answer="Read the results in your browser. Onboard has not read those pages or verified their contents. To discuss a page here, paste permitted public text and choose Internet lookup → Off. Browser connection or proxy errors appear in the browser."
   }
   return};try await Task.sleep(nanoseconds:500_000_000)}
 }catch{if !Task.isCancelled {message=error.localizedDescription}}}}

 func cancel(){if let id=job {Task{_ = try? await call(["op":"cancel","id":id])}};polling?.cancel();busy=false;message="Cancelled. A cloud request already sent may continue at the provider."}
 func stop(){cancel();Task{do{_ = try await call(["op":"stop"]);message="Local service stopped"}catch{message=error.localizedDescription}}}
 func revealCertificate(){NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath:Native.state+"/tls.crt")])}
}
struct ContentView:View {
 @StateObject var s=Store()
 var body:some View {
  NavigationSplitView {
   List(selection:$s.tab){Label("Ask AI",systemImage:"bubble.left.and.bubble.right").tag("Ask AI");Label("AI Settings",systemImage:"slider.horizontal.3").tag("AI Settings")}.navigationTitle("Onboard AI").frame(minWidth:200)
  } detail: {
   VStack(alignment:.leading,spacing:16){Text(s.tab).font(.largeTitle.bold());if s.tab=="AI Settings"{settings}else{chat};Divider();Text(s.message).font(.caption).foregroundStyle(.secondary)}.padding(26).frame(minWidth:670,minHeight:600)
  }.onAppear{s.launch()}.onChange(of:s.tab){_,_ in if s.busy{s.cancel()}}
 }
 var chat:some View {
  VStack(alignment:.leading,spacing:12){
   Text("Search for facts. Use local AI for writing and reasoning, with configured cloud assistance when needed.").foregroundStyle(.secondary)
   Text(s.localStatus).font(.caption)
   if !s.savedLocalEnabled {VStack(alignment:.leading,spacing:8){Text("Local processing is turned off.").font(.headline);Button("Enable Local AI for public input"){s.enableLocal()}.disabled(s.localSettingBusy)}.padding().background(.quaternary,in:RoundedRectangle(cornerRadius:8))}
   TextEditor(text:$s.prompt).font(.body).frame(minHeight:100,maxHeight:160).overlay(RoundedRectangle(cornerRadius:6).stroke(.gray.opacity(0.3))).accessibilityLabel("Your question")
   Picker("Internet lookup",selection:$s.webMode){Text("Automatic").tag("auto");Text("Search this question").tag("always");Text("Off").tag("off")}.pickerStyle(.segmented)
   Toggle("Use configured cloud AI if local limits are reached",isOn:$s.allowCloud)
   Text(s.endpoint.isEmpty ? "Cloud AI is not configured. Add a provider in AI Settings when ready." : "Cloud destination: \(s.providerName) · \(s.model) · \(s.endpoint)").font(.caption).textSelection(.enabled)
   Text("General searches open in your chosen browser and send the question to your selected search engine. Weather uses its configured service. Browser pages are not automatically read into Ask AI. Mail and Teams content are never attached here.").font(.caption).foregroundStyle(.secondary)
   Toggle("I confirm this question is public and permitted for the selected connections",isOn:$s.publicInput)
   HStack{Button("Ask AI"){s.submit()}.buttonStyle(.borderedProminent).disabled(s.busy || s.prompt.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || !s.publicInput || !s.savedLocalEnabled);if s.busy{ProgressView().controlSize(.small);Button("Cancel"){s.cancel()}};if !s.responseRoute.isEmpty {Text(s.responseRoute=="browser" ? "Browser search":s.responseRoute=="web" ? "Web lookup":s.responseRoute=="cloud" ? "Cloud AI":"Local AI").font(.caption)}}
   ScrollView{VStack(alignment:.leading,spacing:14){Text(s.answer.isEmpty ? "Ask a question to get an actual response.":s.answer).textSelection(.enabled).frame(maxWidth:.infinity,alignment:.leading)
    ForEach(Array(s.sources.enumerated()),id:\.offset){_,source in
     VStack(alignment:.leading,spacing:3){if let address=source["url"] as? String,let url=URL(string:address),["https","http"].contains(url.scheme ?? ""){Button(source["title"] as? String ?? "Source"){s.openLink(url)}.buttonStyle(.link)}else{Text(source["title"] as? String ?? "Source")};Text(source["retrieved_at"] as? String ?? "").font(.caption).foregroundStyle(.secondary);if let excerpt=source["text"] as? String,!excerpt.isEmpty{DisclosureGroup("View retrieved text"){Text(excerpt).font(.callout).textSelection(.enabled)}}}
    }
   }}.frame(maxHeight:.infinity)
  }
 }

 var settings:some View {
  ScrollView{VStack(alignment:.leading,spacing:20){
   GroupBox("Local AI and processing policy") {VStack(alignment:.leading,spacing:10){Text(s.localStatus);Text("Development policy: only explicitly declared PUBLIC content. Internal, FCI, CUI and unknown content are not enabled. This is not centrally signed production policy.").font(.caption).foregroundStyle(.secondary);Toggle("Enable local processing of user-declared public input",isOn:$s.localEnabled);Text("After changing a toggle, choose Save settings.").font(.caption);Button("Save settings"){s.save()};Toggle("Enable cloud processing of public input",isOn:$s.cloudEnabled);Toggle("Allow cloud assistance when local limits are reached",isOn:$s.cloudFallback);HStack{Button("Start service"){s.launch()};Button("Stop service"){s.stop()};Button("Refresh status"){Task{await s.refresh()}}}}.frame(maxWidth:.infinity,alignment:.leading)}
   GroupBox("Internet access") {VStack(alignment:.leading,spacing:10){
    Toggle("Allow public internet lookups",isOn:$s.internetEnabled)
    TextField("Default weather city (optional)",text:$s.weatherLocation)
    Picker("Weather units",selection:$s.weatherUnits){Text("Fahrenheit").tag("fahrenheit");Text("Celsius").tag("celsius")}
    Picker("Open-Meteo weather plan",selection:$s.weatherPlan){Text("Noncommercial evaluation — no key").tag("evaluation");Text("Commercial subscription").tag("commercial")}
    if s.weatherPlan=="commercial"{SecureField("Open-Meteo API key — saved in Keychain",text:$s.weatherCredential)}
    Text("Weather uses Open-Meteo and GeoNames. Its free endpoint is for noncommercial evaluation; choose a commercial subscription before customer deployment.").font(.caption)
    Picker("Browser",selection:$s.browserID){
     Text("Use macOS default browser").tag("")
     ForEach(s.installedBrowsers){browser in Text(browser.name).tag(browser.id)}
     if !s.browserID.isEmpty && !s.installedBrowsers.contains(where:{$0.id==s.browserID}){Text("Unavailable — choose another browser").tag(s.browserID)}
    }
    Button("Refresh installed browsers"){s.refreshBrowsers()}
    Picker("Search engine",selection:$s.searchEngine){Text("DuckDuckGo").tag("duckduckgo");Text("Google").tag("google");Text("Bing").tag("bing")}
    Text("Choose Save settings to apply. Searches and source links open in this browser without a search API key. This does not change your Mac’s default browser. Search results remain in the browser; Onboard does not automatically read its tabs.").font(.caption)
    TextField("Approved proxy URL (optional, e.g. http://proxy.example:8080)",text:$s.proxy)
    Text("Browsers use their own network and proxy settings and display their own errors. This proxy field applies to Onboard’s direct weather and API requests. Those use the Mac’s manual proxy settings unless an approved proxy is entered here. Automatic PAC/WPAD requires an explicit proxy. Authentication, access-denied, certificate and timeout errors are shown; blocked requests are not retried around the proxy.").font(.caption)
   }}
   GroupBox("Microsoft 365") {VStack(alignment:.leading,spacing:10){
    Picker("Environment",selection:$s.cloud){Text("Choose after setup").tag("");Text("GCC High").tag("GCC High");Text("DoD").tag("DoD")}
    TextField("Tenant ID",text:$s.tenant);TextField("Application (client) ID",text:$s.client)
    Text("Enable only the read access you need; save before signing in.").font(.caption)
    HStack{Toggle("Calendar",isOn:$s.calendar);Toggle("Mail",isOn:$s.mail);Toggle("Files",isOn:$s.files)}
    HStack{Toggle("Teams messages",isOn:$s.teams);Toggle("Transcripts",isOn:$s.transcripts)}
    Text(s.account).foregroundStyle(.secondary)
    HStack{Button("Sign in with Microsoft"){s.signIn()}.disabled(s.signing || s.cloud.isEmpty || s.tenant.isEmpty || s.client.isEmpty);Button(s.signing ? "Cancel sign-in":"Disconnect"){s.disconnect()}}
    if !s.signCode.isEmpty{Text(s.signCode).font(.title.monospaced()).textSelection(.enabled);if let url=URL(string:s.signURL){Button("Open Microsoft sign-in"){s.openLink(url)}.buttonStyle(.link)}}
    Text("Public-client device-code sign-in. If your organization blocks it, a broker-approved sign-in adapter is required; policy is never bypassed.").font(.caption)
   }}
   GroupBox("GenAI API connection") {VStack(alignment:.leading,spacing:10){
    Picker("API format",selection:$s.providerType){Text("Chat Completions-compatible").tag("compatible-chat");Text("Azure OpenAI").tag("azure-chat")}
    TextField("Connection name",text:$s.providerName);TextField("HTTPS API base URL",text:$s.endpoint);TextField("Model or deployment identifier",text:$s.model);SecureField("API key — saved to macOS Keychain",text:$s.credential)
    Text(s.providerType=="azure-chat" ? "Endpoint: Azure resource root. Uses deployment Chat Completions, API version 2024-10-21, API-key authentication." : "Endpoint: API base, typically ending in /v1. Appends /chat/completions and uses bearer-key authentication. Other API protocols require their own adapter.").font(.caption)
    HStack{TextField("Output tokens",value:$s.maxOutput,format:.number);TextField("Input characters",value:$s.maxInput,format:.number)}
    HStack{TextField("Timeout seconds",value:$s.timeout,format:.number);TextField("Requests per day",value:$s.daily,format:.number)}
    Text("Save to make this provider available to Ask AI. Cloud assistance is used only when enabled and a local context or resource limit is reached; no background prompt is sent.").font(.caption)
   }}
   GroupBox("Outlook and Teams connections") {VStack(alignment:.leading,spacing:10){
    Picker("Application",selection:$s.pairApplication){Text("Outlook").tag("outlook");Text("Teams").tag("teams")}
    Button("Create one-use pairing code"){s.pair()}.disabled(!s.connected);if !s.pairCode.isEmpty{Text(s.pairCode).font(.title.monospaced()).textSelection(.enabled)}
    Text("Pair the same Microsoft account in both applications. Pairing expires after 30 minutes or on disconnect. Tokens stay in memory.").font(.caption)
    TextField("Approved hosted add-in origins, one HTTPS origin per line",text:$s.origins,axis:.vertical)
    Text("Local bridge: https://localhost:38473. The generated certificate is for development only and is not automatically trusted. Teams requires an acceptable HTTPS certificate; organization deployment and actual host validation remain required.").font(.caption)
    Button("Show development certificate"){s.revealCertificate()}
   }}
   Button("Save settings"){s.save()}.buttonStyle(.borderedProminent)
   Text(s.settingsMessage).textSelection(.enabled).foregroundStyle(.secondary)
  }.textFieldStyle(.roundedBorder)}
 }
}
@main struct OnboardApp:App {
 init(){
  if CommandLine.arguments.contains("--vault"){Vault.run(CommandLine.arguments)}
  let mode=CommandLine.arguments.dropFirst().first ?? ""
  if ["--probe","--start-service","--stop-service","--local-check","--enable-public-local","--weather-check","--browser-check"].contains(mode) {
   do {
    let result:[String:Any]
    if mode=="--browser-check"{result=["browsers":Browsers.installed().map{["id":$0.id,"name":$0.name]},"opensBrowser":false,"searchURL":try Browsers.searchURL(query:"a & b + café?",engine:"duckduckgo").absoluteString]}
    else if mode=="--start-service"{try Native.start();result=["started":true]}
    else if mode=="--stop-service"{result=try Native.request(["op":"stop"])}
    else if mode=="--enable-public-local"{result=try Native.request(["op":"set_local_enabled","enabled":true])}
    else if mode=="--weather-check"{result=try Native.weatherCheck()}
    else if mode=="--local-check"{result=try Native.localCheck()}
    else{result=try Native.request(["op":"status"])}
    FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys,.prettyPrinted]));exit(0)
   }catch {FileHandle.standardError.write(Data((error.localizedDescription+"\n").utf8));exit(1)}
  }
 }

 var body:some Scene {WindowGroup("Onboard AI"){ContentView()}.defaultSize(width:1050,height:820)}
}

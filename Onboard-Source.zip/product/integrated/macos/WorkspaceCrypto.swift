import Foundation
import CryptoKit
import Security

// Content encryption is separate from provider credentials. The key never leaves this process.
enum WorkspaceCrypto {
 static func seal(_ data: Data, key: SymmetricKey, context: Data) throws -> Data {
  guard let combined = try AES.GCM.seal(data, using:key, authenticating:context).combined else { throw NSError(domain:"Workspace",code:1) }
  return combined
 }
 static func open(_ data: Data, key: SymmetricKey, context: Data) throws -> Data {
  try AES.GCM.open(AES.GCM.SealedBox(combined:data), using:key, authenticating:context)
 }
 static func key(create: Bool) throws -> SymmetricKey {
  let query:[String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"local.onboard.integrated.workspace",kSecAttrAccount as String:"aes256-v1"]
  var read=query;read[kSecReturnData as String]=true;read[kSecMatchLimit as String]=kSecMatchLimitOne
  var result:CFTypeRef?;let status=SecItemCopyMatching(read as CFDictionary,&result)
  if status == errSecSuccess, let data=result as? Data, data.count == 32 { return SymmetricKey(data:data) }
  guard status == errSecItemNotFound, create else { throw NSError(domain:"WorkspaceKeychain",code:Int(status)) }
  var bytes=Data(count:32)
  let random=bytes.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault,32,$0.baseAddress!) }
  guard random == errSecSuccess else { throw NSError(domain:"WorkspaceKeychain",code:Int(random)) }
  var add=query;add[kSecValueData as String]=bytes;add[kSecAttrAccessible as String]=kSecAttrAccessibleWhenUnlockedThisDeviceOnly
  let added=SecItemAdd(add as CFDictionary,nil)
  if added == errSecDuplicateItem { return try key(create:false) }
  guard added == errSecSuccess else { throw NSError(domain:"WorkspaceKeychain",code:Int(added)) }
  return SymmetricKey(data:bytes)
 }
 static func run(_ args:[String]) -> Never {
  do {
   guard args.count == 3, ["seal","open"].contains(args[2]) else { exit(2) }
   let input=FileHandle.standardInput.readDataToEndOfFile()
   guard input.count <= 8_000_000,
    let request=try JSONSerialization.jsonObject(with:input) as? [String:String],
    let context=request["context"],context.count == 64,context.allSatisfy({$0.isHexDigit}),
    let encoded=request["data"],let data=Data(base64Encoded:encoded) else { exit(2) }
   let key=try key(create:args[2] == "seal")
   let output = try args[2] == "seal" ? seal(data,key:key,context:Data(context.utf8)) : open(data,key:key,context:Data(context.utf8))
   FileHandle.standardOutput.write(Data(output.base64EncodedString().utf8));exit(0)
  } catch {
   FileHandle.standardError.write(Data("Saved workspace unavailable. Unlock Keychain; existing encrypted files have been preserved.\n".utf8));exit(3)
  }
 }
}

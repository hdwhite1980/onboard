import Foundation
import Security

enum CodeTrust {
 static func verifyBundle() throws {
  var code:SecStaticCode?
  guard SecStaticCodeCreateWithPath(Bundle.main.bundleURL as CFURL,[],&code)==errSecSuccess,let code=code,
        SecStaticCodeCheckValidity(code,SecCSFlags(rawValue:kSecCSCheckAllArchitectures|kSecCSCheckNestedCode),nil)==errSecSuccess else {
   throw OnboardError(message:"Application signature or resources changed. Reinstall a verified Onboard package.")
  }
 }
 static func verifyPeer(_ pid:pid_t) throws {
  try verifyBundle()
  var own:SecCode?,peer:SecCode?,staticOwn:SecStaticCode?,requirement:SecRequirement?
  guard SecCodeCopySelf([],&own)==errSecSuccess,let own=own,
        SecCodeCopyStaticCode(own,[],&staticOwn)==errSecSuccess,let staticOwn=staticOwn,
        SecCodeCopyDesignatedRequirement(staticOwn,[],&requirement)==errSecSuccess,let requirement=requirement,
        SecCodeCopyGuestWithAttributes(nil,[kSecGuestAttributePid as String:pid] as CFDictionary,[],&peer)==errSecSuccess,let peer=peer,
        SecCodeCheckValidity(peer,[],requirement)==errSecSuccess else {
   throw OnboardError(message:"Native client's running code identity was rejected.")
  }
 }
}

import SwiftUI
import UniformTypeIdentifiers

extension Store {
 func chooseAutomationApp(){let panel=NSOpenPanel();panel.allowedContentTypes=[.applicationBundle];panel.canChooseDirectories=false;panel.allowsMultipleSelection=false;if panel.runModal() == .OK,let url=panel.url,let id=Bundle(url:url)?.bundleIdentifier {automationApps += (automationApps.isEmpty ? "":"\n")+id}}
 func refreshTasks(){Task{do{let result=try await call(["op":"task_list"]);taskRows=result["tasks"] as? [[String:Any]] ?? []}catch{taskNotice=error.localizedDescription}}}
 func openTask(_ id:String,preservingNotice:Bool=false){guard !busy else{return};taskSelection=id;taskReviewed=false;Task{do{let result=try await call(["op":"task_get","id":id]);taskDocument=result["document"] as? String ?? "";let row=result["record"] as? [String:Any] ?? [:];taskUncertain=row["uncertain"] as? Bool ?? false;if !preservingNotice{taskNotice=row["notice"] as? String ?? ""};if let plan=row["plan"],let raw=try? JSONSerialization.data(withJSONObject:plan,options:[.prettyPrinted,.sortedKeys]){taskPlan=String(decoding:raw,as:UTF8.self)}}catch{taskNotice=error.localizedDescription}}}
 func importTask(){let panel=NSOpenPanel();panel.allowedContentTypes=[.json];panel.allowsMultipleSelection=false;if panel.runModal() == .OK,let url=panel.url {do{let attrs=try FileManager.default.attributesOfItem(atPath:url.path);guard attrs[.type] as? FileAttributeType == .typeRegular,(attrs[.size] as? Int ?? 120001)<=120000 else{throw OnboardError(message:"Import a regular JSON plan below 120 KB.")};let raw=try Data(contentsOf:url);taskPlan=String(decoding:raw,as:UTF8.self);taskReviewed=false;taskNotice="Imported for review. Nothing has run."}catch{taskNotice=error.localizedDescription}}}
 func saveTaskPlan(){Task{do{let value=try JSONSerialization.jsonObject(with:Data(taskPlan.utf8));let result=try await call(["op":"task_create","plan":value,"reviewed":taskReviewed,"public_attested":taskPublic]);taskNotice=result["message"] as? String ?? "Saved";taskSelection=result["id"] as? String ?? "";taskReviewed=false;refreshTasks();if !taskSelection.isEmpty{openTask(taskSelection)}}catch{taskNotice=error.localizedDescription}}}
 func exportTask(){guard !taskDocument.isEmpty else{return};let panel=NSSavePanel();panel.nameFieldStringValue="Onboard Task.md";if panel.runModal() == .OK,let url=panel.url {do{guard !FileManager.default.fileExists(atPath:url.path) else{throw OnboardError(message:"Choose a new filename; existing files are not overwritten.")};try Data(taskDocument.utf8).write(to:url,options:.withoutOverwriting);try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:url.path);taskNotice="Readable PUBLIC task document exported to your chosen file. Treat it according to your organization's storage policy."}catch{taskNotice=error.localizedDescription}}}
 func resolveTask(_ choice:String){Task{do{let r=try await call(["op":"task_resolve","id":taskSelection,"choice":choice,"reviewed":taskReviewed]);taskNotice=r["message"] as? String ?? "Resolved";openTask(taskSelection);refreshTasks()}catch{taskNotice=error.localizedDescription}}}
 func startSavedTask(planning:Bool=false,repair:Bool=false){guard !busy else{return};busy=true;agentApproval=[:];agentProgress=[];taskNotice="Preparing task…";polling=Task{defer{busy=false;job=nil;agentApproval=[:];if !Task.isCancelled && !taskSelection.isEmpty{openTask(taskSelection,preservingNotice:true)}};do{
  var request:[String:Any]=["op":"submit","task":"ask","route":"auto","prompt":taskInstructions,"public_attested":taskPublic,"allow_cloud":taskUseCloud,"web_mode":"off"]
  if planning {request["task_planning"]=true;if repair{request["repair_task"]=taskSelection}}else{request["saved_task"]=taskSelection}
  let queued=try await call(request);job=queued["id"] as? String
  while !Task.isCancelled,let id=job {
   let status=try await call(["op":"job","id":id]);agentApproval=status["approval"] as? [String:String] ?? [:];agentProgress=status["progress"] as? [String] ?? [];let phase=status["state"] as? String ?? "processing";taskNotice=phase
   if ["complete","failed","cancelled"].contains(phase){let result=status["result"] as? [String:Any] ?? [:];taskNotice=result["message"] as? String ?? result["answer"] as? String ?? phase;if let saved=result["task_id"] as? String{taskSelection=saved};refreshTasks();return}
   try await Task.sleep(nanoseconds:500_000_000)
  }
 }catch{if !Task.isCancelled{taskNotice=error.localizedDescription};refreshTasks()}}}
}
struct TasksView:View {
 @ObservedObject var s:Store
 var body:some View {
  ScrollView {VStack(alignment:.leading,spacing:12){
   Text("Create, import and resume task plans. Local steps can run offline. Website and Microsoft requests need connectivity; cloud planning is optional.").font(.callout)
   HStack{Button("Refresh tasks"){s.refreshTasks()};Button("Import JSON plan…"){s.importTask()};Button("Export readable task…"){s.exportTask()}.disabled(s.taskDocument.isEmpty)}.disabled(s.busy)
   ForEach(Array(s.taskRows.enumerated()),id:\.offset){_,row in
    Button("\(row["title"] as? String ?? "Task") · \(row["state"] as? String ?? "") · step \((row["next"] as? Int ?? 0)+1)"){s.openTask(row["id"] as? String ?? "")}.disabled(s.busy)
   }
   Text("Instructions for a new or revised plan")
   TextEditor(text:$s.taskInstructions).frame(height:70).disabled(s.busy)
   Toggle("Use configured cloud AI for planning or repair",isOn:$s.taskUseCloud).disabled(s.busy)
   Toggle("I confirm the task and inspected content are PUBLIC and permitted",isOn:$s.taskPublic).disabled(s.busy)
   HStack{Button("Generate plan"){s.startSavedTask(planning:true)}.disabled(!s.taskPublic || s.taskInstructions.isEmpty || s.busy);Button("Repair remaining plan"){s.startSavedTask(planning:true,repair:true)}.disabled(!s.taskPublic || s.taskSelection.isEmpty || s.taskUncertain || s.busy)}
   DisclosureGroup("Review or edit structured plan") {TextEditor(text:$s.taskPlan).font(.system(.caption,design:.monospaced)).frame(height:180);Toggle("I reviewed this plan / checked the interrupted action",isOn:$s.taskReviewed);Button("Save as a new task"){s.saveTaskPlan()}.disabled(!s.taskPublic || !s.taskReviewed || s.taskPlan.isEmpty)}.disabled(s.busy)
   HStack{Button("Review and run / resume"){s.startSavedTask()}.buttonStyle(.borderedProminent).disabled(s.busy || !s.taskPublic || s.taskSelection.isEmpty || s.taskUncertain);if s.busy{Button("Pause / stop"){s.cancel();s.taskNotice="Stopping; reopen the task after cleanup to inspect its checkpoint."}}}
   if s.taskUncertain {Text("An interrupted action may already have happened. Inspect the target before deciding. Completed means you verified it yourself; retry may repeat a side effect.").foregroundStyle(.orange);HStack{Button("I verified it completed"){s.resolveTask("completed")};Button("Allow reviewed retry"){s.resolveTask("retry")}}.disabled(!s.taskReviewed || s.busy)}
   if !s.agentApproval.isEmpty {GroupBox(s.agentApproval["title",default:"Review task step"]){VStack(alignment:.leading){ScrollView{Text(s.agentApproval["preview",default:""]).font(.system(.caption,design:.monospaced)).textSelection(.enabled)}.frame(maxHeight:220);HStack{Button("Approve this step"){s.decideTask(true)};Button("Decline and stop"){s.decideTask(false)}}.disabled(s.agentDecisionBusy)}}}
   Text(s.taskNotice).textSelection(.enabled)
   if !s.agentProgress.isEmpty {Text(s.agentProgress.joined(separator:"\n")).font(.caption)}
   DisclosureGroup("Saved task document and results"){Text(s.taskDocument).font(.system(.caption,design:.monospaced)).textSelection(.enabled)}
  }}.onAppear{s.refreshTasks()}.onChange(of:s.taskPlan){s.taskReviewed=false}
 }
}

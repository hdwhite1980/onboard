# Onboard AI integrated development build

A download-based development setup is available in [setup/INSTALL.md](setup/INSTALL.md). It downloads the pinned model/runtime, verifies them, runs fresh local qualification, and builds the app on Apple silicon with macOS 26+, Apple's command-line tools and Rust. The Swift UI deployment target alone does not establish runtime support: the retained MLX wheels require macOS 26. This is not a notarized customer installer.

The dashboard has one **Ask AI** area and **AI Settings**. Outlook and Teams have separate packages in `build/addins` and share the background service. Missing connections show setup/unavailable states; there are no demo mailboxes, fabricated meetings, or mock successful API responses.

Ask AI opens general public factual searches in the browser chosen under **AI Settings → Internet access → Browser**. Choose an installed browser or the macOS default, then choose DuckDuckGo, Google or Bing as the search engine and save. No Brave API key or search subscription is required. Browser discovery uses macOS registered web handlers that declare support for HTTP and HTTPS, rather than a fixed Safari/Chrome list. A missing selected browser produces an error; Onboard does not silently switch applications or change the macOS default.

Writing and text transformations use local AI. Choose **Search this question** to explicitly request a lookup, or **Off** to keep a question offline. Browser searches open real results externally; the app does not automatically read browser tabs, retrieve page text, or claim to have answered from those pages. Paste permitted public text into Ask AI with internet lookup Off to discuss it. Source links and Microsoft sign-in links also use the saved browser choice.

Weather remains a direct Open-Meteo lookup with a city in the question or a default city in Settings. Its evaluation endpoint needs no key; commercial deployment requires its commercial subscription. Direct weather/API requests retain the existing explicit/manual proxy handling and failure reporting. Browser requests use the browser’s own proxy and network settings; page-level failures appear there and cannot be diagnosed from successful app launch alone.

Cloud assistance stays in the same Ask AI area. It requires a configured provider, enabled public-cloud policy, enabled fallback, and permission for that question. Fallback currently handles local context limits and safely completed resource stops; integrity failures do not trigger cloud dispatch. Public questions can be sent to the configured connections; mailbox and Teams content are never silently attached to native questions.

The local runtime blocker is resolved. See [the repair and verification record](evidence/runtime-repair/REPAIR.md) for the actual offline response and bounded lifecycle checks.

Open `/Users/donwhite/Applications/Onboard AI.app`. In AI Settings, enable public local requests for development, save, and ask a short question. The retained local profile permits 384 prompt tokens plus 128 output tokens; longer input is rejected rather than truncated. Public-input confirmation is a user declaration for development, not enterprise classification approval. Unknown, FCI, and CUI content is not authorized by this development policy.

Microsoft 365 and cloud access are intentionally unconfigured. AI Settings provides automatic Commercial/GCC/GCC High/DoD detection from the configured tenant, approved tenant/client IDs, optional read permissions, and an approved GenAI endpoint/model/API key. Credentials use Keychain. Sign-in and organization-managed add-in deployment still require the organization's approval and access.

Verification: a genuine local response and live Washington, DC weather retrieval completed through the installed app's authenticated service connection. A controlled local proxy returned HTTP 407 and the request stopped without direct retry. The Python suite passed 35 tests and the Rust suite passed four tests. Commercial weather and cloud generation still need actual configured credentials for live acceptance; no successful responses from those connections were simulated. See [the Ask AI verification record](evidence/ask-ai/VERIFICATION.md).

The Outlook/Teams packages, Graph adapters, and GenAI adapters are implementation work in progress. Their actual host connections and live-data workflows have not passed end-to-end acceptance. The development HTTPS certificate is not automatically trusted, and Teams certificate/host deployment requirements remain unresolved. Do not deploy these as a production government-data product.

Build with `python3 -B product/integrated/tools/build.py`. Install the verified staging result with `python3 -B product/integrated/tools/install.py`. The installed development app still references this repository's runtime/model locations. This is not a portable, signed/notarized distribution.

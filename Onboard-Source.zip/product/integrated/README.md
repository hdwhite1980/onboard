# Onboard AI integrated development build

The current product is an application-first Outlook, Teams and Word assistant with a shared local service, bounded local AI, optional approved cloud reasoning and reviewed cross-application work.

Start with [PRODUCT-STATUS.md](PRODUCT-STATUS.md) for current capabilities, priorities, limitations and live acceptance steps. This replaces the earlier integrated README's runtime limits and deployment status.

- [HYBRID-WORD.md](HYBRID-WORD.md): hybrid tools, Word and email/document workflows.
- [ACCESS-SETUP.md](ACCESS-SETUP.md): sign-in, delegated permissions and add-in connections.
- [MANAGED-POLICY.md](MANAGED-POLICY.md): administrator-owned endpoint restrictions.
- [setup/INSTALL.md](setup/INSTALL.md): source installer, model reuse and prerequisites.

Release 0.6 adds explicitly saved encrypted public drafts across native/Outlook/Teams/Word, recovery after restart/sign-in, non-destructive handoff failure handling, and authenticated readiness diagnostics. Native approval remains the connection mechanism; SSO is not implemented.

This remains an Apple-silicon/macOS-26+ development build, with an ad-hoc signature rather than a notarized customer installer. Public-content policy only. GenAI.mil, government tenant deployment, protected-data handling, Windows and live Office acceptance remain separate uncompleted qualifications. See PRODUCT-STATUS.md rather than historical Sprint documents for the current integrated state.

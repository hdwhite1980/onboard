"""Routing/security controls with explicit fixtures, not live Graph/cloud acceptance."""
import json,pathlib,sys,tempfile,threading,time,unittest
from unittest.mock import Mock,patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from host import Host
from connectors import Graph,Failure,cloud
from email_analysis import analyze

class MailSearchTests(unittest.TestCase):
    def test_provider_accepts_base_or_full_endpoint_without_duplicate_path(self):
        for endpoint in ('https://approved.invalid/v1','https://approved.invalid/v1/chat/completions','https://approved.invalid/v1/chat/completions/'):
            provider={'type':'compatible-chat','endpoint':endpoint,'model':'test','max_output':512,'max_input_chars':1000,'timeout':10,'daily_requests':10}
            with patch('connectors.http',return_value={'choices':[{'message':{'content':'Transport fixture only'}}]}) as request:
                cloud(provider,'test-only',[{'role':'user','content':'public fixture'}])
            self.assertEqual(request.call_args.args[0],'https://approved.invalid/v1/chat/completions')
    def test_read_only_search_is_bounded_and_input_cannot_supply_kql_operators(self):
        g=Graph();g.config={'mail':True};g.get=Mock(return_value={'value':[],'@odata.nextLink':'https://untrusted.invalid'})
        got,note=g.search_mail('Find relevant emails about "budget" OR from:someone; https://bad.invalid')
        path,query=g.get.call_args.args
        self.assertEqual(path,'me/messages');self.assertEqual(query['$top'],'10')
        self.assertNotIn(':',query['$search']);self.assertNotIn(';',query['$search']);self.assertEqual(g.get.call_count,1)
        self.assertIn('not an exhaustive',note);self.assertEqual(got,[])
    def test_search_requires_mail_permission(self):
        g=Graph();g.config={};g.get=Mock()
        with self.assertRaises(Failure):g.search_mail('Budget')
        g.get.assert_not_called()
    def test_generic_request_uses_subject_without_unbounded_browse(self):
        g=Graph();g.config={'mail':True};g.get=Mock(return_value={'value':[]})
        g.search_mail('Summarize this email','Project Falcon')
        self.assertEqual(g.get.call_args.args[1]['$search'],'"project OR falcon"')
        g.get.reset_mock();g.search_mail('Summarize this email');g.get.assert_not_called()

class CloudHandoffTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.h=Host.__new__(Host);self.h.state=pathlib.Path(self.tmp.name)
        self.h.resources=P/'build/Onboard AI.app/Contents/Resources'
        self.h.config={'addin_cloud':True,'public_cloud':True,'provider':{'name':'Test-only transport','type':'compatible-chat','max_input_chars':16000,'daily_requests':2}}
        self.h.graph=Mock();self.h.graph.identity.return_value=('tenant','user',1)
        self.h.sessions={'paired':{'app':'outlook'}};self.h.vault=Mock(return_value='test-only-no-network')
        self.job={'owner':'paired','identity':('tenant','user',1),'cancel':threading.Event(),'request':{'task':'ask','prompt':'Budget?','public_attested':True,'allow_cloud':True}}
        self.base={'sources':[{'id':'a','title':'Selected','text':'Budget pending.'},{'id':'b','title':'Unrelated','text':'Never transmit this.'}],
                   'claims':[{'source_id':'a','quote':'Budget pending.'}],'retrieval_notes':[],'answer':'Local result','route':'local'}
        self.packet={'sources':[{'id':'a','alias':'S1','text':'Budget pending.'}]}
    def test_only_locally_cited_source_is_sent(self):
        response=json.dumps({'claims':[{'source_id':'S1','quote':'Budget pending.'}],'suggestions':'Review status.'})
        with patch('email_analysis.cloud',return_value=(response,{})) as send:
            result=analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
        self.assertEqual(result['route'],'cloud');self.assertEqual(result['claims'][0]['source_id'],'a')
        payload=send.call_args.args[2];self.assertNotIn('Never transmit',json.dumps(payload))
        self.assertEqual(result['cloud_sources'][0]['id'],'a')
    def test_settings_and_request_permission_both_required(self):
        for setting,request in ((False,True),(True,False)):
            self.h.config['addin_cloud']=setting;self.job['request']['allow_cloud']=request
            with patch('email_analysis.cloud',side_effect=AssertionError('No permission')):
                analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
        self.h.vault.assert_not_called()
    def test_no_provider_or_no_public_confirmation_blocks_transmission(self):
        self.job['request']['public_attested']=False
        with patch('email_analysis.cloud',side_effect=AssertionError('No public permission')):
            analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
        self.h.config['provider']={};self.job['request']['public_attested']=True
        with patch('email_analysis.cloud',side_effect=AssertionError('No provider')):
            analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
        self.h.vault.assert_not_called()
    def test_no_local_citation_never_sends_mail(self):
        self.base['claims']=[]
        with patch('email_analysis.cloud',side_effect=AssertionError('No verified selection')):
            analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
        self.h.vault.assert_not_called()
    def test_account_change_after_credential_read_blocks_dispatch(self):
        def change(*args):self.h.graph.identity.return_value=('tenant','other',2);return 'test-only'
        self.h.vault.side_effect=change
        with patch('email_analysis.cloud',side_effect=AssertionError('Changed account')):
            with self.assertRaises(Failure):analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
    def test_cancel_and_disconnected_session_block_dispatch(self):
        for cancel in (False,True):
            self.job['cancel'].set() if cancel else self.job['cancel'].clear()
            self.h.sessions={'paired':{'app':'outlook'}} if cancel else {}
            with patch('email_analysis.cloud',side_effect=AssertionError('Inactive request')):
                with self.assertRaises(Failure):analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
    def test_provider_error_preserves_source_result_and_does_not_retry(self):
        with patch('email_analysis.cloud',side_effect=Failure('Proxy authentication required')) as send:
            with self.assertRaises(Failure):analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
        self.assertEqual(send.call_count,1);self.assertEqual(self.base['answer'],'Local result')
    def test_unseen_cloud_quote_withheld(self):
        with patch('email_analysis.cloud',return_value=(json.dumps({'claims':[{'source_id':'S1','quote':'approved'}]}),{})):
            result=analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
        self.assertEqual(result['answer'],'Local result');self.assertEqual(result['route'],'local')
    def test_input_cap_reuses_only_locally_reviewed_excerpt(self):
        self.base['sources'][0]['text']='Budget pending.\n\n'+('Additional text. '*2000)
        with patch('email_analysis.cloud',return_value=(json.dumps({'claims':[]}),{})) as send:
            analyze(self.h,self.job,self.base,self.packet,'Use evidence.')
        self.assertNotIn('Additional text',json.dumps(send.call_args.args[2]))
    def test_daily_cap_checked_before_dispatch(self):
        (self.h.state/'usage.json').write_text(json.dumps({time.strftime('%Y-%m-%d'):2}))
        with patch('email_analysis.cloud',side_effect=AssertionError('Daily cap')):
            with self.assertRaises(Failure):analyze(self.h,self.job,self.base,self.packet,'Use evidence.')

if __name__=='__main__':unittest.main()

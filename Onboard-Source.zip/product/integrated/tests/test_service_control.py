import pathlib,sys,unittest
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
import service_control as c

class ControlTests(unittest.TestCase):
 def setUp(self):self.item=c.Identity(123,(100,1),('python',),'/python')
 def test_rejects_unrelated_arguments(self):
  with self.assertRaises(c.ControlError):c.verify_onboard(self.item,38473)
 def test_pid_reuse_refused(self):
  with patch.object(c,'identity',return_value=c.Identity(123,(101,1),('python',),'/python')):
   with self.assertRaises(c.ControlError):c.same(self.item)
 def test_all_owners_checked_before_any_signal(self):
  with patch.object(c,'owners',return_value={123,124}),patch.object(c,'identity',return_value=self.item),patch.object(c,'verify_onboard',side_effect=[None,c.ControlError('unrelated')]),patch.object(c.os,'kill') as kill:
   with self.assertRaises(c.ControlError):c.stop('/state',38473)
   kill.assert_not_called()
 def test_active_legacy_work_not_orphaned(self):
  with patch.object(c,'owners',return_value={123}),patch.object(c,'identity',return_value=self.item),patch.object(c,'verify_onboard'),patch.object(c,'has_children',return_value=True),patch.object(c.os,'kill') as kill:
   with self.assertRaisesRegex(c.ControlError,'active work'):c.stop('/state',38473)
   kill.assert_not_called()
 def test_stopped_is_idempotent(self):
  with patch.object(c,'owners',return_value=set()),patch.object(c.os,'kill') as kill:
   self.assertTrue(c.stop('/state',38473)['stopped']);kill.assert_not_called()
 def test_force_stop_rechecks_identity(self):
  with patch.object(c,'owners',return_value={123}),patch.object(c,'identity',return_value=self.item),patch.object(c,'verify_onboard'),patch.object(c,'has_children',return_value=False),patch.object(c.os,'kill') as kill,patch.object(c.time,'monotonic',side_effect=[0,20]),patch.object(c,'same',side_effect=[True,True,c.ControlError('changed')]):
   with self.assertRaises(c.ControlError):c.stop('/state',38473)
   self.assertEqual(kill.call_args_list,[unittest.mock.call(123,c.signal.SIGTERM)])
if __name__=='__main__':unittest.main()

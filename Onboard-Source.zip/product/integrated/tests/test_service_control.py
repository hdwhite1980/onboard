import pathlib,sys,unittest
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
import service_control as c

class ControlTests(unittest.TestCase):
 def setUp(self):self.item=c.Identity(123,(100,1),('python',),'/python')
 def test_rejects_unrelated_arguments(self):
  with self.assertRaises(c.ControlError):c.verify_onboard(self.item,38473)
 def test_pid_reuse_refused(self):
  with patch.object(c,'identity',return_value=c.Identity(123,(101,1),('python',),'/python')):
   with self.assertRaises(c.ControlError):c.same(self.item)
 def test_all_owners_checked_before_any_signal(self):
  with patch.object(c,'owners',return_value={123,124}),patch.object(c,'identity',return_value=self.item),patch.object(c,'verify_onboard',side_effect=[None,c.ControlError('unrelated')]),patch.object(c.os,'kill') as kill:
   with self.assertRaises(c.ControlError):c.stop('/state',38473)
   kill.assert_not_called()
 def test_active_legacy_work_not_orphaned(self):
  with patch.object(c,'owners',return_value={123}),patch.object(c,'identity',return_value=self.item),patch.object(c,'verify_onboard'),patch.object(c,'has_children',return_value=True),patch.object(c.os,'kill') as kill:
   with self.assertRaisesRegex(c.ControlError,'active work'):c.stop('/state',38473)
   kill.assert_not_called()
 def test_stopped_is_idempotent(self):
  with patch.object(c,'owners',return_value=set()),patch.object(c.os,'kill') as kill:
   self.assertTrue(c.stop('/state',38473)['stopped']);kill.assert_not_called()
 def test_force_stop_rechecks_identity(self):
  with patch.object(c,'owners',return_value={123}),patch.object(c,'identity',return_value=self.item),patch.object(c,'verify_onboard'),patch.object(c,'has_children',return_value=False),patch.object(c.os,'kill') as kill,patch.object(c.time,'monotonic',side_effect=[0,20]),patch.object(c,'same',side_effect=[True,True,c.ControlError('changed')]):
   with self.assertRaises(c.ControlError):c.stop('/state',38473)
   self.assertEqual(kill.call_args_list,[unittest.mock.call(123,c.signal.SIGTERM)])

class VerificationTests(unittest.TestCase):
 def setUp(self):
  import tempfile,plistlib,json
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.root=pathlib.Path(self.temp.name);self.app=self.root/'Onboard AI.app';self.res=self.app/'Contents/Resources';self.res.mkdir(parents=True)
  self.exe=self.app/'Contents/MacOS/OnboardAI';self.exe.parent.mkdir();self.exe.write_text('fixture')
  (self.res/'service').mkdir();(self.res/'service/host.py').write_text('fixture');self.state=self.root/'state';self.state.mkdir()
  (self.app/'Contents/Info.plist').write_bytes(plistlib.dumps({'CFBundleIdentifier':'local.onboard.integrated.dev','CFBundleExecutable':'OnboardAI'}))
  (self.res/'deployment.json').write_text(json.dumps({'state':str(self.state),'python':'/usr/bin/python3'}))
  self.argv=('/usr/bin/python3','-I','-B',str(self.res/'service/host.py'),'--resources',str(self.res),'--state',str(self.state),'--app',str(self.exe))
 def item(self,exe):return c.Identity(123,(100,1),self.argv,exe)
 def test_standalone_tools_actual_interpreter_is_accepted(self):
  import subprocess
  exe='/Library/Developer/CommandLineTools/usr/bin/python3'
  with patch.object(c,'apple_python_executable',return_value=pathlib.Path(exe)),patch.object(c.subprocess,'run',return_value=subprocess.CompletedProcess([],0,b'',b'')):
   self.assertEqual(c.verify_onboard(self.item(exe),38473),self.state.resolve())
 def test_custom_xcode_location_resolved_by_apple_launcher(self):
  import subprocess
  exe='/Applications/Xcode-beta.app/Contents/Developer/usr/bin/python3'
  with patch.object(c,'apple_python_executable',return_value=pathlib.Path(exe)),patch.object(c.subprocess,'run',return_value=subprocess.CompletedProcess([],0,b'',b'')):
   c.verify_onboard(self.item(exe),38473)
 def test_python_in_apple_folder_is_not_sufficient(self):
  with patch.object(c,'apple_python_executable',return_value=pathlib.Path('/usr/bin/expected-python')):
   with self.assertRaisesRegex(c.ControlError,'PYTHON_EXECUTABLE_MISMATCH'):c.verify_onboard(self.item('/Applications/Xcode.app/Contents/Developer/Unexpected/Python'),38473)
 def test_signature_failure_has_specific_reason(self):
  import subprocess
  with patch.object(c,'apple_python_executable',return_value=pathlib.Path('/example/python')),patch.object(c.subprocess,'run',return_value=subprocess.CompletedProcess([],1,b'',b'invalid')):
   with self.assertRaisesRegex(c.ControlError,'APP_SIGNATURE_INVALID'):c.verify_onboard(self.item('/example/python'),38473)
 def test_missing_bundle_has_specific_reason(self):
  self.app.rename(self.root/'Moved.app')
  with self.assertRaisesRegex(c.ControlError,'APP_BUNDLE_MISSING'):c.verify_onboard(self.item('/example/python'),38473)
 def test_diagnostic_never_signals_or_stops(self):
  with patch.object(c,'owners',return_value={123}),patch.object(c,'identity',return_value=self.item('/example/python')),patch.object(c,'verify_onboard',side_effect=c.ControlError('specific reason')),patch.object(c.os,'kill') as kill:
   r=c.diagnose(str(self.state),38473);self.assertTrue(r['readOnly']);self.assertEqual(r['processes'][0]['reason'],'specific reason');kill.assert_not_called()
 def test_apple_launcher_query_uses_only_trusted_program(self):
  import subprocess
  c.apple_python_executable.cache_clear();self.addCleanup(c.apple_python_executable.cache_clear)
  with patch.object(c.subprocess,'run',return_value=subprocess.CompletedProcess([],0,'/example/python\n','')) as run:
   self.assertEqual(c.apple_python_executable(),pathlib.Path('/example/python'))
   self.assertEqual(run.call_args.args[0][:3],['/usr/bin/python3','-I','-B'])

class DeploymentRecoveryTests(unittest.TestCase):
 setUp=VerificationTests.setUp
 item=VerificationTests.item
 def changed_deployment(self):
  import json
  (self.res/'deployment.json').write_text(json.dumps({'state':str(self.root/'new-state'),'python':'/usr/bin/python3'}))
 def test_changed_state_requires_owned_active_lock(self):
  import subprocess
  self.changed_deployment()
  with patch.object(c,'apple_python_executable',return_value=pathlib.Path('/example/python')),patch.object(c.subprocess,'run',return_value=subprocess.CompletedProcess([],0,b'',b'')),patch.object(c,'owns_active_state_lock',return_value=True) as owned:
   self.assertEqual(c.verify_onboard(self.item('/example/python'),38473),self.state.resolve());owned.assert_called_once_with(123,self.state.resolve())
 def test_changed_state_without_lock_proof_refused(self):
  import subprocess
  self.changed_deployment()
  with patch.object(c,'apple_python_executable',return_value=pathlib.Path('/example/python')),patch.object(c.subprocess,'run',return_value=subprocess.CompletedProcess([],0,b'',b'')),patch.object(c,'owns_active_state_lock',return_value=False):
   with self.assertRaisesRegex(c.ControlError,'DEPLOYMENT_MISMATCH'):c.verify_onboard(self.item('/example/python'),38473)
 def test_owned_lock_does_not_override_invalid_signature(self):
  import subprocess
  self.changed_deployment()
  with patch.object(c,'apple_python_executable',return_value=pathlib.Path('/example/python')),patch.object(c.subprocess,'run',return_value=subprocess.CompletedProcess([],1,b'',b'')),patch.object(c,'owns_active_state_lock',return_value=True) as owned:
   with self.assertRaisesRegex(c.ControlError,'APP_SIGNATURE_INVALID'):c.verify_onboard(self.item('/example/python'),38473)
   owned.assert_not_called()
 def test_abandoned_lock_file_is_not_recovery_evidence(self):
  (self.state/'service.lock').touch()
  with patch.object(c,'lsof_pids',return_value={123}) as lsof:
   self.assertFalse(c.owns_active_state_lock(123,self.state));lsof.assert_not_called()
 def test_other_pid_holding_lock_is_not_recovery_evidence(self):
  lock=self.state/'service.lock'
  with lock.open('w') as handle,patch.object(c,'lsof_pids',return_value={456}):
   c.fcntl.flock(handle,c.fcntl.LOCK_EX|c.fcntl.LOCK_NB)
   self.assertFalse(c.owns_active_state_lock(123,self.state))
 def test_symlink_lock_is_not_recovery_evidence(self):
  target=self.root/'other.lock';target.touch();(self.state/'service.lock').symlink_to(target)
  self.assertFalse(c.owns_active_state_lock(123,self.state))

class ExitRaceTests(unittest.TestCase):
 def test_process_exiting_before_argv_is_treated_as_gone(self):
  self.check(5,True)
 def test_live_process_with_unreadable_argv_is_not_treated_as_gone(self):
  self.check(2,False)
 def check(self,second_status,gone):
  from unittest.mock import Mock
  lib=Mock();libc=Mock();statuses=iter([2,second_status])
  def info(pid,flavor,arg,out,size):
   value=c.ctypes.cast(out,c.ctypes.POINTER(c.BSDInfo)).contents
   value.uid=c.os.getuid();value.ruid=c.os.getuid();value.pid=pid;value.status=next(statuses)
   return size
  def path(pid,out,size):out.value=b'/usr/bin/python3';return len(out.value)
  lib.proc_pidinfo.side_effect=info;lib.proc_pidpath.side_effect=path;libc.sysctl.return_value=-1
  with patch.object(c.ctypes,'CDLL',side_effect=[lib,libc]):
   if gone:self.assertIsNone(c.identity(123))
   else:
    with self.assertRaisesRegex(c.ControlError,'process arguments'):c.identity(123)

if __name__=='__main__':unittest.main()

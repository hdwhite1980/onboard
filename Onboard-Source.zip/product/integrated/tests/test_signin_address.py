"""Real observed address regression and malicious address rejection; no live codes."""
import pathlib,sys,unittest
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from connectors import Failure,Graph,verification_address
from test_tenant import metadata,TENANT,CLIENT
GLOBAL='https://login.microsoftonline.com'
GOV='https://login.microsoftonline.us'

class SigninAddress(unittest.TestCase):
 def test_current_commercial_address_completes_signin_start(self):
  response={'verification_uri':'https://login.microsoft.com/device','expires_in':900,'user_code':'control-only','device_code':'control-only'}
  graph=Graph()
  with patch('tenant.http',return_value=metadata('Commercial')),patch.object(graph,'post',return_value=response):
   result=graph.start({'tenant':TENANT,'client':CLIENT,'cloud':'Auto'})
  self.assertEqual(result['verification_uri'],response['verification_uri']);self.assertIsNotNone(graph.pending);self.assertIsNone(graph.token)
 def test_legacy_and_tenant_authority_addresses_remain_supported(self):
  for authority in (GLOBAL,GOV):
   for url in ('https://microsoft.com/devicelogin','https://www.microsoft.com/devicelogin',authority+'/common/oauth2/deviceauth'):
    self.assertEqual(verification_address(url,authority),url)
 def test_new_commercial_page_does_not_widen_government_hosts(self):
  with self.assertRaises(Failure):verification_address('https://login.microsoft.com/device',GOV)
  with self.assertRaises(Failure):verification_address(GLOBAL+'/common/oauth2/deviceauth',GOV)
 def test_new_host_is_limited_to_exact_device_page(self):
  for suffix in ('/','/other','/device/other','/device?redirect=https://attacker.invalid','/device#fragment'):
   with self.subTest(suffix=suffix),self.assertRaises(Failure):verification_address('https://login.microsoft.com'+suffix,GLOBAL)
 def test_spoofed_or_malformed_addresses_are_rejected(self):
  for url in (None,42,'','http://login.microsoft.com/device','https://login.microsoft.com.attacker.invalid/device','https://attacker.invalid/device','https://login.microsoft.com@attacker.invalid/device','https://user@login.microsoft.com/device','https://@login.microsoft.com/device','https://login.microsoft.com:444/device','https://login.microsoft.com:bad/device','https://login.micro\nsoft.com/device','https://login.microsoft.com\\@attacker.invalid/device','https://[bad/device'):
   with self.subTest(url=url),self.assertRaises(Failure):verification_address(url,GLOBAL)

if __name__=='__main__':unittest.main()

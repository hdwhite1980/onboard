"""Budget and citation control fixtures, not model-quality or live-data evidence."""
import json,pathlib,sys,threading,time,unittest
from unittest.mock import Mock,patch
P=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P/'local'));sys.path.insert(0,str(P/'service'))
from context_packet import pack,render,ContextLimit,PROMPT_LIMIT
from host import Host
from connectors import Failure
from local_engine import LocalUnavailable

class ByteTokenizer:
    # Deliberately strict and deterministic; live tokenizer verification is separate.
    def apply_chat_template(self,messages,**kwargs):
        return '\n'.join(m['role']+':'+m['content'] for m in messages)
    def encode(self,text,**kwargs):return list(text.encode())

class PacketTests(unittest.TestCase):
    def setUp(self):
        self.tok=ByteTokenizer();self.messages=[{'role':'system','content':'Use evidence.'},{'role':'user','content':'Budget?'}]
    def source(self,text,**kw):return dict(id='mail:'+('long-id-'*100),text=text,**kw)
    def test_long_ids_do_not_consume_context_and_question_is_preserved(self):
        source=self.source('The budget is not approved.')
        messages,p=pack(self.tok,self.messages,[source])
        self.assertFalse(p['partial']);self.assertIn('S1\nThe budget is not approved.',messages[1]['content'])
        self.assertNotIn(source['id'],messages[1]['content']);self.assertEqual(p['sources'][0]['id'],source['id'])
        self.assertTrue(messages[1]['content'].startswith('Budget?\n'));self.assertLessEqual(len(render(self.tok,messages)[1]),PROMPT_LIMIT)
    def test_whole_paragraphs_and_negation_preserved_with_omissions_disclosed(self):
        paragraph='The budget is proposed. It is not approved.'
        source=self.source(('Unrelated material. '*200)+'\n\n'+paragraph)
        messages,p=pack(self.tok,self.messages,[source])
        self.assertTrue(p['partial']);self.assertEqual(p['sources'][0]['text'],paragraph)
        self.assertIn('may omit relevant or contradictory',messages[0]['content'])
        self.assertLessEqual(p['prompt_tokens'],PROMPT_LIMIT)
    def test_no_mid_paragraph_cut_to_make_space(self):
        with self.assertRaisesRegex(ContextLimit,'complete paragraph'):
            pack(self.tok,self.messages,[self.source('Budget approved. '*100+'Not authorized.')])
    def test_question_never_silently_cut(self):
        messages=[self.messages[0],{'role':'user','content':'Long question '*200}]
        with self.assertRaisesRegex(ContextLimit,'question is too long'):pack(self.tok,messages,[])
        self.assertEqual(messages[1]['content'],'Long question '*200)
    def test_unicode_budget_measured_not_character_estimated(self):
        _,p=pack(self.tok,self.messages,[self.source('予算は未承認です。')])
        self.assertLessEqual(p['prompt_tokens'],PROMPT_LIMIT)
    def test_already_truncated_retrieval_is_never_full_coverage(self):
        _,p=pack(self.tok,self.messages,[self.source('The budget is unknown.',incomplete=True)])
        self.assertTrue(p['partial'])
    def test_relevant_later_source_can_fit_after_oversized_source(self):
        sources=[self.source('Large paragraph '*400),{'id':'b','text':'Budget is unknown.'}]
        _,p=pack(self.tok,self.messages,sources)
        self.assertEqual(p['included_sources'],1);self.assertEqual(p['retrieved_sources'],2)
        self.assertEqual(p['sources'][0]['id'],'b');self.assertEqual(p['sources'][0]['alias'],'S2')
    def test_empty_sources_do_not_trigger_model_without_evidence(self):
        with self.assertRaises(ContextLimit):pack(self.tok,self.messages,[self.source('')])

class HostContextTests(unittest.TestCase):
    def setUp(self):
        self.h=Host.__new__(Host);self.h.resources=P/'build/Onboard AI.app/Contents/Resources'
        self.h.config={'public_local':True};self.h.graph=Mock();self.h.graph.identity.return_value=('tenant','user',1)
        self.h.sessions={'paired':{'app':'outlook'}}
        self.h.local_status=Mock(return_value={'ready':True})
        self.job={'id':'unit','owner':'paired','identity':('tenant','user',1),'cancel':threading.Event(),
                  'request':{'task':'summarize','route':'local','prompt':'Summarize','public_attested':True,
                             'sources':[{'kind':'selected','text':'Included.\n\nOmitted.'}]}}
        self.packet={'partial':True,'prompt_tokens':380,'prompt_limit':384,'retrieved_sources':1,'included_sources':1,
                     'sources':[{'id':'selected:unit','alias':'S1','text':'Included.'}]}
    def test_context_error_retains_sources_without_cloud_dispatch(self):
        with patch('local_engine.generate_grounded',side_effect=LocalUnavailable('CONTEXT_LIMIT','Select a shorter excerpt.')),patch('host.cloud',side_effect=AssertionError('No cloud fallback')):
            r=self.h.process(self.job)
        self.assertEqual(r['status'],'model_unavailable');self.assertEqual(r['network_code'],'CONTEXT_LIMIT')
        self.assertEqual(r['sources'][0]['text'],'Included.\n\nOmitted.');self.assertEqual(r['answer'],'')
    def test_error_path_still_checks_account_and_session(self):
        for expired in (False,True):
            def fail(*args):
                if expired:self.h.sessions.pop('paired',None)
                else:self.h.graph.identity.return_value=('tenant','different-user',2)
                raise LocalUnavailable('CONTEXT_LIMIT','Too long')
            self.h.graph.identity.return_value=self.job['identity']
            with patch('local_engine.generate_grounded',side_effect=fail):
                with self.assertRaises(Failure):self.h.process(self.job)
    def test_unseen_source_quote_withheld_even_if_in_original(self):
        output=json.dumps({'claims':[{'source_id':'S1','quote':'Omitted.'}]})
        with patch('local_engine.generate_grounded',return_value=(output,self.packet)):
            r=self.h.process(self.job)
        self.assertEqual(r['status'],'withheld');self.assertEqual(r['claims'],[])
        self.assertIn('Partial coverage',r['retrieval_notes'][-1])
    def test_accepted_citation_maps_back_to_original_source(self):
        output=json.dumps({'claims':[{'source_id':'S1','quote':'Included.'}]})
        with patch('local_engine.generate_grounded',return_value=(output,self.packet)) as generate:
            r=self.h.process(self.job)
        self.assertEqual(r['claims'][0]['source_id'],'selected:unit')
        self.assertEqual(generate.call_args.args[1][1]['content'],'Summarize')
        self.assertIn('excerpts only',r['message']);self.assertNotIn('sources',r['context'])
    def test_cancel_before_inference(self):
        self.job['cancel'].set()
        with patch('local_engine.generate_grounded',side_effect=AssertionError('No model after cancellation')):
            with self.assertRaises(Failure):self.h.process(self.job)

if __name__=='__main__':unittest.main()

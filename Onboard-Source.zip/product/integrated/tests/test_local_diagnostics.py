"""Guard classification and privacy regression checks; no model loads."""
import json,pathlib,sys,tempfile,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from local_diagnostics import outcome,record

def result(**changes):
    row=dict(primary='LOCAL_GENERATION_FAILED',supervisor='TERMINATION_CONFIRMED',evidenceCompleteness='COMPLETE',processGroupPresent=False,aborts=[])
    row.update(changes);return row

class LocalDiagnosticsTests(unittest.TestCase):
    def test_generation_timeout_is_explicit(self):
        for reason in ('RUNTIME: generation timeout','RUNTIME: timeout awaiting generated'):
            code,message,recoverable=outcome(result(aborts=[reason]))
            self.assertEqual(code,'GENERATION_TIMEOUT');self.assertIn('time',message);self.assertTrue(recoverable)
    def test_cleanup_failure_overrides_timeout_and_prevents_fallback(self):
        for changes in ({'supervisor':'CLEANUP_OR_EVIDENCE_ERROR'},{'evidenceCompleteness':'PARTIAL'},{'processGroupPresent':True},{'processGroupPresent':None}):
            row=result(aborts=['RUNTIME: generation timeout'],**changes)
            self.assertEqual(outcome(row)[0],'CLEANUP_UNCONFIRMED');self.assertFalse(outcome(row)[2])
    def test_success_requires_proven_cleanup(self):
        self.assertEqual(outcome(result(primary='LOCAL_GENERATION_SUCCESS'))[0],'SUCCESS')
        self.assertEqual(outcome(result(primary='LOCAL_GENERATION_SUCCESS',processGroupPresent=True))[0],'CLEANUP_UNCONFIRMED')
    def test_security_failure_cannot_be_downgraded_to_resource_fallback(self):
        row=result(primary='NETWORK_BOUNDARY_FAILED',aborts=['RESOURCE: pressure WARN'])
        self.assertEqual(outcome(row)[0],'NETWORK_BOUNDARY_FAILED');self.assertFalse(outcome(row)[2])
    def test_resource_reasons_are_distinct(self):
        for reason,code in [('RESOURCE: protected reserve approached','MEMORY_RESERVE'),('RESOURCE: nonzero initial swap','EXISTING_SWAP'),('RESOURCE: worker footprint exceeded','MODEL_MEMORY_LIMIT'),('RESOURCE: positive swap-in','SWAP_ACTIVITY')]:
            self.assertEqual(outcome(result(aborts=[reason]))[0],code)
    def test_unreliable_monitor_does_not_fallback(self):
        self.assertEqual(outcome(result(aborts=['MONITOR: MLX telemetry stale']))[0],'MODEL_MONITOR_STALE')
        self.assertFalse(outcome(result(aborts=['MONITOR: required telemetry unavailable']))[2])
    def test_diagnostic_never_retains_arbitrary_text(self):
        secret='private-email-body-api-key-source-path'
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d);run=p/'request';(run/'calibration').mkdir(parents=True)
            (run/'calibration/resources.jsonl').write_text(json.dumps({'phase':secret,'guardReason':secret,'availableEstimateLegacyBytes':1234,'workerPhysicalFootprintBytes':secret,'swapUsedBytes':0})+'\n')
            record(p,run,result(aborts=['RUNTIME: '+secret],rawOutput=secret,workerExitCode=70,modelLoads=1))
            target=p/'last-local-run.json';raw=target.read_text();data=json.loads(raw)
            self.assertNotIn(secret,raw);self.assertEqual(data['code'],'LOCAL_RUNTIME_FAILED')
            self.assertEqual(data['availableEstimateLegacyBytes'],1234);self.assertNotIn('workerPhysicalFootprintBytes',data)
            self.assertEqual(target.stat().st_mode & 0o777,0o600)
            record(p,run,result(primary='LOCAL_GENERATION_SUCCESS'))
            self.assertEqual(json.loads(target.read_text())['code'],'SUCCESS')
            self.assertEqual(list(p.glob('.local-diagnostic-*')),[])
    def test_unknown_error_is_not_exposed(self):
        self.assertNotIn('SECRET',outcome(result(aborts=['RUNTIME: SECRET']))[1])

if __name__=='__main__':unittest.main()

// Isolated Office API fixtures, never presented as live document/tenant verification.
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const web=path.join(__dirname,'../web');
function labels(){const c={setTimeout,clearTimeout,Office:{AsyncResultStatus:{Succeeded:'ok'}}};vm.runInNewContext(fs.readFileSync(path.join(web,'labels.js'),'utf8'),c);return c.OnboardLabels;}
test('Outlook reads tenant and label metadata without inferring PUBLIC from name',()=>{
 const label='22222222-2222-2222-2222-222222222222',tenant='11111111-1111-1111-1111-111111111111';
 const result=labels().headers('MSIP_Labels: MSIP_Label_'+label+'_Enabled=True;\r\n MSIP_Label_'+label+'_SiteId='+tenant+';MSIP_Label_'+label+'_Name=Public;');
 assert.equal(result.state,'labeled');assert.equal(result.labels[0].tenant,tenant);assert.equal(result.labels[0].id,label);assert.equal(result.labels[0].enabled,true);
});
test('unsupported or failed Outlook label inspection returns unavailable',async()=>{
 assert.equal((await labels().outlook({})).state,'unavailable');
 assert.equal((await labels().outlook({sensitivityLabel:{getAsync:cb=>cb({status:'failed'})}})).state,'unavailable');
});
test('compose label API does not invent tenant or downgrade classification',async()=>{
 const result=await labels().outlook({sensitivityLabel:{getAsync:cb=>cb({status:'ok',value:'LABEL-ID'})}});assert.equal(result.state,'labeled');assert.equal(result.labels[0].tenant,'');
});
function word(){
 let closed=0;const writes=[];const body={text:'Original fixture document',load(){},insertParagraph:(...args)=>writes.push(args)},selection={text:'Original',load(){},insertText:(...args)=>writes.push(args)};
 const file={size:4,sliceCount:1,getSliceAsync:(i,cb)=>cb({status:'ok',value:{data:[80,75,3,4]}}),closeAsync:cb=>{closed++;cb({status:'ok'});}};
 const c={setTimeout,clearTimeout,Uint8Array,btoa:s=>Buffer.from(s,'binary').toString('base64'),Office:{onReady:async()=>({host:'Word'}),AsyncResultStatus:{Succeeded:'ok'},FileType:{Compressed:'compressed'},context:{document:{url:'fixture.docx',getFileAsync:(type,options,cb)=>cb({status:'ok',value:file})}}},Word:{InsertLocation:{replace:'Replace',end:'End'},run:async fn=>fn({document:{body,getSelection:()=>selection},sync:async()=>{}})}};
 vm.runInNewContext(fs.readFileSync(path.join(web,'word-host.js'),'utf8'),c);return {c,body,selection,file,writes,closed:()=>closed,host:c.OnboardWord};
}
test('Word capture releases the file and produces bytes only from the host',async()=>{const f=word();await f.host.initialize();const result=await f.host.capture();assert.equal(result.file,'UEsDBA==');assert.equal(f.closed(),1);});
test('fresh Word verification cannot replace the originally reviewed selection',async()=>{
 const f=word();await f.host.capture();f.selection.text='Other';await f.host.verify();await assert.rejects(f.host.insert('Draft',true),/selected text changed/);assert.equal(f.writes.length,0);
});
test('fresh Word verification rejects changed body before authorization',async()=>{
 const f=word();await f.host.capture();f.body.text='Changed';await assert.rejects(f.host.verify(),/changed/);assert.equal(f.writes.length,0);
});
test('oversized Word capture closes its host file before failing',async()=>{const f=word();f.file.size=4000001;await assert.rejects(f.host.capture(),/4 MB/);assert.equal(f.closed(),1);});
test('Word insert requires a capture and refuses changed content',async()=>{
 const f=word();await assert.rejects(f.host.insert('Draft'),/Inspect/);await f.host.capture();f.body.text='Changed';await assert.rejects(f.host.insert('Draft'),/changed/);assert.equal(f.writes.length,0);
});
test('Word replacement refuses a changed selection and a different document',async()=>{
 const f=word();await f.host.capture();f.selection.text='Other';await assert.rejects(f.host.insert('Draft',true),/selected text changed/);f.selection.text='Original';f.c.Office.context.document.url='other.docx';await assert.rejects(f.host.insert('Draft',true),/document changed/);assert.equal(f.writes.length,0);
});
test('Word inserts reviewed plain text without replacing the whole document or sending',async()=>{
 const f=word();await f.host.capture();await f.host.insert('<literal> draft',false);assert.deepEqual(f.writes,[['<literal> draft','End']]);await assert.rejects(f.host.insert('Again'),/Inspect/);
});
test('Outlook attachment requires compose and leaves Send to the user',async()=>{
 const attached=[];const item={subject:{setAsync(){}},addFileAttachmentFromBase64Async:(data,name,cb)=>{attached.push({data,name});cb({status:'ok'});}};
 const c={setTimeout,clearTimeout,URL,addEventListener(){},Office:{AsyncResultStatus:{Succeeded:'ok'},context:{mailbox:{item}}}};
 vm.runInNewContext(fs.readFileSync(path.join(web,'outlook-host.js'),'utf8'),c);
 const file={name:'Review.docx',base64:'UEsDBA=='};assert.match(await c.OnboardOutlook.attachDocument(item,file),/click Send in Outlook/);assert.equal(attached.length,1);
 item.subject='Read mode';await assert.rejects(c.OnboardOutlook.attachDocument(item,file),/compose window/);assert.equal(attached.length,1);
});

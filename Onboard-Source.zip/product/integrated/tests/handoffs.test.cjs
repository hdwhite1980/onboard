// UI contract tests only; no real account or communication is used.
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const code=fs.readFileSync(path.join(__dirname,'../web/handoffs.js'),'utf8');
function setup(app){
 const nodes=new Map(),node=()=>({value:'',checked:false,disabled:false,hidden:false,children:[],handlers:{},addEventListener(n,f){this.handlers[n]=f;},replaceChildren(){this.children=[];},append(x){this.children.push(x);}}),get=id=>{if(!nodes.has(id))nodes.set(id,node());return nodes.get(id);};
 const calls=[],opened=[],row={id:'fixture-transfer',body:'Fixture draft',subject:'Fixture subject',recipient:'person@example.invalid',category:'summary',source:app==='outlook'?'teams':'outlook'};
 const c={application:app,document:{getElementById:get,createElement:node},crypto:{randomUUID:()=> 'fixture-uuid-123456'},verifyHostAccount:async()=>{},api:async(route,body)=>{calls.push({route,body});if(route==='handoff-list')return {drafts:[row]};return {message:'Queued',removed:true};},OnboardOutlook:{newDraft:async(...args)=>{opened.push(args);return 'Opened';}},OnboardTeams:{useDraft:async(...args)=>{opened.push(args);return 'Opened';}}};
 vm.createContext(c);vm.runInContext(code,c);get('answer').value='Fixture draft';get('task').value='summarize';return {c,get,calls,opened,row};
}
for(const app of ['outlook','teams']){
 test(app+' transfers only a reviewed generated draft to the other app',async()=>{
  const f=setup(app);f.c.OnboardHandoffs.result({status:'source_excerpts'},'job');await f.get('handoff-create').handlers.click();assert.equal(f.calls.length,0);
  f.c.OnboardHandoffs.result({status:'generated'},'job');assert.equal(f.get('handoff-category').value,'summary');await f.get('handoff-create').handlers.click();assert.equal(f.calls.length,0);
  f.get('handoff-share').checked=true;await f.get('handoff-create').handlers.click();assert.equal(f.calls[0].route,'handoff-create');assert.equal(f.calls[0].body.target,app==='outlook'?'teams':'outlook');assert.equal(f.opened.length,0);
 });
 test(app+' requires destination review and claims before opening native composer',async()=>{
  const f=setup(app);await f.c.OnboardHandoffs.refresh();f.get('handoff-list').value='0';f.get('handoff-list').handlers.change();await f.get('handoff-open').handlers.click();assert.equal(f.opened.length,0);
  f.get('handoff-review').checked=true;await f.get('handoff-open').handlers.click();assert.equal(f.calls.at(-1).route,'handoff-remove');assert.equal(f.opened.length,1);assert.equal(f.opened[0][0],'person@example.invalid');await f.get('handoff-open').handlers.click();assert.equal(f.opened.length,1);
 });
 test(app+' does not open a draft already claimed by another panel',async()=>{
  const f=setup(app);await f.c.OnboardHandoffs.refresh();f.get('handoff-list').value='0';f.get('handoff-list').handlers.change();f.get('handoff-review').checked=true;f.c.api=async()=>{throw Error('No longer available');};await f.get('handoff-open').handlers.click();assert.equal(f.opened.length,0);
 });
 test(app+' edits clear consent and disconnect clears received draft state',async()=>{
  const f=setup(app);await f.c.OnboardHandoffs.refresh();f.get('handoff-list').value='0';f.get('handoff-list').handlers.change();f.get('handoff-review').checked=true;f.get('handoff-incoming-body').handlers.input();assert.equal(f.get('handoff-review').checked,false);f.c.OnboardHandoffs.disconnect();assert.equal(f.get('handoff-preview').hidden,true);assert.equal(f.get('handoff-incoming-body').value,'');assert.equal(f.get('handoff-open').disabled,true);
 });
}

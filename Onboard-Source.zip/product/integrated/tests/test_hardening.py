"""Failure-path hardening checks; no account, key, or real application mutation."""
import base64,importlib.util,json,pathlib,subprocess,sys,tempfile,time,unittest
from types import SimpleNamespace
from unittest.mock import Mock,patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from connectors import Failure
from helper_broker import Helpers
from managed_policy import ManagedPolicy
from audit import Audit
from documents import create_docx
from run_retention import cleanup_previous_boot
from tls_health import certificate_health
from test_hybrid_documents import host

class HelperTests(unittest.TestCase):
    def setUp(self):
        self.h=SimpleNamespace(config={},stopping=False,app=pathlib.Path('/fixture'),graph=Mock(),check_policy=Mock())
        self.h.graph.identity.return_value=('tenant','user',1);self.b=Helpers(self.h)
    def run_fixture(self,change=None):
        def run(command,**kw):
            self.assertEqual(command,['/fixture','--vault'])
            token=json.loads(kw['input'])['ticket']
            if change:change(token)
            value=self.b.claim(token,'vault');self.assertEqual(value,{'action':'read','key':'provider-key'})
            with self.assertRaises(Failure):self.b.claim(token,'vault')
            return subprocess.CompletedProcess(command,0,'fixture-output')
        with patch('helper_broker.subprocess.run',side_effect=run):return self.b.invoke('vault',{'action':'read','key':'provider-key'})
    def test_authorized_operation_and_one_use(self):self.assertEqual(self.run_fixture(),'fixture-output');self.assertEqual(self.b.pending,{})
    def test_unknown_ticket_is_rejected(self):
        with self.assertRaises(Failure):self.b.claim('unissued','vault')
    def test_expiry_settings_and_account_changes_reject_before_release(self):
        for change in (lambda t:self.b.pending[t].update(expires=0),lambda t:setattr(self.h,'config',{}),lambda t:setattr(self.h.graph.identity,'return_value',('other','user',1))):
            with self.subTest(change=change),self.assertRaises(Failure):self.run_fixture(change)
            self.assertEqual(self.b.pending,{})
    def test_wrong_helper_cannot_claim_ticket(self):
        def wrong(token):
            with self.assertRaises(Failure):self.b.claim(token,'workspace')
        with self.assertRaises(Failure):self.run_fixture(wrong)
    def test_helper_timeout_cleans_ticket(self):
        with patch('helper_broker.subprocess.run',side_effect=subprocess.TimeoutExpired('fixture',1)):
            with self.assertRaises(subprocess.TimeoutExpired):self.b.invoke('vault',{})
        self.assertEqual(self.b.pending,{})

class InstallationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);root=pathlib.Path(self.tmp.name)
        spec=importlib.util.spec_from_file_location('review_install',P/'tools/install.py');self.module=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.module)
        self.source=root/'source.app';self.dest=root/'Applications/Onboard AI.app'
        for directory,value in ((self.source,'new'),(self.dest,'old')):
            for name in ('Contents/MacOS/OnboardAI','Contents/Resources/policy-core'):
                f=directory/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(value)
    def contents(self):return (self.dest/'Contents/MacOS/OnboardAI').read_text()
    def test_failed_candidate_preserves_existing_app(self):
        with patch.object(self.module,'verify',side_effect=[None,RuntimeError('signature')]):
            with self.assertRaises(RuntimeError):self.module.install(self.source,self.dest)
        self.assertEqual(self.contents(),'old');self.assertEqual(list(self.dest.parent.glob('.onboard-install-*')),[])
    def test_failed_final_verification_restores_existing_app(self):
        with patch.object(self.module,'verify',side_effect=[None,None,RuntimeError('signature')]):
            with self.assertRaises(RuntimeError):self.module.install(self.source,self.dest)
        self.assertEqual(self.contents(),'old')
    def test_success_preserves_backup(self):
        with patch.object(self.module,'verify'):result=self.module.install(self.source,self.dest)
        self.assertEqual(self.contents(),'new');self.assertEqual((pathlib.Path(result['backup'])/'Contents/MacOS/OnboardAI').read_text(),'old')

class PolicyAuditTests(unittest.TestCase):
    def test_certificate_expiry_and_parse_errors_are_explicit(self):
        with tempfile.TemporaryDirectory() as t:
            path=pathlib.Path(t)/'cert';path.write_text('fixture')
            with patch('tls_health.subprocess.run',return_value=SimpleNamespace(stdout='notAfter=Jan  1 00:00:00 2020 GMT')):
                self.assertEqual(certificate_health(path)['state'],'expired')
            with patch('tls_health.subprocess.run',return_value=SimpleNamespace(stdout='bad')):
                self.assertEqual(certificate_health(path)['state'],'unknown')
    def test_required_policy_does_not_fall_back_to_development(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaisesRegex(Failure,'requires'):ManagedPolicy(pathlib.Path(t)/'missing',required=True).check({})
            ManagedPolicy(pathlib.Path(t)/'missing').check({})
    def test_managed_browser_and_computer_controls(self):
        policy={'allow_cloud':False,'allow_hybrid':True,'allow_saved_work':True,'allowed_tenants':[],'allowed_provider_origins':[],'public_label_mappings':[]}
        m=ManagedPolicy(required=True)
        with patch.object(m,'read',return_value=policy):
            with self.assertRaises(Failure):m.check({'automation':{'enabled':True}})
            with self.assertRaises(Failure):m.check({'agent':{'domains':['unapproved.example']}})
            policy.update(allow_computer_control=True,allowed_browser_domains=['approved.example'],central_audit={'configured':True})
            m.check({'automation':{'enabled':True},'agent':{'domains':['approved.example']}})
    def test_audit_rejects_content_and_symlinks(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t);a=Audit(root)
            with self.assertRaises(Failure):a.emit('request',prompt='content')
            with self.assertRaises(Failure):a.emit('request',result='content with spaces')
            a.emit('request',result='denied');self.assertEqual(json.loads(a.path.read_text())['result'],'denied')
            victim=root/'keep';victim.write_text('unchanged');a.path.unlink();a.path.symlink_to(victim)
            with self.assertRaises(Failure):a.emit('request',result='denied')
            self.assertEqual(victim.read_text(),'unchanged')

class WordFreshnessTests(unittest.TestCase):
    def test_insertion_requires_fresh_document_and_rejects_changed_metadata(self):
        with tempfile.TemporaryDirectory() as t:
            h=host(t);raw=create_docx('Fixture','Original');encoded=base64.b64encode(raw).decode()
            snap=h.documents.inspect('word',{'file':encoded,'inspect_confirmed':True})['snapshot']
            with self.assertRaises(Failure):h.documents.authorize('word',{'snapshot':snap})
            self.assertTrue(h.documents.authorize('word',{'snapshot':snap,'file':encoded})['permitted'])
            changed=base64.b64encode(create_docx('Fixture','Different')).decode()
            with self.assertRaisesRegex(Failure,'changed'):h.documents.authorize('word',{'snapshot':snap,'file':changed})
            h.documents.snapshots[snap]['sensitivity']['origin']='different metadata'
            with self.assertRaisesRegex(Failure,'changed'):h.documents.authorize('word',{'snapshot':snap,'file':encoded})

class RetentionTests(unittest.TestCase):
    def test_cleanup_only_removes_private_marked_prior_boot_runs(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t);root.chmod(0o700)
            for name,boot in (('request-old','100:0'),('request-live','200:0'),('request-unknown',None)):
                d=root/name;d.mkdir(mode=0o700);(d/'input.json').write_text('fixture')
                if boot:
                    marker=d/'run-owner.json';marker.write_text(json.dumps({'schema':1,'boot':boot}));marker.chmod(0o600)
            outside=root/'outside';outside.mkdir();(root/'request-link').symlink_to(outside)
            result=cleanup_previous_boot(root,'200:0')
            self.assertEqual(result,{'removed':1,'preserved':3});self.assertTrue(outside.exists());self.assertFalse((root/'request-old').exists())

if __name__=='__main__':unittest.main()

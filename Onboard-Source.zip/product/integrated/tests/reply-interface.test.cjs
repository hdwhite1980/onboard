// UI control fixtures only; no mailbox access or real model output.
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const code=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');
function app(){
 const nodes=new Map();const create=()=>({value:'',checked:false,disabled:false,handlers:{},children:[],textContent:'',append(...children){this.children.push(...children);},replaceChildren(){this.children=[];},addEventListener(n,f){this.handlers[n]=f;}});
 const get=id=>{if(!nodes.has(id))nodes.set(id,create());return nodes.get(id);};
 const sandbox={document:{body:{dataset:{application:'outlook'}},getElementById:get,createElement:create},window:{addEventListener(){}},OnboardOutlook:{initialize:async()=>({userProfile:{emailAddress:'fixture@example.invalid'}})}};
 vm.createContext(sandbox);vm.runInContext(code,sandbox);return {sandbox,get};
}
test('reply and edit selection clear a previous broad search choice',()=>{
 const f=app();for(const task of ['reply','rewrite','shorten','tone']){f.get('search-mail').checked=true;f.get('task').value=task;f.get('task').handlers.change();assert.equal(f.get('search-mail').checked,false);}
 const html=fs.readFileSync(path.join(__dirname,'../web/outlook.html'),'utf8');assert.doesNotMatch(html,/id="search-mail" checked/);
});
test('source titles are displayed instead of raw mailbox identifiers',()=>{
 const f=app();const id='mail:TEST_ONLY_OPAQUE_IDENTIFIER';f.sandbox.render({status:'generated',sources:[{id,title:'Selected subject',text:'Exact quotation.'}],claims:[{source_id:id,quote:'Exact quotation.'}],answer:'Proposed reply.'});
 assert.match(f.get('answer').value,/Source 1 · Selected subject/);assert.doesNotMatch(f.get('answer').value,/OPAQUE_IDENTIFIER/);
 assert.equal(f.get('sources').children[0].children[0].textContent,'Source 1 · Selected subject');
});

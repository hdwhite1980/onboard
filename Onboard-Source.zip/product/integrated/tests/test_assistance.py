"""Policy and failure-path tests; never substitutes a fake successful AI or search response."""
import io,json,pathlib,socket,ssl,sys,tempfile,threading,unittest,urllib.error
from unittest.mock import patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from host import Host
from connectors import Failure
from network import NetworkFailure,failure_for,proxy_configuration,validate_proxy
from online import intent,location_from,weather
from assistant import answer,run_model
from local_engine import LocalUnavailable

class Assistance(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.h=Host(P/'build/Onboard AI.app/Contents/Resources',self.tmp.name,'/usr/bin/true')
 def job(self,**fields):return {'owner':'native','request':dict(task='ask',route='auto',prompt='What is the weather in Washington, DC?',public_attested=True,web_mode='auto',allow_cloud=True,**fields),'cancel':threading.Event()}
 def test_intent_and_city(self):
  self.assertEqual(intent('What is the weather in Washington, DC?'),'weather');self.assertEqual(location_from('Weather in Washington, DC tomorrow?'),'Washington, DC')
  self.assertEqual(intent('Search for keyboard comparisons'),'search');self.assertIsNone(intent('Write a thank-you note'))
  self.assertIsNone(intent('latest news','off'))
 def test_general_fact_finding_uses_web_across_topics(self):
  for question in ('Who founded Microsoft?','What is the capital of France?','Find a laptop under 1000 dollars','How do I replace a faucet?','Tell me about hiking trails in Virginia','Why do leaves change color?','Best restaurants in Boston','Explain how weather forecasting works'):
   self.assertEqual(intent(question),'search',question)
  self.assertEqual(intent('Explain how weather forecasting works','always'),'search')
  for question in ('Rewrite this note: the current plan is ready','Translate the following text into French','Write a Python function to sort names','Write an email thanking the team','Draft a letter about rain damage','What is 2+2?','Hello'):
   self.assertIsNone(intent(question),question)
 def test_missing_weather_city_never_uses_network(self):
  with patch('online.request',side_effect=AssertionError('unexpected network')):
   self.assertEqual(weather('What is the weather?',{},threading.Event())['status'],'needs_location')
 def test_no_web_dispatch_without_public_confirmation(self):
  j=self.job();j['request']['public_attested']=False;self.h.config['public_local']=True
  with patch('assistant.weather',side_effect=AssertionError('unexpected network')):
   self.assertEqual(answer(self.h,j)['status'],'policy_blocked')
 def test_web_disabled_fails_before_dispatch(self):
  self.h.config['public_local']=True;self.h.config['internet']['enabled']=False
  with patch('assistant.weather',side_effect=AssertionError('unexpected network')):
   self.assertEqual(answer(self.h,self.job())['status'],'policy_blocked')
 def test_proxy_block_never_falls_back_to_cloud(self):
  self.h.config['public_local']=True
  with patch('assistant.weather',side_effect=NetworkFailure('PROXY_AUTH_REQUIRED','Proxy requires sign-in')),patch('assistant.cloud',side_effect=AssertionError('must not evade block')):
   r=answer(self.h,self.job());self.assertEqual(r['network_code'],'PROXY_AUTH_REQUIRED');self.assertEqual(r['answer'],'')
 def test_cloud_permission_requires_all_controls(self):
  for provider,automatic,enabled,public in ((False,True,True,True),(True,False,True,True),(True,True,False,True),(True,True,True,False)):
   self.assertFalse(self.h.rust('policy',task='ask',route='cloud',provider_enabled=provider,automatic_cloud=automatic,enabled=enabled,public_attested=public)['allowed'])
  self.assertTrue(self.h.rust('policy',task='ask',route='cloud',provider_enabled=True,automatic_cloud=True,enabled=True,public_attested=True)['allowed'])
 def test_cloud_not_called_for_integrity_failure(self):
  with patch.object(self.h,'local_status',return_value={'ready':True}),patch('assistant.generate',side_effect=Failure('Integrity failure')),patch('assistant.cloud',side_effect=AssertionError('must not escalate')):
   with self.assertRaises(Failure):run_model(self.h,self.job(),[],{})
 def test_cloud_not_called_without_provider_or_question_permission(self):
  for allow in (False,True):
   j=self.job();j['request']['allow_cloud']=allow;result={}
   with patch.object(self.h,'local_status',return_value={'ready':True}),patch('assistant.generate',side_effect=LocalUnavailable('CONTEXT_LIMIT','Local context limit')),patch('assistant.cloud',side_effect=AssertionError('not configured')):
    self.assertIsNone(run_model(self.h,j,[],result));self.assertEqual(result['status'],'local_limit')
 def test_permitted_cloud_dispatch_preserves_proxy_error(self):
  self.h.config.update(public_cloud=True,cloud_fallback=True,provider={'daily_requests':2,'name':'Configured provider','type':'compatible-chat','model':'configured'})
  with patch.object(self.h,'local_status',return_value={'ready':True}),patch.object(self.h,'vault',return_value='test-only-no-network'),patch('assistant.generate',side_effect=LocalUnavailable('CONTEXT_LIMIT','Local context limit')),patch('assistant.cloud',side_effect=NetworkFailure('PROXY_AUTH_REQUIRED','Proxy denied')) as dispatch:
   with self.assertRaises(NetworkFailure):run_model(self.h,self.job(),[{'role':'user','content':'public test input'}],{})
   self.assertEqual(dispatch.call_count,1)
 def test_407_and_unconfirmed_403_are_distinct(self):
  self.assertEqual(failure_for(urllib.error.HTTPError('https://service.invalid',407,'',{},io.BytesIO())).code,'PROXY_AUTH_REQUIRED')
  x=failure_for(urllib.error.HTTPError('https://service.invalid',403,'',{},io.BytesIO()));self.assertEqual(x.code,'ACCESS_DENIED');self.assertIn('cannot be confirmed',str(x))
  self.assertEqual(failure_for(urllib.error.URLError(OSError('Tunnel connection failed: 407 Proxy Authentication Required'))).code,'PROXY_AUTH_REQUIRED')
 def test_tls_dns_timeout_codes(self):
  for error,code in ((ssl.SSLCertVerificationError('bad'), 'TLS_CERTIFICATE_REJECTED'),(socket.gaierror('dns'),'DNS_FAILURE'),(TimeoutError(),'NETWORK_TIMEOUT')):self.assertEqual(failure_for(urllib.error.URLError(error)).code,code)
 def test_proxy_credentials_not_saved_in_urls(self):
  with self.assertRaises(Failure):validate_proxy('http://person:secret@proxy.example:8080')
 def test_pac_does_not_silently_connect_direct(self):
  import subprocess
  with patch('network.subprocess.run',return_value=subprocess.CompletedProcess([],0,'ProxyAutoConfigEnable : 1\n','')):
   with self.assertRaises(NetworkFailure) as caught:proxy_configuration()
   self.assertEqual(caught.exception.code,'PROXY_AUTO_CONFIG_UNSUPPORTED')
 def test_addin_cannot_opt_into_native_auto_egress(self):
  with self.assertRaises(Failure):self.h.submit('browser',{'task':'ask','route':'auto','prompt':'search','allow_cloud':True})
if __name__=='__main__':unittest.main(verbosity=2)

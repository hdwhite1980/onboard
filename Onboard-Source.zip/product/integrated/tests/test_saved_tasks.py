"""Isolated task/controller tests; no user data, UI actions or external requests."""
import copy,json,pathlib,sys,tempfile,threading,time,unittest
from unittest.mock import Mock,patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from connectors import Failure
from agent import Runner
from task_store import Tasks,plan,remaining_plan,resolve
from automation import Controller,validate
from test_hybrid_documents import host,job

def fixture_plan():
    return {'title':'Fixture workflow','steps':[
        {'tool':'file_create','arguments':{'root':0,'path':'output.txt','title':'Fixture','text':'Public fixture'},'verify':{'manual':True}},
        {'tool':'file_read','arguments':{'root':0,'path':'output.txt'},'verify':{'path':'text','equals':'Public fixture'}}]}

class SavedTasksTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.h=host(self.tmp.name);self.h.graph.config={};self.tasks=Tasks(self.h)
        # Persistence logic uses this reversible fixture codec. Native AES-GCM is tested separately.
        self.codec=patch('task_store.Workspace.crypt',side_effect=lambda op,context,data: context.encode()+b':'+data if op=='seal' else data.split(b':',1)[1] if data.startswith(context.encode()+b':') else (_ for _ in ()).throw(ValueError('binding')))
        self.codec.start();self.review=patch.object(Runner,'review');self.reviews=self.review.start()
    def tearDown(self):self.review.stop();self.codec.stop();self.tmp.cleanup()
    def create(self,p=None):return self.tasks.admin('task_create',{'plan':p or fixture_plan(),'reviewed':True,'public_attested':True})['id']
    def run_task(self,ident):return self.tasks.process(job(self.h,saved_task=ident))
    def test_offline_file_workflow_checkpoint_and_no_replay(self):
        ident=self.create();self.h.graph.identity.side_effect=Failure('Offline')
        with patch.object(Runner,'model',side_effect=AssertionError('No provider allowed')):
            self.run_task(ident);self.assertEqual(self.tasks.load(ident)['state'],'complete')
            with patch.object(Runner,'execute') as execute:self.run_task(ident);execute.assert_not_called()
        self.assertEqual((self.h.state/'output.txt').read_text(),'Public fixture')
        self.assertEqual(self.tasks.path(ident).stat().st_mode&0o777,0o600)
    def test_interrupted_step_requires_resolution_and_preserves_prior_results(self):
        ident=self.create();execute=Runner.execute;count=[]
        def interrupted(r,tool,args):
            count.append(tool)
            if tool=='file_read':raise Failure('Interrupted')
            return execute(r,tool,args)
        with patch.object(Runner,'execute',interrupted):
            with self.assertRaises(Failure):self.run_task(ident)
        row=self.tasks.load(ident);self.assertEqual(row['next'],1);self.assertTrue(row['uncertain'])
        with patch.object(Runner,'execute') as run:
            with self.assertRaises(Failure):self.run_task(ident)
            run.assert_not_called()
        self.tasks.admin('task_resolve',{'id':ident,'choice':'retry','reviewed':True})
        with patch.object(Runner,'execute',autospec=True,side_effect=execute) as run:
            self.run_task(ident);self.assertEqual(run.call_count,1);self.assertEqual(run.call_args.args[1],'file_read')
    def test_crash_intent_recovered_without_replay(self):
        ident=self.create();row=self.tasks.load(ident);row.update(state='running',uncertain=True);self.tasks.write(row)
        recovered=Tasks(self.h).load(ident);self.assertEqual(recovered['state'],'needs_review');self.assertTrue(recovered['uncertain'])
    def test_expired_task_is_removed_without_replaying_actions(self):
        ident=self.create();row=self.tasks.load(ident);row['created']=time.time()-8*86400;self.tasks.write(row)
        with patch.object(Runner,'execute') as execute:
            self.assertEqual(self.tasks.admin('task_list',{})['tasks'],[]);execute.assert_not_called()
        self.assertFalse(self.tasks.path(ident).exists())
    def test_result_mismatch_keeps_step_uncertain(self):
        p=fixture_plan();p['steps'][1]['verify']['equals']='Different';ident=self.create(p)
        with self.assertRaises(Failure):self.run_task(ident)
        self.assertEqual(self.tasks.load(ident)['next'],1)
        self.tasks.admin('task_resolve',{'id':ident,'choice':'completed','reviewed':True})
        self.assertEqual(self.tasks.load(ident)['state'],'complete')
    def test_declining_initial_review_runs_nothing(self):
        ident=self.create();self.reviews.side_effect=Failure('Declined')
        with patch.object(Runner,'execute') as execute:
            with self.assertRaises(Failure):self.run_task(ident)
            execute.assert_not_called()
        self.assertFalse(self.tasks.load(ident)['uncertain'])
    def test_cloud_planning_decline_keeps_instructions_local(self):
        self.reviews.side_effect=Failure('Declined')
        with patch.object(Runner,'model') as model:
            with self.assertRaises(Failure):self.tasks.process(job(self.h,task_planning=True))
            model.assert_not_called()
        self.assertEqual(self.tasks.admin('task_list',{})['tasks'],[])
    def test_policy_and_account_changes_stop_before_effect(self):
        p={'title':'Mail','steps':[{'tool':'mail_search','arguments':{'query':'fixture'},'verify':{'manual':True}}]};ident=self.create(p)
        self.h.graph.identity.return_value=('different','user',1)
        with patch.object(Runner,'execute') as execute:
            with self.assertRaises(Failure):self.run_task(ident)
            execute.assert_not_called()
        self.h.config['agent']['enabled']=False
        with self.assertRaises(Failure):self.run_task(ident)
    def test_record_binding_and_permissions(self):
        first=self.create();second=self.create();self.tasks.path(second).write_bytes(self.tasks.path(first).read_bytes())
        with self.assertRaises(Failure):self.tasks.load(second)
        self.tasks.path(first).chmod(0o644)
        with self.assertRaises(Failure):self.tasks.load(first)
    def test_other_account_cannot_read_task_title_or_saved_evidence(self):
        p={'title':'Account-bound fixture','steps':[{'tool':'mail_search','arguments':{'query':'fixture'},'verify':{'manual':True}}]};ident=self.create(p)
        self.h.graph.identity.return_value=('other','user',1)
        self.assertEqual(self.tasks.admin('task_list',{})['tasks'],[])
        with self.assertRaises(Failure):self.tasks.admin('task_get',{'id':ident})
    def test_repair_rebases_references_without_repeating_completed_steps(self):
        p=fixture_plan();replacement=copy.deepcopy(p);replacement['steps'][1]['arguments']['path']='@step:0.path'
        updated=remaining_plan(p,replacement,1)
        self.assertEqual(updated['steps'][2]['arguments']['path'],'@step:1.path')
        self.assertEqual(resolve('@step:1.path',[{}, {'path':'new.txt'}]),'new.txt')
    def test_schema_rejects_authority_and_fake_verification(self):
        for mutation in ('shell','extra','forward','delivery'):
            p=fixture_plan()
            if mutation=='shell':p['steps'][0]['tool']='shell'
            if mutation=='extra':p['steps'][0]['arguments']['approved']=True
            if mutation=='forward':p['steps'][0]['arguments']['text']='@step:1.text'
            if mutation=='delivery':p['steps'][0]={'tool':'computer_action','arguments':{'snapshot':'$last','action':'key','details':'{"key":"Return"}'},'verify':{'path':'performed','equals':True}}
            with self.assertRaises(Failure):plan(p)

class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.h=host(self.tmp.name);self.h.config['automation']={'enabled':True,'apps':['com.example.Editor']};self.h.config['internet']['browser_id']='com.apple.Safari'
        self.c=Controller(self.h);self.r=Runner(self.h,job(self.h));self.r.review=Mock()
        self.snap={'app':'com.example.Editor','window':'Fixture','fingerprint':'abc','nodes':[{'id':'0','protected':False}],'urls':[]}
        self.c.native=Mock(return_value=self.snap)
    def tearDown(self):self.tmp.cleanup()
    def action(self,token,action='press',details=None):return self.c.execute(self.r,'computer_action',{'snapshot':token,'action':action,'details':json.dumps(details or {'target':'0'})})
    def test_ticket_single_use_cancel_and_expiry(self):
        for token,expires in [('valid',time.monotonic()+10),('expired',time.monotonic()-1)]:self.c.tickets[token]=({'operation':'inspect'},self.r,expires)
        self.assertEqual(self.c.claim('valid')['operation'],'inspect')
        for token in ('valid','expired'):
            with self.assertRaises(Failure):self.c.claim(token)
        self.c.tickets['cancelled']=({},self.r,time.monotonic()+10);self.r.job['cancel'].set()
        with self.assertRaises(Failure):self.c.claim('cancelled')
    def test_allowlist_browser_bypass_and_permission_toggle(self):
        for app in ('com.apple.Terminal','com.apple.Safari','com.example.Unknown'):
            with self.assertRaises(Failure):self.c.execute(self.r,'desktop_inspect',{'app':app})
        self.c.native.assert_not_called();self.h.config['automation']['enabled']=False
        with self.assertRaises(Failure):self.c.execute(self.r,'desktop_inspect',{'app':'com.example.Editor'})
    def test_decline_inspection_reads_no_ui(self):
        self.r.review.side_effect=Failure('Declined')
        with self.assertRaises(Failure):self.c.execute(self.r,'desktop_inspect',{'app':'com.example.Editor'})
        self.c.native.assert_not_called()
    def test_action_consumes_observation_once_and_requires_review(self):
        token=self.c.remember(self.snap,self.r,False)['snapshot'];self.c.native.return_value={'performed':True,'verified':False,'after':self.snap}
        result=self.action(token);self.assertFalse(result['verified']);self.r.review.assert_called_once()
        with self.assertRaises(Failure):self.action(token)
        self.assertEqual(self.c.native.call_count,1)
    def test_expired_or_foreign_observation_never_acts(self):
        for key,value in [('time',time.monotonic()-181),('job','different')]:
            token=self.c.remember(self.snap,self.r,False)['snapshot'];self.c.snapshots[token][key]=value
            with self.assertRaises(Failure):self.action(token)
        self.c.native.assert_not_called()
    def test_protected_input_and_invalid_details_never_act(self):
        for action,details in [('type',{'target':'0','text':'x\n'}),('point',{'x':float('nan'),'y':0}),('key',{'key':'Command+Q'}),('scroll',{'direction':'sideways'}),('press',{'target':'0','extra':True})]:
            token=self.c.remember(self.snap,self.r,False)['snapshot']
            with self.assertRaises(Failure):self.action(token,action,details)
        self.snap['nodes'][0]['protected']=True;token=self.c.remember(self.snap,self.r,False)['snapshot']
        with self.assertRaises(Failure):self.action(token)
        self.c.native.assert_not_called()
    def test_browser_url_required_and_post_navigation_denied(self):
        with self.assertRaises(Failure):self.c.execute(self.r,'browser_inspect',{})
        self.snap['urls']=['https://example.com'];token=self.c.remember(self.snap,self.r,True)['snapshot']
        changed=dict(self.snap,urls=['https://unapproved.example.org']);self.c.native.return_value={'performed':True,'after':changed}
        with self.assertRaises(Failure):self.action(token)
        self.assertEqual(self.c.native.call_count,2) # initial inspection + reviewed input; no continued action
    def test_addin_cannot_use_controller(self):
        self.r.job['owner']='outlook'
        with self.assertRaises(Failure):self.c.execute(self.r,'desktop_inspect',{'app':'com.example.Editor'})
        self.c.native.assert_not_called()
    def test_saved_named_target_resolves_only_unique_observed_control(self):
        self.snap['nodes'][0]['title']='Save';token=self.c.remember(self.snap,self.r,False)['snapshot']
        self.c.native.return_value={'performed':True,'verified':False,'after':self.snap}
        self.action(token,details={'target':'name:Save'})
        self.assertEqual(self.c.native.call_args.args[0]['target'],'0')
        self.snap['nodes'].append({'id':'1','title':'Save'});token=self.c.remember(self.snap,self.r,False)['snapshot']
        with self.assertRaises(Failure):self.action(token,details={'target':'name:Save'})
        self.assertEqual(self.c.native.call_count,1)
    def test_open_only_allowlisted_app_after_review(self):
        self.c.native.return_value={'opened':'com.example.Editor'}
        result=self.c.execute(self.r,'desktop_open',{'app':'com.example.Editor'})
        self.assertEqual(result['opened'],'com.example.Editor');self.r.review.assert_called_once()
        self.assertEqual(self.c.native.call_args.args[0]['operation'],'open')

if __name__=='__main__':unittest.main()

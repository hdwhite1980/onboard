"""Provider-specific wire contracts. Fixtures never contact a provider."""
import json
import pathlib
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'service'))
from connectors import cloud


class CloudPayloadTests(unittest.TestCase):
    def payload(self, endpoint, model, provider_type='compatible-chat'):
        config = dict(type=provider_type, endpoint=endpoint, model=model,
                      max_output=512, max_input_chars=1000, timeout=10, daily_requests=10)
        with patch('connectors.http', return_value={'choices': [{'message': {'content': 'Fixture'}}]}) as request:
            cloud(config, 'test-only', [{'role': 'user', 'content': 'Public fixture'}])
        return json.loads(request.call_args.args[2])

    def test_gpt55_uses_completion_budget_without_legacy_sampling(self):
        for model in ('gpt-5.5', 'gpt-5.5-2026-04-23'):
            for endpoint in ('https://api.openai.com/v1', 'https://api.openai.com/v1/chat/completions'):
                with self.subTest(model=model, endpoint=endpoint):
                    data = self.payload(endpoint, model)
                    self.assertEqual(data['max_completion_tokens'], 512)
                    self.assertEqual(data['reasoning_effort'], 'none')
                    self.assertNotIn('max_tokens', data)
                    self.assertNotIn('temperature', data)
                    self.assertEqual(data['model'], model)

    def test_other_providers_and_deployments_keep_their_wire_contract(self):
        for endpoint, model, kind in (
            ('https://approved.invalid/v1', 'gpt-5.5', 'compatible-chat'),
            ('https://api.openai.com.untrusted.invalid/v1', 'gpt-5.5', 'compatible-chat'),
            ('https://api.openai.com/v1', 'gpt-4o', 'compatible-chat'),
            ('https://approved.openai.azure.com', 'gpt-5.5', 'azure-chat'),
        ):
            with self.subTest(endpoint=endpoint, model=model, kind=kind):
                data = self.payload(endpoint, model, kind)
                self.assertEqual(data['max_tokens'], 512)
                self.assertEqual(data['temperature'], 0)
                self.assertNotIn('max_completion_tokens', data)
                self.assertNotIn('reasoning_effort', data)


if __name__ == '__main__':
    unittest.main()

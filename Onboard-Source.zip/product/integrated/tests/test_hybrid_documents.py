"""Offline unit/integration fixtures only. No live tenant, provider, or user content."""
import base64,io,json,os,pathlib,queue,sys,tempfile,threading,time,unittest,zipfile
from unittest.mock import Mock,patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from connectors import Failure,Graph
from host import Host
from agent import Runner,parse_plan,read_file,validate_settings,decide
from documents import create_docx,inspect_docx,check_labels,email_labels
from document_workflows import Documents
from connections import Connections
from network import public_addresses

TENANT='11111111-1111-1111-1111-111111111111';LABEL='22222222-2222-2222-2222-222222222222'
def host(tmp):
    h=Host.__new__(Host);h.lock=threading.RLock();h.stopping=False;h.state=pathlib.Path(tmp);h.resources=P
    tmp=str(pathlib.Path(tmp).resolve())
    h.config={'public_local':True,'public_cloud':True,'addin_cloud':True,'provider':{'name':'Fixture provider','daily_requests':100,'max_input_chars':60000},'agent':{'enabled':True,'roots':[tmp],'domains':['example.com'],'max_steps':5,'public_labels':[]},'internet':{'enabled':True}}
    h.graph=Mock();h.graph.identity.return_value=(TENANT,'user',1);h.graph.account={'mail':'fixture@example.com'}
    h.sessions={'word':{'app':'word','identity':h.graph.identity()},'outlook':{'app':'outlook','identity':h.graph.identity()}}
    h.jobs={};h.queue=queue.Queue();h.rust=Mock(return_value={'allowed':True});h.vault=Mock(return_value='test-credential');h.documents=Documents(h);return h
def job(h,owner='native',**request):
    j={'id':'j','owner':owner,'identity':None if owner=='native' else h.graph.identity(),'request':dict(prompt='Summarize fixture.txt',task='ask',public_attested=True,allow_cloud=True,**request),'cancel':threading.Event(),'state':'processing','result':None,'created':time.monotonic()};h.jobs['j']=j;return j

class HybridTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.h=host(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_plan_rejects_arbitrary_actions_and_extra_arguments(self):
        for value in ('not json','[]','{"tool":"shell","arguments":{"command":"echo hi"}}','{"tool":"file_read","arguments":{"root":0,"path":"a.txt","execute":true}}'):
            with self.assertRaises(Failure):parse_plan(value)
    def test_read_boundaries_and_symlinks(self):
        root=pathlib.Path(self.tmp.name).resolve();(root/'fixture.txt').write_text('Fixture text')
        self.assertEqual(read_file([str(root)],{'root':0,'path':'fixture.txt'})['text'],'Fixture text')
        (root/'link.txt').symlink_to(root/'fixture.txt')
        for path in ('../fixture.txt','/etc/passwd','.env','a/../../fixture.txt','link.txt'):
            with self.assertRaises((Failure,OSError)):read_file([str(root)],{'root':0,'path':path})
        with self.assertRaises(Failure):read_file([str(root)],{'root':True,'path':'fixture.txt'})
    def test_fifo_not_read(self):
        os.mkfifo(pathlib.Path(self.tmp.name)/'pipe.txt')
        with self.assertRaises(Failure):read_file([str(pathlib.Path(self.tmp.name).resolve())],{'root':0,'path':'pipe.txt'})
    def test_new_file_never_overwrites(self):
        path=pathlib.Path(self.tmp.name)/'notes.txt';path.write_text('Original')
        runner=Runner(self.h,job(self.h));runner.review=Mock()
        with self.assertRaises((Failure,OSError)):runner.execute('file_create',{'root':0,'path':'notes.txt','title':'Test','text':'Changed'})
        self.assertEqual(path.read_text(),'Original')
    def test_review_binding_decline_and_replay(self):
        j=job(self.h);j['approval']={'id':'a','title':'Review','preview':'fixture'}
        with self.assertRaises(Failure):decide(self.h,{'id':'j','approval_id':'other','approve':True})
        decide(self.h,{'id':'j','approval_id':'a','approve':False})
        with self.assertRaises(Failure):decide(self.h,{'id':'j','approval_id':'a','approve':True})
    def test_review_decline_stops_before_model_receives_file(self):
        (pathlib.Path(self.tmp.name)/'fixture.txt').write_text('Private fixture must not leave')
        runner=Runner(self.h,job(self.h));runner.review=Mock(side_effect=Failure('Declined'))
        with patch('agent.cloud',return_value=(json.dumps({'tool':'file_read','arguments':{'root':0,'path':'fixture.txt'}}),{})) as cloud:
            with self.assertRaises(Failure):runner.run()
            self.assertEqual(cloud.call_count,1)
            self.assertNotIn('Private fixture',str(cloud.call_args))
    def test_end_to_end_planner_read_review_create_finish(self):
        (pathlib.Path(self.tmp.name)/'fixture.txt').write_text('Approved fixture text')
        steps=[({'tool':'file_read','arguments':{'root':0,'path':'fixture.txt'}},{}),({'tool':'file_create','arguments':{'root':0,'path':'brief.docx','title':'Fixture briefing','text':'Approved fixture summary'}},{}),({'answer':'Created brief.docx from fixture.txt.'},{})]
        reviews=[];runner=Runner(self.h,job(self.h));runner.review=lambda title,payload:reviews.append((title,payload))
        with patch('agent.cloud',side_effect=[(json.dumps(p),u) for p,u in steps]) as cloud:
            result=runner.run()
        self.assertEqual(result['route'],'hybrid');self.assertEqual(cloud.call_count,3);self.assertEqual(len(reviews),3)
        self.assertIn('Approved fixture summary',inspect_docx((pathlib.Path(self.tmp.name)/'brief.docx').read_bytes())['text'])
        self.assertEqual(json.loads((self.h.state/'usage.json').read_text())[time.strftime('%Y-%m-%d')],3)
    def test_settings_change_cancels_review(self):
        runner=Runner(self.h,job(self.h));self.h.config=dict(self.h.config)
        with self.assertRaises(Failure):runner.active()
    def test_cancel_clears_pending_review(self):
        j=job(self.h);runner=Runner(self.h,j);errors=[]
        def run():
            try:runner.review('Review',{'fixture':'data'})
            except Failure as e:errors.append(str(e))
        thread=threading.Thread(target=run);thread.start()
        for _ in range(100):
            if j.get('approval'):break
            time.sleep(.005)
        j['cancel'].set();thread.join(2)
        self.assertFalse(thread.is_alive());self.assertNotIn('approval',j);self.assertTrue(errors)
    def test_cloud_policy_and_daily_limit(self):
        runner=Runner(self.h,job(self.h));self.h.rust.return_value={'allowed':False,'reason':'Disabled'}
        with patch('agent.cloud') as cloud:
            with self.assertRaises(Failure):runner.model([{'role':'user','content':'Fixture'}])
            cloud.assert_not_called()
        self.h.rust.return_value={'allowed':True};self.h.config['provider']['daily_requests']=1
        (self.h.state/'usage.json').write_text(json.dumps({time.strftime('%Y-%m-%d'):1}))
        with patch('agent.cloud') as cloud:
            with self.assertRaises(Failure):runner.model([{'role':'user','content':'Fixture'}])
            cloud.assert_not_called()
    def test_web_host_and_private_address_denied(self):
        runner=Runner(self.h,job(self.h))
        for url in ('http://example.com','https://example.com.evil.test','https://user@example.com','https://example.com:444','https://localhost'):
            with self.assertRaises(Failure):runner.url(url)
        with patch('network.socket.getaddrinfo',return_value=[(2,1,6,'',('127.0.0.1',443))]):
            with self.assertRaises(Failure):public_addresses('example.com')
    def test_settings_do_not_allow_entire_home(self):
        with self.assertRaises(Failure):validate_settings({'roots':[str(pathlib.Path.home())]})
        with self.assertRaises(Failure):validate_settings({'domains':['*.example.com']})
        with self.assertRaises(Failure):validate_settings({'max_steps':99})

class DocumentTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.h=host(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def labeled(self):
        raw=create_docx('Test','Fixture body');out=io.BytesIO()
        with zipfile.ZipFile(io.BytesIO(raw)) as src,zipfile.ZipFile(out,'w') as dst:
            for name in src.namelist():dst.writestr(name,src.read(name))
            props='<Properties>'+''.join('<property name="MSIP_Label_'+LABEL+'_'+key+'"><value>'+val+'</value></property>' for key,val in [('Enabled','true'),('SiteId',TENANT),('Name','Public-looking name')])+'</Properties>'
            dst.writestr('docProps/custom.xml',props)
        return out.getvalue()
    def test_docx_round_trip_and_xml_escaping(self):
        result=inspect_docx(create_docx('A & B','## Heading\n<text> & more'))
        self.assertIn('<text> & more',result['text']);self.assertEqual(result['sensitivity']['state'],'unlabeled')
    def test_label_name_never_authorizes_processing(self):
        value=inspect_docx(self.labeled())
        with self.assertRaises(Failure):check_labels([value],self.h.config)
        self.h.config['agent']['public_labels']=[TENANT+':'+LABEL];check_labels([value],self.h.config)
    def test_unavailable_label_blocked(self):
        with self.assertRaises(Failure):check_labels([{'sensitivity':{'state':'unavailable'}}],self.h.config)
    def test_mip_label_part_and_encryption_are_not_downgraded(self):
        from documents import label_part
        raw=('<clbl:labelList xmlns:clbl="http://schemas.microsoft.com/office/2020/mipLabelMetadata"><clbl:label id="{'+LABEL+'}" siteId="{'+TENANT+'}" enabled="1" removed="0" contentBits="8"/></clbl:labelList>').encode()
        info=label_part(raw);self.assertEqual(info['labels'][0]['id'],LABEL)
        self.h.config['agent']['public_labels']=[TENANT+':'+LABEL]
        with self.assertRaises(Failure):check_labels([{'sensitivity':info}],self.h.config)
    def test_document_chunking_keeps_aliases_and_stays_in_budget(self):
        self.h.config['provider']['max_input_chars']=3000
        runner=Runner(self.h,job(self.h,'word'));calls=[]
        def model(messages):
            self.assertLessEqual(sum(len(m['content']) for m in messages),3000);calls.append(messages);return 'Fixture evidence [S1].'
        runner.model=model
        answer=self.h.documents.cloud_document(runner,'Draft with source citations','Summarize',[{'id':'S1','title':'Fixture','text':'word '*1600}],[],lambda:None)
        self.assertGreater(len(calls),2);self.assertIn('[S1]',answer);self.assertIn('SOURCE S1',calls[0][1]['content'])
    def test_encrypted_or_invalid_document_is_not_unlabeled(self):
        with self.assertRaises(Failure):inspect_docx(b'Encrypted Office document')
    def test_xml_entity_and_duplicate_part_rejected(self):
        raw=io.BytesIO()
        with zipfile.ZipFile(raw,'w') as z:z.writestr('word/document.xml','<!DOCTYPE x [<!ENTITY e "test">]><x>&e;</x>')
        with self.assertRaises(Failure):inspect_docx(raw.getvalue())
    def test_email_msip_tenant_and_label(self):
        value=email_labels([{'name':'MSIP_Labels','value':'MSIP_Label_'+LABEL+'_Enabled=True;MSIP_Label_'+LABEL+'_SiteId='+TENANT+';'}])
        self.assertEqual(value['labels'][0]['tenant'],TENANT)
    def test_word_inspection_and_unknown_policy(self):
        result=self.h.documents.inspect('word',{'inspect_confirmed':True,'file':base64.b64encode(self.labeled()).decode()})
        self.assertFalse(result['permitted']);self.assertTrue(result['snapshot'])
        with self.assertRaises(Failure):self.h.documents.submit('outlook',{'mode':'summarize','public_attested':True,'snapshot':result['snapshot']})
    def test_word_connection_requires_native_approval(self):
        self.h.connections=Connections(self.h);self.h.new_session=Mock(return_value={'token':'fixture-token'})
        pending=self.h.connections.request({'application':'word'},'https://localhost:38473')
        self.assertEqual(self.h.connections.status(pending,'https://localhost:38473')['state'],'pending');self.h.new_session.assert_not_called()
        self.h.connections.decide({'id':pending['id'],'approve':True})
        self.assertEqual(self.h.connections.status(pending,'https://localhost:38473')['state'],'connected')
    def test_document_cloud_gate_and_account_binding(self):
        source={'kind':'selected','text':'Fixture body','title':'Fixture','sensitivity':{'state':'unlabeled','labels':[]}}
        j=job(self.h,'word',mode='thoughts',sources=[source]);self.h.config['addin_cloud']=True
        with patch('agent.cloud',return_value=('Constructive fixture feedback',{})):
            result=self.h.documents.process(j)
        self.assertEqual(result['draft_text'],'Constructive fixture feedback')
        j['state']='complete';j['result']=result
        exported=self.h.documents.export('word',{'job':'j','title':'Fixture feedback','text':result['answer'],'reviewed':True,'public_attested':True})
        self.assertEqual(self.h.documents.files('outlook',{'id':exported['id']})['sha256'],exported['sha256'])
        self.h.graph.identity.return_value=(TENANT,'other',2)
        with self.assertRaises(Failure):self.h.documents.files('outlook',{'id':exported['id']})
    def test_labeled_source_never_reaches_cloud(self):
        source={'kind':'selected','text':'Fixture restricted body','sensitivity':inspect_docx(self.labeled())['sensitivity']}
        with patch('agent.cloud') as cloud:
            with self.assertRaises(Failure):self.h.documents.process(job(self.h,'word',mode='summarize',sources=[source]))
            cloud.assert_not_called()
    def test_unreviewed_and_withheld_documents_cannot_export(self):
        j=job(self.h,'word');j['state']='complete';j['result']={'status':'source_excerpts'}
        with self.assertRaises(Failure):self.h.documents.export('word',{'job':'j','title':'test','text':'text','reviewed':True,'public_attested':True})
    def test_mail_collection_is_bounded_and_validates_continuation(self):
        graph=Graph();graph.config={'mail':True,'graph':'https://graph.microsoft.com'}
        graph.get=Mock(return_value={'value':[{'id':str(i),'internetMessageHeaders':[]} for i in range(50)],'@odata.nextLink':'https://graph.microsoft.com/v1.0/me/messages?$skip=50'})
        rows,note=graph.collect_mail('fixture project','search',threading.Event());self.assertEqual(len(rows),200);self.assertEqual(graph.get.call_count,4);self.assertIn('omitted',note)
        graph.get.return_value={'value':[],'@odata.nextLink':'https://evil.example/v1.0/me/messages'}
        with self.assertRaises(Failure):graph.collect_mail('fixture','search',threading.Event())

if __name__=='__main__':unittest.main()

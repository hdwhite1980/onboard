"""Production boundary regression tests; no customer account or live provider access."""
import hashlib,importlib.util,json,os,pathlib,queue,secrets,subprocess,sys,tempfile,threading,time,unittest
from types import SimpleNamespace
from unittest.mock import Mock,patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from connectors import Failure
from activity import Activity,CURRENT,publish
from audit import Audit
from automation import Controller
from managed_policy import ManagedPolicy
from documents import check_labels

def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
release=module('production_release_test',P/'tools/production_release.py')
installer=module('installer_test',P/'tools/install.py')
collector=module('collector_test',P/'operations/audit_collector.py')

class ActivityTests(unittest.TestCase):
 def test_logs_do_not_accept_payloads_and_are_bounded(self):
  with tempfile.TemporaryDirectory() as t:
   a=Activity(t);h=SimpleNamespace(lock=threading.Lock(),jobs={},queue=queue.Queue())
   token=CURRENT.set(lambda stage,code=None,pid=None:a.emit('secret-source-id',stage,code,pid))
   try:
    publish('private prompt');publish('failed','SECRET with whitespace')
    for i in range(250):publish('preflight')
    publish('failed','MEMORY_PRESSURE')
   finally:CURRENT.reset(token)
   value=a.snapshot(h);raw=json.dumps(value)
   self.assertEqual(len(value['events']),200);self.assertNotIn('secret-source-id',raw);self.assertNotIn('private prompt',raw);self.assertNotIn('SECRET with whitespace',raw);self.assertIn('Quit unneeded',raw)
 def test_diagnostic_only_projects_numeric_known_metrics(self):
  with tempfile.TemporaryDirectory() as t:
   pathlib.Path(t,'last-local-run.json').write_text(json.dumps({'prompt':'private','outputTokens':20,'code':'private','seconds':'private'}))
   value=Activity(t).snapshot(SimpleNamespace(lock=threading.Lock(),jobs={},queue=queue.Queue()))
   self.assertEqual(value['last_local_run'],{'outputTokens':20})

class CentralTests(unittest.TestCase):
 def row(self):return {'schema':1,'id':secrets.token_hex(16),'time':time.time(),'event':'request_accepted','reference':'abcdef'}
 def test_durable_idempotent_receipt_and_tampered_replay(self):
  with tempfile.TemporaryDirectory() as t:
   store=collector.Store(pathlib.Path(t).resolve());row=self.row();ack=store.append('device',row)
   self.assertEqual(ack['accepted'],hashlib.sha256(collector.canonical(row)).hexdigest());self.assertEqual(store.append('device',row),ack)
   with self.assertRaises(ValueError):store.append('device',dict(row,reference='changed'))
   self.assertEqual(store.db.execute('SELECT COUNT(*) FROM events').fetchone()[0],1);store.db.close()
   reopened=collector.Store(pathlib.Path(t).resolve());self.assertEqual(reopened.db.execute('SELECT COUNT(*) FROM events').fetchone()[0],1);reopened.db.close()
 def test_collector_rejects_content_fields(self):
  with self.assertRaises(ValueError):collector.validate(dict(self.row(),prompt='private'))
 def test_required_collector_failure_prevents_completion(self):
  with tempfile.TemporaryDirectory() as t:
   managed=Mock(required=True);managed.read.return_value={'central_audit':{'fixture':True}}
   with patch('central_audit.Collector.send',side_effect=Failure('Unavailable')):
    with self.assertRaises(Failure):Audit(t,managed).emit('request_accepted')
   self.assertFalse(pathlib.Path(t,'audit.jsonl').exists())
 def test_browser_cannot_act_with_only_post_navigation_checks(self):
  managed=Mock(required=True);managed.read.return_value={}
  c=Controller(SimpleNamespace(managed=managed))
  with self.assertRaises(Failure):c.browser_boundary()
  managed.read.return_value={'browser_network_enforced':True};c.browser_boundary()
 def test_labeled_output_cannot_silently_lose_protection(self):
  label={'tenant':'t','id':'l','enabled':True,'content_bits':'0'};source={'sensitivity':{'state':'labeled','labels':[label]}};config={'agent':{'public_labels':['t:l']}}
  check_labels([source],config)
  for operation in ('export','send'):
   with self.assertRaises(Failure):check_labels([source],config,operation)
  with self.assertRaises(Failure):check_labels([source],dict(config,_managed_public=True))

class ReleaseTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=pathlib.Path(self.temp.name).resolve();self.private=self.root/'key';self.public=self.root/'public.pem'
  subprocess.run(['/usr/bin/openssl','genrsa','-out',str(self.private),'2048'],check=True,capture_output=True)
  subprocess.run(['/usr/bin/openssl','rsa','-in',str(self.private),'-pubout','-out',str(self.public)],check=True,capture_output=True)
  (self.root/'Onboard-AI.zip').write_bytes(b'archive fixture')
  self.manifest={'schema':1,'archive':'Onboard-AI.zip','bytes':15,'sha256':release.digest(self.root/'Onboard-AI.zip'),'team':'ABCDEFGHIJ','bundle':'local.onboard.integrated.dev','build':13,'version':'0.7.3','created':int(time.time()),'expires':int(time.time())+3600,'notarization':'fixture'}
 def sign(self):
  (self.root/'release.json').write_bytes(release.canonical(self.manifest));release.run(['/usr/bin/openssl','dgst','-sha256','-sign',self.private,'-out',self.root/'release.sig',self.root/'release.json'])
 def test_signature_digest_rollback_and_expiry(self):
  self.sign();self.assertEqual(release.verify(self.root,self.public,'ABCDEFGHIJ',12)['build'],13)
  with self.assertRaises(ValueError):release.verify(self.root,self.public,'ABCDEFGHIJ',13)
  (self.root/'Onboard-AI.zip').write_bytes(b'tampered')
  with self.assertRaises(ValueError):release.verify(self.root,self.public,'ABCDEFGHIJ',12)
  self.manifest['expires']=1;self.sign()
  with self.assertRaises(ValueError):release.verify(self.root,self.public,'ABCDEFGHIJ',12)
 def test_forged_manifest_rejected(self):
  self.sign();self.manifest['build']=99;(self.root/'release.json').write_bytes(release.canonical(self.manifest))
  with self.assertRaises(subprocess.CalledProcessError):release.verify(self.root,self.public,'ABCDEFGHIJ',12)
 def test_crash_after_old_app_move_restores_old_app(self):
  dest=self.root/'Onboard AI.app';stage=self.root/'.onboard-install-fixture';stage.mkdir();backup=self.root/'Onboard AI.previous-fixture.app';backup.mkdir();(backup/'fixture').write_text('old')
  journal=self.root/'.onboard-install-journal.json';installer.write_journal(journal,{'destination':dest.name,'stage':stage.name,'backup':backup.name})
  with patch.object(installer,'verify'):installer.recover(dest,journal)
  self.assertEqual((dest/'fixture').read_text(),'old');self.assertFalse(journal.exists());self.assertFalse(stage.exists())
 def test_recovery_does_not_follow_journal_symlink(self):
  journal=self.root/'journal';journal.symlink_to(self.private)
  with self.assertRaises(RuntimeError):installer.recover(self.root/'Onboard AI.app',journal)

if __name__=='__main__':unittest.main()

class SealedRecoveryTests(unittest.TestCase):
 def test_live_owner_is_never_detached(self):
  import encrypted_run
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t)/'sealed-fixture';root.mkdir(mode=0o700);owner=root/'owner.json';owner.write_text(json.dumps({'schema':1,'pid':os.getpid(),'boot':'1:1'}));owner.chmod(0o600)
   with patch('run_retention.boot_id',return_value='1:1'),patch('encrypted_run.command') as command:
    with self.assertRaises(Failure):encrypted_run.recover_abandoned(t)
   command.assert_not_called();self.assertTrue(root.exists())
 def test_prior_boot_unmounted_image_is_cleaned(self):
  import encrypted_run,plistlib
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t)/'sealed-fixture';root.mkdir(mode=0o700);owner=root/'owner.json';owner.write_text(json.dumps({'schema':1,'pid':123,'boot':'1:1'}));owner.chmod(0o600)
   with patch('run_retention.boot_id',return_value='2:2'),patch('encrypted_run.command',return_value=plistlib.dumps({'images':[]})):
    self.assertEqual(encrypted_run.recover_abandoned(t),1)
   self.assertFalse(root.exists())
 def test_unknown_owner_is_preserved(self):
  import encrypted_run
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t)/'sealed-fixture';root.mkdir(mode=0o700)
   with patch('run_retention.boot_id',return_value='2:2'):
    with self.assertRaises(Failure):encrypted_run.recover_abandoned(t)
   self.assertTrue(root.exists())

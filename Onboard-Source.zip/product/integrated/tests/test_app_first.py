"""App-first boundary fixtures. No live Microsoft access or generated answers."""
import pathlib,sys,threading,unittest
from unittest.mock import Mock
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from connectors import Graph,Failure
from host import Host
class AppFirst(unittest.TestCase):
 def graph(self):
  g=Graph();g.config={'teams':True};g.get=Mock(return_value={'id':'m','body':{'content':'Please review this fixture.'},'from':{'user':{'displayName':'Fixture sender'}}});return g
 def test_specific_chat_message_fetch_does_not_expand_conversation(self):
  g=self.graph();rows,note=g.retrieve('chat_message','chat|m');g.get.assert_called_once_with('chats/chat/messages/m');self.assertEqual(len(rows),1);self.assertTrue(rows[0]['primary'])
 def test_channel_message_uses_specific_channel_path(self):
  g=self.graph();g.retrieve('channel_message','team|channel|m');g.get.assert_called_once_with('teams/team/channels/channel/messages/m')
 def test_picker_labels_are_bounded_and_deleted_messages_omitted(self):
  g=self.graph();g.get.return_value={'value':[{'id':'removed','deletedDateTime':'date'},{'id':'m','body':{'content':'x'*500},'from':{'user':{'displayName':'Fixture'}}}]}
  r=g.message_options('chat','chat');self.assertEqual(len(r['options']),1);self.assertLess(len(r['options'][0]['label']),200);self.assertEqual(r['options'][0]['selection'],{'kind':'chat_message','ref':'chat|m'})
 def test_picker_requires_teams_permission(self):
  g=self.graph();g.config={}
  with self.assertRaises(Failure):g.message_options('chat','chat')
  g.get.assert_not_called()
 def host(self):
  h=Host.__new__(Host);h.graph=Mock();h.graph.identity.return_value=('tenant','user',1);h.sessions={'s':{'app':'teams','identity':('tenant','user',1)}};return h
 def test_picker_account_change_during_lookup_withholds_results(self):
  h=self.host();h.graph.identity.side_effect=[('tenant','user',1),('tenant','other',2)]
  with self.assertRaisesRegex(Failure,'withheld'):h.source_options('s',{'kind':'chat','ref':'chat'})
 def test_picker_disconnect_during_lookup_withholds_results(self):
  h=self.host();h.graph.message_options.side_effect=lambda *args:h.sessions.clear()
  with self.assertRaisesRegex(Failure,'withheld'):h.source_options('s',{'kind':'chat','ref':'chat'})
 def test_outlook_cannot_use_teams_picker(self):
  h=self.host();h.sessions['s']['app']='outlook'
  with self.assertRaises(Failure):h.source_options('s',{'kind':'chat','ref':'chat'})
  h.graph.message_options.assert_not_called()
 def test_direct_outlook_input_preserves_no_reply_without_graph(self):
  h=self.host();h.sessions['s']['app']='outlook';h.config={'public_local':True};h.rust=Mock(return_value={'allowed':True})
  j={'id':'j','owner':'s','identity':('tenant','user',1),'cancel':threading.Event(),'request':{'task':'reply','sources':[{'kind':'selected','origin':'outlook-mail','title':'Notice','text':'Please do not reply to this email.'}],'public_attested':True}}
  result=h.process(j);self.assertEqual(result['status'],'no_reply_recommended');h.graph.retrieve.assert_not_called();h.graph.search_mail.assert_not_called()
 def test_multiple_direct_sources_have_distinct_evidence_ids(self):
  h=self.host();h.config={};h.rust=Mock(return_value={'allowed':False,'reason':'Fixture policy'})
  j={'id':'j','owner':'s','identity':('tenant','user',1),'cancel':threading.Event(),'request':{'task':'summarize','sources':[{'kind':'selected','text':'First'},{'kind':'selected','text':'Second'}]}}
  result=h.process(j);self.assertEqual(len(result['sources']),2);self.assertNotEqual(result['sources'][0]['id'],result['sources'][1]['id'])
if __name__=='__main__':unittest.main()

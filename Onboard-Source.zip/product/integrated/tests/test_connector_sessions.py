"""Connection lifetime and shared routing controls, without live accounts or model output."""
import collections,json,pathlib,sys,threading,unittest
from unittest.mock import Mock,patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from host import Host,ORIGIN
from connectors import Failure

class Sessions(unittest.TestCase):
    def setUp(self):
        self.h=Host.__new__(Host);self.h.lock=threading.RLock();self.h.stopping=False
        self.h.pairs={};self.h.sessions={};self.h.jobs={};self.h.failures=collections.deque();self.h.config={}
        self.h.graph=Mock();self.h.graph.identity.return_value=('tenant','user',1)
        self.h.graph.account={'id':'user','mail':'test@example.invalid','displayName':'Control fixture'}
    def connect(self,app,code):
        return self.h.pair({'application':app,'code':code,'email':'test@example.invalid','tenant':'tenant','account':'user'},ORIGIN)
    def test_both_codes_and_sessions_work_after_elapsed_days(self):
        for app in ('outlook','teams'):
            with patch('host.time.monotonic',return_value=1):code=self.h.admin({'op':'pair','application':app})
            self.assertIsNone(code['expires_in'])
            with patch('host.time.monotonic',return_value=30*86400):session=self.connect(app,code['code'])
            self.assertIsNone(session['expires_in'])
            with patch('host.time.monotonic',return_value=60*86400):
                self.assertEqual(self.h.auth(session['token'],ORIGIN,'a'*32)['app'],app)
    def test_code_still_one_use(self):
        code=self.h.admin({'op':'pair','application':'teams'})['code'];self.connect('teams',code)
        with self.assertRaises(Failure):self.connect('teams',code)
    def test_new_code_replaces_previous_code(self):
        old=self.h.admin({'op':'pair','application':'outlook'})['code']
        new=self.h.admin({'op':'pair','application':'teams'})['code']
        self.assertNotIn(old,self.h.pairs);self.assertIn(new,self.h.pairs)
    def test_disconnect_invalidates_pending_codes_and_connections(self):
        code=self.h.admin({'op':'pair','application':'teams'})['code'];session=self.connect('teams',code)
        self.h.admin({'op':'pair','application':'outlook'});self.h.invalidate()
        self.assertEqual(self.h.pairs,{})
        with self.assertRaises(Failure):self.h.auth(session['token'],ORIGIN,'a'*32)
    def test_origin_replay_and_microsoft_session_checks_remain(self):
        code=self.h.admin({'op':'pair','application':'teams'})['code'];token=self.connect('teams',code)['token']
        with self.assertRaises(Failure):self.h.auth(token,'https://other.invalid','a'*32)
        self.h.auth(token,ORIGIN,'b'*32)
        with self.assertRaises(Failure):self.h.auth(token,ORIGIN,'b'*32)
        self.h.graph.identity.side_effect=Failure('Microsoft sign-in is required.')
        with self.assertRaises(Failure):self.h.auth(token,ORIGIN,'c'*32)
    def test_wrong_teams_identity_cannot_pair(self):
        code=self.h.admin({'op':'pair','application':'teams'})['code']
        with self.assertRaises(Failure):self.h.pair({'application':'teams','code':code,'tenant':'wrong','account':'user'},ORIGIN)

class SharedRouting(unittest.TestCase):
    def test_outlook_and_teams_use_same_local_and_large_request_cloud_stages(self):
        for app,kind in (('outlook','mail'),('teams','chat'),('teams','channel')):
            for partial in (False,True):
                with self.subTest(app=app,kind=kind,partial=partial):
                    h=Host.__new__(Host);h.config={'public_local':True};h.resources=P/'build/Onboard AI.app/Contents/Resources'
                    h.graph=Mock();h.graph.identity.return_value=('tenant','user',1)
                    h.graph.retrieve.return_value=([{'id':'source-a','text':'Pending review.','title':'Control fixture'}],'Bounded source retrieval')
                    h.sessions={'paired':{'app':app}};h.local_status=Mock(return_value={'ready':True})
                    job={'id':'control','owner':'paired','identity':('tenant','user',1),'cancel':threading.Event(),
                         'request':{'task':'summarize','route':'local','public_attested':True,'allow_cloud':True,'sources':[{'kind':kind,'ref':'control'}]}}
                    packet={'partial':partial,'prompt_tokens':1000,'prompt_limit':1536,'retrieved_sources':1,'included_sources':1,
                            'sources':[{'id':'source-a','alias':'S1','text':'Pending review.'}]}
                    output=json.dumps({'claims':[{'source_id':'S1','quote':'Pending review.'}]})
                    with patch('local_engine.generate_grounded',return_value=(output,packet)) as local,patch('email_analysis.analyze',side_effect=lambda host,j,base,*args:base) as cloud:
                        result=h.process(job)
                    self.assertEqual(local.call_count,1);self.assertEqual(cloud.call_count,int(partial))
                    self.assertEqual(result['claims'][0]['source_id'],'source-a')
                    h.graph.retrieve.assert_called_once_with(kind,'control')

if __name__=='__main__':unittest.main()

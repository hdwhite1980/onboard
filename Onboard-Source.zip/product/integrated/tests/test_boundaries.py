"""Control tests only. No simulated provider success or synthetic product dataset."""
import ast,hashlib,json,pathlib,queue,sys,tempfile,time,unittest,threading
ROOT=pathlib.Path(__file__).resolve().parents[3];P=ROOT/'product/integrated'
sys.path.insert(0,str(P/'service'))
from host import Host
from connectors import Failure,validate_provider,plain

class Boundaries(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.h=Host(P/'build/Onboard AI.app/Contents/Resources',self.tmp.name,'/usr/bin/true')
 def test_unknown_denied(self):
  p=self.h.rust('policy',task='ask',route='local',enabled=True,public_attested=False)
  self.assertFalse(p['allowed'])
 def test_cloud_requires_explicit_request(self):
  self.assertFalse(self.h.rust('policy',task='ask',route='cloud',enabled=True,public_attested=True,provider_enabled=True,explicit_cloud=False)['allowed'])
 def test_processing_disabled_and_confirmation_are_distinct(self):
  p=self.h.rust('policy',task='ask',route='local',enabled=False,public_attested=True)
  self.assertFalse(p['allowed']);self.assertEqual(p['code'],'PROCESSING_DISABLED')
  p=self.h.rust('policy',task='ask',route='local',enabled=True,public_attested=False)
  self.assertFalse(p['allowed']);self.assertEqual(p['code'],'PUBLIC_CONFIRMATION_REQUIRED')
 def test_local_enable_preserves_other_settings_and_needs_confirmation(self):
  before=json.loads(json.dumps(self.h.config));self.h.admin({'op':'set_local_enabled','enabled':True})
  saved=json.loads((pathlib.Path(self.tmp.name)/'settings.json').read_text())
  self.assertEqual(saved,dict(before,public_local=True));self.assertFalse(saved['public_cloud'])
  self.assertFalse(self.h.rust('policy',task='ask',route='local',enabled=True,public_attested=False)['allowed'])
  with self.assertRaises(Failure):self.h.admin({'op':'set_local_enabled','enabled':'true'})
 def test_public_policy(self):
  p=self.h.rust('policy',task='ask',route='local',enabled=True,public_attested=True)
  self.assertTrue(p['allowed']);self.assertFalse(p['production_policy'])
 def test_job_session_isolation(self):
  r=self.h.submit('native',{'task':'ask','route':'local','prompt':'','public_attested':False})
  with self.assertRaises(Failure):self.h.job('another-session',r['id'])
 def test_cloud_not_callable_by_addin(self):
  with self.assertRaises(Failure):self.h.submit('browser',{'task':'ask','route':'cloud','prompt':''})
 def test_no_dashboard_implicit_sources(self):
  with self.assertRaises(Failure):self.h.submit('native',{'task':'ask','sources':[{'kind':'mail','ref':'not-used'}]})
 def test_no_secrets_in_settings(self):
  self.h.admin({'op':'save_settings','settings':{'graph':{},'provider':{},'api_key':'MUST_NOT_PERSIST'}})
  self.assertNotIn('MUST_NOT_PERSIST',(pathlib.Path(self.tmp.name)/'settings.json').read_text())
 def test_insecure_origin_denied(self):
  with self.assertRaises(Failure):self.h.admin({'op':'save_settings','settings':{'origins':['http://evil.test']}})
 def test_unpaired_rejected(self):
  with self.assertRaises(Failure):self.h.auth('not-issued','https://localhost:38473','a'*32)
 def test_pairing_requires_actual_signin(self):
  with self.assertRaises(Failure):self.h.admin({'op':'pair','application':'outlook'})
 def test_graph_unconfigured_denied(self):
  with self.assertRaises(Failure):self.h.graph.get('me')
 def test_no_commercial_cloud(self):
  with self.assertRaises(Failure):self.h.admin({'op':'save_settings','settings':{'graph':{'cloud':'Commercial'}}})
 def test_no_http_provider(self):
  with self.assertRaises(Failure):validate_provider({'type':'compatible-chat','endpoint':'http://example.invalid','model':'x'})
 def test_runtime_identity_block(self):
  self.h.resources=pathlib.Path(self.tmp.name)
  (self.h.resources/'local.json').write_text(json.dumps({'python':'/usr/bin/true','qualified_sha256':'incorrect'}))
  self.assertFalse(self.h.local_status()['ready'])
 def test_sources_must_support_claims(self):
  self.assertFalse(self.h.rust('validate',sources=[{'id':'a','text':'not approved'}],claims=[{'source_id':'b','quote':'approved'}])['valid'])
 def test_cancel_discards_result(self):
  r=self.h.submit('native',{'task':'ask','prompt':'','public_attested':False});self.h.cancel('native',r['id']);time.sleep(.1)
  self.assertEqual(self.h.job('native',r['id'])['state'],'cancelled');self.assertIsNone(self.h.job('native',r['id'])['result'])
 def test_original_resource_guards_unchanged(self):
  def functions(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
  old=functions(ROOT/'product/meeting_briefing/provider/policy.py');new=functions(P/'local/policy.py')
  for name in ('valid','pressure_reason','violation','deadline','classify'):self.assertEqual(old[name],new[name])
 def test_text_removes_embedded_script(self):self.assertEqual(plain('<p>Text</p><script>not content</script>'),'Text')

if __name__=='__main__':unittest.main(verbosity=2)

import Foundation
struct OnboardError: LocalizedError {let message:String;var errorDescription:String?{message}}
@main struct BrowserChecks {
 @MainActor static func main() async throws {
  for engine in ["duckduckgo","google","bing"] {
   let query="a & b + café? # = /"
   let url=try Browsers.searchURL(query:query,engine:engine)
   precondition(URLComponents(url:url,resolvingAgainstBaseURL:false)?.queryItems?.first?.value==query)
   precondition(url.absoluteString.contains("%2B"))
   precondition(url.scheme=="https")
  }
  do{_ = try Browsers.searchURL(query:"search",engine:"javascript:bad");fatalError("Invalid engine accepted")}catch{}
  do{try await Browsers.open(URL(string:"javascript:alert(1)")!,browserID:"");fatalError("Invalid scheme accepted")}catch{}
  do{try await Browsers.open(URL(string:"https://example.com")!,browserID:"invalid.onboard.browser.check");fatalError("Missing browser silently replaced")}catch{}
  print("PASS: three search engines preserve query text, plus encoding, invalid engine/scheme, missing browser; no browser opened")
 }
}

// UI contract fixtures; no real messages, accounts, or network calls.
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const code=fs.readFileSync(path.join(__dirname,'../web/teams-actions.js'),'utf8');
function setup(overrides={}){
 const nodes=new Map(),get=id=>{if(!nodes.has(id))nodes.set(id,{value:'',checked:false,disabled:false,hidden:false,handlers:{},addEventListener(n,f){this.handlers[n]=f;}});return nodes.get(id);};
 const launch={version:1,command:'reply',bot:'fixture-bot',tenant:'fixture-tenant',account:'fixture-user',text:'Fixture message',selected:true,conversation:'fixture-chat',channel:'',...overrides};
 const context={user:{id:'fixture-user',tenant:{id:'fixture-tenant'}},chat:{id:'fixture-chat'}};
 const calls=[],s={document:{getElementById:get},location:{hash:'#onboardAction='+encodeURIComponent(JSON.stringify(launch)),pathname:'/teams.html',search:''},history:{replaceState:(...a)=>calls.push(['history',...a])},OnboardActionConfig:{botId:'fixture-bot'},OnboardTeams:{current:async()=>context},microsoftTeams:{tasks:{submitTask:(...a)=>calls.push(['submit',...a])}},verifyHostAccount:async()=>{},api:async(...a)=>calls.push(['api',...a]),addEventListener:()=>{}};
 vm.runInNewContext(code,s);return {s,get,calls,context,launch};
}
test('action removes fragment and reads only selected application text',async()=>{
 const f=setup();assert.equal(f.calls[0][3],'/teams.html');f.s.OnboardActions.initialize(f.context);const source=await f.s.OnboardActions.source();assert.equal(source.kind,'selected');assert.equal(source.origin,'teams-message');assert.equal(source.text,'Fixture message');assert.equal(f.calls.filter(c=>c[0]==='api').length,0);
});
test('wrong bot, account, tenant and conversation cannot enable a message action',()=>{
 for(const x of [{bot:'other'},{tenant:'other'},{account:'other'},{conversation:'other'}]){const f=setup(x);assert.throws(()=>f.s.OnboardActions.initialize(f.context));}
});
test('changed account blocks retrieval and draft insertion',async()=>{
 const f=setup();f.s.OnboardActions.initialize(f.context);f.context.user.id='other';await assert.rejects(f.s.OnboardActions.source(),/different Microsoft account/);f.s.OnboardActions.result({status:'generated'});f.get('action-review').checked=true;await f.get('action-insert').handlers.click();assert.equal(f.calls.filter(c=>c[0]==='submit').length,0);
});
test('draft insertion requires generated output and explicit review; editing clears review',async()=>{
 const f=setup();f.s.OnboardActions.initialize(f.context);f.get('answer').value='Fixture draft';f.get('action-review').checked=true;f.s.OnboardActions.result({status:'source_excerpts'});await f.get('action-insert').handlers.click();assert.equal(f.calls.filter(c=>c[0]==='submit').length,0);
 f.s.OnboardActions.result({status:'generated'});await f.get('action-insert').handlers.click();assert.equal(f.calls.filter(c=>c[0]==='submit').length,0);
 f.get('action-review').checked=true;f.get('answer').handlers.input();assert.equal(f.get('action-review').checked,false);
 f.get('action-review').checked=true;await f.get('action-insert').handlers.click();const inserted=f.calls.find(c=>c[0]==='submit');assert.equal(inserted[1].body,'Fixture draft');assert.equal(inserted[1].reviewed,true);assert.equal(inserted[2],'fixture-bot');assert.equal(f.calls.filter(c=>c[0]==='api')[0][1],'handoff-list');
 await f.get('action-insert').handlers.click();assert.equal(f.calls.filter(c=>c[0]==='submit').length,1);
});
test('Outlook action uses local handoff panel and cannot insert or send a Teams message',async()=>{
 const f=setup({command:'outlook'});f.s.OnboardActions.initialize(f.context);assert.equal(f.get('handoff-outgoing').open,true);assert.equal(f.get('action-insert').hidden,true);f.s.OnboardActions.result({status:'generated'});f.get('action-review').checked=true;await f.get('action-insert').handlers.click();assert.equal(f.calls.filter(c=>c[0]==='submit'||c[0]==='api').length,0);
});
test('compose requires explicit text and never falls back to conversation search',async()=>{
 const f=setup({selected:false,text:''});f.s.OnboardActions.initialize(f.context);assert.equal(f.get('action-source').readOnly,false);await assert.rejects(f.s.OnboardActions.source(),/Provide message text/);f.get('action-source').value='Explicit fixture';assert.equal((await f.s.OnboardActions.source()).text,'Explicit fixture');
});

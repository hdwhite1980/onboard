"""Control-only fixtures for the in-memory, account-scoped add-in conduit."""
import pathlib,sys,threading,unittest
from unittest.mock import Mock
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from connectors import Failure
from handoffs import Handoffs
class HandoffTests(unittest.TestCase):
 def setUp(self):
  self.identity=('tenant','account',1);self.host=Mock();self.host.lock=threading.RLock();self.host.config={'public_local':True};self.host.graph.identity.return_value=self.identity
  self.host.sessions={k:{'app':app,'identity':self.identity} for k,app in [('out','outlook'),('team','teams'),('team2','teams')]}
  self.host.job.return_value={'state':'complete','result':{'status':'generated','policy':{'allowed':True}}};self.q=Handoffs(self.host)
  self.r={'job':'j','target':'teams','body':'Fixture reviewed draft.','subject':'Fixture','recipient':'','category':'summary','key':'fixture-key-123456','public_attested':True}
 def test_transfer_is_local_and_visible_only_in_destination(self):
  self.q.create('out',self.r);self.assertEqual(self.q.inbox('out')['drafts'],[]);rows=self.q.inbox('team')['drafts'];self.assertEqual(rows[0]['category'],'summary');self.assertEqual(rows[0]['body'],self.r['body']);self.host.graph.write.assert_not_called();self.host.graph.get.assert_not_called()
 def test_reverse_direction_works(self):
  self.q.create('team',dict(self.r,target='outlook'));self.assertEqual(len(self.q.inbox('out')['drafts']),1)
 def test_repeated_create_is_idempotent_even_after_removal(self):
  a=self.q.create('out',self.r);b=self.q.create('out',self.r);self.assertEqual(a['id'],b['id']);self.assertEqual(len(self.q.rows),1);self.q.remove('team',a);self.assertEqual(self.q.create('out',self.r)['state'],'removed');self.assertEqual(len(self.q.rows),0)
 def test_same_key_cannot_replace_recipient_or_text(self):
  self.q.create('out',self.r)
  with self.assertRaisesRegex(Failure,'different draft'):self.q.create('out',dict(self.r,body='Changed'))
 def test_only_one_destination_panel_can_claim_a_transfer(self):
  r=self.q.create('out',self.r);self.q.remove('team',r)
  with self.assertRaises(Failure):self.q.remove('team2',r)
 def test_other_account_cannot_list_or_claim_drafts(self):
  r=self.q.create('out',self.r);other=('tenant','other',2);self.host.graph.identity.return_value=other;self.host.sessions['team']['identity']=other
  self.assertEqual(self.q.inbox('team')['drafts'],[])
  with self.assertRaises(Failure):self.q.remove('team',r)
 def test_stale_session_rejected(self):
  self.host.graph.identity.return_value=('tenant','other',2)
  with self.assertRaises(Failure):self.q.create('out',self.r)
 def test_sender_cannot_claim_destination_draft(self):
  r=self.q.create('out',self.r)
  with self.assertRaises(Failure):self.q.remove('out',r)
 def test_withheld_output_cannot_be_transferred(self):
  self.host.job.return_value={'state':'complete','result':{'status':'source_excerpts','policy':{'allowed':True}}}
  with self.assertRaises(Failure):self.q.create('out',self.r)
 def test_policy_and_attestation_are_required(self):
  with self.assertRaises(Failure):self.q.create('out',dict(self.r,public_attested=False))
  self.host.config['public_local']=False
  with self.assertRaises(Failure):self.q.create('out',self.r)
 def test_queue_is_bounded_without_silent_eviction(self):
  for n in range(20):self.q.create('out',dict(self.r,key='fixture-key-123456-'+str(n)))
  with self.assertRaisesRegex(Failure,'full'):self.q.create('out',dict(self.r,key='fixture-key-123456-final'))
  self.assertEqual(len(self.q.rows),20)
 def test_clear_removes_all_account_memory(self):
  self.q.create('out',self.r);self.q.clear();self.assertFalse(self.q.rows);self.assertFalse(self.q.receipts)
 def test_disconnect_clears_sender_transfers(self):
  self.q.create('out',self.r);self.q.clear('out');self.assertFalse(self.q.rows)
 def test_fields_cannot_carry_multiple_recipients_or_header_injection(self):
  for fields in ({'recipient':'a@example.invalid,b@example.invalid'},{'subject':'Subject\r\nBcc: x'},{'body':'x'*12001},{'category':'send_now'}):
   with self.assertRaises(Failure):self.q.create('out',dict(self.r,**fields))
if __name__=='__main__':unittest.main()

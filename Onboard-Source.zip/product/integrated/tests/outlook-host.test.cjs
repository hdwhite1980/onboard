// Initialization control fixtures only; no mailbox messages or provider output.
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const helper=fs.readFileSync(path.join(__dirname,'../web/outlook-host.js'),'utf8');
function setup({host='Outlook',identity=true,missing=false,pending=false}={}){
 const handlers={};const mailbox={userProfile:identity?{emailAddress:'control@example.invalid'}:{}};
 const c={URL,addEventListener:(name,fn)=>handlers[name]=fn,setTimeout:(fn)=>setTimeout(fn,5),clearTimeout};
 if(!missing)c.Office={context:{mailbox},onReady:()=>pending?new Promise(()=>{}):Promise.resolve({host})};
 vm.runInNewContext(helper,c);return {c,handlers,mailbox};
}
test('mailbox identity allows pairing without a selected message',async()=>{const h=setup();assert.equal(await h.c.OnboardOutlook.initialize(),h.mailbox);});
test('browser previews stay disconnected',async()=>{const h=setup({host:null});await assert.rejects(h.c.OnboardOutlook.initialize(),/inside Outlook/);});
test('missing identity cannot enable connection',async()=>{const h=setup({identity:false});await assert.rejects(h.c.OnboardOutlook.initialize(),/mailbox identity/);});
test('missing library reports useful failure',async()=>{const h=setup({missing:true});await assert.rejects(h.c.OnboardOutlook.initialize(),/library did not load/);});
test('unresolved readiness times out and supports retry',async()=>{const h=setup({pending:true});await assert.rejects(h.c.OnboardOutlook.initialize(),/15 seconds/);h.c.Office.onReady=()=>Promise.resolve({host:'Outlook'});assert.equal(await h.c.OnboardOutlook.initialize(),h.mailbox);});
test('policy failure reports only resource origin, not URL parameters',async()=>{const h=setup({pending:true});h.handlers.securitypolicyviolation({effectiveDirective:'script-src-elem',blockedURI:'https://appsforoffice.microsoft.com/a.js?private=value'});await assert.rejects(h.c.OnboardOutlook.initialize(),e=>e.message.includes('appsforoffice.microsoft.com')&&!e.message.includes('private'));});
test('Connect button follows readiness and exposes failures',async()=>{
 const elements=new Map();const get=id=>{if(!elements.has(id))elements.set(id,{disabled:true,hidden:false,textContent:'',addEventListener(){}});return elements.get(id);};
 const c={document:{body:{dataset:{application:'outlook'}},getElementById:get},window:{addEventListener(){}},OnboardOutlook:{initialize:async()=>{throw Error('host unavailable');}}};
 vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8'),c);await new Promise(setImmediate);
 assert.equal(get('pair').disabled,true);assert.match(get('context').textContent,/host unavailable/);assert.equal(get('retry-host').hidden,false);
 c.OnboardOutlook.initialize=async()=>({userProfile:{}});await vm.runInContext('init()',c);assert.equal(get('pair').disabled,false);assert.equal(get('retry-host').hidden,true);
});

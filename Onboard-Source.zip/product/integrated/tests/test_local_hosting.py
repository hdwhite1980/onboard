"""HTTP boundary regression tests; no Microsoft accounts or AI calls."""
import http.client,json,pathlib,sys,threading,unittest
from http.server import ThreadingHTTPServer
from unittest.mock import Mock
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from host import Host,Web,ORIGIN

class LocalHostingTests(unittest.TestCase):
    def setUp(self):
        self.h=Host.__new__(Host)
        self.h.config={'origins':['https://onboard.huestechnology.com']}
        self.h.connections=Mock()
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Web);self.server.host=self.h
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.addCleanup(self.server.server_close);self.addCleanup(self.server.shutdown)
    def request(self,method,origin):
        c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=2)
        try:
            c.request(method,'/api/connection-request',body='{}',headers={'Host':'localhost:38473','Origin':origin,'Content-Type':'application/json'})
            r=c.getresponse();status=r.status;allow=r.getheader('Access-Control-Allow-Origin');r.read();return status,allow
        finally:c.close()
    def test_stale_hosted_origin_denied_before_connection_handler(self):
        for mode in (None,'local','invalid'):
            self.h.config['addin_hosting']=mode
            for method in ('OPTIONS','POST'):
                code,allow=self.request(method,'https://onboard.huestechnology.com')
                self.assertGreaterEqual(code,400);self.assertIsNone(allow)
        self.h.connections.request.assert_not_called()
    def test_local_origin_is_available_without_external_host(self):
        self.assertEqual(self.request('OPTIONS',ORIGIN),(200,ORIGIN))
    def test_organization_mode_requires_exact_allowlisted_origin(self):
        self.h.config={'addin_hosting':'organization','origins':['https://approved.example.invalid']}
        self.assertEqual(self.request('OPTIONS','https://approved.example.invalid'),(200,'https://approved.example.invalid'))
        self.assertEqual(self.request('OPTIONS','https://other.example.invalid'),(403,None))

if __name__=='__main__':unittest.main()

// UI contract fixtures only: no live account, mailbox, or generated answer.
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const code=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');
for(const app of ['outlook','teams']){
 test(app+' shows the shared cloud control and a connection without a timer',async()=>{
  const nodes=new Map();const get=id=>{if(!nodes.has(id))nodes.set(id,{value:'control-code',checked:false,disabled:true,handlers:{},addEventListener(n,f){this.handlers[n]=f;}});return nodes.get(id);};
  const context={userProfile:{emailAddress:'test@example.invalid'},user:{tenant:{id:'tenant'},id:'user'}};
  const sandbox={document:{body:{dataset:{application:app}},getElementById:get},window:{addEventListener(){}},
   OnboardOutlook:{initialize:async()=>context},OnboardTeams:{initialize:async()=>context},
   AbortSignal,fetch:async()=>({ok:true,json:async()=>({token:'control-session',account:'Test fixture',cloud_available:true,cloud_name:'Configured test provider',expires_in:null})})};
  vm.createContext(sandbox);vm.runInContext(code,sandbox);await new Promise(setImmediate);
  await get('pair').handlers.click();
  assert.equal(get('submit').disabled,false);assert.equal(get('allow-cloud').checked,true);
  assert.match(get('status').textContent,/No Onboard connection timeout/);assert.doesNotMatch(get('status').textContent,/30 minutes/);
  const html=fs.readFileSync(path.join(__dirname,'../web/'+app+'.html'),'utf8');
  assert.match(html,/2,048 total tokens/);assert.match(html,/id="allow-cloud"/);assert.match(html,/code has no time limit/);
 });
}

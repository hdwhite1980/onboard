"""Explicit notice fixtures, never copied customer email."""
import pathlib,sys,threading,unittest
from unittest.mock import Mock,patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from grounding import no_reply_notice
from host import Host
class NoReply(unittest.TestCase):
 def source(self,text):return {'id':'mail:fixture','kind':'mail','primary':True,'text':text,'title':'Automated notice'}
 def test_standalone_notice_is_exact_and_task_scoped(self):
  source=self.source('Your report is ready.\nPlease do not reply to this email.\nFooter')
  notice=no_reply_notice({'task':'reply'},[source]);self.assertEqual(notice['quote'],'Please do not reply to this email.')
  self.assertIn(notice['quote'],source['text'])
  for task in ('followup','ask','summarize'):self.assertIsNone(no_reply_notice({'task':task},[source]))
 def test_quoted_discussion_and_unselected_related_mail_do_not_block(self):
  for source in (self.source('The old footer said "Please do not reply to this email." What do you think?'),dict(self.source('Please do not reply to this email.'),primary=False)):
   self.assertIsNone(no_reply_notice({'task':'reply'},[source]))
 def test_notice_returns_advice_before_model_or_cloud_and_cannot_enable_send(self):
  h=Host.__new__(Host);h.graph=Mock();h.graph.identity.return_value=('tenant','user',1)
  h.graph.retrieve.return_value=([self.source('Notice.\nPlease do not reply to this email.')],'Selected only')
  h.config={'public_local':True};h.rust=Mock(return_value={'allowed':True});h.sessions={'paired':{'app':'outlook'}}
  j={'id':'fixture','owner':'paired','identity':('tenant','user',1),'cancel':threading.Event(),'request':{'task':'reply','sources':[{'kind':'mail','ref':'fixture'}],'public_attested':True}}
  with patch('local_engine.generate_grounded') as local,patch('email_analysis.analyze') as cloud:r=h.process(j)
  self.assertEqual(r['status'],'no_reply_recommended');self.assertEqual(r['draft_text'],'');local.assert_not_called();cloud.assert_not_called()
if __name__=='__main__':unittest.main()

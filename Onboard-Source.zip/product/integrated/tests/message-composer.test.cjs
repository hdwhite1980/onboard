// Shared add-in controls only. No Microsoft account, network, or actual send.
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const code=fs.readFileSync(path.join(__dirname,'../web/messages.js'),'utf8');
function fixture(application){
 const nodes=new Map(),calls=[];let handler;
 const get=id=>{if(!nodes.has(id))nodes.set(id,{value:'',checked:false,disabled:false,hidden:false,handlers:{},textContent:'',addEventListener(n,f){this.handlers[n]=f;},click(){return this.handlers.click?.();}});return nodes.get(id);};
 const sandbox={application,document:{getElementById:get},Intl,Date,api:async(name,data)=>{calls.push({name,data});return handler?handler(name,data):{id:'review',target:data.target,recipient:'Resolved recipient',sender:'Me',body:data.body,subject:data.subject};}};
 vm.createContext(sandbox);vm.runInContext(code,sandbox);
 return {sandbox,get,calls,setHandler:f=>{handler=f;},result:()=>sandbox.OnboardMessages.result({status:'generated',draft_text:'Draft fixture'},'job-fixture')};
}
for(const app of ['outlook','teams']){
 test(app+' requires review and explicit Send, and sends the server review ID only',async()=>{
  const f=fixture(app);f.result();f.get('message-recipient').value='recipient@example.invalid';f.get('message-share').checked=true;
  assert.equal(f.calls.length,0);assert.equal(f.get('message-send').disabled,true);
  await f.get('message-review').click();assert.equal(f.calls[0].name,'message-review');assert.equal(f.get('message-preview').hidden,false);assert.equal(f.get('message-send').disabled,false);
  f.setHandler(()=>({state:'sent',message:'Fixture accepted'}));await f.get('message-send').click();await f.get('message-send').click();
  assert.equal(f.calls.length,2);assert.equal(f.calls[1].name,'message-send');assert.equal(f.calls[1].data.id,'review');assert.equal(f.calls[1].data.confirmed,true);
  assert.equal(Object.hasOwn(f.calls[1].data,'body'),false);
 });
 test(app+' edits invalidate review and withheld output never enables message review',async()=>{
  const f=fixture(app);f.result();await f.get('message-review').click();f.get('message-body').handlers.input();
  assert.equal(f.get('message-send').disabled,true);await f.get('message-send').click();assert.equal(f.calls.length,1);
  f.sandbox.OnboardMessages.result({status:'source_excerpts',answer:'Not a draft'},'job');assert.equal(f.get('message-review').disabled,true);assert.equal(f.get('message-body').value,'');
 });
 test(app+' stale recipient lookup cannot re-enable Send after editing',async()=>{
  const f=fixture(app);f.result();let release;f.setHandler(()=>new Promise(r=>{release=r;}));
  const request=f.get('message-review').click();f.get('message-recipient').handlers.input();release({id:'old',target:'email',recipient:'Old',body:'Old',sender:'Me'});await request;
  assert.equal(f.get('message-send').disabled,true);assert.equal(f.get('message-preview').hidden,true);
 });
 test(app+' changed calendar controls remove prior availability',async()=>{
  const f=fixture(app);f.setHandler(()=>({id:'times',text:'Calendar fixture',message:'Checked'}));await f.get('message-times').click();
  assert.equal(f.get('message-times-text').textContent,'Calendar fixture');f.get('message-date').handlers.input();assert.equal(f.get('message-times-text').textContent,'');
 });
}

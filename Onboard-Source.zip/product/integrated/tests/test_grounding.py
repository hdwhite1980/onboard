"""Formatting recovery and adversarial citation controls; no production source data."""
import json,pathlib,sys,unittest
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from grounding import checked_answer,GroundingError
from host import Host
class Grounding(unittest.TestCase):
    def setUp(self):
        self.host=Host.__new__(Host);self.host.resources=P/'build/Onboard AI.app/Contents/Resources'
        self.rows=[{'id':'mail:original','alias':'S1','text':'Budget is not\napproved. Review pending.'}]
        self.originals=[{'id':'mail:original','text':self.rows[0]['text']+'\nOmitted detail.'}]
    def answer(self,quote='Budget is not\napproved.',sid='S1',**extra):return json.dumps(dict(claims=[{'source_id':sid,'quote':quote}],suggestions='Consider a review.',**extra))
    def test_markdown_wrapper_does_not_discard_valid_json(self):
        result,claims,note=checked_answer(self.host,'```json\n'+self.answer()+'\n```',self.rows,self.originals)
        self.assertEqual(claims[0]['source_id'],'mail:original')
    def test_whitespace_repaired_only_to_original_exact_text(self):
        _,claims,_=checked_answer(self.host,self.answer('Budget is not approved.'),self.rows,self.originals)
        self.assertEqual(claims[0]['quote'],'Budget is not\napproved.')
    def test_original_id_is_accepted_without_changing_source_mapping(self):
        _,claims,_=checked_answer(self.host,self.answer(sid='mail:original'),self.rows,self.originals)
        self.assertEqual(claims[0]['source_id'],'mail:original')
    def test_changed_fact_unseen_quote_and_unknown_id_are_rejected(self):
        for raw in [self.answer('Budget is approved.'),self.answer('Omitted detail.'),self.answer(sid='S2')]:
            with self.assertRaises(GroundingError):checked_answer(self.host,raw,self.rows,self.originals)
    def test_incomplete_json_and_wrong_types_never_salvaged(self):
        for raw in [self.answer()[:-2],'[]','null','{"claims":[]}',self.answer(unknowns={'action':'send'})]:
            with self.assertRaises(GroundingError):checked_answer(self.host,raw,self.rows,self.originals)

class EvidenceReferences(unittest.TestCase):
    def setUp(self):
        self.host=Host.__new__(Host);self.host.resources=P/'build/Onboard AI.app/Contents/Resources'
        self.rows=[{'id':'mail:original','alias':'S1','evidence_id':'E1','text':'The proposal is not approved.'}]
        self.originals=[{'id':'mail:original','text':'The proposal is not approved. Additional context.'}]
    def test_source_text_is_attached_without_model_retyping_it(self):
        raw=json.dumps({'claims':[{'evidence_id':'E1'}],'suggestions':'Could we discuss the pending proposal?'})
        _,claims,_=checked_answer(self.host,raw,self.rows,self.originals)
        self.assertEqual(claims[0]['quote'],'The proposal is not approved.');self.assertEqual(claims[0]['source_id'],'mail:original')
    def test_unique_source_alias_resolves_to_exact_supplied_excerpt(self):
        _,claims,_=checked_answer(self.host,'{"claims":[{"evidence_id":"S1"}],"suggestions":"Please review the proposal."}',self.rows,self.originals)
        self.assertEqual(claims[0]['quote'],'The proposal is not approved.')
    def test_source_alias_is_rejected_when_it_could_mean_multiple_excerpts(self):
        self.rows.append({'id':'mail:original','alias':'S1','evidence_id':'E2','text':'Additional context.'})
        with self.assertRaises(GroundingError):checked_answer(self.host,'{"claims":[{"evidence_id":"S1"}]}',self.rows,self.originals)
    def test_invented_or_conflicting_reference_is_rejected(self):
        for claim in [{'evidence_id':'E2'},{'evidence_id':'E1','source_id':'unseen'},{'evidence_id':'E1','quote':'The proposal is approved.'}]:
            with self.assertRaises(GroundingError):checked_answer(self.host,json.dumps({'claims':[claim]}),self.rows,self.originals)
    def test_reference_still_must_match_original_source_exactly(self):
        self.rows[0]['text']='The proposal is approved.'
        with self.assertRaises(GroundingError):checked_answer(self.host,'{"claims":[{"evidence_id":"E1"}]}',self.rows,self.originals)


class PlaceholderRejection(unittest.TestCase):
    def test_prompt_placeholder_is_not_a_completed_answer(self):
        from grounding import parse
        with self.assertRaisesRegex(GroundingError,'placeholder'):
            parse('{"claims":[{"evidence_id":"E1"}],"suggestions":"clearly proposed preparation or draft"}')


class StructuralRepair(unittest.TestCase):
    def test_observed_extra_brace_keeps_all_field_values(self):
        from grounding import parse
        raw='{"claims":[{"evidence_id":"E1"}]}, "suggestions":"Thank you for the instructions.", "unknowns":""}'
        result=parse(raw);self.assertEqual(result['suggestions'],'Thank you for the instructions.');self.assertEqual(result['claims'],[{'evidence_id':'E1'}])
    def test_incomplete_strings_multiple_objects_and_duplicate_fields_stay_rejected(self):
        from grounding import parse
        for raw in ['{"claims":[{"evidence_id":"E1"}]}, "suggestions":"unfinished', '{"claims":[]} {"suggestions":"different object"}', '{"claims":[],"claims":[{"evidence_id":"E1"}],"suggestions":"Draft"}']:
            with self.assertRaises(GroundingError):parse(raw)

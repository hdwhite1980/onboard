"""Formatting recovery and adversarial citation controls; no production source data."""
import json,pathlib,sys,unittest
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from grounding import checked_answer,GroundingError
from host import Host
class Grounding(unittest.TestCase):
    def setUp(self):
        self.host=Host.__new__(Host);self.host.resources=P/'build/Onboard AI.app/Contents/Resources'
        self.rows=[{'id':'mail:original','alias':'S1','text':'Budget is not\napproved. Review pending.'}]
        self.originals=[{'id':'mail:original','text':self.rows[0]['text']+'\nOmitted detail.'}]
    def answer(self,quote='Budget is not\napproved.',sid='S1',**extra):return json.dumps(dict(claims=[{'source_id':sid,'quote':quote}],suggestions='Consider a review.',**extra))
    def test_markdown_wrapper_does_not_discard_valid_json(self):
        result,claims,note=checked_answer(self.host,'```json\n'+self.answer()+'\n```',self.rows,self.originals)
        self.assertEqual(claims[0]['source_id'],'mail:original')
    def test_whitespace_repaired_only_to_original_exact_text(self):
        _,claims,_=checked_answer(self.host,self.answer('Budget is not approved.'),self.rows,self.originals)
        self.assertEqual(claims[0]['quote'],'Budget is not\napproved.')
    def test_original_id_is_accepted_without_changing_source_mapping(self):
        _,claims,_=checked_answer(self.host,self.answer(sid='mail:original'),self.rows,self.originals)
        self.assertEqual(claims[0]['source_id'],'mail:original')
    def test_changed_fact_unseen_quote_and_unknown_id_are_rejected(self):
        for raw in [self.answer('Budget is approved.'),self.answer('Omitted detail.'),self.answer(sid='S2')]:
            with self.assertRaises(GroundingError):checked_answer(self.host,raw,self.rows,self.originals)
    def test_incomplete_json_and_wrong_types_never_salvaged(self):
        for raw in [self.answer()[:-2],'[]','null','{"claims":[]}',self.answer(unknowns={'action':'send'})]:
            with self.assertRaises(GroundingError):checked_answer(self.host,raw,self.rows,self.originals)

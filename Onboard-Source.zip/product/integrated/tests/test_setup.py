"""Verify setup integrity/failure behavior without fabricated remote successes."""
import hashlib, importlib.util, io, pathlib, tempfile, unittest
import json,zipfile,os,subprocess
from unittest import mock

spec=importlib.util.spec_from_file_location('setup_local',pathlib.Path(__file__).resolve().parents[1]/'tools/setup_local.py')
setup=importlib.util.module_from_spec(spec);spec.loader.exec_module(setup)
launch_spec=importlib.util.spec_from_file_location('setup_launch',pathlib.Path(__file__).resolve().parents[1]/'setup/launch.py')
launch=importlib.util.module_from_spec(launch_spec);launch_spec.loader.exec_module(launch)

class SetupTests(unittest.TestCase):
 def test_paths_cannot_escape(self):
  with tempfile.TemporaryDirectory() as t:
   for name in ('../outside','/absolute','a/../../outside','a\\b'):
    with self.assertRaises(ValueError):setup.safe_path(pathlib.Path(t),name)
 def test_wrong_existing_asset_is_not_overwritten(self):
  with tempfile.TemporaryDirectory() as t:
   path=pathlib.Path(t)/'asset';path.write_bytes(b'keep')
   with self.assertRaises(RuntimeError):setup.acquire({'bytes':4,'sha256':'0'*64},path,None)
   self.assertEqual(path.read_bytes(),b'keep')
 def test_verified_local_cache_avoids_network(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);cache=root/'cache';cache.mkdir();(cache/'asset').write_bytes(b'local test bytes')
   row={'destination':'asset','bytes':16,'sha256':hashlib.sha256(b'local test bytes').hexdigest()}
   setup.acquire(row,root/'dest',None,cache)
   self.assertTrue(setup.matches(root/'dest',row))
 def test_corrupted_response_never_becomes_installed_asset(self):
  class CorruptTransport:
   def open(self,*args,**kwargs):return io.BytesIO(b'corruption')
  with tempfile.TemporaryDirectory() as t:
   dest=pathlib.Path(t)/'asset'
   with self.assertRaises(RuntimeError):setup.acquire({'bytes':10,'sha256':'0'*64,'source':'https://example.invalid/asset'},dest,CorruptTransport())
   self.assertFalse(dest.exists());self.assertEqual(list(dest.parent.iterdir()),[])
 def test_http_redirect_rejected(self):
  with self.assertRaises(RuntimeError):setup.HTTPSRedirect().redirect_request(None,None,302,'',{},'http://example.invalid/asset')
 def test_inventory_is_version_pinned(self):
  model,rows=setup.inventory()
  self.assertEqual(model['repository'],'mlx-community/Qwen3-1.7B-4bit')
  self.assertEqual(model['revision'],'3b1b1768f8f8cf8351c712464f906e86c2b8269e')
  self.assertTrue(all(len(row['sha256'])==64 and row['bytes']>0 and row['source'].startswith('https://') for row in rows))
 def test_launcher_rejects_traversal_before_writing(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);archive=root/'source.zip';dest=root/'dest'
   with zipfile.ZipFile(archive,'w') as z:z.writestr('../outside','invalid')
   with self.assertRaises(RuntimeError):launch.extract(archive,dest)
   self.assertFalse(dest.exists());self.assertFalse((root/'outside').exists())
 def test_launcher_rejects_corruption_before_writing(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);archive=root/'source.zip';dest=root/'dest'
   with zipfile.ZipFile(archive,'w') as z:
    z.writestr('file','changed');z.writestr('SOURCE-INVENTORY.json',json.dumps({'files':[{'path':'file','bytes':7,'sha256':'0'*64}]}))
   with self.assertRaises(RuntimeError):launch.extract(archive,dest)
   self.assertFalse(dest.exists())

class PrerequisiteTests(unittest.TestCase):
 def test_installed_rust_is_found_without_reinstall(self):
  with tempfile.TemporaryDirectory() as t:
   cargo=pathlib.Path(t)/'bin';cargo.mkdir()
   with mock.patch.dict(os.environ,{'CARGO_HOME':t,'PATH':'/usr/bin'}), mock.patch.object(launch,'rust_ready',return_value=True):
    launch.ensure_rust(None)
    self.assertEqual(os.environ['PATH'].split(os.pathsep)[0],str(cargo))
 def test_failed_rust_download_never_executes_installer(self):
  opener=mock.Mock();opener.open.side_effect=OSError('blocked')
  with mock.patch.dict(os.environ,clear=False), mock.patch.object(launch,'rust_ready',return_value=False), mock.patch.object(launch.subprocess,'run') as run:
   with self.assertRaisesRegex(RuntimeError,'Rust installation failed'):launch.ensure_rust(opener)
   run.assert_not_called()
 def test_proxy_html_is_not_executed(self):
  opener=mock.Mock();opener.open.return_value=io.BytesIO(b'<html>Access denied</html>')
  with mock.patch.dict(os.environ,clear=False), mock.patch.object(launch,'rust_ready',return_value=False), mock.patch.object(launch.subprocess,'run') as run:
   with self.assertRaises(RuntimeError):launch.ensure_rust(opener)
   run.assert_not_called()
 def test_rust_install_is_checked_and_updates_current_path(self):
  opener=mock.Mock();opener.open.return_value=io.BytesIO(b'#!/bin/sh\n# test fixture; never executed\n')
  with tempfile.TemporaryDirectory() as t, mock.patch.dict(os.environ,{'CARGO_HOME':t}), mock.patch.object(launch,'rust_ready',side_effect=[False,True]), mock.patch.object(launch.subprocess,'run') as run:
   launch.ensure_rust(opener)
   command=run.call_args.args[0]
   self.assertEqual(command[2:],['-y','--profile','minimal','--default-toolchain','stable','--no-modify-path'])
   self.assertTrue(run.call_args.kwargs['check'])
   self.assertEqual(os.environ['PATH'].split(os.pathsep)[0],str(pathlib.Path(t)/'bin'))
 def test_unusable_rust_after_install_stops(self):
  opener=mock.Mock();opener.open.return_value=io.BytesIO(b'#!/bin/sh\n')
  with mock.patch.dict(os.environ,clear=False), mock.patch.object(launch,'rust_ready',return_value=False), mock.patch.object(launch.subprocess,'run'):
   with self.assertRaisesRegex(RuntimeError,'did not become usable'):launch.ensure_rust(opener)
 def test_automatic_proxy_requires_explicit_configuration(self):
  with mock.patch.object(launch.subprocess,'run',return_value=mock.Mock(stdout='ProxyAutoConfigEnable : 1')):
   with self.assertRaisesRegex(RuntimeError,'PAC/WPAD'):launch.configure_network()
 def test_explicit_proxy_applies_to_rust_and_cargo(self):
  with mock.patch.dict(os.environ,{'NO_PROXY':'*'}), mock.patch.object(launch.subprocess,'run',return_value=mock.Mock(stdout='ProxyAutoConfigEnable : 1')):
   launch.configure_network('http://proxy.example:8080')
   self.assertEqual(os.environ['HTTPS_PROXY'],'http://proxy.example:8080')
   self.assertEqual(os.environ['CARGO_HTTP_PROXY'],'http://proxy.example:8080')
   self.assertNotIn('NO_PROXY',os.environ)
 def test_proxy_credentials_are_rejected(self):
  with mock.patch.object(launch.subprocess,'run',return_value=mock.Mock(stdout='')):
   with self.assertRaises(RuntimeError):launch.configure_network('http://user:secret@proxy.example:8080')
 def test_rust_http_redirect_is_rejected(self):
  with self.assertRaises(RuntimeError):launch.SecureRedirect().redirect_request(None,None,302,'',{},'http://example.invalid')
 def test_shell_plan_needs_no_python_and_makes_no_changes(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);script=pathlib.Path(__file__).resolve().parents[1]/'setup/Setup.command'
   (root/'Setup.command').write_bytes(script.read_bytes());(root/'source-release.json').write_text('{}')
   before=set(root.iterdir())
   result=subprocess.run(['/bin/bash',str(root/'Setup.command'),'--plan'],capture_output=True,text=True,check=True)
   self.assertIn('No changes made',result.stdout);self.assertEqual(before,set(root.iterdir()))

if __name__=='__main__':unittest.main()

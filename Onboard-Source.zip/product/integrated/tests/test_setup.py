"""Verify setup integrity/failure behavior without fabricated remote successes."""
import hashlib, importlib.util, io, pathlib, tempfile, unittest
import json,zipfile

spec=importlib.util.spec_from_file_location('setup_local',pathlib.Path(__file__).resolve().parents[1]/'tools/setup_local.py')
setup=importlib.util.module_from_spec(spec);spec.loader.exec_module(setup)
launch_spec=importlib.util.spec_from_file_location('setup_launch',pathlib.Path(__file__).resolve().parents[1]/'setup/launch.py')
launch=importlib.util.module_from_spec(launch_spec);launch_spec.loader.exec_module(launch)

class SetupTests(unittest.TestCase):
 def test_paths_cannot_escape(self):
  with tempfile.TemporaryDirectory() as t:
   for name in ('../outside','/absolute','a/../../outside','a\\b'):
    with self.assertRaises(ValueError):setup.safe_path(pathlib.Path(t),name)
 def test_wrong_existing_asset_is_not_overwritten(self):
  with tempfile.TemporaryDirectory() as t:
   path=pathlib.Path(t)/'asset';path.write_bytes(b'keep')
   with self.assertRaises(RuntimeError):setup.acquire({'bytes':4,'sha256':'0'*64},path,None)
   self.assertEqual(path.read_bytes(),b'keep')
 def test_verified_local_cache_avoids_network(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);cache=root/'cache';cache.mkdir();(cache/'asset').write_bytes(b'local test bytes')
   row={'destination':'asset','bytes':16,'sha256':hashlib.sha256(b'local test bytes').hexdigest()}
   setup.acquire(row,root/'dest',None,cache)
   self.assertTrue(setup.matches(root/'dest',row))
 def test_corrupted_response_never_becomes_installed_asset(self):
  class CorruptTransport:
   def open(self,*args,**kwargs):return io.BytesIO(b'corruption')
  with tempfile.TemporaryDirectory() as t:
   dest=pathlib.Path(t)/'asset'
   with self.assertRaises(RuntimeError):setup.acquire({'bytes':10,'sha256':'0'*64,'source':'https://example.invalid/asset'},dest,CorruptTransport())
   self.assertFalse(dest.exists());self.assertEqual(list(dest.parent.iterdir()),[])
 def test_http_redirect_rejected(self):
  with self.assertRaises(RuntimeError):setup.HTTPSRedirect().redirect_request(None,None,302,'',{},'http://example.invalid/asset')
 def test_inventory_is_version_pinned(self):
  model,rows=setup.inventory()
  self.assertEqual(model['repository'],'mlx-community/Qwen3-1.7B-4bit')
  self.assertEqual(model['revision'],'3b1b1768f8f8cf8351c712464f906e86c2b8269e')
  self.assertTrue(all(len(row['sha256'])==64 and row['bytes']>0 and row['source'].startswith('https://') for row in rows))
 def test_launcher_rejects_traversal_before_writing(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);archive=root/'source.zip';dest=root/'dest'
   with zipfile.ZipFile(archive,'w') as z:z.writestr('../outside','invalid')
   with self.assertRaises(RuntimeError):launch.extract(archive,dest)
   self.assertFalse(dest.exists());self.assertFalse((root/'outside').exists())
 def test_launcher_rejects_corruption_before_writing(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);archive=root/'source.zip';dest=root/'dest'
   with zipfile.ZipFile(archive,'w') as z:
    z.writestr('file','changed');z.writestr('SOURCE-INVENTORY.json',json.dumps({'files':[{'path':'file','bytes':7,'sha256':'0'*64}]}))
   with self.assertRaises(RuntimeError):launch.extract(archive,dest)
   self.assertFalse(dest.exists())

if __name__=='__main__':unittest.main()

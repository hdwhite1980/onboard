"""Verify setup integrity/failure behavior without fabricated remote successes."""
import hashlib, importlib.util, io, pathlib, tempfile, unittest
import json,zipfile,os,subprocess
from unittest import mock

spec=importlib.util.spec_from_file_location('setup_local',pathlib.Path(__file__).resolve().parents[1]/'tools/setup_local.py')
setup=importlib.util.module_from_spec(spec);spec.loader.exec_module(setup)
launch_spec=importlib.util.spec_from_file_location('setup_launch',pathlib.Path(__file__).resolve().parents[1]/'setup/launch.py')
launch=importlib.util.module_from_spec(launch_spec);launch_spec.loader.exec_module(launch)

class SetupTests(unittest.TestCase):
 def test_paths_cannot_escape(self):
  with tempfile.TemporaryDirectory() as t:
   for name in ('../outside','/absolute','a/../../outside','a\\b'):
    with self.assertRaises(ValueError):setup.safe_path(pathlib.Path(t),name)
 def test_wrong_existing_asset_is_not_overwritten(self):
  with tempfile.TemporaryDirectory() as t:
   path=pathlib.Path(t)/'asset';path.write_bytes(b'keep')
   with self.assertRaises(RuntimeError):setup.acquire({'bytes':4,'sha256':'0'*64},path,None)
   self.assertEqual(path.read_bytes(),b'keep')
 def test_verified_local_cache_avoids_network(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);cache=root/'cache';cache.mkdir();(cache/'asset').write_bytes(b'local test bytes')
   row={'destination':'asset','bytes':16,'sha256':hashlib.sha256(b'local test bytes').hexdigest()}
   setup.acquire(row,root/'dest',None,cache)
   self.assertTrue(setup.matches(root/'dest',row))
 def test_corrupted_response_never_becomes_installed_asset(self):
  class CorruptTransport:
   def open(self,*args,**kwargs):return io.BytesIO(b'corruption')
  with tempfile.TemporaryDirectory() as t:
   dest=pathlib.Path(t)/'asset'
   with self.assertRaises(RuntimeError):setup.acquire({'bytes':10,'sha256':'0'*64,'source':'https://example.invalid/asset'},dest,CorruptTransport())
   self.assertFalse(dest.exists());self.assertEqual(list(dest.parent.iterdir()),[])
 def test_http_redirect_rejected(self):
  with self.assertRaises(RuntimeError):setup.HTTPSRedirect().redirect_request(None,None,302,'',{},'http://example.invalid/asset')
 def test_inventory_is_version_pinned(self):
  model,rows=setup.inventory()
  self.assertEqual(model['repository'],'mlx-community/Qwen3-1.7B-4bit')
  self.assertEqual(model['revision'],'3b1b1768f8f8cf8351c712464f906e86c2b8269e')
  self.assertTrue(all(len(row['sha256'])==64 and row['bytes']>0 and row['source'].startswith('https://') for row in rows))
 def test_launcher_rejects_traversal_before_writing(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);archive=root/'source.zip';dest=root/'dest'
   with zipfile.ZipFile(archive,'w') as z:z.writestr('../outside','invalid')
   with self.assertRaises(RuntimeError):launch.extract(archive,dest)
   self.assertFalse(dest.exists());self.assertFalse((root/'outside').exists())
 def test_launcher_rejects_corruption_before_writing(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);archive=root/'source.zip';dest=root/'dest'
   with zipfile.ZipFile(archive,'w') as z:
    z.writestr('file','changed');z.writestr('SOURCE-INVENTORY.json',json.dumps({'files':[{'path':'file','bytes':7,'sha256':'0'*64}]}))
   with self.assertRaises(RuntimeError):launch.extract(archive,dest)
   self.assertFalse(dest.exists())

class PinnedPythonTests(unittest.TestCase):
 def fixture(self,root):
  bundled=root/'python-local';bundled.mkdir();(bundled/'python3.12').write_bytes(b'qualified test binary')
  return {'sourceExecutableSHA256':hashlib.sha256(b'publisher test binary').hexdigest(),'packagedExecutableSHA256':hashlib.sha256(b'qualified test binary').hexdigest()}
 def test_checked_copy_does_not_resign(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);record=self.fixture(root);dest=root/'installed'
   with mock.patch.object(setup,'ASSETS',root),mock.patch.object(setup,'run') as run:
    setup.install_pinned_executable(dest,b'publisher test binary',record)
   self.assertEqual(dest.read_bytes(),b'qualified test binary')
   self.assertEqual(run.call_args.args[0][:3],['/usr/bin/codesign','--verify','--strict'])
 def test_corrupted_bundle_is_not_installed(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);record=self.fixture(root);dest=root/'installed';(root/'python-local/python3.12').write_bytes(b'corrupt')
   with mock.patch.object(setup,'ASSETS',root),mock.patch.object(setup,'run') as run:
    with self.assertRaises(RuntimeError):setup.install_pinned_executable(dest,b'publisher test binary',record)
    run.assert_not_called()
   self.assertFalse(dest.exists())
 def test_corrupted_publisher_is_not_installed(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);record=self.fixture(root);dest=root/'installed'
   with mock.patch.object(setup,'ASSETS',root),mock.patch.object(setup,'run') as run:
    with self.assertRaises(RuntimeError):setup.install_pinned_executable(dest,b'wrong publisher',record)
    run.assert_not_called()
   self.assertFalse(dest.exists())
 def test_mismatched_python_is_backed_up_and_repaired(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);record=self.fixture(root);dest=root/'installed';dest.write_bytes(b'previous signing result')
   with mock.patch.object(setup,'ASSETS',root),mock.patch.object(setup,'P',root),mock.patch.object(setup,'run'):
    setup.install_pinned_executable(dest,b'publisher test binary',record)
   self.assertEqual(dest.read_bytes(),b'qualified test binary')
   backups=list((root/'evidence/setup-history').rglob('previous-python3.12'))
   self.assertEqual(len(backups),1);self.assertEqual(backups[0].read_bytes(),b'previous signing result')
 def test_signature_failure_never_publishes_copy(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);record=self.fixture(root);dest=root/'installed'
   with mock.patch.object(setup,'ASSETS',root),mock.patch.object(setup,'run',side_effect=subprocess.CalledProcessError(1,'codesign')):
    with self.assertRaises(subprocess.CalledProcessError):setup.install_pinned_executable(dest,b'publisher test binary',record)
   self.assertFalse(dest.exists());self.assertFalse(list(root.glob('.python-*')))

class UpdateTests(unittest.TestCase):
 def archive(self,root,files):
  archive=root/'release.zip'
  with zipfile.ZipFile(archive,'w') as z:
   rows=[]
   for name,data in files.items():
    z.writestr(name,data);rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
   z.writestr('SOURCE-INVENTORY.json',json.dumps({'files':rows}))
  return archive
 def test_update_preserves_state_assets_and_unchanged_source(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);dest=root/'installed'
   launch.extract(self.archive(root,{'code.py':b'old','same.py':b'same'}),dest)
   (dest/'state').mkdir();(dest/'state/settings.json').write_bytes(b'private settings')
   (dest/'model').write_bytes(b'verified separately');before=(dest/'same.py').stat().st_mtime_ns
   launch.extract(self.archive(root,{'code.py':b'new','same.py':b'same','added.py':b'added'}),dest)
   self.assertEqual((dest/'code.py').read_bytes(),b'new');self.assertEqual((dest/'same.py').stat().st_mtime_ns,before)
   self.assertEqual((dest/'state/settings.json').read_bytes(),b'private settings');self.assertEqual((dest/'model').read_bytes(),b'verified separately')
   self.assertEqual(next((dest/'setup-history').rglob('code.py')).read_bytes(),b'old')
 def test_modified_source_blocks_before_any_replacement(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);dest=root/'installed'
   launch.extract(self.archive(root,{'a.py':b'old','b.py':b'old'}),dest);(dest/'b.py').write_bytes(b'local edit')
   with self.assertRaisesRegex(RuntimeError,'Locally modified'):launch.extract(self.archive(root,{'a.py':b'new','b.py':b'new'}),dest)
   self.assertEqual((dest/'a.py').read_bytes(),b'old');self.assertEqual((dest/'b.py').read_bytes(),b'local edit')
 def test_existing_unmanaged_directory_is_preserved(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);dest=root/'installed';dest.mkdir();(dest/'user').write_bytes(b'keep')
   with self.assertRaises(RuntimeError):launch.extract(self.archive(root,{'code.py':b'new'}),dest)
   self.assertEqual((dest/'user').read_bytes(),b'keep')
 def test_existing_symlink_does_not_escape(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);dest=root/'installed';outside=root/'outside';outside.mkdir()
   launch.extract(self.archive(root,{'code.py':b'old'}),dest);(dest/'link').symlink_to(outside)
   with self.assertRaises(RuntimeError):launch.extract(self.archive(root,{'link/code.py':b'new'}),dest)
   self.assertEqual(list(outside.iterdir()),[])
 def test_detects_installed_custom_root(self):
  with tempfile.TemporaryDirectory() as t:
   home=pathlib.Path(t);dest=home/'custom';dest.mkdir();(dest/'SOURCE-INVENTORY.json').write_text('{}')
   config=home/'Applications/Onboard AI.app/Contents/Resources/local.json';config.parent.mkdir(parents=True);config.write_text(json.dumps({'root':str(dest)}))
   self.assertEqual(launch.installation_destination(home=home),dest.resolve())
 def test_detects_partial_default_install(self):
  with tempfile.TemporaryDirectory() as t:
   home=pathlib.Path(t);dest=home/'OnboardAI';dest.mkdir();(dest/'SOURCE-INVENTORY.json').write_text('{}')
   self.assertEqual(launch.installation_destination(home=home),dest)
 def test_qualification_is_archived_without_deleting_evidence(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);e=root/'evidence/runtime-repair/monitor';e.mkdir(parents=True);(e/'result.json').write_text('previous record')
   with mock.patch.object(setup,'P',root):setup.preserve_qualification()
   self.assertFalse(e.exists());self.assertEqual(next((root/'evidence/setup-history').rglob('result.json')).read_text(),'previous record')

class PrerequisiteTests(unittest.TestCase):
 def test_installed_rust_is_found_without_reinstall(self):
  with tempfile.TemporaryDirectory() as t:
   cargo=pathlib.Path(t)/'bin';cargo.mkdir()
   with mock.patch.dict(os.environ,{'CARGO_HOME':t,'PATH':'/usr/bin'}), mock.patch.object(launch,'rust_ready',return_value=True):
    launch.ensure_rust(None)
    self.assertEqual(os.environ['PATH'].split(os.pathsep)[0],str(cargo))
 def test_failed_rust_download_never_executes_installer(self):
  opener=mock.Mock();opener.open.side_effect=OSError('blocked')
  with mock.patch.dict(os.environ,clear=False), mock.patch.object(launch,'rust_ready',return_value=False), mock.patch.object(launch.subprocess,'run') as run:
   with self.assertRaisesRegex(RuntimeError,'Rust installation failed'):launch.ensure_rust(opener)
   run.assert_not_called()
 def test_proxy_html_is_not_executed(self):
  opener=mock.Mock();opener.open.return_value=io.BytesIO(b'<html>Access denied</html>')
  with mock.patch.dict(os.environ,clear=False), mock.patch.object(launch,'rust_ready',return_value=False), mock.patch.object(launch.subprocess,'run') as run:
   with self.assertRaises(RuntimeError):launch.ensure_rust(opener)
   run.assert_not_called()
 def test_rust_install_is_checked_and_updates_current_path(self):
  opener=mock.Mock();opener.open.return_value=io.BytesIO(b'#!/bin/sh\n# test fixture; never executed\n')
  with tempfile.TemporaryDirectory() as t, mock.patch.dict(os.environ,{'CARGO_HOME':t}), mock.patch.object(launch,'rust_ready',side_effect=[False,True]), mock.patch.object(launch.subprocess,'run') as run:
   launch.ensure_rust(opener)
   command=run.call_args.args[0]
   self.assertEqual(command[2:],['-y','--profile','minimal','--default-toolchain','stable','--no-modify-path'])
   self.assertTrue(run.call_args.kwargs['check'])
   self.assertEqual(os.environ['PATH'].split(os.pathsep)[0],str(pathlib.Path(t)/'bin'))
 def test_unusable_rust_after_install_stops(self):
  opener=mock.Mock();opener.open.return_value=io.BytesIO(b'#!/bin/sh\n')
  with mock.patch.dict(os.environ,clear=False), mock.patch.object(launch,'rust_ready',return_value=False), mock.patch.object(launch.subprocess,'run'):
   with self.assertRaisesRegex(RuntimeError,'did not become usable'):launch.ensure_rust(opener)
 def test_automatic_proxy_requires_explicit_configuration(self):
  with mock.patch.object(launch.subprocess,'run',return_value=mock.Mock(stdout='ProxyAutoConfigEnable : 1')):
   with self.assertRaisesRegex(RuntimeError,'PAC/WPAD'):launch.configure_network()
 def test_explicit_proxy_applies_to_rust_and_cargo(self):
  with mock.patch.dict(os.environ,{'NO_PROXY':'*'}), mock.patch.object(launch.subprocess,'run',return_value=mock.Mock(stdout='ProxyAutoConfigEnable : 1')):
   launch.configure_network('http://proxy.example:8080')
   self.assertEqual(os.environ['HTTPS_PROXY'],'http://proxy.example:8080')
   self.assertEqual(os.environ['CARGO_HTTP_PROXY'],'http://proxy.example:8080')
   self.assertNotIn('NO_PROXY',os.environ)
 def test_proxy_credentials_are_rejected(self):
  with mock.patch.object(launch.subprocess,'run',return_value=mock.Mock(stdout='')):
   with self.assertRaises(RuntimeError):launch.configure_network('http://user:secret@proxy.example:8080')
 def test_rust_http_redirect_is_rejected(self):
  with self.assertRaises(RuntimeError):launch.SecureRedirect().redirect_request(None,None,302,'',{},'http://example.invalid')
 def test_shell_plan_needs_no_python_and_makes_no_changes(self):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t);script=pathlib.Path(__file__).resolve().parents[1]/'setup/Setup.command'
   (root/'Setup.command').write_bytes(script.read_bytes());(root/'source-release.json').write_text('{}')
   before=set(root.iterdir())
   result=subprocess.run(['/bin/bash',str(root/'Setup.command'),'--plan'],capture_output=True,text=True,check=True)
   self.assertIn('No changes made',result.stdout);self.assertEqual(before,set(root.iterdir()))

class ServiceUpdateTests(unittest.TestCase):
 def archive(self,root,corrupt=False):
  data=b'# fixture';name='product/integrated/service/service_control.py';archive=root/'source.zip'
  with zipfile.ZipFile(archive,'w') as z:
   z.writestr(name,data);z.writestr('SOURCE-INVENTORY.json',json.dumps({'files':[{'path':name,'bytes':len(data),'sha256':'0'*64 if corrupt else hashlib.sha256(data).hexdigest()}]}))
  return archive
 def test_update_helper_requires_matching_inventory(self):
  with tempfile.TemporaryDirectory() as t,mock.patch.object(launch.subprocess,'run') as run:
   with self.assertRaisesRegex(RuntimeError,'verification'):launch.stop_previous_from_archive(self.archive(pathlib.Path(t),True),pathlib.Path(t))
   run.assert_not_called()
 def test_update_reports_shutdown_refusal(self):
  with tempfile.TemporaryDirectory() as t,mock.patch.object(launch.subprocess,'run',return_value=subprocess.CompletedProcess([],1,'','Unrelated application preserved')):
   with self.assertRaisesRegex(RuntimeError,'Unrelated application preserved'):launch.stop_previous_from_archive(self.archive(pathlib.Path(t)),pathlib.Path(t))
 def test_update_uses_verified_isolated_helper(self):
  with tempfile.TemporaryDirectory() as t,mock.patch.object(launch.subprocess,'run',return_value=subprocess.CompletedProcess([],0,'','')) as run:
   launch.stop_previous_from_archive(self.archive(pathlib.Path(t)),pathlib.Path(t))
   self.assertEqual(run.call_args.args[0][1:3],['-I','-B'])
   self.assertEqual(run.call_args.args[0][-1],str(pathlib.Path(t)/'product/integrated/state'))

if __name__=='__main__':unittest.main()

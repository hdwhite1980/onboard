"""Routing/control fixtures only; no invented mailbox content or live acceptance claims."""
import pathlib,sys,threading,unittest
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from connectors import Failure,Graph
from tenant import discover,ENVIRONMENTS
from network import NetworkFailure
TENANT='11111111-2222-3333-4444-555555555555'
CLIENT='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
def metadata(cloud,authority=None):
 authority=authority or ENVIRONMENTS[cloud][0]
 return {'issuer':authority+'/'+TENANT+'/v2.0','token_endpoint':authority+'/'+TENANT+'/oauth2/v2.0/token','msgraph_host':ENVIRONMENTS[cloud][1].split('//')[1],'tenant_region_scope':'USGov' if cloud in ('GCC High','DoD') else 'NA','tenant_region_sub_scope':{'Commercial':'','GCC':'GCC','GCC High':'DODCON','DoD':'DOD'}[cloud]}

class TenantDiscovery(unittest.TestCase):
 def test_auto_routes_every_supported_cloud(self):
  for cloud in ENVIRONMENTS:
   with self.subTest(cloud=cloud),patch('tenant.http',return_value=metadata(cloud)) as request:
    r=discover(TENANT);self.assertEqual(r['cloud'],cloud);self.assertEqual(r['graph'],ENVIRONMENTS[cloud][1]);self.assertEqual(request.call_count,2 if cloud in ('GCC High','DoD') else 1)
    self.assertTrue(all(not c.kwargs.get('headers') and c.kwargs['proxy']=='' for c in request.call_args_list))
 def test_explicit_environment_is_verified(self):
  with patch('tenant.http',return_value=metadata('Commercial')):
   with self.assertRaisesRegex(Failure,'identifies this tenant'):discover(TENANT,'GCC')
 def test_government_subtype_required(self):
  m=metadata('DoD');m.pop('tenant_region_sub_scope')
  with patch('tenant.http',return_value=m),self.assertRaisesRegex(Failure,'did not identify'):discover(TENANT)
 def test_cross_cloud_conflict_is_rejected(self):
  m=metadata('DoD');m['msgraph_host']='graph.microsoft.com'
  with patch('tenant.http',return_value=m),self.assertRaisesRegex(Failure,'conflicting'):discover(TENANT)
 def test_wrong_tenant_or_token_destination_rejected(self):
  for key,value in [('issuer','https://login.microsoftonline.com/wrong/v2.0'),('token_endpoint','https://attacker.invalid/token')]:
   m=metadata('Commercial');m[key]=value
   with patch('tenant.http',return_value=m),self.assertRaisesRegex(Failure,'did not match'):discover(TENANT)
 def test_government_confirmation_must_agree(self):
  with patch('tenant.http',side_effect=[metadata('DoD'),metadata('GCC High')]),self.assertRaisesRegex(Failure,'disagree'):discover(TENANT)
 def test_proxy_error_stops_without_cloud_fallback(self):
  with patch('tenant.http',side_effect=NetworkFailure('PROXY_AUTH_REQUIRED','Proxy requires authentication')) as request:
   with self.assertRaises(NetworkFailure):discover(TENANT,proxy='http://proxy.example:8080')
   self.assertEqual(request.call_count,1);self.assertEqual(request.call_args.kwargs['proxy'],'http://proxy.example:8080')
 def test_invalid_tenant_never_requests_network(self):
  with patch('tenant.http') as request:
   for value in ('https://attacker.invalid','common','someone@example.mil','',None):
    with self.assertRaises(Failure):discover(value)
   request.assert_not_called()
 def test_untrusted_graph_host_rejected(self):
  m=metadata('Commercial');m['msgraph_host']='graph.microsoft.com.attacker.invalid'
  with patch('tenant.http',return_value=m),self.assertRaises(Failure):discover(TENANT)
 def test_no_subtype_downgrade_on_unknown_environment(self):
  m=metadata('Commercial');m['tenant_region_sub_scope']='UNRECOGNIZED'
  with patch('tenant.http',return_value=m),self.assertRaises(Failure):discover(TENANT)
 def test_only_metadata_is_used_for_discovery(self):
  with patch('tenant.http',return_value=metadata('Commercial')) as request:
   discover(TENANT)
   self.assertEqual(request.call_args.args,('https://login.microsoftonline.com/'+TENANT+'/v2.0/.well-known/openid-configuration',))

class GraphRouting(unittest.TestCase):
 def test_detection_selects_token_authority_and_scopes(self):
  for cloud in ENVIRONMENTS:
   graph=Graph();config={'tenant':TENANT,'client':CLIENT,'cloud':'Auto','calendar':True,'proxy':'http://proxy.example:8080'}
   response={'user_code':'control-fixture','verification_uri':ENVIRONMENTS[cloud][0]+'/deviceauth','expires_in':60}
   with patch('tenant.http',return_value=metadata(cloud)),patch('connectors.http',return_value=response) as request:
    result=graph.start(config)
    self.assertEqual(result['cloud'],cloud);self.assertTrue(request.call_args.args[0].startswith(ENVIRONMENTS[cloud][0]+'/'+TENANT+'/'))
    from urllib.parse import parse_qs
    fields=parse_qs(request.call_args.args[2].decode());self.assertEqual(fields['scope'][0],ENVIRONMENTS[cloud][1]+'/User.Read '+ENVIRONMENTS[cloud][1]+'/Calendars.Read')
    self.assertEqual(request.call_args.kwargs['proxy'],config['proxy'])
 def test_discovery_failure_clears_previous_token_without_requesting_new_token(self):
  graph=Graph();graph.token='control-fixture'
  with patch('tenant.http',side_effect=Failure('blocked')),patch('connectors.http') as request:
   with self.assertRaises(Failure):graph.start({'tenant':TENANT,'client':CLIENT,'cloud':'Auto'})
   self.assertIsNone(graph.token);request.assert_not_called()
 def test_cancelled_discovery_cannot_start_signin(self):
  graph=Graph()
  def cancel(*a,**k):graph.disconnect();return metadata('Commercial')
  with patch('tenant.http',side_effect=cancel),patch('connectors.http') as request:
   with self.assertRaisesRegex(Failure,'cancelled'):graph.start({'tenant':TENANT,'client':CLIENT,'cloud':'Auto'})
   request.assert_not_called()
 def test_government_token_never_retries_commercial_graph(self):
  import time
  graph=Graph();graph.token='control-fixture';graph.expires=time.monotonic()+60;graph.config={'graph':ENVIRONMENTS['DoD'][1]}
  with patch('connectors.http',side_effect=Failure('denied')) as request:
   with self.assertRaises(Failure):graph.get('me')
   self.assertEqual(request.call_count,1);self.assertTrue(request.call_args.args[0].startswith('https://dod-graph.microsoft.us/'))

if __name__=='__main__':unittest.main()

"""Authentication control fixtures only; no Microsoft credentials or live account."""
import pathlib,sys,threading,unittest
from unittest.mock import Mock,patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from connections import Connections
from connectors import Failure
from host import Host,ORIGIN
class Approval(unittest.TestCase):
 def setUp(self):
  self.h=Host.__new__(Host);self.h.lock=threading.RLock();self.h.stopping=False;self.h.config={};self.h.sessions={};self.h.pairs={};self.h.jobs={}
  self.h.graph=Mock();self.h.graph.identity.return_value=('tenant','user',1);self.h.graph.account={'mail':'test@example.invalid','displayName':'Fixture'}
  self.c=self.h.connections=Connections(self.h)
 def request(self,app='outlook'):
  return self.c.request({'application':app,'email':'test@example.invalid','tenant':'tenant','account':'user'},ORIGIN)
 def test_matching_accounts_cannot_authorize_without_native_approval(self):
  for app in ('outlook','teams'):
   self.h.sessions.clear();r=self.request(app);self.assertEqual(self.c.status(r,ORIGIN),{'state':'pending'});self.assertFalse(self.h.sessions)
   self.h.admin({'op':'connection_decide','id':r['id'],'approve':True});result=self.c.status(r,ORIGIN)
   self.assertEqual(result['state'],'connected');self.assertIsNone(result['expires_in']);self.assertEqual(self.h.sessions[result['token']]['app'],app)
   with self.assertRaises(Failure):self.c.status(r,ORIGIN)
 def test_wrong_account_origin_and_secret_are_rejected(self):
  for r in ({'application':'outlook','email':''},{'application':'outlook','email':'other@example.invalid'},{'application':'teams','tenant':'other','account':'user'}):
   with self.assertRaises(Failure):self.c.request(r,ORIGIN)
  r=self.request()
  with self.assertRaises(Failure):self.c.status(r,'https://unapproved.invalid')
  with self.assertRaises(Failure):self.c.status(dict(r,secret='wrong'),ORIGIN)
  self.assertFalse(self.h.sessions)
 def test_account_change_between_approval_and_collection_is_rejected(self):
  r=self.request();self.c.decide({'id':r['id'],'approve':True});self.h.graph.identity.return_value=('tenant','other',2)
  with self.assertRaises(Failure):self.c.status(r,ORIGIN)
  self.assertFalse(self.h.sessions)
 def test_decline_cancel_and_invalidation_never_mint_session(self):
  r=self.request();self.c.decide({'id':r['id'],'approve':False});self.assertEqual(self.c.status(r,ORIGIN)['state'],'declined')
  r=self.request();self.c.status(r,ORIGIN,cancel=True)
  with self.assertRaises(Failure):self.c.decide({'id':r['id'],'approve':True})
  r=self.request();self.h.invalidate();self.assertFalse(self.c.pending()['requests']);self.assertFalse(self.h.sessions)
 def test_pending_requests_bounded_and_abandoned_requests_expire(self):
  with patch('connections.time.monotonic',return_value=1):
   for i in range(8):self.request()
   with self.assertRaises(Failure):self.request()
  with patch('connections.time.monotonic',return_value=602):self.assertEqual(self.c.pending()['requests'],[])
 def test_native_list_contains_no_poll_secret(self):
  r=self.request();item=self.h.admin({'op':'connection_requests'})['requests'][0]
  self.assertEqual(item['id'],r['id']);self.assertNotIn('secret',item)
if __name__=='__main__':unittest.main()

"""HTTP boundary regressions without network or account access."""
import io,pathlib,sys,types,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from host import Web

class TeamsWeb(unittest.TestCase):
 def handler(self,path='/teams-host.js'):
  h=object.__new__(Web);h.headers={'Host':'localhost:38473','Origin':'https://untrusted.example'};h.path=path
  h.server=types.SimpleNamespace(host=types.SimpleNamespace(config={},resources=pathlib.Path(__file__).resolve().parents[1]))
  h.wfile=io.BytesIO();h.response_headers={};h.send_response=lambda code:setattr(h,'code',code);h.send_header=lambda k,v:h.response_headers.update({k:v});h.end_headers=lambda:None
  return h
 def test_teams_parents_allowed_without_loosening_api_origins(self):
  h=self.handler();h.send(200,{})
  csp=h.response_headers['Content-Security-Policy'];ancestors=csp.split('frame-ancestors ')[1].split(';')[0].split()
  for origin in ('https://teams.microsoft.com','https://*.teams.microsoft.com','https://*.cloud.microsoft'):self.assertIn(origin,ancestors)
  self.assertNotIn('*',ancestors);self.assertIn("object-src 'none'",csp);self.assertNotIn('Access-Control-Allow-Origin',h.response_headers)
 def test_sdk_bootstrap_is_served_without_cache(self):
  h=self.handler();h.do_GET();self.assertEqual(h.code,200);self.assertIn(b'OnboardTeams',h.wfile.getvalue());self.assertEqual(h.response_headers['Cache-Control'],'no-store')
 def test_outlook_allows_exact_microsoft_dependency_only(self):
  url='https://ajax.aspnetcdn.com/ajax/3.5/MicrosoftAjax.js'
  outlook=self.handler('/outlook.html?_host_Info=Outlook');outlook.send(200,{})
  csp=outlook.response_headers['Content-Security-Policy'];self.assertIn(url,csp);self.assertNotIn("'unsafe-eval'",csp);self.assertNotIn("'unsafe-inline'",csp)
  teams=self.handler('/teams.html');teams.send(200,{});self.assertNotIn('ajax.aspnetcdn.com',teams.response_headers['Content-Security-Policy'])
 def test_outlook_helper_is_served(self):
  h=self.handler('/outlook-host.js');h.do_GET();self.assertEqual(h.code,200);self.assertIn(b'OnboardOutlook',h.wfile.getvalue())
 def test_arbitrary_script_is_not_exposed(self):
  h=self.handler('/service/host.py');h.do_GET();self.assertEqual(h.code,404)

if __name__=='__main__':unittest.main()

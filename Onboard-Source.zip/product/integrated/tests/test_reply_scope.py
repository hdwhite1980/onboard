"""Explicit control fixtures for reply scope and promotional-noise filtering; no live email."""
import json,pathlib,sys,threading,unittest
from unittest.mock import Mock,patch
P=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P/'service'));sys.path.insert(0,str(P/'local'))
from connectors import Graph,Failure
from host import Host
from context_packet import pack,ContextLimit,mail_blocks
from test_context_packet import ByteTokenizer

class ReplyScope(unittest.TestCase):
    def test_reply_without_selected_context_stops_before_search_or_model(self):
        h=Host.__new__(Host)
        with self.assertRaisesRegex(Failure,'Select the opened email'):
            h.process({'owner':'paired','request':{'task':'reply','sources':[],'search_mail':True,'prompt':'suggest a reply'}})
    def test_current_message_only_never_requests_thread(self):
        g=Graph();g.config={'mail':True};g.get=Mock(return_value={'id':'opened','subject':'Budget review','body':{'content':'The proposal is not approved.'},'conversationId':'thread'})
        rows,note=g.retrieve('mail','opened',current_only=True)
        self.assertEqual(g.get.call_count,1);self.assertTrue(rows[0]['primary']);self.assertEqual(rows[0]['id'],'mail:opened')
    def host(self,explicit=False):
        h=Host.__new__(Host);h.resources=P/'build/Onboard AI.app/Contents/Resources';h.config={'public_local':True}
        h.graph=Mock();h.graph.identity.return_value=('tenant','user',1);h.sessions={'paired':{'app':'outlook'}};h.local_status=Mock(return_value={'ready':True})
        source={'id':'mail:opened','title':'Selected','text':'The proposal is not approved.','kind':'mail','primary':True}
        h.graph.retrieve.return_value=([source],'Selected only');h.graph.search_mail.return_value=([],'Explicit search')
        job={'id':'fixture','owner':'paired','identity':('tenant','user',1),'cancel':threading.Event(),'request':{'task':'reply','route':'local','public_attested':True,'search_mail':True,'search_mail_explicit':explicit,'sources':[{'kind':'mail','ref':'opened'}],'prompt':'suggest a reply'}}
        packet={'partial':False,'sources':[dict(source,alias='S1')],'included_sources':1}
        answer=json.dumps({'claims':[{'source_id':'S1','quote':source['text']}],'suggestions':'Could we review the pending proposal?'})
        with patch('local_engine.generate_grounded',return_value=(answer,packet)) as model:r=h.process(job)
        return h,r,model
    def test_old_default_search_flag_does_not_pollute_reply(self):
        h,r,model=self.host();h.graph.search_mail.assert_not_called();h.graph.retrieve.assert_called_once_with('mail','opened',current_only=True)
        self.assertEqual(r['status'],'generated');self.assertEqual(len(r['sources']),1)
    def test_explicit_related_search_is_still_available(self):
        h,r,model=self.host(True);h.graph.search_mail.assert_called_once()
    def test_generic_reply_words_do_not_become_mail_search_terms(self):
        g=Graph();g.config={'mail':True};g.get=Mock(return_value={'value':[]})
        rows,note=g.search_mail('Can you suggest a reply to this email please?');g.get.assert_not_called();self.assertEqual(rows,[])
    def test_search_requires_all_topic_terms(self):
        g=Graph();g.config={'mail':True};g.get=Mock(return_value={'value':[]})
        g.search_mail('Find relevant emails about project falcon')
        self.assertEqual(g.get.call_args.args[1]['$search'],'"project AND falcon"')

class MailNoise(unittest.TestCase):
    def setUp(self):
        self.messages=[{'role':'system','content':'Reply using evidence.'},{'role':'user','content':'Suggest a reply.'}]
        self.tracker='https://tracking.example.invalid/click?token='+'a'*1700
        self.body='Please review the budget. It is not approved.\n\n['+self.tracker+']\n\nCopyright 2026. All rights reserved.\n\nUnsubscribe from these emails.'
        self.source={'id':'mail:test-only','kind':'mail','primary':True,'text':self.body}
    def test_footer_and_link_do_not_displace_actual_request(self):
        messages,packet=pack(ByteTokenizer(),self.messages,[self.source]);joined='\n'.join(s['text'] for s in packet['sources'])
        self.assertIn('It is not approved.',joined);self.assertNotIn('Copyright',joined);self.assertNotIn('https://',joined);self.assertTrue(packet['partial'])
        self.assertEqual(packet['filtered_source_ids'],['mail:test-only'])
        for row in packet['sources']:self.assertIn(row['text'],self.body)
        self.assertEqual(self.source['text'],self.body)
    def test_link_inside_business_paragraph_keeps_exact_context_both_sides(self):
        s=dict(self.source,text='Please review the proposal. ['+self.tracker+'] It is not approved.')
        rows,filtered=mail_blocks(s,'Suggest a reply')
        self.assertTrue(filtered);self.assertIn('It is not approved.',rows);self.assertTrue(all(r in s['text'] for r in rows))
    def test_specific_link_or_footer_question_keeps_requested_material(self):
        for question in ('Explain the unsubscribe link.','What does the privacy notice say?'):
            rows,filtered=mail_blocks(self.source,question);self.assertFalse(filtered);self.assertEqual(rows,[self.body])
    def test_link_only_email_does_not_generate_reply_from_footers(self):
        with self.assertRaisesRegex(ContextLimit,'only links or standard footer'):
            pack(ByteTokenizer(),self.messages,[dict(self.source,text='['+self.tracker+']\n\nCopyright 2026.')])
    def test_regular_documents_and_ordinary_business_links_are_preserved(self):
        doc=dict(self.source,kind='document');self.assertEqual(mail_blocks(doc,'Summarize'),([self.body],False))
        body='Please review https://example.invalid/proposal. It is not approved.'
        self.assertEqual(mail_blocks(dict(self.source,text=body),'Reply'),([body],False))
    def test_primary_opened_message_wins_limited_space_over_search_match(self):
        primary=dict(self.source,text='Selected message: '+('Pending review. '*35));secondary={'id':'other','text':'Budget '+('irrelevant material. '*40)}
        messages=[self.messages[0],{'role':'user','content':'Budget'}]
        _,packet=pack(ByteTokenizer(),messages,[secondary,primary])
        self.assertIn(primary['id'],[s['id'] for s in packet['sources']])

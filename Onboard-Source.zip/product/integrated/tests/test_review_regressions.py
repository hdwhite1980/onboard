"""Isolated security regressions; no real credentials, provider, or tenant actions."""
import hashlib, importlib.util, io, json, pathlib, queue, socket, socketserver, sys, tempfile, threading, unittest, zipfile
from unittest.mock import patch
P = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(P / 'service'))
from host import Host, NativeServer, atomic
from connectors import Graph, Failure
from assistant import run_model
from local_engine import LocalUnavailable

class DispatchReview(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.host = Host(P/'build/Onboard AI.app/Contents/Resources', self.tmp.name, '/usr/bin/true')
        self.host.config.update(public_cloud=True, cloud_fallback=True, provider={'daily_requests':20,'type':'compatible-chat','model':'test'})
        self.job = {'owner':'native','identity':None,'request':{'task':'ask','route':'cloud','prompt':'public regression fixture','explicit_cloud':True,'public_attested':True,'allow_cloud':True},'cancel':threading.Event()}
    def test_settings_change_during_keychain_read_blocks_both_native_cloud_paths(self):
        for fallback in (False, True):
            with self.subTest(fallback=fallback):
                self.job['cancel'].clear()
                def key(*args):
                    self.host.config = dict(self.host.config, public_cloud=False)
                    return 'regression-not-a-key'
                self.host.config = dict(self.host.config, public_cloud=True)
                with patch.object(self.host,'vault',side_effect=key), patch.object(self.host,'local_status',return_value={'ready':True}), patch('assistant.generate',side_effect=LocalUnavailable('CONTEXT_LIMIT','test limit')), patch('assistant.cloud') as auto, patch('host.cloud') as direct:
                    with self.assertRaises(Failure):
                        if fallback:run_model(self.host,self.job,[],{})
                        else:self.host.process(self.job)
                    auto.assert_not_called(); direct.assert_not_called()
    def test_policy_revoked_during_keychain_read_blocks_dispatch(self):
        revoked = threading.Event()
        def policy(*args):
            if revoked.is_set():raise Failure('Organization policy revoked')
        def key(*args):revoked.set();return 'regression-not-a-key'
        for fallback in (False,True):
            with self.subTest(fallback=fallback):
                revoked.clear()
                with patch.object(self.host,'check_policy',side_effect=policy), patch.object(self.host,'vault',side_effect=key), patch.object(self.host,'local_status',return_value={'ready':True}), patch('assistant.generate',side_effect=LocalUnavailable('CONTEXT_LIMIT','test limit')), patch('assistant.cloud') as auto, patch('host.cloud') as direct:
                    with self.assertRaises(Failure):
                        if fallback:run_model(self.host,self.job,[],{})
                        else:self.host.process(self.job)
                    auto.assert_not_called();direct.assert_not_called()
    def test_cancel_during_direct_keychain_read_blocks_dispatch(self):
        def key(*args):self.job['cancel'].set();return 'regression-not-a-key'
        with patch.object(self.host,'vault',side_effect=key),patch('host.cloud') as dispatch:
            with self.assertRaises(Failure):self.host.process(self.job)
            dispatch.assert_not_called()
    def test_policy_revoked_while_cloud_request_is_running_withholds_result(self):
        revoked=threading.Event()
        def policy(*args):
            if revoked.is_set():raise Failure('Organization policy revoked')
        def result(*args,**kwargs):revoked.set();return ('unreleased test output',{})
        with patch.object(self.host,'check_policy',side_effect=policy),patch.object(self.host,'vault',return_value='test-only'),patch('host.cloud',side_effect=result):
            with self.assertRaisesRegex(Failure,'revoked'):self.host.process(self.job)
    def test_settings_changed_during_local_inference_withholds_result(self):
        def result(*args,**kwargs):self.host.config=dict(self.host.config);return 'unreleased test output'
        with patch.object(self.host,'local_status',return_value={'ready':True}),patch('assistant.generate',side_effect=result):
            with self.assertRaisesRegex(Failure,'Settings changed'):run_model(self.host,self.job,[],{})

class FileReview(unittest.TestCase):
    def test_failed_atomic_serialization_preserves_original_and_cleans_up(self):
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);target=root/'settings.json';target.write_text('original')
            with self.assertRaises(TypeError):atomic(target,object())
            self.assertEqual(target.read_text(),'original');self.assertEqual(list(root.iterdir()),[target])
    def test_atomic_write_cannot_follow_predictable_temporary_symlink(self):
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);victim=root/'keep';victim.write_text('unchanged')
            (root/'settings.tmp').symlink_to(victim)
            atomic(root/'settings.json',{'ok':True})
            self.assertEqual(victim.read_text(),'unchanged')
            self.assertEqual(json.loads((root/'settings.json').read_text()),{'ok':True})
    def test_setup_backup_cannot_escape_through_existing_symlink(self):
        spec=importlib.util.spec_from_file_location('review_launcher',P/'setup/launch.py')
        launcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(launcher)
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);dest=root/'installed';outside=root/'outside';outside.mkdir()
            def archive(data):
                path=root/'source.zip'
                with zipfile.ZipFile(path,'w') as z:
                    z.writestr('file',data);z.writestr('SOURCE-INVENTORY.json',json.dumps({'files':[{'path':'file','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}]}))
                return path
            launcher.extract(archive(b'old'),dest);(dest/'setup-history').symlink_to(outside)
            with self.assertRaises(RuntimeError):launcher.extract(archive(b'new'),dest)
            self.assertEqual((dest/'file').read_bytes(),b'old');self.assertEqual(list(outside.iterdir()),[])

class GraphDocxReview(unittest.TestCase):
    def retrieve(self,xml):
        raw=io.BytesIO()
        with zipfile.ZipFile(raw,'w') as z:z.writestr('word/document.xml',xml)
        graph=Graph();graph.config={'sharepoint_suffix':'.sharepoint.com'}
        metadata={'id':'file','name':'test.docx','size':len(raw.getvalue()),'@microsoft.graph.downloadUrl':'https://example.sharepoint.com/file'}
        with patch.object(graph,'require'),patch.object(graph,'get',return_value=metadata),patch('connectors.http',return_value=raw.getvalue()):return graph.retrieve('file','drive|file')
    def test_graph_uses_same_visible_text_parser_as_local_word(self):
        xml='<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:instrText>HIDDEN FIELD INSTRUCTION</w:instrText><w:t>Visible text</w:t></w:r></w:p></w:body></w:document>'
        rows,note=self.retrieve(xml)
        self.assertEqual(rows[0]['text'],'Visible text')
        self.assertIn('Headers',note)
    def test_doctype_is_rejected_before_any_elementtree_parse(self):
        xml='<!DOCTYPE doc [<!ENTITY sample "text">]><doc>&sample;</doc>'
        with patch('documents.ET.fromstring',side_effect=AssertionError('Unvalidated XML reached parser')):
            with self.assertRaisesRegex(Failure,'entities'):self.retrieve(xml)

class TransportReview(unittest.TestCase):
    def test_native_listener_rejects_excess_workers(self):
        release=threading.Event();started=queue.Queue()
        class SlowHandler(socketserver.BaseRequestHandler):
            def handle(self):started.put(True);release.wait(3)
        # Short path also exercises the macOS Unix socket path limit.
        with tempfile.TemporaryDirectory(dir='/tmp',prefix='onboard-review-') as directory:
            server=NativeServer(directory+'/s',SlowHandler);server.slots=threading.BoundedSemaphore(2)
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();clients=[]
            try:
                for index in range(3):
                    client=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);clients.append(client);client.settimeout(1);client.connect(directory+'/s')
                    if index<2:started.get(timeout=1)
                self.assertEqual(clients[-1].recv(1),b'');self.assertTrue(started.empty())
            finally:
                release.set()
                for client in clients:client.close()
                server.shutdown();server.server_close();thread.join(2)

if __name__=='__main__':unittest.main()

"""No-network reviewed-send controls and calendar fixtures; never sends a real message."""
import datetime as dt,json,pathlib,sys,tempfile,threading,time,unittest
from unittest.mock import Mock,patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'service'))
from messaging import Messages,free_slots,UTC
from connectors import Graph,Failure
from host import Host
USER='11111111-1111-4111-8111-111111111111';OTHER='22222222-2222-4222-8222-222222222222'
class Sending(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        h=Host.__new__(Host);h.state=pathlib.Path(tmp.name);h.lock=threading.RLock();h.graph=Graph()
        h.graph.account={'id':USER,'mail':'sender@example.invalid'};h.graph.token='unit-fixture';h.graph.expires=time.monotonic()+999
        h.graph.config={'tenant':'tenant','graph':'https://dod-graph.microsoft.us','send_email':True,'send_teams':True,'calendar':True}
        h.sessions={'paired':{'identity':h.graph.identity()}};h.jobs={'job':{'id':'job','owner':'paired','state':'complete','result':{'status':'generated','policy':{'allowed':True}}}}
        h.graph.get=Mock(return_value={'id':OTHER,'displayName':'Fixture recipient','userPrincipalName':'recipient@example.invalid'})
        h.graph.write=Mock(return_value={'id':'chat-fixture'})
        self.h=h;self.m=Messages(h)
        self.r={'job':'job','target':'email','recipient':'recipient@example.invalid','body':'Reviewed fixture text.','subject':'Fixture subject','public_attested':True}
    def review(self):return self.m.review('paired',self.r)
    def test_review_never_writes_and_exact_edited_body_is_sent_once(self):
        self.r['body']='Edited exact text.';review=self.review();self.h.graph.write.assert_not_called()
        result=self.m.send('paired',{'id':review['id'],'confirmed':True})
        self.assertEqual(result['state'],'sent');args=self.h.graph.write.call_args
        self.assertEqual(args.args[0],'me/sendMail');self.assertEqual(args.args[1]['message']['body']['content'],'Edited exact text.')
        self.assertTrue(args.kwargs['raw']);self.m.send('paired',{'id':review['id'],'confirmed':True});self.assertEqual(self.h.graph.write.call_count,1)
        receipt=next((self.h.state/'message-receipts').iterdir()).read_text();self.assertNotIn('Edited',receipt);self.assertNotIn('recipient',receipt)
    def test_no_review_or_confirmation_cannot_send(self):
        with self.assertRaises(Failure):self.m.send('paired',{'id':'invented','confirmed':True})
        review=self.review()
        with self.assertRaises(Failure):self.m.send('paired',{'id':review['id']})
        self.h.graph.write.assert_not_called()
    def test_other_session_cannot_send_even_for_same_account(self):
        review=self.review();self.h.sessions['other']={'identity':self.h.graph.identity()}
        with self.assertRaises(Failure):self.m.send('other',{'id':review['id'],'confirmed':True})
        self.h.graph.write.assert_not_called()
    def test_new_review_revokes_old_review(self):
        old=self.review();self.r['body']='New edit.';new=self.review()
        with self.assertRaises(Failure):self.m.send('paired',{'id':old['id'],'confirmed':True})
        self.h.graph.write.assert_not_called();self.assertNotEqual(new['id'],old['id'])
    def test_account_change_and_disconnect_block_send(self):
        review=self.review();self.h.graph.epoch+=1
        with self.assertRaises(Failure):self.m.send('paired',{'id':review['id'],'confirmed':True})
        self.h.graph.write.assert_not_called()
    def test_missing_write_capability_and_public_confirmation_block_review(self):
        self.h.graph.config['send_email']=False
        with self.assertRaises(Failure):self.review()
        self.h.graph.config['send_email']=True;self.r['public_attested']=False
        with self.assertRaises(Failure):self.review()
        self.h.graph.write.assert_not_called()
    def test_withheld_answer_cannot_be_sent(self):
        self.h.jobs['job']['result']['status']='source_excerpts'
        with self.assertRaises(Failure):self.review()
    def test_recipient_and_subject_injection_rejected(self):
        for key,value in [('recipient','a@example.invalid,b@example.invalid'),('recipient','a@example.invalid\r\nBcc:spy@bad.invalid'),('subject','Good\nBcc:spy@bad.invalid')]:
            with self.subTest(key=key):
                r=dict(self.r,**{key:value})
                with self.assertRaises(Failure):self.m.review('paired',r)
    def test_teams_directory_recipient_is_reviewed_before_chat_creation(self):
        self.r['target']='teams';review=self.review();self.assertIn('Fixture recipient',review['recipient']);self.h.graph.write.assert_not_called()
        self.m.send('paired',{'id':review['id'],'confirmed':True})
        create,send=self.h.graph.write.call_args_list
        self.assertEqual(create.args[0],'chats');self.assertTrue(all(x['user@odata.bind'].startswith('https://dod-graph.microsoft.us/v1.0/users(') for x in create.args[1]['members']))
        self.assertEqual(send.args[0],'chats/chat-fixture/messages');self.assertEqual(send.args[1]['body']['content'],self.r['body'])
    def test_unresolved_or_different_recipient_blocks_review(self):
        self.r['target']='teams';self.h.graph.get.return_value={'id':OTHER,'mail':'different@example.invalid'}
        with self.assertRaises(Failure):self.review()
    def test_timeout_is_not_retried(self):
        review=self.review();self.h.graph.write.side_effect=TimeoutError()
        self.assertEqual(self.m.send('paired',{'id':review['id'],'confirmed':True})['state'],'uncertain')
        self.m.send('paired',{'id':review['id'],'confirmed':True});self.assertEqual(self.h.graph.write.call_count,1)
    def test_pending_receipt_exists_before_network_call(self):
        review=self.review()
        def write(*args,**kwargs):self.assertEqual(json.loads((self.h.state/'message-receipts'/(review['id']+'.json')).read_text())['state'],'attempting')
        self.h.graph.write.side_effect=write;self.m.send('paired',{'id':review['id'],'confirmed':True})
    def test_calendar_change_blocks_dispatch(self):
        identity=self.h.graph.identity();self.m.availability['times']={'owner':'paired','identity':identity,'slots':[{'start':'a','end':'b'}],'options':{},'text':'Verified times'}
        self.r['availability']='times';review=self.review()
        self.assertIn('Verified times',review['body'])
        with patch('messaging.free_slots',return_value=[]):
            with self.assertRaisesRegex(Failure,'availability changed'):self.m.send('paired',{'id':review['id'],'confirmed':True})
        self.h.graph.write.assert_not_called()
    def test_missing_calendar_result_cannot_be_fabricated(self):
        self.r['availability']='fake'
        with self.assertRaises(Failure):self.review()
    def test_graph_write_requires_original_account_and_handles_empty_202(self):
        g=self.h.graph;g.write=Graph.write.__get__(g,Graph)
        with patch('connectors.http',return_value=b'') as request:
            self.assertEqual(g.write('me/sendMail',{},g.identity(),raw=True),b'')
            self.assertEqual(request.call_args.kwargs['timeout'],10)
            with self.assertRaises(Failure):g.write('me/sendMail',{},('different',USER,1),raw=True)
        self.assertEqual(request.call_count,1)

class Calendar(unittest.TestCase):
    def setUp(self):
        self.g=Mock();self.g.get.return_value={'value':[]}
        self.now=dt.datetime(2026,9,25,12,tzinfo=UTC)
        self.options={'date':'2026-09-25','zone':'America/New_York','duration':30,'start_hour':9,'end_hour':17}
    def event(self,start,end,status='busy'):
        return {'start':{'dateTime':start,'timeZone':'UTC'},'end':{'dateTime':end,'timeZone':'UTC'},'showAs':status}
    def test_busy_tentative_unknown_and_all_day_block_times(self):
        for status in ('busy','tentative','oof','unknown','workingElsewhere'):
            self.g.get.return_value={'value':[self.event('2026-09-25T13:00:00','2026-09-25T14:00:00',status)]}
            slots=free_slots(self.g,self.options,self.now)
            self.assertEqual(slots[0]['start'],'2026-09-25T14:00:00+00:00')
        self.g.get.return_value={'value':[self.event('2026-09-25T00:00:00','2026-09-26T04:00:00')]}
        self.assertTrue(free_slots(self.g,self.options,self.now)[0]['start'].startswith('2026-09-28'))
    def test_weekends_and_past_times_are_excluded(self):
        slots=free_slots(self.g,self.options,self.now)
        self.assertTrue(all(dt.datetime.fromisoformat(s['start']).weekday()<5 for s in slots))
        self.assertTrue(all(dt.datetime.fromisoformat(s['start'])>self.now for s in slots))
    def test_incomplete_or_invalid_calendar_does_not_claim_availability(self):
        for response in ({'value':[],'@odata.nextLink':'more'},{},{'value':[self.event('bad','bad')]}):
            self.g.get.return_value=response
            with self.assertRaises(Failure):free_slots(self.g,self.options,self.now)
    def test_dst_uses_each_days_zone_offset(self):
        self.options.update(date='2026-10-30');now=dt.datetime(2026,10,30,0,tzinfo=UTC)
        slots=free_slots(self.g,self.options,now)
        self.assertEqual(slots[0]['start'],'2026-10-30T13:00:00+00:00')
        monday=next(s for s in slots if s['start'].startswith('2026-11-02'))
        self.assertEqual(monday['start'],'2026-11-02T14:00:00+00:00')
    def test_free_and_cancelled_events_do_not_block(self):
        self.g.get.return_value={'value':[self.event('2026-09-25T13:00:00','2026-09-25T14:00:00','free')]}
        self.assertEqual(free_slots(self.g,self.options,self.now)[0]['start'],'2026-09-25T13:00:00+00:00')

import pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from package_teams_actions import make_manifest

class TeamsActionsPackageTests(unittest.TestCase):
    def test_real_registration_required_and_tab_identity_preserved(self):
        base={'id':'existing-app','staticTabs':[{'entityId':'onboard'}],'configurableTabs':[{}],'developer':{},'permissions':['identity']}
        with self.assertRaises(ValueError):make_manifest(base,'https://example.invalid','placeholder')
        m=make_manifest(base,'https://example.invalid','00000000-0000-4000-8000-000000000001')
        self.assertEqual(m['id'],base['id']);self.assertEqual(m['permissions'],['identity'])
        self.assertNotIn('composeExtensions',base)
        commands=m['composeExtensions'][0]['commands']
        self.assertEqual([c['id'] for c in commands],['summarize','reply','outlook'])
        for c in commands:self.assertTrue(c['fetchTask']);self.assertEqual(c['context'],['message','compose'])
        self.assertNotIn('bots',m)

if __name__=='__main__':unittest.main()

"""Protocol regression tests; not a live CAC or Microsoft tenant test."""
import base64,hashlib,http.client,pathlib,sys,time,unittest,urllib.parse
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'service'))
from browser_auth import BrowserAuth
from connectors import Graph,Failure
from test_tenant import metadata,TENANT,CLIENT
class CallbackTests(unittest.TestCase):
 def setUp(self):self.flow=BrowserAuth();self.addCleanup(self.cleanup)
 def cleanup(self):self.flow.close();self.flow.thread.join(3)
 def path(self,**kw):return '/onboard-signin?'+urllib.parse.urlencode(dict(state=self.flow.state,**kw))
 def test_pkce_and_real_loopback(self):
  f=self.flow;expected=base64.urlsafe_b64encode(hashlib.sha256(f.verifier.encode()).digest()).decode().rstrip('=');self.assertEqual(f.challenge,expected)
  c=http.client.HTTPConnection('127.0.0.1',f.server.server_port,timeout=3);self.addCleanup(c.close)
  c.request('GET',self.path(code='test-code'),headers={'Host':f.host});r=c.getresponse();body=r.read();self.assertEqual(r.status,200);self.assertEqual(r.getheader('Cache-Control'),'no-store');self.assertNotIn(b'test-code',body)
  result=f.take();self.assertEqual(result['code'],'test-code');self.assertTrue(result['verifier']);self.assertFalse(f.verifier)
 def test_wrong_state_host_path_duplicates_rejected(self):
  f=self.flow
  for path,host in [(self.path(code='x'),'evil.invalid'),('/other?state='+f.state+'&code=x',f.host),('/onboard-signin?state=wrong&code=x',f.host),(self.path(code='x')+'&code=y',f.host)]:
   self.assertIn(f.accept(path,host)[0],(400,404));self.assertIsNone(f.result)
 def test_denial_is_generic(self):
  f=self.flow;self.assertEqual(f.accept(self.path(error='access_denied',error_description='private details'),f.host)[0],200);self.assertEqual(f.result,{'error':True})
 def test_replay_and_cancel(self):
  f=self.flow;p=self.path(code='x');self.assertEqual(f.accept(p,f.host)[0],200);self.assertEqual(f.accept(p,f.host)[0],409);f.close();self.assertEqual(f.accept(p,f.host)[0],410)
 def test_expiry_closes_listener(self):
  f=self.flow;f.deadline=time.monotonic()-1
  with self.assertRaises(ValueError):f.take()
  f.thread.join(3);self.assertFalse(f.thread.is_alive())
class GraphBrowserTests(unittest.TestCase):
 def setUp(self):self.g=Graph();self.addCleanup(self.g.disconnect)
 def start(self,cloud='Commercial'):
  with patch('tenant.http',return_value=metadata(cloud)):
   return self.g.start({'tenant':TENANT,'client':CLIENT,'cloud':cloud,'mail':True},mode='browser')
 def test_authority_scope_and_exchange(self):
  for cloud in ('Commercial','DoD'):
   r=self.start(cloud);u=urllib.parse.urlsplit(r['authorization_uri']);q=urllib.parse.parse_qs(u.query);self.assertEqual(u.hostname,'login.microsoftonline.us' if cloud=='DoD' else 'login.microsoftonline.com');self.assertEqual(q['code_challenge_method'],['S256']);self.assertNotIn('client_secret',q);self.assertIn('/Mail.Read',q['scope'][0]);self.assertEqual(self.g.poll(),{'state':'pending'})
   f=self.g.browser_flow;v=f.verifier;f.accept('/onboard-signin?'+urllib.parse.urlencode({'state':f.state,'code':'test-code'}),f.host)
   with patch.object(self.g,'post',return_value={'token_type':'Bearer','access_token':'test-only','expires_in':3600}) as post,patch.object(self.g,'get',return_value={'id':'account'}):
    self.assertEqual(self.g.poll()['state'],'connected');fields=post.call_args.args[2];self.assertEqual(fields['code_verifier'],v);self.assertEqual(fields['grant_type'],'authorization_code')
 def test_exchange_failure_clears_session(self):
  self.start();f=self.g.browser_flow;f.accept('/onboard-signin?'+urllib.parse.urlencode({'state':f.state,'code':'test-code'}),f.host)
  with patch.object(self.g,'post',side_effect=Failure('private provider details')),self.assertRaisesRegex(Failure,'desktop redirect'):self.g.poll()
  self.assertIsNone(self.g.pending);self.assertIsNone(self.g.token)
 def test_disconnect_during_exchange_never_connects(self):
  self.start();f=self.g.browser_flow;f.accept('/onboard-signin?'+urllib.parse.urlencode({'state':f.state,'code':'test-code'}),f.host)
  def exchange(*args):self.g.disconnect();return {'token_type':'Bearer','access_token':'test-only','expires_in':3600}
  with patch.object(self.g,'post',side_effect=exchange),self.assertRaises(Failure):self.g.poll()
  self.assertIsNone(self.g.token)
 def test_restart_cancels_previous_flow(self):
  self.start();old=self.g.browser_flow;self.start();self.assertTrue(old.closed);self.assertFalse(old.verifier)
if __name__=='__main__':unittest.main()

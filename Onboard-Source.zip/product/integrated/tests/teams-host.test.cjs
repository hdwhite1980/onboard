// Control-only SDK stubs; no fabricated account data or provider responses.
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const code=fs.readFileSync(require('node:path').join(__dirname,'../web/teams-host.js'),'utf8');
function setup({mode='success',configure=false,download=false}={}){
 const calls=[];let save;
 const sdk={app:{initialize:async()=>{calls.push('initialize');if(mode==='handshake')throw Error('handshake failed');},notifyAppLoaded:()=>calls.push('loaded'),getContext:async()=>{calls.push('context');if(mode==='context')throw Error('context failed');return {};},notifySuccess:()=>calls.push('success'),notifyFailure:()=>calls.push('failure')},pages:{config:{registerOnSaveHandler:handler=>{save=handler;},setValidityState:value=>calls.push('valid:'+value),setConfig:async()=>{if(mode==='save')throw Error('save failed');}}}};
 const sandbox={URLSearchParams,location:{search:configure?'?configure=1':'',origin:'https://localhost:38473',pathname:'/teams.html'},setTimeout:(f,ms)=>setTimeout(f,mode==='timeout'?1:ms),clearTimeout};
 sandbox.document={createElement:()=>({remove:()=>calls.push('removed')}),head:{appendChild:script=>{calls.push(script.src);if(mode==='download')queueMicrotask(()=>script.onerror());else if(mode!=='timeout')queueMicrotask(()=>{sandbox.microsoftTeams=sdk;script.onload();});}}};
 if(!download)sandbox.microsoftTeams=sdk;
 vm.runInNewContext(code,sandbox);
 return {calls,initialize:sandbox.OnboardTeams.initialize,save:()=>save};
}
test('context readiness precedes Teams success',async()=>{const h=setup();await h.initialize();assert.deepEqual(h.calls,['initialize','loaded','context','success']);});
test('failed handshake never signals success',async()=>{const h=setup({mode:'handshake'});await assert.rejects(h.initialize(),/handshake failed/);assert.deepEqual(h.calls,['initialize']);});
test('context failure notifies Teams and rejects',async()=>{const h=setup({mode:'context'});await assert.rejects(h.initialize(),/context failed/);assert.deepEqual(h.calls,['initialize','loaded','context','failure']);});
test('download failure identifies SDK/proxy and cleans up',async()=>{const h=setup({mode:'download',download:true});await assert.rejects(h.initialize(),/proxy/);assert.equal(h.calls.at(-1),'removed');assert.ok(!h.calls.includes('success'));});
test('download timeout is bounded and cleans up',async()=>{const h=setup({mode:'timeout',download:true});await assert.rejects(h.initialize(),/timed out/);assert.equal(h.calls.at(-1),'removed');});
test('downloaded SDK completes normal readiness',async()=>{const h=setup({download:true});await h.initialize();assert.equal(h.calls.at(-1),'success');});
test('configuration save reports failure instead of false success',async()=>{const h=setup({configure:true,mode:'save'});await h.initialize();let result='';await h.save()({notifySuccess:()=>result='success',notifyFailure:()=>result='failure'});assert.equal(result,'failure');});
test('configuration save succeeds only after setConfig',async()=>{const h=setup({configure:true});await h.initialize();let result='';await h.save()({notifySuccess:()=>result='success',notifyFailure:()=>result='failure'});assert.equal(result,'success');});

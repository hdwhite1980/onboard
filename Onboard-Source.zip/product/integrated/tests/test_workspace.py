"""Persistence boundary fixtures; no real mailbox, credential or customer data."""
import json,pathlib,sys,tempfile,time,unittest
from unittest.mock import Mock,patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from test_hybrid_documents import host,job,TENANT,LABEL
from workspace import Workspace
from connectors import Failure
from managed_policy import ManagedPolicy
from handoffs import Handoffs

class WorkspaceTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.h=host(self.tmp.name);self.h.graph.config={'authority':'https://login.microsoftonline.com'};self.ws=Workspace(self.h)
  # Fixture codec exercises storage/identity/retention only. Real AEAD is tested in Swift separately.
  self.ws.crypt=lambda action,context,data: b'FIXTURE:'+data if action=='seal' else data.removeprefix(b'FIXTURE:')
  self.j=job(self.h,'word');self.j.update(state='complete',result={'status':'generated','policy':{'allowed':True},'sources':[{'id':'mail:fixture','title':'Fixture source','text':'Source body must not be cached'}],'retrieval_notes':['Selected email only']})
  self.r={'job':'j','title':'Fixture work','text':'Reviewed fixture draft','key':'fixture-save-123456','reviewed':True,'public_attested':True}
 def tearDown(self):self.tmp.cleanup()
 def test_saved_draft_survives_service_restart_and_new_signin_epoch(self):
  result=self.ws.save('word',self.r)
  other=host(self.tmp.name);other.graph.config={'authority':'https://login.microsoftonline.com'};other.graph.identity.return_value=(TENANT,'user',99);other.sessions['outlook']['identity']=other.graph.identity()
  restored=Workspace(other);restored.crypt=self.ws.crypt
  self.assertEqual(restored.list('outlook')['items'][0]['id'],result['id'])
  loaded=restored.get('outlook',result);self.assertEqual(loaded['result']['answer'],self.r['text']);self.assertNotIn('text',loaded['result']['sources'][0]);self.assertIn(loaded['job'],other.jobs)
  exported=other.documents.export('outlook',{'job':loaded['job'],'title':'Fixture','text':loaded['result']['answer'],'reviewed':True,'public_attested':True});self.assertTrue(exported['base64'])
 def test_account_switch_during_unlock_withholds_the_result(self):
  saved=self.ws.save('word',self.r);original=self.ws.crypt
  def switched(action,context,data):
   result=original(action,context,data)
   if action=='open':
    self.h.graph.identity.return_value=(TENANT,'other',2);self.h.sessions['word']['identity']=self.h.graph.identity()
   return result
  self.ws.crypt=switched
  with self.assertRaises(Failure):self.ws.get('word',saved)
  self.assertEqual(len(self.h.jobs),1)
 def test_cross_account_and_cloud_cannot_read(self):
  saved=self.ws.save('word',self.r)
  for identity,authority in [((TENANT,'other',2),'https://login.microsoftonline.com'),((TENANT,'user',2),'https://login.microsoftonline.us')]:
   self.h.graph.identity.return_value=identity;self.h.graph.config['authority']=authority;self.h.sessions['word']['identity']=identity
   self.assertEqual(self.ws.list('word')['items'],[])
   with self.assertRaises(Failure):self.ws.get('word',saved)
 def test_no_source_body_or_session_token_persisted(self):
  self.ws.save('word',self.r);raw=next((self.h.state/'workspace').glob('*.sealed')).read_bytes()
  self.assertNotIn(b'Source body must not be cached',raw);self.assertNotIn(b'"owner"',raw);self.assertNotIn(b'"epoch"',raw)
 def test_no_automatic_or_unreviewed_storage(self):
  self.assertFalse((self.h.state/'workspace').exists())
  with self.assertRaises(Failure):self.ws.save('word',dict(self.r,reviewed=False))
  self.assertFalse((self.h.state/'workspace').exists())
 def test_idempotent_save_and_key_content_conflict(self):
  first=self.ws.save('word',self.r);second=self.ws.save('word',self.r);self.assertEqual(first['id'],second['id']);self.assertEqual(len(self.ws.list('word')['items']),1)
  with self.assertRaises(Failure):self.ws.save('word',dict(self.r,text='Other'))
 def test_expiry_removes_work_and_no_resume_after_expiry(self):
  saved=self.ws.save('word',self.r)
  with patch('workspace.time.time',return_value=time.time()+8*86400):
   self.assertEqual(self.ws.list('word')['items'],[])
   with self.assertRaises(Failure):self.ws.get('word',saved)
 def test_new_label_policy_is_checked_when_reopened(self):
  self.j['result']['sources'][0]['sensitivity']={'state':'labeled','labels':[{'tenant':TENANT,'id':LABEL,'enabled':True,'content_bits':'0'}]};self.h.config['agent']['public_labels']=[TENANT+':'+LABEL]
  saved=self.ws.save('word',self.r);self.h.config['agent']['public_labels']=[]
  with self.assertRaises(Failure):self.ws.get('word',saved)
 def test_failed_crypto_does_not_overwrite_existing_work(self):
  self.ws.save('word',self.r);path=next((self.h.state/'workspace').glob('*.sealed'));before=path.read_bytes();self.ws.crypt=Mock(side_effect=Failure('Keychain locked'))
  with self.assertRaises(Failure):self.ws.save('word',dict(self.r,key='another-key-123456'))
  self.assertEqual(path.read_bytes(),before)
 def test_symlinked_workspace_rejected(self):
  outside=self.h.state/'other';outside.mkdir();(self.h.state/'workspace').symlink_to(outside)
  with self.assertRaises(Failure):self.ws.save('word',self.r)
  self.assertEqual(list(outside.iterdir()),[])
 def test_purge_allowed_after_processing_disabled(self):
  self.ws.save('word',self.r);self.h.config['public_local']=False;self.ws.purge('word');self.assertEqual(list((self.h.state/'workspace').glob('*.sealed')),[])
 def test_unknown_or_withheld_output_not_saved(self):
  self.j['result']['status']='source_excerpts'
  with self.assertRaises(Failure):self.ws.save('word',self.r)
 def test_destination_word_must_have_valid_inspection(self):
  with self.assertRaises(Failure):self.h.documents.authorize('word',{'snapshot':'missing'})
 def test_saved_restoration_cannot_restore_execution_or_approval(self):
  saved=self.ws.save('word',self.r);row=self.ws.get('word',saved);j=self.h.jobs[row['job']]
  self.assertEqual(j['request'],{});self.assertNotIn('approval',j);self.assertEqual(j['state'],'complete')

class ManagedPolicyTests(unittest.TestCase):
 def setUp(self):
  self.p=ManagedPolicy();self.value={'schema':1,'name':'Fixture policy','allow_cloud':False,'allow_hybrid':False,'allow_saved_work':False,'allowed_tenants':['tenant'],'allowed_provider_origins':['https://approved.example'],'public_label_mappings':[]};self.p.read=Mock(return_value=self.value)
 def test_cloud_hybrid_tenant_destination_and_label_restrictions(self):
  for config in ({'public_cloud':True},{'agent':{'enabled':True}},{'graph':{'tenant':'other'}},{'provider':{'endpoint':'https://approved.example.evil/v1'}},{'agent':{'public_labels':['unapproved']}}):
   with self.assertRaises(Failure):self.p.check(config)
  self.p.check({'graph':{'tenant':'tenant'},'provider':{'endpoint':'https://approved.example/v1'}})
 def test_saved_work_policy_and_revocation_are_read_fresh(self):
  with self.assertRaises(Failure):self.p.check({},'workspace')
  self.value['allow_saved_work']=True;self.p.check({},'workspace');self.value['allow_saved_work']=False
  with self.assertRaises(Failure):self.p.check({},'workspace')
 def test_absent_policy_keeps_development_mode(self):
  self.p.read.return_value=None;self.p.check({'public_cloud':True});self.assertFalse(self.p.status({})['managed'])
 def test_invalid_policy_blocks_and_reports(self):
  self.p.read.side_effect=Failure('Invalid policy')
  with self.assertRaises(Failure):self.p.check({})
  self.assertFalse(self.p.status({})['ready'])
 def test_untrusted_policy_file_is_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=pathlib.Path(tmp)/'policy.json';path.write_text(json.dumps(self.value));path.chmod(0o666)
   with self.assertRaises(Failure):ManagedPolicy(path).read()

class RecoveryTests(unittest.TestCase):
 def setUp(self):
  from test_handoffs import HandoffTests
  self.fixture=HandoffTests();self.fixture.setUp();self.q=self.fixture.q;self.row=self.q.create('out',self.fixture.r)
 def test_failed_host_action_preserves_draft(self):
  claim=self.q.claim('team',self.row);self.q.finish('team',dict(self.row,**claim,opened=False));self.assertEqual(len(self.q.inbox('team')['drafts']),1);self.q.claim('team',self.row)
 def test_only_one_panel_can_open_and_complete(self):
  claim=self.q.claim('team',self.row)
  with self.assertRaises(Failure):self.q.claim('team2',self.row)
  with self.assertRaises(Failure):self.q.finish('team2',dict(self.row,**claim,opened=True))
  self.q.finish('team',dict(self.row,**claim,opened=True));self.assertEqual(self.q.inbox('team')['drafts'],[])
if __name__=='__main__':unittest.main()

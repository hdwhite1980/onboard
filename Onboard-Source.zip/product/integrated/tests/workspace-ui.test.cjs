// Isolated UI fixtures, not a live Office session.
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
function setup(){
 const nodes=new Map(),node=()=>({value:'',textContent:'',checked:false,disabled:false,children:[],handlers:{},addEventListener(n,f){this.handlers[n]=f;},replaceChildren(){this.children=[];},append(v){this.children.push(v);}}),get=id=>{if(!nodes.has(id))nodes.set(id,node());return nodes.get(id);};
 const c={document:{getElementById:get,createElement:node},window:{addEventListener(){}},crypto:{randomUUID:()=> 'fixture-key-123456'},Date};const calls=[],restored=[];
 vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/workspace-ui.js'),'utf8'),c);
 c.OnboardWorkspace.configure({api:async(route,body)=>{calls.push({route,body});if(route==='workspace-list')return {items:[{id:'saved',title:'<script>fixture</script>',origin:'outlook',expires:Date.now()/1000+1000}]};if(route==='workspace-get')return {job:'restored',title:'Fixture',result:{status:'generated',answer:'Reviewed fixture',message:'Opened'}};return {message:'Saved'};},restore:r=>restored.push(r)});
 return {c,get,calls,restored};
}
test('saving requires generated output, explicit review and current public confirmation',async()=>{
 const f=setup();await f.get('saved-save').handlers.click();assert.equal(f.calls.length,0);
 f.c.OnboardWorkspace.result({status:'source_excerpts'},'job',()=> 'Fixture');assert.equal(f.get('saved-save').disabled,true);
 f.c.OnboardWorkspace.result({status:'generated'},'job',()=> 'Edited draft');f.get('saved-title').value='Fixture';f.get('saved-reviewed').checked=true;f.get('public').checked=true;
 await f.get('saved-save').handlers.click();assert.equal(f.calls[0].route,'workspace-save');assert.equal(f.calls[0].body.text,'Edited draft');assert.equal(f.calls[0].body.public_attested,true);assert.equal(f.get('saved-reviewed').checked,false);
});
test('restoring returns a draft for review and never sends or auto-inserts',async()=>{
 const f=setup();await f.get('saved-refresh').handlers.click();assert.match(f.get('saved-list').children[1].textContent,/<script>fixture/);f.get('saved-list').value='saved';await f.get('saved-open').handlers.click();assert.equal(f.restored.length,1);assert.equal(f.get('saved-reviewed').checked,false);assert.deepEqual(f.calls.map(c=>c.route),['workspace-list','workspace-get']);
});
test('draft edits revoke storage approval and disconnect clears account listings',()=>{
 const f=setup();f.c.OnboardWorkspace.result({status:'generated'},'job',()=> 'Fixture');f.get('saved-reviewed').checked=true;f.get('answer').handlers.input();assert.equal(f.get('saved-reviewed').checked,false);f.c.OnboardWorkspace.disconnect();assert.equal(f.get('saved-list').children.length,0);assert.equal(f.get('saved-save').disabled,true);
});
test('purge requires a separate explicit confirmation',async()=>{
 const f=setup();await f.get('saved-purge').handlers.click();assert.equal(f.calls.length,0);f.get('saved-delete-confirm').checked=true;await f.get('saved-purge').handlers.click();assert.equal(f.calls[0].route,'workspace-purge');
});
test('a response arriving after disconnect cannot restore another account draft',async()=>{
 const f=setup();let release;f.c.OnboardWorkspace.configure({api:()=>new Promise(resolve=>release=resolve),restore:r=>f.restored.push(r)});f.get('saved-list').value='saved';const pending=f.get('saved-open').handlers.click();f.c.OnboardWorkspace.disconnect();release({job:'stale',title:'Stale',result:{message:'No'}});await pending;assert.equal(f.restored.length,0);
});

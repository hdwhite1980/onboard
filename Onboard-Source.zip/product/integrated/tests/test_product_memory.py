"""Product policy revision tests, no model loads or OS changes."""
import importlib.util,os,pathlib,sys,unittest
from unittest.mock import patch
P=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P/'local'))
spec=importlib.util.spec_from_file_location('product_memory_policy',P/'local/policy.py')
p=importlib.util.module_from_spec(spec)
with patch.dict(os.environ,ONBOARD_BRIEFING_RUN=str(P/'state/runs/unit')):spec.loader.exec_module(p)
class ProductMemory(unittest.TestCase):
    def row(self):
        return dict({k:1 for k in p.REQUIRED},monotonic=10,availableEstimateLegacyBytes=4*1024**3,powerSource='AC',memoryPressure='NORMAL',thermalState=0,swapUsedBytes=1024**3)
    def test_stable_existing_swap_admitted(self):
        row=self.row();self.assertIsNone(p.violation(row,row,dict(row),10))
    def test_new_swap_still_stops(self):
        base=self.row()
        for field in ('swapUsedBytes','swapInPagesTotal','swapOutPagesTotal'):
            row=dict(base);row[field]+=1
            self.assertIsNotNone(p.violation(row,base,base,10))
    def test_pressure_and_reserve_still_stop(self):
        base=self.row()
        for pressure in ('WARN','CRITICAL','UNKNOWN',None):
            self.assertIsNotNone(p.violation(dict(base,memoryPressure=pressure),base,base,10))
        self.assertIsNotNone(p.violation(dict(base,availableEstimateLegacyBytes=2*1024**3),base,base,10))

import Foundation
import CryptoKit
@main struct Checks {
 static func main() throws {
  let key=SymmetricKey(size:.bits256),context=Data("fixture-account".utf8),data=Data("Fixture public draft".utf8)
  let sealed=try WorkspaceCrypto.seal(data,key:key,context:context)
  precondition(!sealed.contains(data))
  let opened=try WorkspaceCrypto.open(sealed,key:key,context:context);precondition(opened==data)
  do { _ = try WorkspaceCrypto.open(sealed,key:key,context:Data("other-account".utf8));fatalError("Account substitution accepted") } catch {}
  var changed=sealed;changed[changed.count-1] ^= 1
  do { _ = try WorkspaceCrypto.open(changed,key:key,context:context);fatalError("Tampered data accepted") } catch {}
  do { _ = try WorkspaceCrypto.open(sealed,key:SymmetricKey(size:.bits256),context:context);fatalError("Wrong key accepted") } catch {}
  print("Workspace AES-GCM round-trip, account binding, tamper and wrong-key checks passed. No Keychain was accessed.")
 }
}

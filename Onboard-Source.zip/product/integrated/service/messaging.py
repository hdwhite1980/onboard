"""User-reviewed cross-app messages. Models cannot select recipients or dispatch actions."""
import datetime as dt,json,re,secrets,time,uuid
from zoneinfo import ZoneInfo,ZoneInfoNotFoundError
from connectors import Failure,segment
UTC=dt.timezone.utc

def address(value):
    if not isinstance(value,str) or len(value)>254 or not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}",value):
        raise Failure('Enter one complete recipient email address or Teams work sign-in address.')
    return value

def graph_date(value):
    try:
        instant=dt.datetime.fromisoformat(value['dateTime'].replace('Z','+00:00'))
        if instant.tzinfo is None:
            if value.get('timeZone') not in ('UTC','Etc/UTC'):raise ValueError()
            instant=instant.replace(tzinfo=UTC)
        return instant.astimezone(UTC)
    except (ValueError,KeyError,TypeError,AttributeError):raise Failure('Calendar returned an unreadable time. Availability was not assumed.')

def free_slots(graph,options,now=None):
    graph.require('calendar');now=now or dt.datetime.now(UTC)
    try:
        zone=ZoneInfo(options['zone']);day=dt.date.fromisoformat(options['date'])
        duration=options['duration'];begin=options['start_hour'];finish=options['end_hour']
        if type(duration) is not int or duration not in (15,30,45,60) or type(begin) is not int or type(finish) is not int or not 0<=begin<finish<=23:raise ValueError()
        if not now.astimezone(zone).date()<=day<=now.astimezone(zone).date()+dt.timedelta(days=30):raise ValueError()
    except (KeyError,TypeError,ValueError,ZoneInfoNotFoundError):raise Failure('Choose a valid time zone, date within 30 days, meeting length and working hours.')
    start=dt.datetime.combine(day,dt.time(),zone);end=dt.datetime.combine(day+dt.timedelta(days=7),dt.time(),zone)
    data=graph.get('me/calendarView',{'startDateTime':start.isoformat(),'endDateTime':end.isoformat(),'$top':'1000','$select':'start,end,showAs,isCancelled'})
    if not isinstance(data.get('value'),list) or data.get('@odata.nextLink'):raise Failure('Calendar results were incomplete. No available times were assumed.')
    blocked=[]
    for event in data['value']:
        if event.get('isCancelled') is True or event.get('showAs')=='free':continue
        a=graph_date(event.get('start'));b=graph_date(event.get('end'))
        if b<=a:raise Failure('Calendar returned an invalid event interval.')
        blocked.append((a,b))
    slots=[]
    for offset in range(7):
        date=day+dt.timedelta(days=offset)
        if date.weekday()>=5:continue
        cursor=dt.datetime.combine(date,dt.time(begin),zone).astimezone(UTC)
        limit=dt.datetime.combine(date,dt.time(finish),zone).astimezone(UTC)
        while cursor+dt.timedelta(minutes=duration)<=limit:
            stop=cursor+dt.timedelta(minutes=duration)
            if cursor>now and not any(cursor<b and stop>a for a,b in blocked):
                local=cursor.astimezone(zone);local_end=stop.astimezone(zone)
                slots.append({'start':cursor.isoformat(),'end':stop.isoformat(),'label':local.strftime('%a %b %d, %Y, %I:%M %p')+'–'+local_end.strftime('%I:%M %p %Z')})
            cursor+=dt.timedelta(minutes=15)
    return slots

class Messages:
    def __init__(self,host):self.host=host;self.drafts={};self.availability={}
    def session(self,owner):
        h=self.host;s=h.sessions.get(owner)
        if not s or tuple(s['identity'])!=h.graph.identity():raise Failure('Reconnect this add-in before preparing or sending a message.')
        return h.graph.identity()
    def clear(self,owner=None):
        self.drafts={k:v for k,v in self.drafts.items() if owner is not None and v['owner']!=owner}
        self.availability={k:v for k,v in self.availability.items() if owner is not None and v['owner']!=owner}
    def times(self,owner,r):
        h=self.host;identity=self.session(owner);options={k:r.get(k) for k in ('zone','date','duration','start_hour','end_hour')}
        slots=free_slots(h.graph,options)
        # Up to three non-overlapping proposals, preferring separate days.
        chosen=[];days=set()
        for slot in slots:
            day=slot['label'].split(',')[0]
            if day not in days:chosen.append(slot);days.add(day)
            if len(chosen)==3:break
        with h.lock:
            if self.session(owner)!=identity:raise Failure('Account changed while checking your calendar.')
            self.availability={k:v for k,v in self.availability.items() if v['owner']!=owner}
            key=secrets.token_urlsafe(32)
            block=('Could we meet for '+str(options['duration'])+' minutes? My calendar currently shows these options ('+options['zone']+'):\n'+ '\n'.join('• '+s['label'] for s in chosen)+'\nWould one of these work for you?') if chosen else ''
            self.availability[key]={'owner':owner,'identity':identity,'options':options,'slots':chosen,'text':block}
        return {'id':key,'text':block,'message':'Your primary calendar only; weekdays within your selected hours. Recipient availability was not checked. Times are not reserved.' if chosen else 'No free times found within the selected weekday hours. Choose another starting date or hours.'}
    def review(self,owner,r):
        h=self.host;identity=self.session(owner)
        if r.get('public_attested') is not True:raise Failure('Confirm that the message is permitted to share with this recipient.')
        job=h.job(owner,r.get('job'))
        result=job.get('result') or {}
        if job['state']!='complete' or result.get('status')!='generated' or not result.get('policy',{}).get('allowed'):
            raise Failure('Prepare a verified AI draft first. Withheld answers cannot be sent.')
        body=r.get('body');subject=r.get('subject','');target=r.get('target');recipient=address(r.get('recipient'))
        if not isinstance(body,str) or not body.strip() or len(body)>12000 or '\x00' in body:raise Failure('Enter a message of 1–12,000 characters.')
        if target not in ('email','teams'):raise Failure('Choose Email or Teams.')
        h.graph.require('send_'+target)
        if not isinstance(subject,str) or len(subject)>200 or any(c in subject for c in '\r\n\x00'):raise Failure('Use a one-line email subject of at most 200 characters.')
        if target=='email' and not subject.strip():raise Failure('Enter the email subject.')
        destination={'address':recipient,'label':recipient}
        if target=='teams':
            user=h.graph.get('users/'+segment(recipient),{'$select':'id,displayName,mail,userPrincipalName'})
            try:uid=str(uuid.UUID(user['id']))
            except (KeyError,ValueError,TypeError):raise Failure('Microsoft did not resolve that Teams recipient.')
            if recipient.casefold() not in {str(user.get('mail','')).casefold(),str(user.get('userPrincipalName','')).casefold()}:raise Failure('Recipient address did not match the Microsoft directory result.')
            if '#EXT#' in str(user.get('userPrincipalName','')).upper():raise Failure('This version supports Teams recipients within your organization. Use email for external recipients.')
            if uid==identity[1]:raise Failure('Choose another Teams recipient.')
            destination.update(id=uid,label=(user.get('displayName') or recipient)+' <'+(user.get('userPrincipalName') or recipient)+'>')
        with h.lock:
            if self.session(owner)!=identity:raise Failure('Account changed during recipient lookup.')
            availability=None
            if r.get('availability'):
                availability=self.availability.get(r['availability'])
                if not availability or availability['owner']!=owner or availability['identity']!=identity or not availability['slots']:raise Failure('Refresh your available times before review.')
                body=body.rstrip()+'\n\n'+availability['text']
            self.drafts={k:v for k,v in self.drafts.items() if v['owner']!=owner or v['state']!='review'}
            if len(self.drafts)>=128:raise Failure('Message history is full. Reconnect the add-in.')
            key=secrets.token_urlsafe(32);sender=h.graph.account.get('mail') or h.graph.account['userPrincipalName']
            self.drafts[key]={'owner':owner,'identity':identity,'target':target,'destination':destination,'subject':subject if target=='email' else '', 'body':body,'availability':availability,'state':'review','sender':sender}
            return {'id':key,'target':target,'recipient':destination['label'],'sender':sender,'subject':subject if target=='email' else '', 'body':body}
    def send(self,owner,r):
        h=self.host
        # Serializes against account changes, edits and duplicate clicks. No background send.
        with h.lock,h.graph.lock:
            identity=self.session(owner);draft=self.drafts.get(r.get('id'))
            if not draft or draft['owner']!=owner or draft['identity']!=identity:raise Failure('Review this message again before sending.')
            if draft['state']!='review':return {'state':draft['state'],'message':'This send was already attempted. Check Outlook Sent Items or Teams before preparing another message.'}
            if r.get('confirmed') is not True:raise Failure('Review the recipient and message, then click Send.')
            h.graph.require('send_'+draft['target'])
            if draft['availability']:
                available=free_slots(h.graph,draft['availability']['options']);pairs={(s['start'],s['end']) for s in available}
                if any((s['start'],s['end']) not in pairs for s in draft['availability']['slots']):
                    draft['state']='changed';raise Failure('Your availability changed. Refresh the times and review again. Nothing was sent.')
            # Write-ahead receipt contains no content, address, credential or source data.
            # After a restart the in-memory draft is gone and cannot be replayed.
            receipt=h.state/'message-receipts';receipt.mkdir(mode=0o700,exist_ok=True)
            from host import atomic
            path=receipt/(r['id']+'.json');atomic(path,{'state':'attempting','at':time.time()})
            draft['state']='uncertain'
            try:
                if draft['target']=='email':
                    h.graph.write('me/sendMail',{'message':{'subject':draft['subject'],'body':{'contentType':'Text','content':draft['body']},'toRecipients':[{'emailAddress':{'address':draft['destination']['address']}}]},'saveToSentItems':True},identity,raw=True)
                    message='Microsoft accepted the email for sending. Check Sent Items for delivery status.'
                else:
                    root=h.graph.config['graph']+'/v1.0/users('
                    members=[{'@odata.type':'#microsoft.graph.aadUserConversationMember','roles':['owner'],'user@odata.bind':root+"'"+str(uuid.UUID(uid))+"')"} for uid in (identity[1],draft['destination']['id'])]
                    chat=h.graph.write('chats',{'chatType':'oneOnOne','members':members},identity)
                    h.graph.write('chats/'+segment(chat['id'])+'/messages',{'body':{'contentType':'text','content':draft['body']}},identity)
                    message='Message sent to the reviewed Teams recipient.'
                draft['state']='sent';atomic(path,{'state':'sent','at':time.time()})
                return {'state':'sent','message':message}
            except Exception as error:
                atomic(path,{'state':'uncertain','at':time.time()})
                detail=str(error) if isinstance(error,Failure) else 'Microsoft did not confirm the complete send operation.'
                return {'state':'uncertain','message':detail+' Delivery is unconfirmed. Check Sent Items or Teams before creating another draft. Onboard will not automatically retry.'}

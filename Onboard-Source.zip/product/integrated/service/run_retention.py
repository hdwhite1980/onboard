"""Clean marked model spill directories from earlier boots; never touch active/unknown runs."""
import json,os,pathlib,re,shutil,stat,subprocess
from connectors import Failure

def boot_id():
    result=subprocess.run(['/usr/sbin/sysctl','-n','kern.boottime'],capture_output=True,text=True,timeout=3,check=True)
    match=re.search(r'sec\s*=\s*(\d+),\s*usec\s*=\s*(\d+)',result.stdout)
    if not match:raise Failure('Cannot identify the current boot for safe runtime cleanup.')
    return match[1]+':'+match[2]

def cleanup_previous_boot(runs,current):
    runs=pathlib.Path(runs)
    if not runs.exists():return {'removed':0,'preserved':0}
    s=runs.lstat()
    if not stat.S_ISDIR(s.st_mode) or s.st_uid!=os.getuid() or s.st_mode&0o077:raise Failure('Runtime folder permissions are unsafe.')
    result={'removed':0,'preserved':0}
    for path in runs.glob('request-*'):
        s=path.lstat()
        if not stat.S_ISDIR(s.st_mode) or s.st_uid!=os.getuid() or s.st_mode&0o077:result['preserved']+=1;continue
        try:
            fd=os.open(path/'run-owner.json',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
            with os.fdopen(fd,'rb') as stream:
                info=os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077 or info.st_size>1024:raise ValueError()
                row=json.loads(stream.read(1025))
            if row.get('schema')!=1 or not re.fullmatch(r'\d+:\d+',row.get('boot','')):raise ValueError()
            # Same-boot residue may still have a running worker even if its parent died.
            if row['boot']==current:result['preserved']+=1;continue
            shutil.rmtree(path);result['removed']+=1
        except (OSError,ValueError,TypeError):result['preserved']+=1
    return result

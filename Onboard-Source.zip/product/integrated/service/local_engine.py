"""Finite adapter to retained Qwen3 supervisor. Never bypasses its runtime/lifecycle identity checks."""
import fcntl,hashlib,json,os,pathlib,shutil,subprocess,tempfile,time
from connectors import Failure
from activity import publish
class LocalUnavailable(Failure):
    def __init__(self,code,message):super().__init__(message);self.code=code

SANDBOX=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)']
def generate(resources,messages,cancel,cache_mode="standard"):
    return _generate(resources,messages,cancel,cache_mode=cache_mode)[0]

def generate_grounded(resources,messages,sources,cancel,cache_mode="standard"):
    return _generate(resources,messages,cancel,sources,cache_mode=cache_mode)

def _generate(resources,messages,cancel,sources=None,cache_mode="standard"):
    if cache_mode not in ("standard","turboquant-k8v4"):raise Failure("Unsupported local cache mode.")
    c=json.loads((pathlib.Path(resources)/'local.json').read_text());root=pathlib.Path(c['root']);python=pathlib.Path(c['python']);adapter=pathlib.Path(c['adapter'])
    expected=json.loads((root/'product/integrated/evidence/runtime-repair/worker/qualification-v2/context.json').read_text())['interpreterSHA256']
    if hashlib.sha256(python.resolve().read_bytes()).hexdigest()!=expected:raise Failure('Runtime identity changed; no model was loaded.')
    state=root/'product/integrated/state';runs=state/'runs';runs.mkdir(exist_ok=True,mode=0o700)
    # Share the prior provider lock: the legacy prototype cannot race a model load.
    legacy=root/'product/meeting_briefing/state/provider.lock';legacy.parent.mkdir(exist_ok=True)
    with legacy.open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise Failure('Another local model request is running.')
        from run_retention import boot_id,cleanup_previous_boot
        boot=boot_id();cleanup_previous_boot(runs,boot)
        from encrypted_run import encrypted_run,recover_abandoned
        recover_abandoned(runs)
        publish('sealed_storage')
        with encrypted_run(runs) as run:
            return execute_run(root,python,adapter,run,messages,sources,cancel,cache_mode)

def execute_run(root,python,adapter,run,messages,sources,cancel,cache_mode):
    state=root/'product/integrated/state'
    env=dict(os.environ,ONBOARD_BRIEFING_RUN=str(run),ONBOARD_CACHE_MODE=cache_mode,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',PYTHONDONTWRITEBYTECODE='1',USE_TORCH='0',USE_TF='0',USE_FLAX='0')
    try:
        (run/'preflight').mkdir();(run/'calibration').mkdir();(run/'input.json').write_text(json.dumps(messages))
        if sources is not None:(run/'sources.json').write_text(json.dumps(sources))
        verify=subprocess.run([str(python),'-I','-B',str(adapter/'runtime_identity.py')],capture_output=True,timeout=60)
        if verify.returncode:raise Failure('Pinned runtime or package integrity check failed. No model was loaded.')
        publish('preflight')
        pre=subprocess.run(SANDBOX+[str(python),'-I','-B',str(adapter/'preflight.py')],env=env,capture_output=True,timeout=60)
        if pre.returncode and b'UNSUPPORTED_RESOURCE_PROFILE' in pre.stderr:
            error=run/'preflight/context-error.json'
            message=json.loads(error.read_text())['message'] if error.exists() else 'Shorten the question or select a smaller excerpt for this local model.'
            raise LocalUnavailable('CONTEXT_LIMIT',message)
        if pre.returncode:raise Failure('Input or runtime preflight failed. The local model supports at most 1536 prompt tokens plus 512 output tokens; shorten the request. Nothing was silently truncated.')
        shutil.copyfile(run/'preflight/frozen-suite.json',run/'calibration/frozen-suite.json')
        files=list(adapter.glob('*.py'))+list((adapter/'vendor').rglob('*.py'))+[run/'calibration/frozen-suite.json']
        (run/'calibration/tested-source.json').write_text(json.dumps({'files':[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}))
        if cancel.is_set():raise Failure('Cancelled before model launch.')
        # Supervisor remains alive to reap its own worker; cancellation uses its watched marker.
        proc=subprocess.Popen([str(python),'-I','-B',str(adapter/'run_once.py')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        publish('supervisor',pid=proc.pid)
        event_offset=0
        while proc.poll() is None:
            events=run/'calibration/worker-events.jsonl'
            if events.exists():
                with events.open('rb') as event_stream:
                    event_stream.seek(event_offset);batch=event_stream.read(65536)
                for line in batch.splitlines(keepends=True):
                    if not line.endswith(b'\n'):break
                    event_offset+=len(line)
                    try:
                        event=json.loads(line);publish(event.get('event'),pid=event.get('pid'))
                    except (ValueError,TypeError):pass
            if cancel.wait(.1):(run/'CANCEL').touch(exist_ok=True)
        if cancel.is_set():raise Failure('Cancelled.')
        report=run/'calibration/run-result.json'
        if not report.exists():raise Failure('Runtime/lifecycle identity or preparation check blocked execution.')
        result=json.loads(report.read_text())
        from local_diagnostics import outcome,record
        code,message,recoverable=outcome(result)
        try:record(state,run,result)
        except (OSError,ValueError):pass  # Diagnostics must never prevent cleanup or mask the guard.
        if code!='SUCCESS':
            publish('failed',code)
            message+=' ['+code+'] No generated answer was released.'
            if recoverable:raise LocalUnavailable(code,message)
            raise Failure(message)
        return json.loads((run/'calibration/response-00.json').read_text())['rawOutput'],json.loads((run/'preflight/context-packet.json').read_text())
    finally:
        publish('cleanup')
        # Remove only this owned ephemeral public-input execution directory, including model snapshot.
        for path in run.rglob('*'):
            if path.is_dir():path.chmod(0o700)
            else:path.chmod(0o600)
        shutil.rmtree(run)

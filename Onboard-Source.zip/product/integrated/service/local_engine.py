"""Finite adapter to retained Qwen3 supervisor. Never bypasses its runtime/lifecycle identity checks."""
import fcntl,hashlib,json,os,pathlib,shutil,subprocess,tempfile,time
from connectors import Failure
class LocalUnavailable(Failure):
    def __init__(self,code,message):super().__init__(message);self.code=code

SANDBOX=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)']
def generate(resources,messages,cancel):
    c=json.loads((pathlib.Path(resources)/'local.json').read_text());root=pathlib.Path(c['root']);python=pathlib.Path(c['python']);adapter=pathlib.Path(c['adapter'])
    expected=json.loads((root/'product/integrated/evidence/runtime-repair/worker/qualification-v2/context.json').read_text())['interpreterSHA256']
    if hashlib.sha256(python.resolve().read_bytes()).hexdigest()!=expected:raise Failure('Runtime identity changed; no model was loaded.')
    state=root/'product/integrated/state';runs=state/'runs';runs.mkdir(exist_ok=True,mode=0o700)
    # Share the prior provider lock: the legacy prototype cannot race a model load.
    legacy=root/'product/meeting_briefing/state/provider.lock';legacy.parent.mkdir(exist_ok=True)
    with legacy.open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise Failure('Another local model request is running.')
        run=pathlib.Path(tempfile.mkdtemp(prefix='request-',dir=runs));env=dict(os.environ,ONBOARD_BRIEFING_RUN=str(run),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',PYTHONDONTWRITEBYTECODE='1',USE_TORCH='0',USE_TF='0',USE_FLAX='0')
        try:
            (run/'preflight').mkdir();(run/'calibration').mkdir();(run/'input.json').write_text(json.dumps(messages))
            verify=subprocess.run([str(python),'-I','-B',str(adapter/'runtime_identity.py')],capture_output=True,timeout=60)
            if verify.returncode:raise Failure('Pinned runtime or package integrity check failed. No model was loaded.')
            pre=subprocess.run(SANDBOX+[str(python),'-I','-B',str(adapter/'preflight.py')],env=env,capture_output=True,timeout=60)
            if pre.returncode and b'UNSUPPORTED_RESOURCE_PROFILE' in pre.stderr:raise LocalUnavailable('CONTEXT_LIMIT','The question exceeds the local model’s context limit.')
            if pre.returncode:raise Failure('Input or runtime preflight failed. The retained model supports at most 384 prompt tokens plus 128 output tokens; shorten the request. Nothing was silently truncated.')
            shutil.copyfile(run/'preflight/frozen-suite.json',run/'calibration/frozen-suite.json')
            files=list(adapter.glob('*.py'))+[run/'calibration/frozen-suite.json']
            (run/'calibration/tested-source.json').write_text(json.dumps({'files':[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}))
            if cancel.is_set():raise Failure('Cancelled before model launch.')
            # Supervisor remains alive to reap its own worker; cancellation uses its watched marker.
            proc=subprocess.Popen([str(python),'-I','-B',str(adapter/'run_once.py')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            while proc.poll() is None:
                if cancel.wait(.1):(run/'CANCEL').touch(exist_ok=True)
            if cancel.is_set():raise Failure('Cancelled.')
            report=run/'calibration/run-result.json'
            if not report.exists():raise Failure('Runtime/lifecycle identity or preparation check blocked execution.')
            result=json.loads(report.read_text())
            if result.get('primary') in ('MODEL_LOAD_ABORTED_RESOURCE_POLICY_V2','LOCAL_GENERATION_ABORTED_RESOURCE_POLICY_V2') and result.get('supervisor')=='TERMINATION_CONFIRMED' and result.get('evidenceCompleteness')=='COMPLETE' and result.get('processGroupPresent') is False:raise LocalUnavailable('RESOURCE_LIMIT','The local model stopped at its resource limit and cleanup completed.')
            if result.get('primary')!='LOCAL_GENERATION_SUCCESS' or result.get('supervisor')!='TERMINATION_CONFIRMED' or result.get('evidenceCompleteness')!='COMPLETE':raise Failure('Local AI stopped under its resource, runtime or lifecycle guard. No generated answer was released.')
            return json.loads((run/'calibration/response-00.json').read_text())['rawOutput']
        finally:
            # Remove only this owned ephemeral public-input execution directory, including model snapshot.
            for path in run.rglob('*'):
                if path.is_dir():path.chmod(0o700)
                else:path.chmod(0o600)
            shutil.rmtree(run)

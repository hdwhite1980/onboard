"""One-use, short-lived native helper capabilities. Never exposed through the web bridge."""
import json,secrets,subprocess,threading,time
from connectors import Failure

class Helpers:
    def __init__(self,host):self.host=host;self.lock=threading.Lock();self.pending={}
    def identity(self):
        try:return self.host.graph.identity()
        except Failure:return None
    def active(self,config,identity,kind):
        self.host.check_policy('workspace' if kind=='workspace' else None)
        if self.host.config is not config or self.identity()!=identity or self.host.stopping:raise Failure('Helper authorization changed. Retry from the current account.')
    def claim(self,token,kind):
        if not isinstance(token,str) or len(token)>100:raise Failure('Invalid native helper ticket.')
        # A separate lock prevents deadlock when a workspace operation holds host.lock.
        with self.lock:row=self.pending.pop(token,None)
        if not row or row['kind']!=kind or time.monotonic()>=row['expires']:raise Failure('Native helper ticket is invalid, expired or already used.')
        self.active(row['config'],row['identity'],kind)
        return row['payload']
    def invoke(self,kind,payload,timeout=30):
        if kind not in ('vault','workspace'):raise Failure('Unsupported native helper.')
        cfg=self.host.config;identity=self.identity();self.active(cfg,identity,kind)
        token=secrets.token_urlsafe(32)
        with self.lock:
            self.pending={k:v for k,v in self.pending.items() if v['expires']>time.monotonic()}
            if len(self.pending)>=16:raise Failure('Native helpers are busy. Retry shortly.')
            self.pending[token]={'kind':kind,'payload':payload,'config':cfg,'identity':identity,'expires':time.monotonic()+10}
        try:
            mode='--vault' if kind=='vault' else '--workspace-crypto'
            result=subprocess.run([str(self.host.app),mode],input=json.dumps({'ticket':token}),capture_output=True,text=True,timeout=timeout)
            self.active(cfg,identity,kind)
            if result.returncode:raise Failure('Authorized native helper failed. Unlock Keychain and retry; existing data was preserved.')
            return result.stdout
        finally:
            with self.lock:self.pending.pop(token,None)

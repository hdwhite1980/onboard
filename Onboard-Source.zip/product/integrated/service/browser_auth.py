"""Short-lived loopback OAuth callback. No credentials, tokens or callback logging."""
import base64, hashlib, hmac, http.server, secrets, threading, time, urllib.parse

class BrowserAuth:
    def __init__(self, lifetime=600):
        self.lock=threading.RLock();self.deadline=time.monotonic()+lifetime
        self.verifier=secrets.token_urlsafe(48);self.state=secrets.token_urlsafe(32)
        self.challenge=base64.urlsafe_b64encode(hashlib.sha256(self.verifier.encode()).digest()).decode().rstrip('=')
        self.result=None;self.closed=False
        flow=self
        class Handler(http.server.BaseHTTPRequestHandler):
            def setup(self):
                super().setup();self.connection.settimeout(2)
            def log_message(self,*args):pass
            def do_GET(self):
                status,message=flow.accept(self.path,self.headers.get('Host',''))
                body=message.encode();self.send_response(status)
                self.send_header('Content-Type','text/plain; charset=utf-8');self.send_header('Content-Length',str(len(body)))
                self.send_header('Cache-Control','no-store');self.send_header('Referrer-Policy','no-referrer')
                self.send_header('Content-Security-Policy',"default-src 'none'; frame-ancestors 'none'")
                self.send_header('Connection','close');self.end_headers();self.wfile.write(body)
        self.server=http.server.HTTPServer(('127.0.0.1',0),Handler)
        self.server.timeout=.2
        self.host='localhost:'+str(self.server.server_port)
        self.redirect='http://'+self.host+'/onboard-signin'
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
    def run(self):
        try:
            while not self.closed and time.monotonic()<self.deadline and self.result is None:
                self.server.handle_request()
        finally:
            self.server.server_close()
    def close(self):
        with self.lock:
            self.closed=True;self.verifier='';self.state='';self.result=None
    def accept(self,path,host):
        with self.lock:
            if self.closed or time.monotonic()>=self.deadline:return 410,'Sign-in expired or cancelled. Start again in Onboard.'
            if self.result is not None:return 409,'This sign-in response has already been received.'
            if host!=self.host or len(path)>16384:return 400,'Invalid sign-in response.'
            try:
                u=urllib.parse.urlsplit(path)
                if u.scheme or u.netloc or u.path!='/onboard-signin' or u.fragment:return 404,'Not found.'
                pairs=urllib.parse.parse_qs(u.query,keep_blank_values=True,max_num_fields=20)
                if any(len(v)!=1 for v in pairs.values()):raise ValueError()
                state=pairs.get('state',[''])[0]
                if not hmac.compare_digest(state,self.state):raise ValueError()
                code=pairs.get('code',[''])[0];error=pairs.get('error',[''])[0]
                if bool(code)==bool(error) or len(code)>8192:raise ValueError()
            except (ValueError,TypeError):return 400,'Invalid sign-in response. Continue the sign-in opened by Onboard.'
            self.result={'error':True} if error else {'code':code}
            return 200,'Microsoft sign-in response received. Return to Onboard AI to see the result. You can close this tab.'
    def take(self):
        with self.lock:
            if self.closed or time.monotonic()>=self.deadline:
                self.close();raise ValueError('Browser sign-in expired or cancelled. Start again.')
            if self.result is None:return None
            result=dict(self.result,verifier=self.verifier,redirect=self.redirect)
            self.close();return result

"""Encrypted, bounded, resumable PUBLIC task plans. No automatic startup execution."""
import copy,hashlib,json,os,pathlib,re,secrets,stat,threading,time
from connectors import Failure
from agent import Runner,parse_plan,TOOLS
from workspace import Workspace
from documents import check_labels
MAX=2_000_000
class AccountUnavailable(Failure):pass

def plan(value):
    if not isinstance(value,dict) or set(value)!={'title','steps'} or not isinstance(value['title'],str) or not 1<=len(value['title'])<=160:raise Failure('Plan needs a title and steps.')
    steps=value['steps']
    if not isinstance(steps,list) or not 1<=len(steps)<=30:raise Failure('Use 1–30 steps.')
    for i,s in enumerate(steps):
        if not isinstance(s,dict) or set(s)!={'tool','arguments','verify'}:raise Failure('Each step needs tool, arguments and verify.')
        parse_plan(json.dumps({'tool':s['tool'],'arguments':s['arguments']}))
        v=s['verify']
        if v!={'manual':True}:
            if not isinstance(v,dict) or set(v) not in ({'path','equals'},{'path','contains'}):raise Failure('Verification needs manual:true or a result path and equals/contains.')
            if not isinstance(v['path'],str) or not re.fullmatch(r'[A-Za-z0-9_.]{1,100}',v['path']):raise Failure('Invalid verification result path.')
            if 'contains' in v and (not isinstance(v['contains'],str) or not v['contains']):raise Failure('Contains verification requires nonempty text.')
            if s['tool']=='computer_action' and not v['path'].startswith('after.'):raise Failure('Verify the observed outcome after a computer action, or require manual verification; input delivery alone is not success.')
        # Only preceding results may be referenced; resolving never turns content into code.
        for match in re.finditer(r'@step:(\d+)\.([A-Za-z0-9_.]+)',json.dumps(s['arguments'])):
            if int(match[1])>=i:raise Failure('A step can reference only an earlier step.')
    if len(json.dumps(value))>120000:raise Failure('Plan is too large.')
    return copy.deepcopy(value)

def field(value,path):
    for part in path.split('.'):
        if isinstance(value,dict) and part in value:value=value[part]
        elif isinstance(value,list) and part.isdigit() and int(part)<len(value):value=value[int(part)]
        else:raise Failure('Expected result field is missing: '+path)
    return value

def resolve(value,results):
    if isinstance(value,dict):return {k:resolve(v,results) for k,v in value.items()}
    if isinstance(value,list):return [resolve(v,results) for v in value]
    if isinstance(value,str) and value.startswith('@step:'):
        match=re.fullmatch(r'@step:(\d+)\.([A-Za-z0-9_.]+)',value)
        if not match or int(match[1])>=len(results):raise Failure('Invalid previous-step reference.')
        return copy.deepcopy(field(results[int(match[1])],match[2]))
    return value

def remaining_plan(original,replacement,completed):
    """Planner references are relative to its new remaining steps, not completed work."""
    value=plan(replacement)
    def shift(v):
        if isinstance(v,dict):return {k:shift(x) for k,x in v.items()}
        if isinstance(v,list):return [shift(x) for x in v]
        if isinstance(v,str) and re.fullmatch(r'@step:\d+\.[A-Za-z0-9_.]+',v):
            return re.sub(r'^@step:(\d+)',lambda m:'@step:'+str(int(m[1])+completed),v)
        return v
    for step in value['steps']:step['arguments']=shift(step['arguments'])
    value['steps']=copy.deepcopy(original['steps'][:completed])+value['steps']
    return plan(value)

class Tasks:
    def __init__(self,host):self.host=host;self.lock=threading.RLock();self.active_ids=set()
    def allowed(self):
        self.host.check_policy('workspace')
        if not self.host.config.get('public_local') or not self.host.config.get('agent',{}).get('enabled'):raise Failure('Enable public local processing and task tools in AI Settings.')
    def directory(self):
        p=self.host.state/'tasks';p.mkdir(mode=0o700,exist_ok=True);s=p.lstat()
        if not stat.S_ISDIR(s.st_mode) or s.st_uid!=os.getuid() or s.st_mode&0o077:raise Failure('Task folder permissions are unsafe.')
        return p
    def path(self,ident):
        if not isinstance(ident,str) or not re.fullmatch(r'[0-9a-f]{32}',ident):raise Failure('Invalid task identifier.')
        return self.directory()/(ident+'.sealed')
    def context(self,ident):return hashlib.sha256(('onboard-tasks-v1:'+str(os.getuid())+':'+str(self.host.state.resolve())+':'+ident).encode()).hexdigest()
    def revalidate(self,row):
        if row.get('identity') is not None:
            try:identity=list(self.host.graph.identity()[:2])+[self.host.graph.config.get('authority','')]
            except Failure:raise AccountUnavailable('Sign in to the original Microsoft account to reopen this task.')
            if identity!=row['identity']:raise AccountUnavailable('This task belongs to a different Microsoft account or cloud.')
        sources=[]
        for result in row.get('results',[]):
            sources.append(result);sources.extend(result.get('sources',[]))
        check_labels(sources,self.host.config)
    def write(self,row):
        path=self.path(row['id']);raw=json.dumps(row,ensure_ascii=False).encode()
        if len(raw)>MAX:raise Failure('Task record is full; no further action was started.')
        sealed=Workspace(self.host).crypt('seal',self.context(row['id']),raw)
        tmp=path.with_name(secrets.token_hex(16)+'.tmp');fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        try:
            with os.fdopen(fd,'wb') as stream:stream.write(sealed);stream.flush();os.fsync(stream.fileno())
            os.replace(tmp,path)
            fd=os.open(path.parent,os.O_RDONLY);os.fsync(fd);os.close(fd)
        finally:
            if tmp.exists():tmp.unlink()
    def load(self,ident):
        path=self.path(ident)
        try:fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        except FileNotFoundError:raise Failure('Saved task not found.')
        with os.fdopen(fd,'rb') as stream:
            s=os.fstat(stream.fileno())
            if not stat.S_ISREG(s.st_mode) or s.st_uid!=os.getuid() or s.st_mode&0o077 or s.st_size>MAX+128:raise Failure('Saved task permissions or size are invalid.')
            sealed=stream.read(MAX+129)
        try:row=json.loads(Workspace(self.host).crypt('open',self.context(ident),sealed))
        except ValueError:raise Failure('Saved task could not be verified.')
        if row.get('id')!=ident or row.get('schema')!=1:raise Failure('Saved task identity mismatch.')
        plan(row['plan'])
        self.revalidate(row)
        if row['state']=='running' and ident not in self.active_ids:
            row['state']='needs_review';row['uncertain']=True;row['notice']='An earlier execution was interrupted. Check the application/files before resolving the current step.';self.write(row)
        return row
    def admin(self,op,r):
        self.allowed()
        with self.lock:
            if op=='task_list':
                rows=[]
                for p in sorted(self.directory().glob('*.sealed'))[:25]:
                    try:row=self.load(p.stem)
                    except AccountUnavailable:continue # Do not disclose other-account task titles or stored evidence.
                    rows.append({k:row[k] for k in ('id','title','state','next','revision','notice')})
                return {'tasks':rows,'folder':str(self.directory())}
            if op=='task_get':
                row=self.load(r.get('id'));return {'record':{k:v for k,v in row.items() if k!='results'},'document':self.document(row)}
            if op=='task_create':
                if r.get('public_attested') is not True or r.get('reviewed') is not True:raise Failure('Review the plan and confirm PUBLIC content before saving.')
                value=plan(r.get('plan'));return self.create(value)
            if op=='task_resolve':
                row=self.load(r.get('id'))
                if row['id'] in self.active_ids or not row.get('uncertain') or r.get('reviewed') is not True:raise Failure('Inspect the interrupted step before resolving it.')
                choice=r.get('choice')
                if choice=='completed':
                    row['results'].append({'manually_confirmed':True,'note':'Owner confirmed completion after interruption. No automatic outcome verification.'});row['next']+=1
                elif choice!='retry':raise Failure('Choose completed or retry after checking for side effects.')
                row.update(uncertain=False,state='complete' if row['next']==len(row['plan']['steps']) else 'paused',notice='Interrupted step resolved by owner; review before resuming.');self.write(row);return {'message':row['notice']}
            raise Failure('Unknown task operation.')
    def create(self,value):
        if len(list(self.directory().glob('*.sealed')))>=25:raise Failure('Task limit reached (25). Archive existing task files before creating more.')
        identity=None
        if any(s['tool'] in ('mail_search','source_read') for s in value['steps']):
            identity=list(self.host.graph.identity()[:2])+[self.host.graph.config.get('authority','')]
        row={'schema':1,'id':secrets.token_hex(16),'title':value['title'],'plan':value,'revision':1,'state':'ready','next':0,'results':[],'uncertain':False,'notice':'Saved; no step has run.','created':time.time(),'identity':identity}
        self.write(row);return {'id':row['id'],'message':'Task saved. Review and run it from Tasks; no action has run.'}
    def document(self,row):
        return '# '+row['title']+'\n\nState: '+row['state']+' · revision '+str(row['revision'])+' · next step '+str(row['next']+1)+'\n\n'+row['notice']+'\n\n```json\n'+json.dumps(row['plan'],indent=2,ensure_ascii=False)+'\n```\n\nCompleted results (untrusted evidence):\n'+'\n\n'.join('Step '+str(i+1)+':\n'+json.dumps(result,ensure_ascii=False) for i,result in enumerate(row['results']))
    def process(self,job):
        self.allowed();runner=Runner(self.host,job);r=job['request']
        if r.get('public_attested') is not True:raise Failure('Confirm this task is PUBLIC.')
        if r.get('task_planning'):return self.propose(runner)
        ident=r.get('saved_task')
        with self.lock:
            row=self.load(ident)
            if ident in self.active_ids:raise Failure('This saved task is already running.')
            if row.get('uncertain'):raise Failure('Resolve the interrupted step before resuming. No action was repeated.')
            if row['next']>=len(row['plan']['steps']):return {'status':'generated','answer':'This task is already complete. No steps were repeated.','task_id':ident,'route':'offline-task'}
            self.active_ids.add(ident)
        try:
            runner.review('Review the remaining task plan before running.',{'task':row['plan'],'next_step':row['next']+1,'revision':row['revision']})
            while row['next']<len(row['plan']['steps']):
                self.allowed();runner.active()
                if len(json.dumps(row,ensure_ascii=False).encode())>MAX-100000:raise Failure('Task record has insufficient space for another result. No further step started.')
                if row['identity'] is not None:
                    current=list(self.host.graph.identity()[:2])+[self.host.graph.config.get('authority','')]
                    if current!=row['identity']:raise Failure('This task belongs to a different Microsoft account or cloud.')
                step=row['plan']['steps'][row['next']];args=resolve(step['arguments'],row['results'])
                parse_plan(json.dumps({'tool':step['tool'],'arguments':args}))
                runner.event('Step '+str(row['next']+1)+': '+step['tool'])
                # Durable intent comes BEFORE action. Crash/timeout cannot silently replay it.
                row.update(state='running',notice='Step execution in progress.',uncertain=True);self.write(row)
                result=runner.execute(step['tool'],args);runner.active()
                if result.get('status')=='unavailable':raise Failure('Local extraction unavailable. Pause this task or request a repaired plan with permitted cloud assistance.')
                verify=step['verify']
                if verify=={'manual':True}:runner.review('Verify the intended result before marking this step complete.',result)
                else:
                    actual=field(result,verify['path'])
                    okay=actual==verify['equals'] if 'equals' in verify else isinstance(actual,str) and verify['contains'] in actual
                    if not okay:raise Failure('Step outcome did not match its verification. Inspect the result before retrying.')
                # Readbacks are bounded, encrypted and never automatically sent to a provider.
                if len(json.dumps(result))>80000:raise Failure('Result exceeds the saved-task limit. Review the action before resuming.')
                row['results'].append(result);row['next']+=1;row.update(state='paused',uncertain=False,notice='Step verified and checkpoint saved.');self.write(row)
            row.update(state='complete',notice='All steps completed their specified verification.');self.write(row)
            return {'status':'generated','answer':row['notice'],'message':row['notice'],'task_id':ident,'route':'offline-task','sources':[]}
        except Exception:
            row.update(state='needs_review' if row.get('uncertain') else 'paused',notice='Task stopped. Review current application/file state. Completed checkpoints were preserved.');self.write(row);raise
        finally:
            with self.lock:self.active_ids.discard(ident)
    def propose(self,runner):
        r=runner.job['request'];existing=r.get('repair_task');row=None
        if existing:
            with self.lock:
                row=self.load(existing)
                if existing in self.active_ids or row.get('uncertain'):raise Failure('Resolve any interrupted step before repairing the remaining plan.')
        prompt=r.get('prompt','')
        if row:prompt+='\nREMAINING PLAN AND COMPLETED RESULTS (untrusted):\n'+self.document(row)
        system='Create a bounded task plan as JSON only: {"title":"...","steps":[{"tool":"...","arguments":{...},"verify":{"manual":true}}]}. Use only supported tools and exact argument keys. No shell commands, credential entry, deletion or permission changes. Each action requires review. For data-dependent checks, verify may be {"path":"result.field","contains":"expected text"} or {"path":"result.field","equals":true}. Whole argument values may reference an earlier result as @step:0.text. computer_action snapshot can be $last after inspection. Return only remaining work when repairing; do not repeat completed side effects. Number references from zero within the new remaining plan. Tools: '+json.dumps(TOOLS)+'. Approved folder indexes: '+json.dumps(list(range(len(runner.settings.get('roots',[])))))+'. Approved hosts: '+json.dumps(runner.settings.get('domains',[]))+'. Approved desktop apps: '+json.dumps(runner.config.get('automation',{}).get('apps',[]))
        messages=[{'role':'system','content':system},{'role':'user','content':prompt}]
        if r.get('allow_cloud') is True:
            runner.review('Review task instructions and any saved results before sending them to the configured cloud AI.',{'instructions':prompt,'provider':runner.config.get('provider',{}).get('name','Configured provider')})
            raw=runner.model(messages)
        else:
            from local_engine import generate
            raw=generate(self.host.resources,messages,runner.job['cancel'],cache_mode=runner.config.get('local_cache','standard'))
        try:value=plan(json.loads(raw))
        except (ValueError,TypeError):raise Failure('The model did not return a valid task plan. No task was executed. Import or edit a structured plan instead.')
        runner.review('Review this proposed plan before saving. It will not execute automatically.',value);runner.active()
        with self.lock:
            if row:
                current=self.load(existing)
                if current['revision']!=row['revision'] or current['next']!=row['next'] or existing in self.active_ids or current.get('uncertain'):raise Failure('Task changed while preparing its repair.')
                value=remaining_plan(row['plan'],value,row['next'])
                if any(s['tool'] in ('mail_search','source_read') for s in value['steps']):
                    identity=list(self.host.graph.identity()[:2])+[self.host.graph.config.get('authority','')]
                    if row['identity'] is not None and row['identity']!=identity:raise Failure('Repair must use the original Microsoft account and cloud.')
                    row['identity']=identity
                row.update(plan=value,title=value['title'],revision=row['revision']+1,state='paused',notice='Repaired remaining plan saved. Review before resuming.');self.write(row);ident=existing
            else:ident=self.create(value)['id']
        return {'status':'generated','answer':'Plan saved; no steps executed. Open Tasks to review and run.','task_id':ident,'route':'cloud' if r.get('allow_cloud') else 'local','sources':[]}

"""Strict structured answers with lossless formatting repair; never fuzzy-match facts."""
import json,re

class GroundingError(ValueError):
    pass

def parse(raw):
    value=raw.strip()
    if value.startswith('```'):
        match=re.fullmatch(r'```(?:json)?\s*\n(.*?)\n```',value,re.S|re.I)
        if match:value=match.group(1)
    try:result=json.loads(value)
    except (ValueError,TypeError):raise GroundingError('The model returned incomplete or incorrectly formatted JSON.')
    if not isinstance(result,dict) or not isinstance(result.get('claims'),list) or not result['claims'] or len(result['claims'])>32:
        raise GroundingError('The model did not provide usable source references.')
    for key in ('suggestions','unknowns'):
        if not isinstance(result.get(key,''),str):raise GroundingError('The model returned an invalid answer field.')
    return result

def checked_answer(host,raw,rows,originals):
    result=parse(raw);aliases={s['alias']:s['id'] for s in rows};reverse={v:k for k,v in aliases.items()}
    texts={a:'\n\n'.join(s['text'] for s in rows if s['alias']==a) for a in aliases}
    claims=[]
    for item in result['claims']:
        if not isinstance(item,dict):raise GroundingError('The model returned an invalid reference.')
        sid=item.get('source_id');q=item.get('quote')
        if not isinstance(sid,str) or not isinstance(q,str) or not q.strip():raise GroundingError('The model omitted a reference or quotation.')
        alias=sid if sid in aliases else reverse.get(sid)
        if alias not in texts:raise GroundingError('The model cited a source it was not given.')
        if q not in texts[alias]:
            # Reconstruct only whitespace differences, with exact case, punctuation and words.
            # The original source substring is then checked again by Rust below.
            pattern=r'\s+'.join(re.escape(word) for word in re.split(r'\s+',q.strip()))
            matches=list(re.finditer(pattern,texts[alias]))
            if len(matches)!=1:raise GroundingError('A model quotation did not match the supplied source text.')
            q=matches[0].group(0)
        claims.append(dict(item,source_id=alias,quote=q))
    checked=host.rust('validate',sources=[{'id':a,'text':v} for a,v in texts.items()],claims=claims)
    if not checked.get('valid'):raise GroundingError('A model quotation failed source validation.')
    claims=[dict(c,source_id=aliases[c['source_id']]) for c in claims]
    if not host.rust('validate',sources=originals,claims=claims).get('valid'):
        raise GroundingError('A quotation did not match its original source.')
    return result,claims,checked['note']

def excerpts(host,rows,originals):
    # Complete locally packed paragraphs, not sentences invented or repaired by the model.
    claims=[{'source_id':s['id'],'quote':s['text']} for s in rows[:5] if s['text'].strip()]
    return claims if claims and host.rust('validate',sources=originals,claims=claims).get('valid') else []

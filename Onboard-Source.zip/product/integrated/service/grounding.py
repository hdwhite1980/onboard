"""Strict structured answers with lossless formatting repair; never fuzzy-match facts."""
import json,re

REPLY_INSTRUCTION = ('Write a short email or chat reply in the first person, addressed to the sender. Put the ready-to-edit message in suggestions. '
                     'Start with a greeting or acknowledgment. Address the selected message rather than summarizing it in the third person. '
                     'Do not describe the writer or user. Do not invent commitments, completed actions or answers to unrelated messages. '
                     'Do not propose a meeting unless the user explicitly asks for one. If the message says not to reply, explain that. If no response is needed, explain that instead of inventing a reason to reply.')
INSTRUCTION = (' Return only a JSON object. Required keys: claims (an array of objects, each with evidence_id set to a supplied E-number), '
               'suggestions (a string containing your actual answer or proposed reply), unknowns (a string listing missing information, or an empty string). '
               'One evidence reference is sufficient. Choose only references from the allowed evidence list. Do not generate quotations; Onboard attaches the exact source text. '
               'Never invent references. Do not copy these instructions into the answer. Preserve negation and uncertainty. No Markdown fences.')
PLACEHOLDERS={'clearly proposed preparation or draft','short summary','your actual answer or proposed reply','clearly proposed draft','proposed reply','suggestions'}

class GroundingError(ValueError):
    pass

def parse(raw):
    value=raw.strip()
    if value.startswith('```'):
        match=re.fullmatch(r'```(?:json)?\s*\n(.*?)\n```',value,re.S|re.I)
        if match:value=match.group(1)
    def unique(pairs):
        result={}
        for key,item in pairs:
            if key in result:raise ValueError('Duplicate JSON field')
            result[key]=item
        return result
    decoder=json.JSONDecoder(object_pairs_hook=unique)
    try:result=decoder.decode(value)
    except (ValueError,TypeError):
        # Observed small-model format error: the claims object closes one brace
        # before suggestions/unknowns. Remove that one structural brace only.
        # JSON decoding locates it outside strings; no field value is changed.
        try:
            first,end=decoder.raw_decode(value)
            if not isinstance(first,dict) or set(first)!={'claims'} or not re.match(r'^\s*,\s*"suggestions"\s*:',value[end:]):raise ValueError()
            result=decoder.decode(value[:end-1]+value[end:])
        except (ValueError,TypeError):raise GroundingError('The model returned incomplete or incorrectly formatted JSON.')

    if not isinstance(result,dict) or not isinstance(result.get('claims'),list) or not result['claims'] or len(result['claims'])>32:
        raise GroundingError('The model did not provide usable source references.')
    for key in ('suggestions','unknowns'):
        if not isinstance(result.get(key,''),str):raise GroundingError('The model returned an invalid answer field.')
    if result.get('suggestions','').strip().casefold() in PLACEHOLDERS:
        raise GroundingError('The model repeated a prompt placeholder instead of writing an answer.')
    return result

def checked_answer(host,raw,rows,originals):
    result=parse(raw);aliases={s['alias']:s['id'] for s in rows};reverse={v:k for k,v in aliases.items()}
    texts={a:'\n\n'.join(s['text'] for s in rows if s['alias']==a) for a in aliases}
    evidence={s['evidence_id']:s for s in rows if s.get('evidence_id')}
    # Older replies sometimes use the supplied source alias as an evidence reference.
    # Resolve it only when that source has exactly one supplied excerpt.
    for alias in aliases:
        candidates=[s for s in rows if s['alias']==alias and s.get('evidence_id')]
        if len(candidates)==1:evidence.setdefault(alias,candidates[0])
    claims=[]
    for item in result['claims']:
        if not isinstance(item,dict):raise GroundingError('The model returned an invalid reference.')
        if 'evidence_id' in item:
            eid=item['evidence_id']
            if not isinstance(eid,str) or eid not in evidence:raise GroundingError('The model cited an evidence reference it was not given.')
            row=evidence[eid]
            if ('quote' in item and item['quote']!=row['text']) or ('source_id' in item and item['source_id'] not in (row['id'],row['alias'])):
                raise GroundingError('The model added a conflicting source or quotation.')
            item=dict(item,source_id=row['alias'],quote=row['text'])
        sid=item.get('source_id');q=item.get('quote')
        if not isinstance(sid,str) or not isinstance(q,str) or not q.strip():raise GroundingError('The model omitted a reference or quotation.')
        alias=sid if sid in aliases else reverse.get(sid)
        if alias not in texts:raise GroundingError('The model cited a source it was not given.')
        if q not in texts[alias]:
            # Reconstruct only whitespace differences, with exact case, punctuation and words.
            # The original source substring is then checked again by Rust below.
            pattern=r'\s+'.join(re.escape(word) for word in re.split(r'\s+',q.strip()))
            matches=list(re.finditer(pattern,texts[alias]))
            if len(matches)!=1:raise GroundingError('A model quotation did not match the supplied source text.')
            q=matches[0].group(0)
        claims.append(dict(item,source_id=alias,quote=q))
    checked=host.rust('validate',sources=[{'id':a,'text':v} for a,v in texts.items()],claims=claims)
    if not checked.get('valid'):raise GroundingError('A model quotation failed source validation.')
    claims=[dict(c,source_id=aliases[c['source_id']]) for c in claims]
    if not host.rust('validate',sources=originals,claims=claims).get('valid'):
        raise GroundingError('A quotation did not match its original source.')
    return result,claims,checked['note']

def excerpts(host,rows,originals):
    # Complete locally packed paragraphs, not sentences invented or repaired by the model.
    claims=[]
    for s in rows:
        if len(claims)>=3:break
        if s['text'].strip():claims.append({'source_id':s['id'],'quote':s['text']})
    return claims if claims and host.rust('validate',sources=originals,claims=claims).get('valid') else []


def no_reply_notice(request,sources):
    """Recognize an explicit standalone no-reply sentence in the opened mail only.
    This is a reply recommendation, not an instruction or policy from source text.
    A separately requested follow-up remains possible.
    """
    if request.get('task')!='reply':return None
    primary=next((s for s in sources if s.get('primary') and s.get('kind')=='mail'),None)
    if not primary:return None
    match=re.search(r'(?im)^[ \t]*(?:please[ \t]+)?do[ \t]+not[ \t]+reply[ \t]+to[ \t]+this[ \t]+(?:email|e-mail|message)[.!]?[ \t]*$',primary['text'])
    if match:return {'source_id':primary['id'],'quote':match.group(0).strip()}
    return None

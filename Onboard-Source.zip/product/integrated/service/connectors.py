"""Bounded tenant-scoped Graph and explicit GenAI HTTP adapters. No content logs."""
import base64, datetime, html.parser, io, json, re, threading, time, urllib.parse, urllib.request, urllib.error, zipfile
import xml.etree.ElementTree as ET

class Failure(Exception): pass
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs): return None
class Text(html.parser.HTMLParser):
    def __init__(self): super().__init__(); self.parts=[]; self.skip=0
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style'): self.skip+=1
        if tag in ('br','p','div','li'): self.parts.append('\n')
    def handle_endtag(self, tag):
        if tag in ('script','style'): self.skip=max(0,self.skip-1)
    def handle_data(self, data):
        if not self.skip: self.parts.append(data)
def plain(value):
    p=Text();p.feed(value or '');return ''.join(p.parts).strip()
def http(url, method='GET', payload=None, headers=None, timeout=30, raw=False, proxy=''):
    from network import request
    return request(url,method,payload,headers,timeout,raw,proxy)
def segment(value):
    if not isinstance(value,str) or not value or len(value)>2048 or any(c in value for c in ('\x00','\r','\n')): raise Failure('Invalid source identifier.')
    return urllib.parse.quote(value,safe='')
def verification_address(value,authority):
    message='Unexpected Microsoft sign-in address.'
    if not isinstance(value,str) or not value or any(ord(c)<=32 for c in value) or '\\' in value:raise Failure(message)
    try:
        u=urllib.parse.urlsplit(value)
        allowed=('microsoft.com','www.microsoft.com',urllib.parse.urlsplit(authority).hostname)
        # Observed in the real commercial Entra device-code response. This is a
        # browser verification page, not a token endpoint or a Graph destination.
        current_device_page=(authority=='https://login.microsoftonline.com' and u.hostname=='login.microsoft.com' and u.path=='/device' and not u.query and not u.fragment)
        if u.scheme!='https' or (u.hostname not in allowed and not current_device_page) or u.username is not None or u.password is not None or u.port not in (None,443):raise Failure(message)
    except ValueError:raise Failure(message)
    return value
class Graph:
    def __init__(self): self.lock=threading.RLock();self.disconnect()
    def disconnect(self):
        with self.lock:
            flow=getattr(self,'browser_flow',None)
            if flow:flow.close()
            self.browser_flow=None
            self.token=None;self.expires=0;self.account=None;self.pending=None;self.config=None;self.epoch=getattr(self,'epoch',0)+1
    def post(self,config,path,fields):
        return http(config['authority']+'/'+config['tenant']+'/oauth2/v2.0/'+path,'POST',urllib.parse.urlencode(fields).encode(),{'Content-Type':'application/x-www-form-urlencoded'},timeout=10,proxy=config.get('proxy',''))
    def start(self,config,mode='device'):
        if mode not in ('browser','device'):raise Failure('Unsupported Microsoft sign-in method.')
        import uuid
        from tenant import discover
        try:uuid.UUID(config.get('client',''))
        except (ValueError,TypeError,AttributeError):raise Failure('Enter the approved Application (client) ID from Entra.')
        self.disconnect()
        with self.lock: epoch=self.epoch
        detected=discover(config.get('tenant',''),config.get('cloud','Auto'),config.get('proxy',''))
        config=dict(config,**detected);graph=config['graph']
        with self.lock:
            if epoch!=self.epoch:raise Failure('Sign-in cancelled.')
        scopes=['User.Read']
        for feature,permissions in {'send_email':['Mail.Send'],'send_teams':['Chat.Create','ChatMessage.Send','User.ReadBasic.All'],'calendar':['Calendars.Read'],'mail':['Mail.Read'],'files':['Files.Read'],'teams':['Chat.Read','ChannelMessage.Read.All'],'transcripts':['OnlineMeetings.Read','OnlineMeetingTranscript.Read.All']}.items():
            if config.get(feature): scopes+=permissions
        if mode=='browser':
            from browser_auth import BrowserAuth
            with self.lock:
                if epoch!=self.epoch:raise Failure('Sign-in cancelled.')
                try:flow=BrowserAuth()
                except OSError:raise Failure('Could not open the local sign-in callback. Retry sign-in.')
                self.browser_flow=flow;self.config=config
                self.pending={'mode':'browser','deadline':flow.deadline,'next_poll':0}
                fields={'client_id':config['client'],'response_type':'code','redirect_uri':flow.redirect,'response_mode':'query','scope':' '.join(graph+'/'+s for s in scopes),'state':flow.state,'code_challenge':flow.challenge,'code_challenge_method':'S256','prompt':'select_account'}
                return {'authorization_uri':config['authority']+'/'+config['tenant']+'/oauth2/v2.0/authorize?'+urllib.parse.urlencode(fields),'expires_in':600,'cloud':config['cloud'],'graph':graph,'mode':'browser'}
        response=self.post(config,'devicecode',{'client_id':config['client'],'scope':' '.join(graph+'/'+s for s in scopes)})
        verification_address(response.get('verification_uri'),config['authority'])
        with self.lock:
            if epoch!=self.epoch: raise Failure('Sign-in cancelled.')
            self.config=dict(config,graph=graph);self.pending=dict(response,deadline=time.monotonic()+min(response['expires_in'],900),next_poll=0)
        return dict({k:response[k] for k in ('user_code','verification_uri','expires_in')},cloud=config['cloud'],graph=graph)
    def poll(self):
        with self.lock:
            p=self.pending;c=self.config;epoch=self.epoch
            if not p or time.monotonic()>p['deadline']:
                self.disconnect();raise Failure('Sign-in expired or cancelled.')
            if time.monotonic()<p['next_poll']: return {'state':'pending'}
            if p.get('exchanging'):return {'state':'pending'}
            if p.get('mode')=='browser':
                try:result=self.browser_flow.take()
                except ValueError as e:self.disconnect();raise Failure(str(e))
                if result is None:return {'state':'pending'}
                if result.get('error'):
                    self.disconnect();raise Failure('Microsoft browser sign-in was denied or cancelled. Check the browser message and your tenant sign-in policy.')
                fields={'client_id':c['client'],'grant_type':'authorization_code','code':result['code'],'redirect_uri':result['redirect'],'code_verifier':result['verifier']}
                p['exchanging']=True
            else:fields={'client_id':c['client'],'grant_type':'urn:ietf:params:oauth:grant-type:device_code','device_code':p['device_code']}
            p['next_poll']=time.monotonic()+max(5,p.get('interval',5))
        try: r=self.post(c,'token',fields)
        except Failure as e:
            if p.get('mode')=='browser':
                with self.lock:
                    if epoch==self.epoch:self.disconnect()
                raise Failure('Microsoft could not complete browser sign-in. Check the Entra desktop redirect URI http://localhost/onboard-signin and sign-in policy, then retry.')
            if str(e)=='authorization_pending': return {'state':'pending'}
            if str(e)=='slow_down':
                with self.lock: p['interval']=p.get('interval',5)+5
                return {'state':'pending'}
            raise
        with self.lock:
            if epoch!=self.epoch: raise Failure('Sign-in cancelled.')
            if r.get('token_type','').lower()!='bearer': raise Failure('Microsoft did not provide a bearer session.')
            self.token=r['access_token'];self.expires=time.monotonic()+int(r['expires_in'])-60
        account=self.get('me',{'$select':'id,displayName,mail,userPrincipalName'})
        with self.lock:
            if epoch!=self.epoch: raise Failure('Account changed during sign-in.')
            self.account={k:account.get(k,'') for k in ('id','displayName','mail','userPrincipalName')};self.pending=None
        return {'state':'connected','account':self.account}
    def identity(self):
        with self.lock:
            if not self.account or time.monotonic()>=self.expires: raise Failure('Sign in to Microsoft 365 in Settings.')
            return (self.config['tenant'],self.account['id'],self.epoch)
    def get(self,path,query=None,raw=False):
        with self.lock:
            if not self.token or time.monotonic()>=self.expires: raise Failure('Microsoft sign-in is required.')
            token=self.token;root=self.config['graph'];proxy=self.config.get('proxy','')
        if path.startswith('/') or '..' in path or '://' in path or '?' in path: raise Failure('Unsupported Graph resource.')
        return http(root+'/v1.0/'+path+('?' + urllib.parse.urlencode(query) if query else ''),headers={'Authorization':'Bearer '+token,'Prefer':'outlook.body-content-type="text", outlook.timezone="UTC"'},raw=raw,proxy=proxy)
    def write(self,path,payload,identity,raw=False):
        with self.lock:
            if self.identity()!=identity:raise Failure('Microsoft account changed before sending.')
            if path.startswith('/') or '..' in path or '://' in path or '?' in path:raise Failure('Unsupported Graph destination.')
            return http(self.config['graph']+'/v1.0/'+path,'POST',json.dumps(payload).encode(),{'Authorization':'Bearer '+self.token,'Content-Type':'application/json'},timeout=10,raw=raw,proxy=self.config.get('proxy',''))
    def require(self,capability):
        if not self.config or not self.config.get(capability): raise Failure('Enable '+capability+' access and sign in again in Settings.')
    def source(self,kind,obj,text=None):
        body=obj.get('body',{});content=body.get('content','') if isinstance(body,dict) else str(body)
        value=text if text is not None else (plain(content) if body.get('contentType','').lower()=='html' else content)
        if not value: value=obj.get('bodyPreview','')
        result={'id':kind+':'+obj['id'],'title':obj.get('subject') or obj.get('name') or kind,'text':value[:65536],'incomplete':len(value)>65536,'url':obj.get('webLink') or obj.get('webUrl',''),'kind':kind,'classification':'UNKNOWN','retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        if kind=='mail':
            from documents import email_labels
            result['sensitivity']=email_labels(obj['internetMessageHeaders']) if isinstance(obj.get('internetMessageHeaders'),list) else {'state':'unavailable','labels':[]}
        return result
    def collect_mail(self,query,scope,cancel):
        """Explicit bounded mailbox collection; never claims an entire mailbox was read."""
        self.require('mail');rows=[];path='me/messages';params={'$top':'50','$select':'id,subject,body,webLink,internetMessageHeaders'};pages=0;more=False
        if scope=='search':
            terms=re.findall(r'[^\W_]{2,}',query)[:8]
            if not terms:raise Failure('Enter specific mailbox search words, or explicitly choose recent messages.')
            params['$search']='"'+' AND '.join(terms)+'"'
        else:params['$orderby']='receivedDateTime desc'
        while pages<4:
            if cancel.is_set():raise Failure('Mailbox collection cancelled.')
            data=self.get(path,params);rows.extend(self.source('mail',m) for m in data.get('value',[])[:50]);pages+=1
            link=data.get('@odata.nextLink');more=bool(link)
            if not link:break
            u=urllib.parse.urlsplit(link);root=urllib.parse.urlsplit(self.config['graph'])
            if u.scheme!='https' or u.netloc!=root.netloc or u.path!='/v1.0/me/messages' or u.fragment or u.username:raise Failure('Unexpected mailbox continuation destination.')
            params=dict(urllib.parse.parse_qsl(u.query))
        return rows,'Collected %d %s messages across %d page(s), with a 200-message limit. %s This is not an exhaustive mailbox review.'%(len(rows),'matching' if scope=='search' else 'most recent',pages,'More results were omitted.' if more else 'No further results reported for this query.')
    def search_mail(self,question,subject=''):
        """One read-only, tenant-scoped query; no mailbox export or automatic pagination."""
        self.require('mail')
        stop={'the','and','for','with','this','that','from','what','when','where','which','about','please','email','emails','message','messages','summarize','summary','prepare','reply','explain','find','relevant','related','suggest','suggested','give','tell','make','create','draft','response','respond','write','read','can','could','would','should','you','your','our','all','have','has','does','been','will','are','not','only','also','some','these','those','into','through','conversation','conversational','style','request','ask','asking','meeting','available','times','send','sent','outlook','teams','using','use','opened','current','selected'}
        def terms(text):
            return list(dict.fromkeys(w for w in re.findall(r'[^\W_]{3,}',text.casefold()) if w not in stop))[:6]
        words=terms(question) or terms(subject)
        if not words:return [],'No specific search terms were supplied; only the selected sources were retrieved.'
        result=self.get('me/messages',{'$search':'"'+' AND '.join(words)+'"','$top':'10','$select':'id,subject,body,webLink,internetMessageHeaders'})
        return [self.source('mail',m) for m in result.get('value',[])[:10]],'Explicit related-mail search returned at most 10 candidates matching all search terms: '+', '.join(words)+'. This is a candidate search, not an exhaustive mailbox review.'
    def message_options(self,kind,ref):
        self.require('teams')
        if kind=='chat':path='chats/'+segment(ref)+'/messages'
        elif kind=='channel':
            team,channel=ref.split('|');path='teams/'+segment(team)+'/channels/'+segment(channel)+'/messages'
        else:raise Failure('Unsupported Teams conversation.')
        rows=self.get(path,{'$top':'30'}).get('value',[])[:30];options=[]
        for row in rows:
            if row.get('deletedDateTime'):continue
            source=self.source('teams',row)
            if not source['text'].strip():continue
            sender=(row.get('from') or {}).get('user') or (row.get('from') or {}).get('application') or {}
            label=' · '.join(x for x in (sender.get('displayName',''),row.get('createdDateTime',''),source['text'][:160]) if x)
            options.append({'label':label,'selection':{'kind':kind+'_message','ref':ref+'|'+row['id']}})
        return {'options':options,'message':'Choose one message. Showing up to 30 recent '+('messages.' if kind=='chat' else 'channel posts; replies are not listed.')}
    def retrieve(self,kind,ref,current_only=False):
        if kind in ('chat_message','channel_message'):
            self.require('teams')
            if kind=='chat_message':
                chat,message=ref.split('|');path='chats/'+segment(chat)+'/messages/'+segment(message)
            else:
                team,channel,message=ref.split('|');path='teams/'+segment(team)+'/channels/'+segment(channel)+'/messages/'+segment(message)
            obj=self.get(path)
            if obj.get('deletedDateTime'):raise Failure('This Teams message was deleted. Choose another message.')
            source=self.source('teams',obj);source['primary']=True
            source['title']=((obj.get('from') or {}).get('user') or {}).get('displayName') or 'Selected Teams message'
            return [source],'Only the Teams message you selected was retrieved.'
        if kind=='mail':
            self.require('mail');m=self.get('me/messages/'+segment(ref),{'$select':'id,subject,body,conversationId,webLink,internetMessageHeaders'});s=[self.source('mail',m)]
            s[0]['primary']=True
            if current_only:return s,'Reply/edit context: only the selected message was retrieved. Other messages were not searched or added.'
            # Conversation query is server-side and read-only; it never follows arbitrary nextLink URLs.
            cid=m.get('conversationId')
            if cid:
                rows=self.get('me/messages',{'$filter':"conversationId eq '"+cid.replace("'","''")+"'",'$top':'10','$select':'id,subject,body,webLink,internetMessageHeaders'})
                s += [self.source('mail',x) for x in rows.get('value',[]) if x['id']!=m['id']]
            return s,'Current message and at most 10 messages in its thread; older context may be omitted.'
        if kind=='meeting':
            self.require('calendar');m=self.get('me/events/'+segment(ref),{'$select':'id,subject,body,start,end,attendees,webLink,onlineMeeting'})
            s=[self.source('calendar',m)];s[0]['text']='Meeting: '+m.get('subject','')+'\nStart: '+json.dumps(m.get('start'))+'\nParticipants: '+', '.join(a['emailAddress'].get('name') or a['emailAddress']['address'] for a in m.get('attendees',[]))+'\n'+s[0]['text']
            return s,'Calendar context retrieved. Add specific related messages, files or Teams sources below; no unverified relevance is implied.'
        if kind=='chat':
            self.require('teams');r=self.get('chats/'+segment(ref)+'/messages',{'$top':'30'})
            return [self.source('teams',x) for x in r.get('value',[])],'At most 30 accessible chat messages; older messages may be omitted.'
        if kind=='channel':
            self.require('teams');team,channel=ref.split('|',1);r=self.get('teams/'+segment(team)+'/channels/'+segment(channel)+'/messages',{'$top':'30'})
            return [self.source('teams',x) for x in r.get('value',[])],'At most 30 channel root messages; replies are not included.'
        if kind=='transcript':
            self.require('transcripts');meeting,transcript=ref.split('|',1)
            raw=self.get('me/onlineMeetings/'+segment(meeting)+'/transcripts/'+segment(transcript)+'/content',raw=True)
            return [self.source('transcript',{'id':transcript},raw.decode('utf-8'))],'Existing authorized transcript; no recording was started.'
        if kind=='file':
            self.require('files');drive,item=ref.split('|',1);base='drives/'+segment(drive)+'/items/'+segment(item);m=self.get(base,{'$select':'id,name,size,webUrl'})
            if m.get('size',0)>4_000_000: raise Failure('Choose a document below 4 MB.')
            # Graph /content commonly redirects to a preauthenticated URL. Obtain only the selected item URL;
            # download anonymously from the detected cloud's SharePoint host, never forward Graph bearer.
            detail=self.get(base);url=detail.get('@microsoft.graph.downloadUrl','');u=urllib.parse.urlparse(url)
            if u.scheme!='https' or not u.hostname or not u.hostname.endswith(self.config['sharepoint_suffix']) or u.username or u.password or u.port not in (None,443): raise Failure('Document download host is not approved for this tenant cloud.')
            raw=http(url,raw=True,proxy=self.config.get('proxy',''));name=m.get('name','').lower()
            if name.endswith(('.txt','.md','.csv')): text=raw.decode('utf-8-sig')
            elif name.endswith('.docx'):
                with zipfile.ZipFile(io.BytesIO(raw)) as z:
                    entry=z.getinfo('word/document.xml')
                    if entry.file_size>4_000_000: raise Failure('Document text exceeds the size limit.')
                    tree=ET.fromstring(z.read(entry));text='\n'.join(''.join(p.itertext()) for p in tree.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'))
            else: raise Failure('This build reads TXT, Markdown, CSV and DOCX. Other formats need a reviewed parser.')
            source=self.source('document',m,text)
            if name.endswith('.docx'):
                from documents import inspect_docx
                source['sensitivity']=inspect_docx(raw)['sensitivity']
            return [source],'Selected accessible file only; text over 64 KiB is explicitly marked incomplete.'
        raise Failure('Unsupported source type.')

def validate_provider(c):
    if c.get('type') not in ('azure-chat','compatible-chat'): raise Failure('Select Azure OpenAI or Chat Completions-compatible API.')
    u=urllib.parse.urlparse(c.get('endpoint',''))
    if u.scheme!='https' or not u.hostname or u.username or u.password or u.query or u.fragment: raise Failure('Enter an HTTPS endpoint without credentials, query parameters or fragments.')
    if u.hostname in ('localhost','127.0.0.1','::1'): raise Failure('Cloud API endpoint cannot be the local bridge.')
    if not c.get('model','').strip(): raise Failure('Model or deployment is required.')
    for field,minimum,maximum in [('max_output',1,4096),('max_input_chars',1,65536),('timeout',1,120),('daily_requests',1,10000)]:
        if type(c.get(field)) is not int or not minimum<=c[field]<=maximum: raise Failure('Invalid provider limit: '+field)
    return c

def cloud(c,secret,messages,proxy=""):
    validate_provider(c)
    if not secret: raise Failure('Add the API credential in Settings.')
    if sum(len(m['content']) for m in messages)>c['max_input_chars']: raise Failure('Input exceeds the configured provider limit. Nothing was sent.')
    headers={'Content-Type':'application/json'};url=c['endpoint'].rstrip('/')
    payload={'messages':messages,'max_tokens':c['max_output'],'temperature':0}
    if c['type']=='azure-chat':
        headers['api-key']=secret;url+='/openai/deployments/'+segment(c['model'])+'/chat/completions?api-version=2024-10-21'
    else:
        headers['Authorization']='Bearer '+secret
        # Accept either the API base or the complete endpoint supplied by its owner.
        if not urllib.parse.urlsplit(url).path.endswith('/chat/completions'):url+='/chat/completions'
        payload['model']=c['model']
        # GPT-5.5 rejects the legacy output limit. Keep vendor-specific options
        # confined to OpenAI; compatible services and Azure deployments vary.
        if urllib.parse.urlsplit(url).hostname=='api.openai.com' and re.fullmatch(r'gpt-5\.5(?:-\d{4}-\d{2}-\d{2})?',c['model']):
            payload.pop('max_tokens');payload.pop('temperature')
            payload['max_completion_tokens']=c['max_output']
            payload['reasoning_effort']='none'
    r=http(url,'POST',json.dumps(payload).encode(),headers,timeout=c['timeout'],proxy=proxy)
    try: answer=r['choices'][0]['message']['content']
    except (KeyError,IndexError,TypeError): raise Failure('Provider response does not match this adapter. No response was fabricated.')
    if not isinstance(answer,str): raise Failure('Provider did not return text.')
    return answer, r.get('usage',{})

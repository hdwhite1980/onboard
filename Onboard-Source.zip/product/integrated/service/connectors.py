"""Bounded read-only tenant-scoped Graph and explicit GenAI HTTP adapters. No content logs."""
import base64, datetime, html.parser, io, json, re, threading, time, urllib.parse, urllib.request, urllib.error, zipfile
import xml.etree.ElementTree as ET

class Failure(Exception): pass
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs): return None
class Text(html.parser.HTMLParser):
    def __init__(self): super().__init__(); self.parts=[]; self.skip=0
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style'): self.skip+=1
        if tag in ('br','p','div','li'): self.parts.append('\n')
    def handle_endtag(self, tag):
        if tag in ('script','style'): self.skip=max(0,self.skip-1)
    def handle_data(self, data):
        if not self.skip: self.parts.append(data)
def plain(value):
    p=Text();p.feed(value or '');return ''.join(p.parts).strip()
def http(url, method='GET', payload=None, headers=None, timeout=30, raw=False, proxy=''):
    from network import request
    return request(url,method,payload,headers,timeout,raw,proxy)
def segment(value):
    if not isinstance(value,str) or not value or len(value)>2048 or any(c in value for c in ('\x00','\r','\n')): raise Failure('Invalid source identifier.')
    return urllib.parse.quote(value,safe='')
def verification_address(value,authority):
    message='Unexpected Microsoft sign-in address.'
    if not isinstance(value,str) or not value or any(ord(c)<=32 for c in value) or '\\' in value:raise Failure(message)
    try:
        u=urllib.parse.urlsplit(value)
        allowed=('microsoft.com','www.microsoft.com',urllib.parse.urlsplit(authority).hostname)
        # Observed in the real commercial Entra device-code response. This is a
        # browser verification page, not a token endpoint or a Graph destination.
        current_device_page=(authority=='https://login.microsoftonline.com' and u.hostname=='login.microsoft.com' and u.path=='/device' and not u.query and not u.fragment)
        if u.scheme!='https' or (u.hostname not in allowed and not current_device_page) or u.username is not None or u.password is not None or u.port not in (None,443):raise Failure(message)
    except ValueError:raise Failure(message)
    return value
class Graph:
    def __init__(self): self.lock=threading.RLock();self.disconnect()
    def disconnect(self):
        with self.lock: self.token=None;self.expires=0;self.account=None;self.pending=None;self.config=None;self.epoch=getattr(self,'epoch',0)+1
    def post(self,config,path,fields):
        return http(config['authority']+'/'+config['tenant']+'/oauth2/v2.0/'+path,'POST',urllib.parse.urlencode(fields).encode(),{'Content-Type':'application/x-www-form-urlencoded'},timeout=10,proxy=config.get('proxy',''))
    def start(self,config):
        import uuid
        from tenant import discover
        try:uuid.UUID(config.get('client',''))
        except (ValueError,TypeError,AttributeError):raise Failure('Enter the approved Application (client) ID from Entra.')
        self.disconnect()
        with self.lock: epoch=self.epoch
        detected=discover(config.get('tenant',''),config.get('cloud','Auto'),config.get('proxy',''))
        config=dict(config,**detected);graph=config['graph']
        with self.lock:
            if epoch!=self.epoch:raise Failure('Sign-in cancelled.')
        scopes=['User.Read']
        for feature,permissions in {'calendar':['Calendars.Read'],'mail':['Mail.Read'],'files':['Files.Read'],'teams':['Chat.Read','ChannelMessage.Read.All'],'transcripts':['OnlineMeetings.Read','OnlineMeetingTranscript.Read.All']}.items():
            if config.get(feature): scopes+=permissions
        response=self.post(config,'devicecode',{'client_id':config['client'],'scope':' '.join(graph+'/'+s for s in scopes)})
        verification_address(response.get('verification_uri'),config['authority'])
        with self.lock:
            if epoch!=self.epoch: raise Failure('Sign-in cancelled.')
            self.config=dict(config,graph=graph);self.pending=dict(response,deadline=time.monotonic()+min(response['expires_in'],900),next_poll=0)
        return dict({k:response[k] for k in ('user_code','verification_uri','expires_in')},cloud=config['cloud'],graph=graph)
    def poll(self):
        with self.lock:
            p=self.pending;c=self.config;epoch=self.epoch
            if not p or time.monotonic()>p['deadline']: raise Failure('Sign-in expired or cancelled.')
            if time.monotonic()<p['next_poll']: return {'state':'pending'}
            p['next_poll']=time.monotonic()+max(5,p.get('interval',5))
        try: r=self.post(c,'token',{'client_id':c['client'],'grant_type':'urn:ietf:params:oauth:grant-type:device_code','device_code':p['device_code']})
        except Failure as e:
            if str(e)=='authorization_pending': return {'state':'pending'}
            if str(e)=='slow_down':
                with self.lock: p['interval']=p.get('interval',5)+5
                return {'state':'pending'}
            raise
        with self.lock:
            if epoch!=self.epoch: raise Failure('Sign-in cancelled.')
            if r.get('token_type','').lower()!='bearer': raise Failure('Microsoft did not provide a bearer session.')
            self.token=r['access_token'];self.expires=time.monotonic()+int(r['expires_in'])-60
        account=self.get('me',{'$select':'id,displayName,mail,userPrincipalName'})
        with self.lock:
            if epoch!=self.epoch: raise Failure('Account changed during sign-in.')
            self.account={k:account.get(k,'') for k in ('id','displayName','mail','userPrincipalName')};self.pending=None
        return {'state':'connected','account':self.account}
    def identity(self):
        with self.lock:
            if not self.account or time.monotonic()>=self.expires: raise Failure('Sign in to Microsoft 365 in Settings.')
            return (self.config['tenant'],self.account['id'],self.epoch)
    def get(self,path,query=None,raw=False):
        with self.lock:
            if not self.token or time.monotonic()>=self.expires: raise Failure('Microsoft sign-in is required.')
            token=self.token;root=self.config['graph'];proxy=self.config.get('proxy','')
        if path.startswith('/') or '..' in path or '://' in path or '?' in path: raise Failure('Unsupported Graph resource.')
        return http(root+'/v1.0/'+path+('?' + urllib.parse.urlencode(query) if query else ''),headers={'Authorization':'Bearer '+token,'Prefer':'outlook.body-content-type="text", outlook.timezone="UTC"'},raw=raw,proxy=proxy)
    def require(self,capability):
        if not self.config or not self.config.get(capability): raise Failure('Enable '+capability+' access and sign in again in Settings.')
    def source(self,kind,obj,text=None):
        body=obj.get('body',{});content=body.get('content','') if isinstance(body,dict) else str(body)
        value=text if text is not None else (plain(content) if body.get('contentType','').lower()=='html' else content)
        if not value: value=obj.get('bodyPreview','')
        return {'id':kind+':'+obj['id'],'title':obj.get('subject') or obj.get('name') or kind,'text':value[:65536],'incomplete':len(value)>65536,'url':obj.get('webLink') or obj.get('webUrl',''),'kind':kind,'classification':'UNKNOWN','retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    def retrieve(self,kind,ref):
        if kind=='mail':
            self.require('mail');m=self.get('me/messages/'+segment(ref),{'$select':'id,subject,body,conversationId,webLink'});s=[self.source('mail',m)]
            # Conversation query is server-side and read-only; it never follows arbitrary nextLink URLs.
            cid=m.get('conversationId')
            if cid:
                rows=self.get('me/messages',{'$filter':"conversationId eq '"+cid.replace("'","''")+"'",'$top':'10','$select':'id,subject,body,webLink'})
                s += [self.source('mail',x) for x in rows.get('value',[]) if x['id']!=m['id']]
            return s,'Current message and at most 10 messages in its thread; older context may be omitted.'
        if kind=='meeting':
            self.require('calendar');m=self.get('me/events/'+segment(ref),{'$select':'id,subject,body,start,end,attendees,webLink,onlineMeeting'})
            s=[self.source('calendar',m)];s[0]['text']='Meeting: '+m.get('subject','')+'\nStart: '+json.dumps(m.get('start'))+'\nParticipants: '+', '.join(a['emailAddress'].get('name') or a['emailAddress']['address'] for a in m.get('attendees',[]))+'\n'+s[0]['text']
            return s,'Calendar context retrieved. Add specific related messages, files or Teams sources below; no unverified relevance is implied.'
        if kind=='chat':
            self.require('teams');r=self.get('chats/'+segment(ref)+'/messages',{'$top':'30'})
            return [self.source('teams',x) for x in r.get('value',[])],'At most 30 accessible chat messages; older messages may be omitted.'
        if kind=='channel':
            self.require('teams');team,channel=ref.split('|',1);r=self.get('teams/'+segment(team)+'/channels/'+segment(channel)+'/messages',{'$top':'30'})
            return [self.source('teams',x) for x in r.get('value',[])],'At most 30 channel root messages; replies are not included.'
        if kind=='transcript':
            self.require('transcripts');meeting,transcript=ref.split('|',1)
            raw=self.get('me/onlineMeetings/'+segment(meeting)+'/transcripts/'+segment(transcript)+'/content',raw=True)
            return [self.source('transcript',{'id':transcript},raw.decode('utf-8'))],'Existing authorized transcript; no recording was started.'
        if kind=='file':
            self.require('files');drive,item=ref.split('|',1);base='drives/'+segment(drive)+'/items/'+segment(item);m=self.get(base,{'$select':'id,name,size,webUrl'})
            if m.get('size',0)>4_000_000: raise Failure('Choose a document below 4 MB.')
            # Graph /content commonly redirects to a preauthenticated URL. Obtain only the selected item URL;
            # download anonymously from the detected cloud's SharePoint host, never forward Graph bearer.
            detail=self.get(base);url=detail.get('@microsoft.graph.downloadUrl','');u=urllib.parse.urlparse(url)
            if u.scheme!='https' or not u.hostname or not u.hostname.endswith(self.config['sharepoint_suffix']) or u.username or u.password or u.port not in (None,443): raise Failure('Document download host is not approved for this tenant cloud.')
            raw=http(url,raw=True,proxy=self.config.get('proxy',''));name=m.get('name','').lower()
            if name.endswith(('.txt','.md','.csv')): text=raw.decode('utf-8-sig')
            elif name.endswith('.docx'):
                with zipfile.ZipFile(io.BytesIO(raw)) as z:
                    entry=z.getinfo('word/document.xml')
                    if entry.file_size>4_000_000: raise Failure('Document text exceeds the size limit.')
                    tree=ET.fromstring(z.read(entry));text='\n'.join(''.join(p.itertext()) for p in tree.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'))
            else: raise Failure('This build reads TXT, Markdown, CSV and DOCX. Other formats need a reviewed parser.')
            return [self.source('document',m,text)],'Selected accessible file only; text over 64 KiB is explicitly marked incomplete.'
        raise Failure('Unsupported source type.')

def validate_provider(c):
    if c.get('type') not in ('azure-chat','compatible-chat'): raise Failure('Select Azure OpenAI or Chat Completions-compatible API.')
    u=urllib.parse.urlparse(c.get('endpoint',''))
    if u.scheme!='https' or not u.hostname or u.username or u.password or u.query or u.fragment: raise Failure('Enter an HTTPS endpoint without credentials, query parameters or fragments.')
    if u.hostname in ('localhost','127.0.0.1','::1'): raise Failure('Cloud API endpoint cannot be the local bridge.')
    if not c.get('model','').strip(): raise Failure('Model or deployment is required.')
    for field,minimum,maximum in [('max_output',1,4096),('max_input_chars',1,65536),('timeout',1,120),('daily_requests',1,10000)]:
        if type(c.get(field)) is not int or not minimum<=c[field]<=maximum: raise Failure('Invalid provider limit: '+field)
    return c

def cloud(c,secret,messages,proxy=""):
    validate_provider(c)
    if not secret: raise Failure('Add the API credential in Settings.')
    if sum(len(m['content']) for m in messages)>c['max_input_chars']: raise Failure('Input exceeds the configured provider limit. Nothing was sent.')
    headers={'Content-Type':'application/json'};url=c['endpoint'].rstrip('/')
    payload={'messages':messages,'max_tokens':c['max_output'],'temperature':0}
    if c['type']=='azure-chat':
        headers['api-key']=secret;url+='/openai/deployments/'+segment(c['model'])+'/chat/completions?api-version=2024-10-21'
    else:
        headers['Authorization']='Bearer '+secret;url+='/chat/completions';payload['model']=c['model']
    r=http(url,'POST',json.dumps(payload).encode(),headers,timeout=c['timeout'],proxy=proxy)
    try: answer=r['choices'][0]['message']['content']
    except (KeyError,IndexError,TypeError): raise Failure('Provider response does not match this adapter. No response was fabricated.')
    if not isinstance(answer,str): raise Failure('Provider did not return text.')
    return answer, r.get('usage',{})

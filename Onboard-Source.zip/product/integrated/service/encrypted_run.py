"""Per-request encrypted disk image. Key exists only in process memory/stdin, never argv.
No plaintext fallback. A failed detach preserves the owned image and reports failure.
This protects backing files, not memory/swap or an already compromised user account.
"""
import contextlib,json,stat,os,pathlib,plistlib,secrets,shutil,subprocess,tempfile
from connectors import Failure
class StorageUnavailable(Failure):
    code='ENCRYPTED_STORAGE'
HDI='/usr/bin/hdiutil'
def command(args,key=None):
    try:result=subprocess.run([HDI,*args],input=key,capture_output=True,timeout=90,env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin'})
    except (OSError,subprocess.SubprocessError):raise StorageUnavailable('Encrypted model storage did not respond. Model processing is blocked until storage can be verified.') from None
    if result.returncode:raise StorageUnavailable('Encrypted model storage is unavailable. No plaintext fallback was used.')
    return result.stdout

@contextlib.contextmanager
def encrypted_run(runs,size='2g'):
    runs=pathlib.Path(runs)
    root=pathlib.Path(tempfile.mkdtemp(prefix='sealed-',dir=runs));root.chmod(0o700)
    image=root/'work.sparseimage';mount=root/'mount';mount.mkdir(mode=0o700)
    from run_retention import boot_id
    owner=root/'owner.json'
    with owner.open('x') as f:json.dump({'schema':1,'pid':os.getpid(),'boot':boot_id()},f);f.flush();os.fsync(f.fileno())
    owner.chmod(0o600)
    key=secrets.token_hex(32).encode()+b'\n';attached=False
    try:
        command(['create','-size',size,'-type','SPARSE','-fs','APFS','-volname','OnboardScratch','-nospotlight','-encryption','AES-256','-stdinpass',str(image)],key)
        image.chmod(0o600)
        info=plistlib.loads(command(['imageinfo','-plist',str(image),'-stdinpass'],key))
        if info.get('Properties',{}).get('Encrypted') is not True:raise StorageUnavailable('Disk image encryption was not confirmed. Model launch blocked.')
        # Mark attached before invoking: a timeout may leave a mounted volume.
        attached=True
        command(['attach','-nobrowse','-noautoopen','-owners','on','-mountpoint',str(mount),'-stdinpass',str(image)],key)
        if not os.path.ismount(mount):raise StorageUnavailable('Encrypted model volume did not mount at its expected location.')
        mount.chmod(0o700)
        (mount/'.metadata_never_index').touch(mode=0o600)
        run=mount/'request';run.mkdir(mode=0o700)
        yield run
    finally:
        key=None
        if attached:
            # Resolve only this unique image's mount, never force an unrelated device.
            if os.path.ismount(mount):command(['detach',str(mount)])
            if os.path.ismount(mount):raise StorageUnavailable('Encrypted scratch volume is still mounted. Model processing stopped; an administrator must recover this request.')
        shutil.rmtree(root)


def recover_abandoned(runs):
    """Under the provider lock, detach only marked images from dead owners.
    Never kill a process or force-detach. Busy or ambiguous images block a new run.
    """
    from run_retention import boot_id
    boot=boot_id();removed=0
    for root in pathlib.Path(runs).glob('sealed-*'):
        st=root.lstat()
        if not stat.S_ISDIR(st.st_mode) or st.st_uid!=os.getuid() or st.st_mode&0o077:raise StorageUnavailable('Unsafe encrypted scratch folder requires administrator review.')
        owner=root/'owner.json'
        try:
            st=owner.lstat()
            if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or st.st_mode&0o077 or st.st_size>1024:raise ValueError()
            value=json.loads(owner.read_text())
            if value.get('schema')!=1 or type(value.get('pid')) is not int or value['pid']<=0 or not isinstance(value.get('boot'),str):raise ValueError()
        except (ValueError,OSError):raise StorageUnavailable('Unrecognized encrypted scratch folder requires administrator review.')
        if value['boot']==boot:
            try:os.kill(value['pid'],0)
            except ProcessLookupError:pass
            except PermissionError:raise StorageUnavailable('Cannot verify encrypted scratch owner. No storage was removed.')
            else:raise StorageUnavailable('Another encrypted model workspace may still be active. Nothing was stopped or removed.')
        image=root/'work.sparseimage';mount=root/'mount'
        if image.is_symlink() or mount.is_symlink():raise StorageUnavailable('Encrypted scratch paths changed. Nothing was removed.')
        inventory=plistlib.loads(command(['info','-plist']))
        attached=[i for i in inventory.get('images',[]) if pathlib.Path(i.get('image-path','')).absolute()==image.absolute()]
        if attached:
            points=[e['mount-point'] for i in attached for e in i.get('system-entities',[]) if e.get('mount-point')]
            if points!=[str(mount)] or not os.path.ismount(mount):raise StorageUnavailable('Encrypted image mount changed. Administrator recovery is required.')
            command(['detach',str(mount)])
        if os.path.ismount(mount):raise StorageUnavailable('Encrypted image is still busy. No new model was loaded.')
        shutil.rmtree(root);removed+=1
    return removed

"""Read-only capability diagnostics. Configuration never implies a successful live test."""
def readiness(host):
    from connectors import Failure
    try:host.graph.identity();signed_in=True
    except Failure:signed_in=False
    config=host.config;local=host.local_status()
    managed=host.managed.status(config) if hasattr(host,'managed') else {'ready':True,'managed':False,'message':'Development policy'}
    provider=config.get('provider',{})
    return {'version':'0.6.3','checks':[
      {'name':'Local service','state':'ready','detail':'This add-in reached the installed service over its authenticated connection.'},
      {'name':'Microsoft account','state':'ready' if signed_in else 'action_needed','detail':'Connected for this session.' if signed_in else 'Sign in in Onboard AI Settings, then reconnect the add-in.'},
      {'name':'Local model','state':'ready' if local.get('ready') else 'action_needed','detail':local.get('message','Unavailable')},
      {'name':'Cloud provider','state':'configured_not_verified' if provider else 'not_configured','detail':(provider.get('name','Configured provider')+' · '+provider.get('model','')+'. A saved endpoint/key is not a live connectivity check.') if provider else 'Configure an approved provider in AI Settings if cloud analysis is needed.'},
      {'name':'Organization policy','state':'blocked' if not managed['ready'] else 'managed' if managed.get('managed') else 'development','detail':managed['message']},
      {'name':'Saved work','state':'available','detail':'Explicitly reviewed PUBLIC drafts only; seven-day encrypted local retention. Sign in to the same account to reopen.'},
      {'name':'Customer acceptance','state':'not_verified','detail':'Host SSO, GenAI.mil, protected-data handling, Windows and target government-tenant workflows require separate validation.'}
    ]}

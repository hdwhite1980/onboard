"""Synchronous mTLS audit delivery. No direct/proxy fallback, redirects or payload logs.
Collector must fsync an append-only record before acknowledging its SHA-256 digest.
"""
import hashlib,json,os,pathlib,ssl,stat,urllib.parse,urllib.request
from connectors import Failure,NoRedirect
from network import proxy_configuration,validate_proxy

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
def validate(value):
    if not isinstance(value,dict) or set(value)!={'endpoint','ca','certificate','private_key','proxy'}:raise ValueError('Invalid central audit configuration')
    u=urllib.parse.urlsplit(value['endpoint'])
    if u.scheme!='https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.path!='/v1/events':raise ValueError('Audit collector must use HTTPS /v1/events')
    for k in ('ca','certificate','private_key'):
        if not isinstance(value[k],str) or not pathlib.Path(value[k]).is_absolute():raise ValueError('Audit certificate paths must be absolute')
    validate_proxy(value['proxy'])
    return value

def protected_file(path,secret=False):
    p=pathlib.Path(path)
    for part in (p,*p.parents):
        s=part.lstat()
        if stat.S_ISLNK(s.st_mode) or s.st_uid not in (0,os.getuid()) or s.st_mode&0o022:raise Failure('Central audit certificate storage is unsafe.')
    if not p.is_file() or p.stat().st_size>65536 or (secret and p.stat().st_mode&0o077):raise Failure('Central audit key/certificate permissions are unsafe.')
    return str(p)

class Collector:
    def send(self,config,row):
        try:
            validate(config)
            context=ssl.create_default_context(cafile=protected_file(config['ca']))
            context.minimum_version=ssl.TLSVersion.TLSv1_2
            context.load_cert_chain(protected_file(config['certificate']),protected_file(config['private_key'],True))
            body=canonical(row);digest=hashlib.sha256(body).hexdigest()
            req=urllib.request.Request(config['endpoint'],data=body,headers={'Content-Type':'application/json'},method='POST')
            proxies=proxy_configuration(config['proxy'])
            if config['proxy']:
                proxy=urllib.parse.urlsplit(config['proxy']);req.set_proxy(proxy.netloc,proxy.scheme);proxies={}
            opener=urllib.request.build_opener(urllib.request.ProxyHandler(proxies),NoRedirect,urllib.request.HTTPSHandler(context=context))
            with opener.open(req,timeout=5) as response:
                if response.status!=201:raise ValueError('Unacknowledged audit record')
                ack=json.loads(response.read(1025))
                if ack!={'accepted':digest}:raise ValueError('Audit receipt mismatch')
        except Exception as error:
            # Never expose endpoints, client material, raw transport exceptions, or event bodies.
            raise Failure('Central audit did not durably acknowledge this operation. Processing is blocked; contact your administrator.') from None

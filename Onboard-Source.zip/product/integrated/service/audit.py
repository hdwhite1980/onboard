"""Bounded local, content-free audit events. Not a tamper-proof central audit service."""
import secrets,json,os,pathlib,re,stat,threading,time
from connectors import Failure
class Audit:
    def __init__(self,state,managed=None,context=None):self.path=pathlib.Path(state)/'audit.jsonl';self.lock=threading.Lock();self.managed=managed;self.context=context
    def emit(self,event,**fields):
        if not re.fullmatch(r'[a-z_]{1,40}',event) or set(fields)-{'operation','result','route','reference'}:raise Failure('Invalid audit event.')
        if any(not isinstance(v,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{0,64}',v) for v in fields.values()):raise Failure('Invalid audit field.')
        value=dict(schema=1,id=secrets.token_hex(16),time=time.time(),event=event,**fields)
        if self.context:value.update(self.context())
        policy=self.managed.read() if self.managed else None
        required=bool(self.managed and self.managed.required) or bool(policy and policy.get('require_central_audit'))
        if required and not (policy or {}).get('central_audit'):raise Failure('A central audit collector is required. Processing is blocked until enrollment.')
        if (policy or {}).get('central_audit'):
            from central_audit import Collector
            Collector().send(policy['central_audit'],value)
        row=json.dumps(value,separators=(',',':')).encode()+b'\n'
        try:
            with self.lock:
                if self.path.exists() and self.path.lstat().st_size>1_048_576:
                    for i in range(2,0,-1):
                        source=self.path.with_suffix('.'+str(i)+'.jsonl')
                        if source.exists():os.replace(source,self.path.with_suffix('.'+str(i+1)+'.jsonl'))
                    os.replace(self.path,self.path.with_suffix('.1.jsonl'))
                fd=os.open(self.path,os.O_WRONLY|os.O_APPEND|os.O_CREAT|os.O_NOFOLLOW|os.O_NONBLOCK,0o600)
                with os.fdopen(fd,'ab') as stream:
                    info=os.fstat(stream.fileno())
                    if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077 or info.st_nlink!=1:raise Failure('Audit file permissions are unsafe.')
                    stream.write(row);stream.flush();os.fsync(stream.fileno())
        except OSError:raise Failure('Audit recording is unavailable. Restore access to the private state folder before processing.')

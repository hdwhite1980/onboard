"""Bounded HTTPS transport: system/explicit proxy, verified TLS, no direct retry or content logs."""
import json, socket, ssl, subprocess, urllib.error, urllib.parse, urllib.request
from connectors import Failure, NoRedirect

class NetworkFailure(Failure):
    def __init__(self,code,message):super().__init__(message);self.code=code

def validate_proxy(value):
    if not value:return ''
    u=urllib.parse.urlsplit(value)
    try:port=u.port
    except ValueError:raise Failure('Enter a valid proxy port.')
    if u.scheme not in ('http','https') or not u.hostname or not port or u.username or u.password or u.path not in ('','/') or u.query or u.fragment:
        raise Failure('Use an HTTP or HTTPS proxy address with a port, without credentials or a path.')
    return value.rstrip('/')

def proxy_configuration(override=''):
    if override:return {'http':validate_proxy(override),'https':validate_proxy(override)}
    # urllib reads manual macOS proxies, but does not execute PAC/WPAD. Never silently go direct.
    try:
        r=subprocess.run(['/usr/sbin/scutil','--proxy'],capture_output=True,text=True,timeout=3)
        if r.returncode:raise NetworkFailure('PROXY_SETTINGS_UNAVAILABLE','Could not read system proxy settings. Check network settings or set an approved proxy in AI Settings.')
        if any(line.strip() in ('ProxyAutoConfigEnable : 1','ProxyAutoDiscoveryEnable : 1') for line in r.stdout.splitlines()):
            raise NetworkFailure('PROXY_AUTO_CONFIG_UNSUPPORTED','This network uses an automatic proxy (PAC/WPAD). Enter an IT-approved explicit proxy in AI Settings; Onboard will not bypass it.')
    except (OSError,subprocess.TimeoutExpired):
        raise NetworkFailure('PROXY_SETTINGS_UNAVAILABLE','System proxy settings could not be read. No direct connection was attempted.')
    return urllib.request.getproxies()

def failure_for(error):
    if isinstance(error,urllib.error.HTTPError):
        code=error.code
        if code==407:return NetworkFailure('PROXY_AUTH_REQUIRED','Your internet proxy requires authentication (HTTP 407). Sign in through your organization’s approved process or contact IT, then retry.')
        if code in (403,451):return NetworkFailure('ACCESS_DENIED','The destination or a network filter denied this request (HTTP %d). A proxy block is possible but cannot be confirmed from this response. Contact IT if the destination should be allowed.'%code)
        if code==401:return NetworkFailure('PROVIDER_AUTH_REQUIRED','The provider rejected its API credential (HTTP 401). Check the key in AI Settings.')
        if code==429:return NetworkFailure('RATE_LIMITED','The provider’s request limit was reached. Try again later or check the account’s usage limit.')
        if 300<=code<400:return NetworkFailure('REDIRECT_BLOCKED','The destination redirected the request. It was not followed; check the endpoint or proxy configuration.')
        return NetworkFailure('REMOTE_HTTP_ERROR','The remote service returned HTTP %d. No answer was invented.'%code)
    reason=getattr(error,'reason',error)
    if '407' in str(reason) and 'tunnel' in str(reason).lower():return NetworkFailure('PROXY_AUTH_REQUIRED','Your HTTPS proxy requires authentication (HTTP 407). Contact IT or complete approved proxy sign-in, then retry.')
    if 'tunnel connection failed' in str(reason).lower():return NetworkFailure('PROXY_TUNNEL_DENIED','The proxy refused the HTTPS connection. Ask IT to allow this destination or verify the approved proxy settings.')
    if isinstance(reason,ssl.SSLCertVerificationError):return NetworkFailure('TLS_CERTIFICATE_REJECTED','The connection’s certificate could not be verified. An inspection proxy may need an IT-installed trusted certificate. TLS verification was not bypassed.')
    if isinstance(reason,(TimeoutError,socket.timeout)):return NetworkFailure('NETWORK_TIMEOUT','The internet request timed out. Check connectivity and proxy settings; a proxy block could not be confirmed.')
    if isinstance(reason,socket.gaierror):return NetworkFailure('DNS_FAILURE','The destination or proxy name could not be resolved. Check the network, DNS, and proxy settings.')
    return NetworkFailure('CONNECTION_FAILED','The internet connection failed. Check connectivity and proxy settings; the cause is not confirmed.')

def request(url,method='GET',payload=None,headers=None,timeout=20,raw=False,proxy=''):
    u=urllib.parse.urlsplit(url)
    if u.scheme!='https' or not u.hostname or u.username or u.password:raise Failure('Only HTTPS destinations without embedded credentials are supported.')
    proxies=proxy_configuration(proxy)
    req=urllib.request.Request(url,data=payload,method=method,headers={'User-Agent':'OnboardAI/0.3 (read-only user-requested lookup)','Accept':'application/json',**(headers or {})})
    if proxy:
        configured=urllib.parse.urlsplit(proxy)
        req.set_proxy(configured.netloc,configured.scheme)
        # Explicit organization proxy takes precedence over system no_proxy exceptions.
        proxies={}
    try:
        with urllib.request.build_opener(urllib.request.ProxyHandler(proxies),NoRedirect).open(req,timeout=timeout) as response:
            body=response.read(5_242_881)
            if len(body)>5_242_880:raise NetworkFailure('RESPONSE_TOO_LARGE','The response exceeded the permitted size.')
            if 'text/html' in response.headers.get('Content-Type','').lower():
                denied=any(x in body[:8192].lower() for x in (b'access denied',b'blocked',b'proxy authentication',b'web filter'))
                if not raw or denied:raise NetworkFailure('POSSIBLE_PROXY_BLOCK' if denied else 'UNEXPECTED_RESPONSE','A web page was returned instead of service data. '+('It reports an access restriction; a proxy or filter may have blocked the request. Contact IT.' if denied else 'Check the endpoint or network sign-in requirements.'))
            if raw:return body
            try:return json.loads(body)
            except (ValueError,UnicodeError):raise NetworkFailure('INVALID_RESPONSE','The service returned unreadable data. No answer was invented.')
    except urllib.error.HTTPError as error:
        try:code=json.loads(error.read(8192)).get('error')
        except Exception:code=None
        if code in ('authorization_pending','slow_down','expired_token','authorization_declined'):raise Failure(code)
        raise failure_for(error)
    except (urllib.error.URLError,TimeoutError,OSError) as error:raise failure_for(error)

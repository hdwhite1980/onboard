"""Local certificate expiry diagnostics; never install trust or replace certificates."""
import pathlib,ssl,subprocess,time
def certificate_health(path):
    path=pathlib.Path(path)
    if not path.is_file():return {'state':'missing','message':'Local HTTPS certificate is not installed.'}
    try:
        result=subprocess.run(['/usr/bin/openssl','x509','-in',str(path),'-noout','-enddate'],capture_output=True,text=True,check=True,timeout=3)
        value=result.stdout.strip()
        if not value.startswith('notAfter='):raise ValueError()
        expires=ssl.cert_time_to_seconds(value.removeprefix('notAfter='));remaining=expires-time.time()
        state='expired' if remaining<=0 else 'expiring' if remaining<7*86400 else 'valid'
        return {'state':state,'expires_at':expires,'message':'Ask your administrator to renew the localhost certificate and its approved trust configuration.' if state!='valid' else 'Local certificate expiry is valid.'}
    except (OSError,ValueError,subprocess.SubprocessError):return {'state':'unknown','message':'Local certificate expiry could not be checked. Existing certificate files were preserved.'}

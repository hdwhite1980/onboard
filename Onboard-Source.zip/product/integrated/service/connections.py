"""Native-approved, account-bound add-in connections. Host context alone grants nothing."""
import secrets,time
from connectors import Failure

class Connections:
    def __init__(self,host):
        self.host=host;self.requests={};self.attempts=[]
    def clear(self):self.requests.clear()
    def prune(self):
        # Bound abandoned handshake state; this is not a connected-session timeout.
        now=time.monotonic()
        self.requests={k:v for k,v in self.requests.items() if now-v['created']<600}
    def request(self,r,origin):
        with self.host.lock:
            if self.host.stopping:raise Failure('The local service is stopping.')
            self.prune();now=time.monotonic();self.attempts=[t for t in self.attempts if now-t<60]
            if len(self.attempts)>=10 or len(self.requests)>=8:raise Failure('Too many connection requests. Close unused add-ins and try again shortly.')
            self.attempts.append(now)
            identity=self.host.graph.identity();account=self.host.graph.account;app=r.get('application')
            if app=='outlook':
                email=r.get('email')
                if not isinstance(email,str) or not email or email.casefold() not in {str(account.get('mail','')).casefold(),str(account.get('userPrincipalName','')).casefold()}:raise Failure('Outlook and Onboard accounts do not match. Sign in to the same Microsoft account.')
            elif app=='teams':
                if (r.get('tenant'),r.get('account'))!=identity[:2]:raise Failure('Teams and Onboard accounts do not match. Sign in to the same Microsoft account.')
            else:raise Failure('Unsupported integration.')
            key=secrets.token_urlsafe(24);secret=secrets.token_urlsafe(32)
            self.requests[key]={'secret':secret,'app':app,'identity':identity,'origin':origin,'state':'pending','created':now}
            return {'id':key,'secret':secret,'state':'pending'}
    def pending(self):
        with self.host.lock:
            self.prune()
            try:identity=self.host.graph.identity()
            except Failure:self.clear();return {'requests':[]}
            self.requests={k:v for k,v in self.requests.items() if v['identity']==identity}
            account=self.host.graph.account
            return {'requests':[{'id':k,'application':v['app'],'origin':v['origin'],'account':account.get('mail') or account.get('userPrincipalName') or account.get('displayName','')} for k,v in self.requests.items() if v['state']=='pending']}
    def decide(self,r):
        with self.host.lock:
            self.prune();p=self.requests.get(r.get('id'))
            if not p or p['state']!='pending':raise Failure('This connection request is no longer pending.')
            if p['identity']!=self.host.graph.identity() or self.host.stopping:raise Failure('Account or service changed. Connect again from the add-in.')
            if type(r.get('approve')) is not bool:raise Failure('Choose Allow or Decline.')
            p['state']='approved' if r['approve'] else 'declined'
            return {'message':'Connection approved.' if r['approve'] else 'Connection declined.'}
    def status(self,r,origin,cancel=False):
        with self.host.lock:
            self.prune();p=self.requests.get(r.get('id'));secret=r.get('secret')
            if not p or p['origin']!=origin or not isinstance(secret,str) or not secrets.compare_digest(p['secret'],secret):raise Failure('Connection request unavailable. Connect again.')
            if cancel:self.requests.pop(r['id']);return {'state':'cancelled'}
            if p['identity']!=self.host.graph.identity() or self.host.stopping:
                self.requests.pop(r['id']);raise Failure('Microsoft account or service changed. Connect again.')
            if p['state']=='pending':return {'state':'pending'}
            self.requests.pop(r['id'])
            if p['state']=='declined':return {'state':'declined'}
            # Only native approval can reach here. The polling secret never grants
            # approval and only this originating client can collect the one-use grant.
            return dict(self.host.new_session(p['app'],p['identity'],origin),state='connected')

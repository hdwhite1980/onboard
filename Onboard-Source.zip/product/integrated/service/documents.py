"""Bounded DOCX text/label inspection and new-document creation. No macros or external links run."""
import base64, hashlib, io, re, zipfile, xml.etree.ElementTree as ET
from xml.sax.saxutils import escape
from connectors import Failure

MAX_FILE=4_000_000
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
GUID=r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'

def xml(raw):
    # Also recognize declarations encoded as UTF-16/32 before ElementTree parses them.
    declarations=raw.replace(b'\x00',b'').upper()
    if b'<!DOCTYPE' in declarations or b'<!ENTITY' in declarations:raise Failure('Document XML entities are not supported.')
    return ET.fromstring(raw)

def label_metadata(properties,origin):
    """Metadata is evidence, not authenticated Purview policy or decryption authority."""
    groups={}
    for name,value in properties.items():
        match=re.fullmatch(r'MSIP_Label_('+GUID+r')_(\w+)',name,re.I)
        if match:groups.setdefault(match[1].lower(),{})[match[2].lower()]=value
    labels=[]
    for ident,p in groups.items():
        if p.get('enabled','').lower()=='false':continue
        labels.append({'id':ident,'tenant':p.get('siteid','').lower(),'name':p.get('name',''),'enabled':p.get('enabled','').lower()=='true','content_bits':p.get('contentbits','0')})
    malformed=any(name.lower().startswith('msip_label_') and not re.fullmatch(r'MSIP_Label_('+GUID+r')_(\w+)',name,re.I) for name in properties)
    return {'state':'unavailable' if malformed else 'labeled' if labels else 'unlabeled','labels':labels,'origin':origin}

def label_part(raw):
    namespace='{http://schemas.microsoft.com/office/2020/mipLabelMetadata}'
    root=xml(raw);labels=[]
    if root.tag!=namespace+'labelList':raise Failure('Unrecognized document label metadata.')
    for label in root:
        if label.tag!=namespace+'label':raise Failure('Unsupported label metadata extension.')
        values=label.attrib
        if values.get('removed') in ('1','true') or values.get('enabled') in ('0','false'):continue
        ident=values.get('id','').strip('{}').lower();tenant=values.get('siteId','').strip('{}').lower()
        if not re.fullmatch(GUID,ident) or not re.fullmatch(GUID,tenant):raise Failure('Malformed document label identity.')
        labels.append({'id':ident,'tenant':tenant,'name':'','enabled':values.get('enabled') in ('1','true'),'content_bits':values.get('contentBits','0')})
    return {'state':'labeled' if labels else 'unlabeled','labels':labels,'origin':'Microsoft mipLabelMetadata part'}

def email_labels(headers):
    properties={}
    for header in headers:
        if str(header.get('name','')).lower()=='msip_labels':
            for entry in header.get('value','').split(';'):
                if '=' in entry:
                    key,value=entry.split('=',1);properties[key.strip()]=value.strip()
    return label_metadata(properties,'Exchange MSIP_Labels header')

def check_labels(sources,config):
    allowed=set(config.get('agent',{}).get('public_labels',[]))
    for source in sources:
        info=source.get('sensitivity')
        if info is None:continue # Existing user-declared public input; not a label claim.
        if info.get('state') not in ('unlabeled','labeled') or (info.get('state')=='labeled' and not info.get('labels')):raise Failure('Sensitivity label could not be inspected. No AI processing or export is permitted for this source.')
        for label in info.get('labels',[]):
            try:bits=int(label.get('content_bits','0'))
            except (TypeError,ValueError):raise Failure('Unrecognized label protection metadata.')
            if bits&8:raise Failure('This label indicates encryption. A rights-aware MIP integration is required; this build will not process or export the content.')
            tenant=label.get('tenant','')
            if not tenant and info.get('origin')=='Outlook compose sensitivity API':tenant=config.get('graph',{}).get('tenant','')
            key=tenant.lower()+':'+label.get('id','').lower()
            if not label.get('enabled') or key not in allowed:raise Failure('A Purview label is present and is not approved as PUBLIC in this development policy. No AI processing or export is permitted.')

def inspect_docx(raw):
    if len(raw)>MAX_FILE:raise Failure('Choose a Word document below 4 MB.')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            entries=z.infolist();names=[e.filename for e in entries]
            if len(entries)>1500 or len(names)!=len(set(names)) or sum(e.file_size for e in entries)>20_000_000:raise Failure('Document package exceeds inspection limits.')
            if any(e.flag_bits&1 for e in entries) or any('vbaProject' in name for name in names):raise Failure('Encrypted or macro-enabled documents require a different approved reader.')
            if 'word/document.xml' not in names:raise Failure('This is not a supported Word document.')
            props={}
            if 'docProps/custom.xml' in names:
                for p in xml(z.read('docProps/custom.xml')):props[p.get('name','')]=''.join(p.itertext())
            label=label_metadata(props,'DOCX custom properties')
            for name in names:
                if 'label' in name.lower() and name!='docProps/custom.xml':
                    part=label_part(z.read(name));label['labels'].extend(part['labels']);label['origin']+=' + '+part['origin']
                    if label['state']!='unavailable' and label['labels']:label['state']='labeled'
            paragraphs=[]
            for p in xml(z.read('word/document.xml')).iter('{'+W+'}p'):
                paragraphs.append(''.join(t.text or '' for t in p.iter('{'+W+'}t')))
            text='\n'.join(paragraphs)
            if len(text)>120000:raise Failure('Word text exceeds 120,000 characters. Split the document before processing.')
            return {'text':text,'sensitivity':label,'sha256':hashlib.sha256(raw).hexdigest(),'coverage':'Main document body and table text only. Headers, footers, comments, revisions, images and embedded objects are not fully represented.'}
    except (zipfile.BadZipFile,ET.ParseError,KeyError,RuntimeError):raise Failure('Cannot inspect this DOCX. It may be protected, encrypted or malformed. Nothing was decrypted or relabeled.')

def decode_docx(value):
    if not isinstance(value,str) or len(value)>5_333_336:raise Failure('Word file exceeds the 4 MB limit.')
    try:return base64.b64decode(value,validate=True)
    except ValueError:raise Failure('Invalid Word file encoding.')

def create_docx(title,text):
    if not isinstance(title,str) or not 1<=len(title)<=200 or not isinstance(text,str) or not 1<=len(text)<=60000:raise Failure('Use a title up to 200 characters and document text up to 60,000 characters.')
    def paragraph(value,style=''):
        value=''.join(c for c in value if c in '\t\n\r' or ord(c)>=32)
        return '<w:p>'+('<w:pPr><w:pStyle w:val="'+style+'"/></w:pPr>' if style else '')+'<w:r><w:t xml:space="preserve">'+escape(value)+'</w:t></w:r></w:p>'
    body=paragraph(title,'Title')
    for line in text.splitlines():
        heading=re.match(r'^(#{1,3})\s+(.+)',line)
        body+=paragraph(heading[2], 'Heading'+str(len(heading[1]))) if heading else paragraph(line)
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>')
        z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        z.writestr('word/_rels/document.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        styles='<w:styles xmlns:w="'+W+'"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="22"/></w:rPr></w:rPrDefault></w:docDefaults>'
        for name,size in [('Title',40),('Heading1',32),('Heading2',28),('Heading3',24)]:styles+='<w:style w:type="paragraph" w:styleId="'+name+'"><w:name w:val="'+name+'"/><w:rPr><w:b/><w:sz w:val="'+str(size)+'"/></w:rPr></w:style>'
        z.writestr('word/styles.xml',styles+'</w:styles>')
        z.writestr('word/document.xml','<w:document xmlns:w="'+W+'"><w:body>'+body+'<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body></w:document>')
    return out.getvalue()

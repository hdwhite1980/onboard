"""Bounded, account-scoped in-memory drafts between approved add-ins. Never sends mail/chat."""
import hashlib,json,secrets,time
from connectors import Failure
from messaging import address
CATEGORIES={'reply','summary','meeting_request','followup','other'}
class Handoffs:
    def __init__(self,host):self.host=host;self.rows={};self.receipts={}
    def clear(self,owner=None):
        if owner is None:self.rows.clear();self.receipts.clear()
        else:
            self.rows={k:v for k,v in self.rows.items() if v['owner']!=owner}
            self.receipts={k:v for k,v in self.receipts.items() if k[0]!=owner}
    def session(self,owner):
        s=self.host.sessions.get(owner)
        if not s or s.get('app') not in ('outlook','teams') or tuple(s['identity'])!=self.host.graph.identity():raise Failure('Reconnect this add-in before transferring a draft.')
        return s,tuple(s['identity'])
    def create(self,owner,r):
        with self.host.lock:
            s,identity=self.session(owner)
            if r.get('public_attested') is not True or self.host.config.get('public_local') is not True:raise Failure('Confirm this draft is public and permitted to transfer.')
            target='teams' if s['app']=='outlook' else 'outlook'
            if r.get('target')!=target:raise Failure('Choose the other Onboard add-in as the destination.')
            body=r.get('body');subject=r.get('subject','');category=r.get('category')
            if not isinstance(body,str) or not body.strip() or len(body)>12000 or '\x00' in body:raise Failure('Use a draft of 1–12,000 characters.')
            if not isinstance(subject,str) or len(subject)>200 or any(c in subject for c in '\r\n\x00'):raise Failure('Use a one-line subject of at most 200 characters.')
            if category not in CATEGORIES:raise Failure('Choose a draft category.')
            recipient=address(r.get('recipient')) if r.get('recipient') else ''
            key=r.get('key')
            if not isinstance(key,str) or not 16<=len(key)<=128:raise Failure('Missing draft transfer identifier.')
            fields={'target':target,'body':body,'subject':subject,'category':category,'recipient':recipient}
            fingerprint=hashlib.sha256(json.dumps(fields,sort_keys=True).encode()).hexdigest();prior=self.receipts.get((owner,key))
            if prior:
                if prior['fingerprint']!=fingerprint:raise Failure('This transfer identifier already belongs to a different draft.')
                return {'id':prior['id'],'state':'pending' if prior['id'] in self.rows else 'removed','message':'This draft was already transferred. Check the destination add-in; no duplicate was created.'}
            job=self.host.job(owner,r.get('job'));result=job.get('result') or {}
            if job['state']!='complete' or result.get('status')!='generated' or not result.get('policy',{}).get('allowed'):raise Failure('Prepare an allowed AI draft first; withheld results cannot be transferred.')
            if len(self.rows)>=20:raise Failure('The local draft queue is full. Open or remove a queued draft first.')
            if len(self.receipts)>=128:raise Failure('This service has reached its transfer limit. Restart it to clear the in-memory history.')
            ident=secrets.token_urlsafe(32)
            self.rows[ident]=dict(fields,id=ident,owner=owner,identity=identity,source=s['app'],created=time.time())
            self.receipts[(owner,key)]={'id':ident,'fingerprint':fingerprint}
            return {'id':ident,'state':'pending','message':'Draft is waiting in the '+target.title()+' add-in. Open Local draft inbox there. Nothing was sent.'}
    def inbox(self,owner):
        with self.host.lock:
            s,identity=self.session(owner)
            rows=[{k:v[k] for k in ('id','source','target','category','subject','recipient','body','created')} for v in self.rows.values() if v['identity']==identity and v['target']==s['app']]
            return {'drafts':rows}
    def remove(self,owner,r):
        with self.host.lock:
            s,identity=self.session(owner);row=self.rows.get(r.get('id'))
            if not row or row['identity']!=identity or row['target']!=s['app']:raise Failure('Draft is no longer available for this add-in and account.')
            # Removal is also the one-time claim before opening a native composer.
            del self.rows[row['id']]
            return {'removed':True}

"""Content-free local runtime outcomes. Never retain prompts, outputs or raw exceptions."""
import json, math, os, tempfile, time
from pathlib import Path

# Only known supervisor signals become customer-visible diagnostics. Raw worker
# errors can contain user content, filesystem paths or other sensitive data.
SIGNALS = (
    ('RESOURCE: protected reserve approached', 'MEMORY_RESERVE', 'Local AI stopped because the Mac approached its protected memory reserve. Quit unneeded apps and try again.'),
    ('RESOURCE: worker footprint exceeded', 'MODEL_MEMORY_LIMIT', 'Local AI exceeded its process memory limit. Try a shorter request.'),
    ('RESOURCE: nonzero initial swap', 'EXISTING_SWAP', 'Local AI could not start because this runtime requires zero swap usage. Closing apps may help; a restart may be needed to clear existing swap.'),
    ('RESOURCE: swap', 'SWAP_ACTIVITY', 'Local AI stopped because swap usage increased. Quit unneeded apps and try again.'),
    ('RESOURCE: positive swap', 'SWAP_ACTIVITY', 'Local AI stopped because macOS was swapping memory. Quit unneeded apps and try again.'),
    ('RESOURCE: pressure', 'MEMORY_PRESSURE', 'Local AI stopped because macOS reported memory pressure or an unknown pressure state. Quit unneeded apps and try again.'),
    ('RESOURCE: thermal', 'THERMAL_LIMIT', 'Local AI stopped because the Mac was too warm or its temperature status was unavailable. Let it cool and try again.'),
    ('RUNTIME: generation timeout', 'GENERATION_TIMEOUT', 'Local AI ran out of time while writing the answer. Try a shorter response or use configured cloud assistance.'),
    ('RUNTIME: timeout awaiting generated', 'GENERATION_TIMEOUT', 'Local AI ran out of time while writing the answer. Try a shorter response or use configured cloud assistance.'),
    ('RUNTIME: load timeout', 'LOAD_TIMEOUT', 'The local model took too long to load. Quit unneeded apps and try again.'),
    ('RUNTIME: timeout awaiting MODEL_LOADED', 'LOAD_TIMEOUT', 'The local model took too long to load. Quit unneeded apps and try again.'),
    ('RUNTIME: wall timeout', 'REQUEST_TIMEOUT', 'The local request exceeded its runtime limit. Try a shorter request.'),
    ('MONITOR: MLX telemetry stale', 'MODEL_MONITOR_STALE', 'Local AI stopped because the model stopped reporting memory readings. Try again; if it repeats, restart the Onboard service.'),
    ('MONITOR: host telemetry stale', 'HOST_MONITOR_STALE', 'Local AI stopped because macOS resource readings were delayed. Try again; if it repeats, restart the Onboard service.'),
    ('MONITOR: worker footprint stale', 'WORKER_MONITOR_STALE', 'Local AI stopped because process memory readings were delayed. Try again; if it repeats, restart the Onboard service.'),
    ('MONITOR:', 'TELEMETRY_UNAVAILABLE', 'Local AI stopped because its resource monitor could not provide reliable readings. Try again; if it repeats, restart the Onboard service.'),
    ('USER: cancellation requested', 'CANCELLED', 'The local request was cancelled.'),
)

def outcome(result):
    clean = (result.get('supervisor') == 'TERMINATION_CONFIRMED'
             and result.get('evidenceCompleteness') == 'COMPLETE'
             and result.get('processGroupPresent') is False)
    if not clean:
        return 'CLEANUP_UNCONFIRMED', 'Local AI could not confirm complete runtime cleanup. Restart the Onboard service before trying again.', False
    primary = result.get('primary')
    if primary == 'LOCAL_GENERATION_SUCCESS':
        return 'SUCCESS', '', False
    # Integrity/security failures must never become automatic cloud fallback.
    if primary in ('NETWORK_BOUNDARY_FAILED', 'ARTIFACT_VERIFICATION_FAILED', 'RUNTIME_COMPATIBILITY_FAILED', 'TOKENIZER_PREFLIGHT_FAILED'):
        return primary, 'Local AI failed a runtime integrity or compatibility check. Repair the local runtime in Onboard setup.', False
    reasons = result.get('aborts', [])
    if isinstance(reasons, list):
        for reason in reasons:
            if not isinstance(reason, str):continue
            for prefix, code, message in SIGNALS:
                if reason.startswith(prefix):
                    recoverable = code in ('MEMORY_RESERVE','MODEL_MEMORY_LIMIT','EXISTING_SWAP','SWAP_ACTIVITY','MEMORY_PRESSURE','THERMAL_LIMIT','GENERATION_TIMEOUT','LOAD_TIMEOUT','REQUEST_TIMEOUT')
                    return code, message, recoverable
    return 'LOCAL_RUNTIME_FAILED', 'The local model failed while running. Restart the Onboard service; if it repeats, repair the local runtime.', False


def record(state, run, result):
    """Keep one bounded diagnostic, replaced atomically, with no source text."""
    code, message, recoverable = outcome(result)
    data = {'schema':1, 'recordedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
            'code':code, 'cleanupConfirmed': result.get('supervisor')=='TERMINATION_CONFIRMED'
                and result.get('evidenceCompleteness')=='COMPLETE' and result.get('processGroupPresent') is False}
    for key in ('modelLoads','generationBegins','workerExitCode'):
        value=result.get(key)
        if type(value) is int and abs(value)<100000:data[key]=value
    # Read only the final resource sample, and copy only numeric measurements.
    samples=Path(run)/'calibration/resources.jsonl'
    if samples.exists():
        with samples.open('rb') as stream:
            stream.seek(0,2);stream.seek(max(0,stream.tell()-16384))
            lines=stream.read().splitlines()
        try:row=json.loads(lines[-1]) if lines else {}
        except (ValueError, UnicodeError):row={}
        for key in ('availableEstimateLegacyBytes','workerPhysicalFootprintBytes','swapUsedBytes','thermalState'):
            value=row.get(key)
            if type(value) in (int,float) and math.isfinite(value) and value>=0:data[key]=value
    state=Path(state)
    fd,name=tempfile.mkstemp(prefix='.local-diagnostic-',dir=state)
    try:
        with os.fdopen(fd,'w') as stream:json.dump(data,stream,indent=2);stream.write('\n')
        os.replace(name,state/'last-local-run.json')
    finally:
        if os.path.exists(name):os.unlink(name)
    return code,message,recoverable

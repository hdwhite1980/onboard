"""User-requested public lookups. Fixed provider destinations, source timestamps, no autonomous browsing."""
import datetime, math, re, urllib.parse
from connectors import Failure,plain
from network import request

WEATHER=re.compile(r'\b(weather|forecast|temperature|rain|snow)\b',re.I)
CURRENT=re.compile(r'\b(latest|current|today|tonight|tomorrow|news|price|recent|right now|this week)\b',re.I)
TRANSFORM=re.compile(r'^\s*(rewrite|rephrase|proofread|translate|shorten|summarize (this|the following)|change the tone|make this)\b',re.I)
CREATE=re.compile(r'^\s*(brainstorm|(?:write|draft|compose) (a |an )?(poem|story|thank.you|fiction|email|letter|message|note|python|javascript|swift|function|code)|generate (a |an )?(poem|story|code)|debug (this|the following))\b',re.I)
def intent(prompt,mode='auto'):
    if mode=='off':return None
    weather_request=WEATHER.search(prompt) and not re.search(r'\b(how|why|explain|meaning|definition|works?|model|software|code|app)\b',prompt,re.I)
    if mode=='always':return 'weather' if weather_request and not TRANSFORM.search(prompt) else 'search'
    if TRANSFORM.search(prompt):return None
    if CREATE.search(prompt) and not CURRENT.search(prompt):return None
    if weather_request:return 'weather'
    if re.fullmatch(r'\s*(hello|hi|hey|thanks|thank you|good morning|good afternoon|good evening)[!.? ]*',prompt,re.I):return None
    arithmetic=re.sub(r'^\s*(what is|what\'s|calculate|solve)\s+','',prompt,flags=re.I).strip(' ?')
    if arithmetic and re.fullmatch(r'[\d\s.+*/()%=-]+',arithmetic):return None
    # Public fact-finding defaults to search across topics, not a small list of weather/news keywords.
    return 'search'

def requires_live_information(prompt):
    return bool(CURRENT.search(prompt) or (WEATHER.search(prompt) and intent(prompt)=='weather'))

def location_from(prompt,default=''):
    match=re.search(r'\b(?:in|for|at)\s+(.+)',prompt,re.I)
    value=match.group(1) if match else ''
    if not value:
        match=re.match(r'^\s*(?:weather|forecast|temperature)\s+(.+)',prompt,re.I)
        value=match.group(1) if match else default
    value=re.sub(r'\b(today|tomorrow|tonight|this week|next week|right now|this weekend)\b.*$','',value,flags=re.I).strip(' ?!.')
    return value if value and len(value)<=120 else default

CODES={0:'Clear',1:'Mainly clear',2:'Partly cloudy',3:'Overcast',45:'Fog',48:'Rime fog',51:'Light drizzle',53:'Drizzle',55:'Dense drizzle',56:'Freezing drizzle',57:'Dense freezing drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',66:'Freezing rain',67:'Heavy freezing rain',71:'Light snow',73:'Snow',75:'Heavy snow',77:'Snow grains',80:'Light rain showers',81:'Rain showers',82:'Heavy rain showers',85:'Snow showers',86:'Heavy snow showers',95:'Thunderstorm',96:'Thunderstorm with hail',99:'Thunderstorm with heavy hail'}
def weather(prompt,config,cancel,key=""):
    location=location_from(prompt,config.get('weather_location',''))
    if not location:return {'status':'needs_location','answer':'Which city or postal code should I check? Include it in your question, or set a default city in AI Settings.','sources':[]}
    if re.search(r'\b(yesterday|last week|last month|last year|historical)\b',prompt,re.I):return {'status':'needs_clarification','answer':'Weather lookup currently provides current conditions and the next seven days. Historical weather is not available in this adapter.','sources':[]}
    commercial=config.get('weather_plan')=='commercial'
    if commercial and not key:raise Failure('Add your Open-Meteo commercial API key in AI Settings.')
    lookup_location=re.sub(r',\s*D\.?C\.?$',', District of Columbia',location,flags=re.I)
    geo_args={'name':lookup_location,'count':5,'language':'en','format':'json'}
    if commercial:geo_args['apikey']=key
    geo=request('https://'+('customer-' if commercial else '')+'geocoding-api.open-meteo.com/v1/search?'+urllib.parse.urlencode(geo_args),proxy=config.get('proxy',''))
    choices=geo.get('results',[])
    populated=[x for x in choices if x.get('feature_code') in ('PPLC','PPLA','PPLA2','PPLA3','PPLA4','PPL','PPLG')]
    if populated:choices=populated
    normalize=lambda value:re.sub(r'[^a-z0-9]','',str(value).casefold())
    wanted={normalize(location.split(',')[0])}
    if 'District of Columbia' in lookup_location and 'washington' in wanted:wanted.add('washingtondc')
    exact=[x for x in choices if normalize(x.get('name','')) in wanted]
    if exact:choices=exact
    if not choices:return {'status':'no_results','answer':'No matching weather location was found. Try the city, state or region, and country.','sources':[]}
    def title(x):return ', '.join(dict.fromkeys(str(x[k]) for k in ('name','admin1','country') if x.get(k)))
    # A bare ambiguous town name must not silently pick another town.
    distinct={title(x) for x in choices}
    if len(distinct)>1:return {'status':'needs_location','answer':'Please specify the region or country. Matching locations: '+ '; '.join(sorted(distinct)), 'sources':[]}
    place=choices[0];lat=place['latitude'];lon=place['longitude']
    if not isinstance(lat,(int,float)) or not isinstance(lon,(int,float)) or not math.isfinite(lat+lon) or not -90<=lat<=90 or not -180<=lon<=180:raise Failure('Weather provider returned invalid coordinates.')
    if cancel.is_set():raise Failure('Cancelled.')
    args={'latitude':lat,'longitude':lon,'current':'temperature_2m,apparent_temperature,weather_code,wind_speed_10m','daily':'temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code','timezone':'auto','forecast_days':7,'temperature_unit':'fahrenheit' if config.get('weather_units','fahrenheit')=='fahrenheit' else 'celsius','wind_speed_unit':'mph' if config.get('weather_units','fahrenheit')=='fahrenheit' else 'kmh'}
    url='https://api.open-meteo.com/v1/forecast?'+urllib.parse.urlencode(args)
    request_url=url
    if commercial:request_url=url.replace('https://api.','https://customer-api.')+'&'+urllib.parse.urlencode({'apikey':key})
    data=request(request_url,proxy=config.get('proxy',''));current=data.get('current',{});units=data.get('current_units',{});daily=data.get('daily',{});du=data.get('daily_units',{})
    if not current.get('time') or current.get('temperature_2m') is None:raise Failure('Weather provider did not return current conditions.')
    updated=datetime.datetime.fromisoformat(current['time'])-datetime.timedelta(seconds=data.get('utc_offset_seconds',0))
    if abs((datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)-updated).total_seconds())>10800:raise Failure('The weather response is stale. Current conditions could not be verified; please retry later.')
    label=title(place);lines=[label,'Current weather at '+current['time']+' ('+data.get('timezone','provider time')+')',CODES.get(current.get('weather_code'),'Conditions unavailable')+', '+str(current['temperature_2m'])+units.get('temperature_2m',''),'Feels like '+str(current.get('apparent_temperature','unavailable'))+units.get('apparent_temperature','')+' · wind '+str(current.get('wind_speed_10m','unavailable'))+' '+units.get('wind_speed_10m',''),'','Forecast — next seven days:']
    for i,day in enumerate(daily.get('time',[])[:7]):
        def val(k):
            rows=daily.get(k,[]);return str(rows[i]) if i<len(rows) and rows[i] is not None else 'unavailable'
        codes=daily.get('weather_code',[])
        lines.append(day+': '+(CODES.get(codes[i],'Conditions unavailable') if i<len(codes) else 'Conditions unavailable')+'; high '+val('temperature_2m_max')+du.get('temperature_2m_max','')+', low '+val('temperature_2m_min')+du.get('temperature_2m_min','')+', rain probability '+val('precipitation_probability_max')+'%.')
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();answer='\n'.join(lines)
    source={'id':'weather:'+str(place['id']),'title':'Open-Meteo — '+label,'url':url,'text':answer,'kind':'weather','classification':'PUBLIC','retrieved_at':stamp}
    return {'status':'retrieved','answer':answer+'\n\nSource: Open-Meteo (weather-model estimates). Retrieved '+stamp,'sources':[source]}

def search(prompt,config,key,cancel):
    if not key:raise Failure('Web search needs a Brave Search API key. Add it under AI Settings → Internet access. Weather lookup does not need this key.')
    if len(prompt)>512:raise Failure('Shorten the web-search query to 512 characters or fewer. Nothing was sent.')
    if cancel.is_set():raise Failure('Cancelled.')
    data=request('https://api.search.brave.com/res/v1/web/search?'+urllib.parse.urlencode({'q':prompt,'count':5,'safesearch':'moderate','extra_snippets':'true','text_decorations':'false'}),headers={'X-Subscription-Token':key},proxy=config.get('proxy',''))
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();sources=[]
    for item in data.get('web',{}).get('results',[])[:5]:
        url=item.get('url','');u=urllib.parse.urlsplit(url)
        if u.scheme not in ('http','https') or not u.hostname or u.username or u.password:continue
        sources.append({'id':'web:'+str(len(sources)+1),'title':plain(item.get('title',''))[:200],'text':'\n'.join(dict.fromkeys(plain(x) for x in [item.get('description','')]+item.get('extra_snippets',[]) if isinstance(x,str)))[:3000],'url':url,'kind':'web_search_snippet','classification':'PUBLIC','retrieved_at':stamp})
    if not sources:return {'status':'no_results','answer':'No web results were returned for this question. Try a more specific search.','sources':[]}
    return {'status':'retrieved','answer':'Search results (snippets; full pages have not been retrieved):\n\n'+'\n\n'.join(s['title']+'\n'+s['text']+'\n'+s['url'] for s in sources),'sources':sources}

"""Content-free activity events. Never accept arbitrary log text from a model or tool."""
import collections,contextvars,hashlib,json,math,os,pathlib,re,stat,threading,time
CURRENT=contextvars.ContextVar('onboard_activity',default=None)
STAGES={'queued':'Waiting in queue','processing':'Processing request','sealed_storage':'Preparing encrypted temporary storage','preflight':'Checking local model and input','supervisor':'Starting local model supervisor','started':'Model worker started','load_begin':'Loading local model','MODEL_LOADED':'Local model loaded','generation_begin':'Writing answer locally','generated':'Local answer generated','unload_begin':'Unloading local model','cloud':'Requesting configured cloud AI','network':'Contacting a configured service','review':'Waiting for your review','tool':'Running an approved tool','complete':'Request complete','failed':'Request stopped','cancelled':'Request cancelled','cleanup':'Cleaning up local model processes'}
HINTS={'MEMORY_PRESSURE':'Quit unneeded apps and retry, or use configured cloud assistance.','MEMORY_RESERVE':'Quit unneeded apps and retry, or use configured cloud assistance.','CONTEXT_LIMIT':'Select less source text or use configured cloud assistance.','PROXY_AUTH_REQUIRED':'Complete your organization’s proxy sign-in or contact IT.','TLS_CERTIFICATE_REJECTED':'Ask IT to verify the destination certificate and trusted proxy certificates.','PROVIDER_AUTH_REQUIRED':'Check the provider credential in AI Settings.','NETWORK_TIMEOUT':'Check connectivity and proxy settings, then retry.','REQUEST_FAILED':'Review the request error in Ask AI and the readiness checks in Settings.','ENCRYPTED_STORAGE':'Check free disk space and run setup diagnostics. No plaintext fallback is allowed; ask your administrator to recover any busy encrypted workspace.','LOCAL_RUNTIME_FAILED':'Restart the Onboard service; repair the local runtime if the problem repeats.'}
from local_diagnostics import SIGNALS
for _,code,message in SIGNALS:HINTS.setdefault(code,message)
def publish(stage,code=None,pid=None):
 target=CURRENT.get()
 if target:target(stage,code,pid)
class Activity:
 def __init__(self,state):self.state=pathlib.Path(state);self.lock=threading.Lock();self.rows=collections.deque(maxlen=200);self.started=time.monotonic()
 def emit(self,reference,stage,code=None,pid=None):
  if stage not in STAGES:return
  row={'time':time.time(),'reference':hashlib.sha256(reference.encode()).hexdigest()[:12],'stage':stage,'message':STAGES[stage]}
  if isinstance(code,str) and re.fullmatch('[A-Z_]{1,60}',code):row.update(code=code,next_step=HINTS.get(code,'Review the request error and run readiness checks.'))
  if type(pid) is int and pid>0:row['pid']=pid
  with self.lock:self.rows.append(row)
 def snapshot(self,host):
  with self.lock:events=list(self.rows)
  with host.lock:
   jobs=[{'reference':hashlib.sha256(j['id'].encode()).hexdigest()[:12],'state':j['state'],'route':(j.get('result') or {}).get('route',j.get('request',{}).get('route','unknown')),'age_seconds':int(time.monotonic()-j['created'])} for j in host.jobs.values()]
  diagnostic={};path=self.state/'last-local-run.json'
  try:
   fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
   with os.fdopen(fd,'rb') as f:
    st=os.fstat(f.fileno())
    if not stat.S_ISREG(st.st_mode) or st.st_size>8192:raise ValueError()
    raw=json.load(f)
   # Project values; an edited diagnostic file cannot inject source text into an export.
   for key in ('workerPhysicalFootprintBytes','availableEstimateLegacyBytes','peakMLXBytes','persistentKVBytes','outputTokens','promptTokens','seconds','tokensPerSecond'):
    if type(raw.get(key)) in (int,float) and math.isfinite(raw[key]) and 0<=raw[key]<10**15:diagnostic[key]=raw[key]
   if raw.get('code') in HINTS or raw.get('code')=='SUCCESS':diagnostic['code']=raw['code']
  except (OSError,ValueError,TypeError):pass
  processes=[{'role':'Local service','pid':os.getpid(),'state':'running'}]
  active={j['reference'] for j in jobs if j['state'] in ('processing','waiting_review')}
  for ref in active:
   recent=[row for row in events if row['reference']==ref]
   if recent and recent[-1]['stage']!='cleanup':
    for role,stage in (('Model supervisor','supervisor'),('Local model worker','started')):
     record=next((row for row in reversed(recent) if row['stage']==stage and row.get('pid')),None)
     if record:processes.append({'role':role,'pid':record['pid'],'state':'reported by active request'})
  return {'processes':processes,'schema':1,'service_pid':os.getpid(),'uptime_seconds':int(time.monotonic()-self.started),'queue_depth':host.queue.qsize(),'jobs':jobs,'events':events,'last_local_run':diagnostic,'scope':'Onboard activity only. Logs exclude prompts, source content, credentials and model responses. Memory metrics describe the last completed local run. Event history resets on service restart.'}

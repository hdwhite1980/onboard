"""Optional administrator-owned endpoint restrictions, read on every operation.
This is an MDM/file deployment boundary, not a signed remote control plane or CUI authority.
"""
import json,os,pathlib,stat,urllib.parse
from connectors import Failure
PATH=pathlib.Path('/Library/Application Support/Onboard AI/managed-policy.json')
FIELDS={'schema','name','allow_cloud','allow_hybrid','allow_saved_work','allowed_tenants','allowed_provider_origins','public_label_mappings'}
class ManagedPolicy:
    def __init__(self,path=PATH,uid=0):self.path=path;self.uid=uid
    def read(self):
        try:info=self.path.lstat()
        except FileNotFoundError:return None
        for path in [self.path,*self.path.parents]:
            mode=path.lstat()
            if mode.st_uid!=self.uid or mode.st_mode&0o022 or stat.S_ISLNK(mode.st_mode):raise Failure('Organization policy permissions are invalid. Ask your administrator to repair the managed policy.')
        if not stat.S_ISREG(info.st_mode) or info.st_size>65536:raise Failure('Organization policy must be a bounded regular file.')
        fd=os.open(self.path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        with os.fdopen(fd,'rb') as stream:
            actual=os.fstat(stream.fileno())
            if actual.st_ino!=info.st_ino or actual.st_dev!=info.st_dev:raise Failure('Organization policy changed while opening. Retry.')
            raw=stream.read(65537)
        try:
            value=json.loads(raw)
            if not isinstance(value,dict) or set(value)-FIELDS or type(value.get('schema')) is not int or value['schema']!=1:raise ValueError()
            for key in ('allow_cloud','allow_hybrid','allow_saved_work'):
                if type(value.get(key)) is not bool:raise ValueError()
            if not isinstance(value.get('name'),str) or len(value['name'])>120:raise ValueError()
            for key in ('allowed_tenants','allowed_provider_origins','public_label_mappings'):
                if not isinstance(value.get(key),list) or len(value[key])>100 or any(not isinstance(x,str) or not x or len(x)>300 for x in value[key]):raise ValueError()
            for origin in value['allowed_provider_origins']:
                u=urllib.parse.urlsplit(origin)
                if u.scheme!='https' or not u.hostname or u.username or u.password or u.path or u.query or u.fragment:raise ValueError()
            return value
        except (ValueError,TypeError):raise Failure('Organization policy is invalid. AI operations are blocked until the administrator repairs it.')
    def check(self,config,operation=None):
        value=self.read()
        if value is None:return
        if not value['allow_cloud'] and (config.get('public_cloud') or config.get('addin_cloud')):raise Failure('Organization policy disables cloud AI. Turn off cloud processing in Settings.')
        if not value['allow_hybrid'] and config.get('agent',{}).get('enabled'):raise Failure('Organization policy disables hybrid tasks. Turn them off in Settings.')
        tenant=config.get('graph',{}).get('tenant','')
        if tenant and tenant.lower() not in [x.lower() for x in value['allowed_tenants']]:raise Failure('This Microsoft tenant is not allowed by organization policy.')
        endpoint=config.get('provider',{}).get('endpoint','')
        if endpoint:
            u=urllib.parse.urlsplit(endpoint);origin=u.scheme+'://'+u.netloc
            if origin.lower() not in [x.lower() for x in value['allowed_provider_origins']]:raise Failure('This AI provider destination is not allowed by organization policy.')
        if not set(config.get('agent',{}).get('public_labels',[]))<=set(value['public_label_mappings']):raise Failure('Public label mappings must be approved in organization policy.')
        if operation=='workspace' and not value['allow_saved_work']:raise Failure('Organization policy disables saving or reopening work. You can still remove previously saved work.')
    def status(self,config):
        try:
            value=self.read();self.check(config)
            return {'managed':value is not None,'ready':True,'name':value['name'] if value else 'Public-content development settings','message':'Administrator restrictions are active.' if value else 'No organization policy installed. This remains a public-content development configuration.'}
        except (Failure,OSError) as error:return {'managed':True,'ready':False,'name':'Organization policy','message':str(error) if isinstance(error,Failure) else 'Organization policy could not be read. Ask your administrator.'}

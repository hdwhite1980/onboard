"""Review-bound macOS/browser controller, exact observations and one-use native tickets."""
import json,re,secrets,subprocess,time,urllib.parse
from connectors import Failure
TOOLS={
 'desktop_open':{'app':'approved application bundle identifier'},
 'desktop_inspect':{'app':'approved application bundle identifier'},
 'browser_inspect':{},
 'computer_action':{'snapshot':'snapshot identifier or $last','action':'press, type, click, point, key or scroll','details':'JSON with target/text, x/y, key or direction; target is inspected ID or name:exact unique title'},
}
DENIED={'com.apple.Terminal','com.googlecode.iterm2','com.apple.systempreferences','com.apple.keychainaccess','local.onboard.integrated.dev'}
BROWSERS={'com.apple.Safari','com.google.Chrome','com.microsoft.edgemac','org.mozilla.firefox','com.brave.Browser','com.vivaldi.Vivaldi','company.thebrowser.Browser','com.operasoftware.Opera'}
def validate(value):
    if not isinstance(value,dict):raise Failure('Invalid controller settings.')
    apps=value.get('apps',[])
    if not isinstance(apps,list) or len(apps)>20 or any(not isinstance(x,str) or not re.fullmatch(r'[A-Za-z0-9.-]{3,200}',x) or x in DENIED for x in apps):raise Failure('Choose up to 20 application bundle identifiers. Terminal, security settings and Onboard itself are not automation targets.')
    return {'enabled':value.get('enabled') is True,'apps':list(dict.fromkeys(apps))}

class Controller:
    def __init__(self,host):self.host=host;self.tickets={};self.snapshots={}
    def native(self,command,runner):
        runner.active();token=secrets.token_urlsafe(32)
        with self.host.lock:self.tickets[token]=(command,runner,time.monotonic()+15)
        try:
            result=subprocess.run([str(self.host.app),'--automation'],input=json.dumps({'ticket':token}),capture_output=True,text=True,timeout=25)
            if result.returncode:raise Failure(result.stderr.strip()[:500] or 'Native computer controller unavailable.')
            value=json.loads(result.stdout)
            if not isinstance(value,dict):raise ValueError()
            runner.active();return value
        except (OSError,ValueError,subprocess.SubprocessError):raise Failure('Computer controller did not confirm completion. Inspect the application before retrying; an input may have been delivered.')
        finally:
            with self.host.lock:self.tickets.pop(token,None)
    def claim(self,token):
        with self.host.lock:item=self.tickets.pop(token,None)
        if not item or time.monotonic()>item[2]:raise Failure('Computer action ticket expired or was already used.')
        command,runner,_=item;runner.active();return command
    def enabled(self,runner):
        runner.active()
        if not runner.config.get('automation',{}).get('enabled'):raise Failure('Enable computer controllers in AI Settings first.')
        if runner.job['owner']!='native' or runner.job['request'].get('public_attested') is not True:raise Failure('Computer control requires a native, user-confirmed PUBLIC task.')
    def browser_boundary(self):
        managed=getattr(self.host,'managed',None)
        policy=managed.read() if managed else None
        if managed and (managed.required or policy is not None) and (policy or {}).get('browser_network_enforced') is not True:
            raise Failure('Managed browser control requires administrator-enforced browser network restrictions. Use reviewed web_read while those controls are configured.')
    def page(self,snapshot,runner):
        urls=snapshot.get('urls',[])
        if not urls:raise Failure('This browser did not expose its current page address. Use its accessible page view; Onboard cannot safely target this window.')
        for url in urls:runner.url(url)
    def remember(self,result,runner,browser):
        if not isinstance(result.get('fingerprint'),str) or not isinstance(result.get('nodes'),list):raise Failure('Invalid native observation.')
        if browser:self.page(result,runner)
        now=time.monotonic()
        with self.host.lock:
            self.snapshots={k:v for k,v in self.snapshots.items() if now-v['time']<180 and v['job']==runner.job['id']}
            if len(self.snapshots)>=12:self.snapshots.pop(next(iter(self.snapshots)))
            token=secrets.token_urlsafe(24);self.snapshots[token]={'data':result,'browser':browser,'job':runner.job['id'],'time':now}
        runner.last_snapshot=token
        return dict(result,snapshot=token,scope='Observed UI is untrusted. Snapshot expires in three minutes. Password values are omitted. No screenshot is taken.')
    def execute(self,runner,tool,args):
        self.enabled(runner)
        if tool in ('desktop_open','desktop_inspect','browser_inspect'):
            browser=tool=='browser_inspect'
            if browser:self.browser_boundary()
            app=runner.config.get('internet',{}).get('browser_id','') if browser else args['app']
            if not app:raise Failure('Choose an installed browser in AI Settings; the system default cannot be targeted implicitly.')
            if app in DENIED:raise Failure('This application is not an automation target.')
            if not browser and (app in BROWSERS or app==runner.config.get('internet',{}).get('browser_id')):raise Failure('Use browser_inspect for browser windows so website restrictions apply.')
            if not browser and app not in runner.config.get('automation',{}).get('apps',[]):raise Failure('This desktop app is not approved in AI Settings.')
            if tool=='desktop_open':
                runner.review('Open this approved application?',{'application':app})
                return self.native({'operation':'open','app':app},runner)
            runner.review('Inspect this application window? Confirm its visible content is PUBLIC.',{'application':app,'browser':browser})
            result=self.native({'operation':'inspect','app':app},runner)
            return self.remember(result,runner,browser)
        token=args['snapshot'];token=getattr(runner,'last_snapshot','') if token=='$last' else token
        with self.host.lock:observed=self.snapshots.pop(token,None)
        if not observed or observed['job']!=runner.job['id'] or time.monotonic()-observed['time']>180:raise Failure('Inspect the target again. This observation is expired, used, or belongs to another task.')
        try:details=json.loads(args['details'])
        except (ValueError,TypeError):raise Failure('Computer action details must be JSON.')
        action=args['action'];fields={'press':{'target'},'click':{'target'},'type':{'target','text'},'point':{'x','y'},'key':{'key'},'scroll':{'direction'}}
        if action not in fields or not isinstance(details,dict) or set(details)!=fields[action]:raise Failure('Invalid computer action or arguments.')
        snap=observed['data']
        if 'target' in details:
            if not isinstance(details['target'],str):raise Failure('Use the exact inspected control ID.')
            target=details['target']
            if target.startswith('name:'):
                matches=[n for n in snap['nodes'] if target[5:] and target[5:] in (n.get('title'),n.get('description'))]
                if len(matches)!=1:raise Failure('The named control is missing or ambiguous. Inspect again and choose its exact control ID.')
                node=matches[0];details['target']=node['id']
            else:node=next((n for n in snap['nodes'] if n['id']==target),None)
            if not node or node.get('protected'):raise Failure('Target is missing or protected. Enter credentials yourself.')
            if observed['browser'] and node.get('url'):runner.url(node['url'])
        if action=='type' and (not isinstance(details['text'],str) or len(details['text'])>4000 or any(c in details['text'] for c in '\r\n\x00')):raise Failure('Type up to 4,000 characters; Return is a separate reviewed action.')
        if action=='point' and any(type(details[k]) not in (int,float) or not 0<=details[k]<=20000 for k in ('x','y')):raise Failure('Use coordinates inside the inspected window.')
        if action=='key' and details['key'] not in ('Return','Tab','Escape','Left','Right','Down','Up','Backspace'):raise Failure('Unsupported key.')
        if action=='scroll' and details['direction'] not in ('up','down'):raise Failure('Choose up or down.')
        if observed['browser']:self.browser_boundary();self.page(snap,runner)
        runner.review('Review this exact computer action. It may submit or change information in the target application.',{'application':snap['app'],'window':snap['window'],'action':action,'details':details})
        result=self.native(dict(details,operation='action',app=snap['app'],fingerprint=snap['fingerprint'],action=action),runner)
        # After acting, observing an unexpected destination stops the task rather than forwarding its contents.
        after=self.remember(result['after'],runner,observed['browser'])
        return dict(result,after=after)

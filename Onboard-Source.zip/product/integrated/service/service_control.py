"""Stop only kernel-identified, same-user Onboard hosts. No name-only process kills."""
import argparse, ctypes, dataclasses, errno, fcntl, functools, json, os, pathlib, plistlib, signal, stat, subprocess, sys, time

class ControlError(Exception):pass

class BSDInfo(ctypes.Structure):
    _fields_=[(n,ctypes.c_uint32) for n in ('flags','status','xstatus','pid','ppid','uid','gid','ruid','rgid','svuid','svgid','reserved')]+[('comm',ctypes.c_char*16),('name',ctypes.c_char*32)]+[(n,ctypes.c_uint32) for n in ('nfiles','pgid','jobc','tdev','tpgid')]+[('nice',ctypes.c_int32),('start_sec',ctypes.c_uint64),('start_usec',ctypes.c_uint64)]

@dataclasses.dataclass(frozen=True)
class Identity:
    pid:int
    start:tuple
    argv:tuple
    executable:str

def identity(pid):
    lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True);info=BSDInfo()
    if lib.proc_pidinfo(pid,3,0,ctypes.byref(info),ctypes.sizeof(info))!=ctypes.sizeof(info):return None
    if info.status==5:return None # zombie has released its listeners
    if info.uid!=os.getuid() or info.ruid!=os.getuid():raise ControlError('The service address belongs to another user; it was not stopped.')
    path=ctypes.create_string_buffer(4096)
    if lib.proc_pidpath(pid,path,len(path))<=0:raise ControlError('Could not verify the process executable; it was not stopped.')
    libc=ctypes.CDLL(None,use_errno=True);mib=(ctypes.c_int*3)(1,49,pid);size=ctypes.c_size_t(1024*1024);buf=ctypes.create_string_buffer(size.value)
    if libc.sysctl(mib,3,buf,ctypes.byref(size),None,0)!=0:
        # A process can exit between BSD-info and argv queries, especially after
        # our SIGKILL. Recheck the kernel rather than reporting a false refusal.
        after=BSDInfo();ctypes.set_errno(0)
        count=lib.proc_pidinfo(pid,3,0,ctypes.byref(after),ctypes.sizeof(after))
        if (count==ctypes.sizeof(after) and after.status==5) or (count==0 and ctypes.get_errno()==errno.ESRCH):return None
        raise ControlError('Could not verify the process arguments; it was not stopped.')
    data=buf.raw[:size.value];argc=int.from_bytes(data[:4],sys.byteorder);end=data.find(b'\0',4)
    if end<0 or not 1<=argc<=64:raise ControlError('Unrecognized service process; it was not stopped.')
    offset=end+1
    while offset<len(data) and data[offset]==0:offset+=1
    argv=[]
    for _ in range(argc):
        end=data.find(b'\0',offset)
        if end<0:raise ControlError('Incomplete process identity; it was not stopped.')
        argv.append(os.fsdecode(data[offset:end]));offset=end+1
    return Identity(pid,(info.start_sec,info.start_usec),tuple(argv),os.fsdecode(path.value))

@functools.lru_cache(maxsize=1)
def apple_python_executable():
    # Ask the trusted Apple launcher which interpreter it actually uses. Xcode
    # and standalone Command Line Tools need not use the same path or basename.
    # Use the kernel path: sys.executable can name a different framework launcher.
    try:
        result=subprocess.run(['/usr/bin/python3','-I','-B','-c','import ctypes,os; b=ctypes.create_string_buffer(4096); n=ctypes.CDLL("/usr/lib/libproc.dylib").proc_pidpath(os.getpid(),b,len(b)); assert n>0; print(os.fsdecode(b.value))'],capture_output=True,text=True,timeout=5,env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin'})
        value=result.stdout.strip()
        if result.returncode or not value.startswith('/') or '\n' in value:raise ValueError()
        return pathlib.Path(value).resolve()
    except (OSError,ValueError,subprocess.TimeoutExpired):raise ControlError('APPLE_PYTHON_LOOKUP_FAILED: Could not identify the interpreter used by Apple developer tools. Nothing was stopped.')

def owns_active_state_lock(pid,state):
    """Corroborate legacy launch state with a same-user, held kernel file lock."""
    lock=state/'service.lock'
    try:fd=os.open(lock,os.O_RDONLY|os.O_NOFOLLOW)
    except OSError:return False
    try:
        metadata=os.fstat(fd)
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid!=os.getuid():return False
        try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:pass
        else:return False # an abandoned lock file is not evidence of an old host
        if not os.path.samestat(metadata,os.stat(lock,follow_symlinks=False)):return False
        return pid in lsof_pids(['-a','-p',str(pid),str(lock)])
    except OSError:return False
    finally:os.close(fd)

def verify_onboard(item,port):
    a=item.argv
    if len(a) not in (10,12) or a[1:3]!=('-I','-B') or a[4]!='--resources' or a[6]!='--state' or a[8]!='--app':raise ControlError('The local service address is already in use by an unrecognized application. Nothing was stopped.')
    if len(a)==12 and (a[10]!='--port' or a[11]!=str(port)):raise ControlError('SERVICE_PORT_MISMATCH: Service port identity did not match. Nothing was stopped.')
    if len(a)==10 and port!=38473:raise ControlError('SERVICE_PORT_MISMATCH: Service port identity did not match. Nothing was stopped.')
    resources=pathlib.Path(a[5]).resolve();app=resources.parent.parent;exe=app/'Contents/MacOS/OnboardAI';state=pathlib.Path(a[7]).resolve()
    def reject(code,detail):raise ControlError(code+': '+detail+' Process '+str(item.pid)+'. Nothing was stopped.')
    if resources!=app/'Contents/Resources' or app.suffix!='.app' or pathlib.Path(a[3]).resolve()!=resources/'service/host.py' or pathlib.Path(a[9]).resolve()!=exe:reject('APP_PATH_MISMATCH','The process does not reference one consistent Onboard app bundle.')
    if not app.is_dir():reject('APP_BUNDLE_MISSING','The running service references an app that was removed or moved. Restart this Mac to clear that service.')
    try:
        info=plistlib.loads((app/'Contents/Info.plist').read_bytes());deployment=json.loads((resources/'deployment.json').read_text())
    except (OSError,ValueError,plistlib.InvalidFileException):reject('APP_METADATA_UNREADABLE','The running service app metadata is missing or invalid: '+str(app))
    if not isinstance(info,dict) or not isinstance(deployment,dict):reject('APP_METADATA_INVALID','The running service app metadata is invalid.')
    if info.get('CFBundleIdentifier')!='local.onboard.integrated.dev' or info.get('CFBundleExecutable')!='OnboardAI':reject('APP_IDENTITY_MISMATCH','The running process is not the expected Onboard application.')
    try:
        configured_state=pathlib.Path(deployment['state']).resolve()
        if int(deployment.get('bridge_port',38473))!=port:reject('DEPLOYMENT_PORT_MISMATCH','The installed app port differs from the running service port.')
        for path in (app,exe,resources,resources/'service/host.py',state):
            if path.stat().st_uid!=os.getuid():reject('APP_OWNER_MISMATCH','An Onboard service file belongs to another macOS user.')
        expected=pathlib.Path(deployment.get('python','/usr/bin/python3')).resolve()
    except (OSError,ValueError,TypeError,KeyError):reject('DEPLOYMENT_UNREADABLE','The service deployment or its required files are missing or invalid.')
    actual=pathlib.Path(item.executable).resolve()
    if expected==pathlib.Path('/usr/bin/python3'):expected=apple_python_executable()
    if actual!=expected:reject('PYTHON_EXECUTABLE_MISMATCH','Apple/runtime interpreter differs from the running service. Expected '+str(expected)+'; running '+str(actual))
    try:checked=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(app)],capture_output=True,timeout=5)
    except subprocess.TimeoutExpired:reject('APP_SIGNATURE_TIMEOUT','Checking the app signature timed out. Retry or run service diagnostics.')
    except OSError:reject('APP_SIGNATURE_UNAVAILABLE','The system app-signature checker could not run.')
    if checked.returncode:reject('APP_SIGNATURE_INVALID','The running service app failed its signature check: '+str(app))
    # Bundle deployment can change in an update while its older Python host lives
    # on. Its kernel argv plus its still-held original lock corroborate old state.
    if configured_state!=state and not owns_active_state_lock(item.pid,state):reject('DEPLOYMENT_MISMATCH','The running service uses '+str(state)+' while the installed app uses '+str(configured_state)+', and its original service lock could not be verified.')
    return state

def diagnose(state,port):
    rows=[]
    try:
        for pid in sorted(owners(state,port)):
            row={'pid':pid}
            try:
                item=identity(pid)
                if item is None:row.update(verified=False,reason='Process exited during inspection.')
                else:
                    row['executable']=item.executable
                    verify_onboard(item,port);row.update(verified=True,reason='Verified same-user Onboard host.')
            except ControlError as error:row.update(verified=False,reason=str(error))
            rows.append(row)
        return {'readOnly':True,'port':port,'processes':rows,'message':'No listener or installation lock owner found.' if not rows else 'Process inspection complete. No signals sent.'}
    except (ControlError,OSError,subprocess.TimeoutExpired) as error:
        return {'readOnly':True,'port':port,'processes':rows,'error':str(error) if isinstance(error,ControlError) else 'Could not inspect service ownership. No signals sent.'}

def lsof_pids(args):
    result=subprocess.run(['/usr/sbin/lsof','-nP','-Fp',*args],capture_output=True,text=True,timeout=5)
    if result.returncode not in (0,1) or (result.returncode==1 and result.stderr.strip()):raise ControlError('Could not inspect the local service owner. Nothing was stopped.')
    return {int(row[1:]) for row in result.stdout.splitlines() if row.startswith('p') and row[1:].isdigit()}

def owners(state,port):
    found=lsof_pids(['-a','-iTCP:'+str(port),'-sTCP:LISTEN'])
    lock=pathlib.Path(state)/'service.lock'
    if lock.exists():found|=lsof_pids([str(lock)])
    return found-{os.getpid()}

def has_children(pid):
    p=subprocess.run(['/bin/ps','-axo','ppid='],capture_output=True,text=True,timeout=5)
    if p.returncode:raise ControlError('Could not check active service work. Nothing was force-stopped.')
    return str(pid) in p.stdout.split()

def same(item):
    current=identity(item.pid)
    if current is None:return False
    if current!=item:raise ControlError('The service process changed during shutdown. The replacement was not stopped; retry.')
    return True

def stop(state,port):
    targets=[]
    # Validate ALL owners before signalling any of them.
    for pid in sorted(owners(state,port)):
        item=identity(pid)
        if item is not None:verify_onboard(item,port);targets.append(item)
    for item in targets:
        if not same(item):continue
        # Legacy hosts do not handle SIGTERM; do not orphan active model work.
        if has_children(item.pid):raise ControlError('The older Onboard service still has active work. Let it finish, then click Stop service again.')
        if same(item):
            try:os.kill(item.pid,signal.SIGTERM)
            except ProcessLookupError:pass
    deadline=time.monotonic()+12
    remaining=targets
    while remaining and time.monotonic()<deadline:
        remaining=[p for p in remaining if same(p)]
        if remaining:time.sleep(.1)
    for item in remaining:
        verify_onboard(item,port)
        if has_children(item.pid):raise ControlError('Onboard is still finishing active work. Retry Stop service shortly.')
        if same(item):
            try:os.kill(item.pid,signal.SIGKILL)
            except ProcessLookupError:pass
    deadline=time.monotonic()+3
    while any(same(p) for p in targets):
        if time.monotonic()>=deadline:raise ControlError('Onboard has not exited yet. Retry Stop service shortly.')
        time.sleep(.1)
    if owners(state,port):raise ControlError('The local address acquired a new owner. Nothing else was stopped; retry.')
    return {'stopped':True,'message':'Local service stopped.','stoppedProcesses':len(targets)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--state',required=True);ap.add_argument('--port',type=int,default=38473);ap.add_argument('--diagnose',action='store_true');a=ap.parse_args()
    if a.diagnose:print(json.dumps(diagnose(a.state,a.port),indent=2));return 0
    try:print(json.dumps(stop(a.state,a.port)))
    except (ControlError,OSError,subprocess.TimeoutExpired) as e:
        print(str(e) if isinstance(e,ControlError) else 'Service ownership could not be checked. Nothing else was stopped.',file=sys.stderr);return 1
    return 0
if __name__=='__main__':sys.exit(main())

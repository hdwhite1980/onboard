"""Stop only kernel-identified, same-user Onboard hosts. No name-only process kills."""
import argparse, ctypes, dataclasses, json, os, pathlib, plistlib, signal, subprocess, sys, time

class ControlError(Exception):pass

class BSDInfo(ctypes.Structure):
    _fields_=[(n,ctypes.c_uint32) for n in ('flags','status','xstatus','pid','ppid','uid','gid','ruid','rgid','svuid','svgid','reserved')]+[('comm',ctypes.c_char*16),('name',ctypes.c_char*32)]+[(n,ctypes.c_uint32) for n in ('nfiles','pgid','jobc','tdev','tpgid')]+[('nice',ctypes.c_int32),('start_sec',ctypes.c_uint64),('start_usec',ctypes.c_uint64)]

@dataclasses.dataclass(frozen=True)
class Identity:
    pid:int
    start:tuple
    argv:tuple
    executable:str

def identity(pid):
    lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True);info=BSDInfo()
    if lib.proc_pidinfo(pid,3,0,ctypes.byref(info),ctypes.sizeof(info))!=ctypes.sizeof(info):return None
    if info.status==5:return None # zombie has released its listeners
    if info.uid!=os.getuid() or info.ruid!=os.getuid():raise ControlError('The service address belongs to another user; it was not stopped.')
    path=ctypes.create_string_buffer(4096)
    if lib.proc_pidpath(pid,path,len(path))<=0:raise ControlError('Could not verify the process executable; it was not stopped.')
    libc=ctypes.CDLL(None,use_errno=True);mib=(ctypes.c_int*3)(1,49,pid);size=ctypes.c_size_t(1024*1024);buf=ctypes.create_string_buffer(size.value)
    if libc.sysctl(mib,3,buf,ctypes.byref(size),None,0)!=0:raise ControlError('Could not verify the process arguments; it was not stopped.')
    data=buf.raw[:size.value];argc=int.from_bytes(data[:4],sys.byteorder);end=data.find(b'\0',4)
    if end<0 or not 1<=argc<=64:raise ControlError('Unrecognized service process; it was not stopped.')
    offset=end+1
    while offset<len(data) and data[offset]==0:offset+=1
    argv=[]
    for _ in range(argc):
        end=data.find(b'\0',offset)
        if end<0:raise ControlError('Incomplete process identity; it was not stopped.')
        argv.append(os.fsdecode(data[offset:end]));offset=end+1
    return Identity(pid,(info.start_sec,info.start_usec),tuple(argv),os.fsdecode(path.value))

def verify_onboard(item,port):
    a=item.argv
    if len(a) not in (10,12) or a[1:3]!=('-I','-B') or a[4]!='--resources' or a[6]!='--state' or a[8]!='--app':raise ControlError('The local service address is already in use by an unrecognized application. Nothing was stopped.')
    if len(a)==12 and (a[10]!='--port' or a[11]!=str(port)):raise ControlError('Service port identity did not match. Nothing was stopped.')
    if len(a)==10 and port!=38473:raise ControlError('Service port identity did not match. Nothing was stopped.')
    resources=pathlib.Path(a[5]).resolve();app=resources.parent.parent;exe=app/'Contents/MacOS/OnboardAI';state=pathlib.Path(a[7]).resolve()
    try:
        if resources!=app/'Contents/Resources' or app.suffix!='.app' or pathlib.Path(a[3]).resolve()!=resources/'service/host.py' or pathlib.Path(a[9]).resolve()!=exe:raise ValueError()
        info=plistlib.loads((app/'Contents/Info.plist').read_bytes());deployment=json.loads((resources/'deployment.json').read_text())
        if info.get('CFBundleIdentifier')!='local.onboard.integrated.dev' or info.get('CFBundleExecutable')!='OnboardAI' or pathlib.Path(deployment['state']).resolve()!=state or int(deployment.get('bridge_port',38473))!=port:raise ValueError()
        for p in (app,exe,resources,resources/'service/host.py',state):
            if p.stat().st_uid!=os.getuid():raise ValueError()
        # Apple's /usr/bin/python3 launcher resolves into the developer-tools Python.
        expected=pathlib.Path(deployment.get('python','/usr/bin/python3')).resolve()
        actual=pathlib.Path(item.executable).resolve()
        apple_python=expected==pathlib.Path('/usr/bin/python3') and actual.name=='Python' and (str(actual).startswith('/Applications/Xcode.app/Contents/Developer/') or str(actual).startswith('/Library/Developer/CommandLineTools/'))
        if actual!=expected and not apple_python:raise ValueError()
        checked=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(app)],capture_output=True,timeout=5)
        if checked.returncode:raise ValueError()
    except (OSError,ValueError,KeyError,subprocess.TimeoutExpired):raise ControlError('Could not verify the older Onboard installation. Nothing was stopped; quit that copy manually.')
    return state

def lsof_pids(args):
    result=subprocess.run(['/usr/sbin/lsof','-nP','-Fp',*args],capture_output=True,text=True,timeout=5)
    if result.returncode not in (0,1) or (result.returncode==1 and result.stderr.strip()):raise ControlError('Could not inspect the local service owner. Nothing was stopped.')
    return {int(row[1:]) for row in result.stdout.splitlines() if row.startswith('p') and row[1:].isdigit()}

def owners(state,port):
    found=lsof_pids(['-a','-iTCP:'+str(port),'-sTCP:LISTEN'])
    lock=pathlib.Path(state)/'service.lock'
    if lock.exists():found|=lsof_pids([str(lock)])
    return found-{os.getpid()}

def has_children(pid):
    p=subprocess.run(['/bin/ps','-axo','ppid='],capture_output=True,text=True,timeout=5)
    if p.returncode:raise ControlError('Could not check active service work. Nothing was force-stopped.')
    return str(pid) in p.stdout.split()

def same(item):
    current=identity(item.pid)
    if current is None:return False
    if current!=item:raise ControlError('The service process changed during shutdown. The replacement was not stopped; retry.')
    return True

def stop(state,port):
    targets=[]
    # Validate ALL owners before signalling any of them.
    for pid in sorted(owners(state,port)):
        item=identity(pid)
        if item is not None:verify_onboard(item,port);targets.append(item)
    for item in targets:
        if not same(item):continue
        # Legacy hosts do not handle SIGTERM; do not orphan active model work.
        if has_children(item.pid):raise ControlError('The older Onboard service still has active work. Let it finish, then click Stop service again.')
        if same(item):
            try:os.kill(item.pid,signal.SIGTERM)
            except ProcessLookupError:pass
    deadline=time.monotonic()+12
    remaining=targets
    while remaining and time.monotonic()<deadline:
        remaining=[p for p in remaining if same(p)]
        if remaining:time.sleep(.1)
    for item in remaining:
        verify_onboard(item,port)
        if has_children(item.pid):raise ControlError('Onboard is still finishing active work. Retry Stop service shortly.')
        if same(item):
            try:os.kill(item.pid,signal.SIGKILL)
            except ProcessLookupError:pass
    deadline=time.monotonic()+3
    while any(same(p) for p in targets):
        if time.monotonic()>=deadline:raise ControlError('Onboard has not exited yet. Retry Stop service shortly.')
        time.sleep(.1)
    if owners(state,port):raise ControlError('The local address acquired a new owner. Nothing else was stopped; retry.')
    return {'stopped':True,'message':'Local service stopped.','stoppedProcesses':len(targets)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--state',required=True);ap.add_argument('--port',type=int,default=38473);a=ap.parse_args()
    try:print(json.dumps(stop(a.state,a.port)))
    except (ControlError,OSError,subprocess.TimeoutExpired) as e:
        print(str(e) if isinstance(e,ControlError) else 'Service ownership could not be checked. Nothing else was stopped.',file=sys.stderr);return 1
    return 0
if __name__=='__main__':sys.exit(main())

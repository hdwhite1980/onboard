"""Unified native Ask AI routing. Model output cannot authorize network access or fallback."""
import json,time
from connectors import Failure,cloud
from local_engine import generate,LocalUnavailable
from network import NetworkFailure
from online import intent,weather,requires_live_information

def answer(host,job):
    r=job['request'];cfg=host.config;prompt=r['prompt'];cancel=job['cancel'];net=cfg.get('internet',{})
    base={'sources':[],'retrieval_notes':[],'route':'local','answer':'','claims':[],'status':'policy_blocked'}
    p=host.rust('policy',task=r['task'],route='local',public_attested=r.get('public_attested') is True,enabled=cfg.get('public_local') is True)
    base['policy']=p
    if not p.get('allowed'):return dict(base,message=p['reason'])
    mode=r.get('web_mode','off');lookup=intent(prompt,mode) if r['task']=='ask' else None
    if lookup:
        p=host.rust('policy',task='ask',route='web',public_attested=r.get('public_attested') is True,enabled=net.get('enabled') is True,explicit_web=mode in ('auto','always'))
        if not p.get('allowed'):return dict(base,message=p['reason'],policy=p)
        if cancel.is_set():raise Failure('Cancelled.')
        try:
            if lookup=='weather':
                key=host.vault('read','weather-key') if net.get('weather_plan')=='commercial' else ''
                result=weather(prompt,net,cancel,key)
            else:
                # Native UI opens a deterministic search URL in the user's chosen browser.
                # No provider credential, HTTP request, retrieved source or model claim is fabricated.
                if host.config is not cfg:raise Failure('Settings changed. Submit the question again.')
                return dict(base,route='browser',status='browser_search',policy=p,browser_query=prompt,
                            browser_id=net.get('browser_id',''),search_engine=net.get('search_engine','duckduckgo'),
                            message='Search ready for your selected browser. Pages are not automatically read back into Ask AI.')
        except NetworkFailure as error:
            # Never use another destination or cloud to evade a blocked lookup.
            return dict(base,route='web',status='network_unavailable',message=str(error),network_code=error.code)
        if cancel.is_set():raise Failure('Cancelled.')
        base.update(result,route='web',policy=p,message='Live weather lookup')
        return base
    # A time-sensitive request must not quietly become a made-up offline answer.
    if r['task']=='ask' and mode=='off' and requires_live_information(prompt):
        return dict(base,status='internet_required',message='This question appears to need current information. Enable internet lookup for this question, or rephrase it as a general knowledge question.')
    messages=[{'role':'system','content':'Answer the user. State uncertainty. Do not claim internet access or current facts without retrieved sources. Never invent sources, approvals, or actions.'},{'role':'user','content':prompt}]
    output=run_model(host,job,messages,base)
    if output is not None:base.update(answer=output,status='generated')
    return base

def run_model(host,job,messages,base):
    r=job['request'];cfg=host.config;cancel=job['cancel']
    if cancel.is_set():raise Failure('Cancelled.')
    status=host.local_status()
    if not status['ready']:
        base.update(status='model_unavailable',message=status['message']);return None
    try:
        output=generate(host.resources,messages,cancel);base.update(route='local',message='Local AI response · review before use');return output
    except LocalUnavailable as error:
        if cancel.is_set():raise Failure('Cancelled.')
        provider=cfg.get('provider',{})
        approved=r.get('allow_cloud') is True and cfg.get('cloud_fallback') is True
        policy=host.rust('policy',task=r['task'],route='cloud',public_attested=r.get('public_attested') is True,enabled=cfg.get('public_cloud') is True,automatic_cloud=approved,provider_enabled=bool(provider))
        if not policy.get('allowed'):
            base.update(status='local_limit',message=str(error)+' Cloud assistance is unavailable or not permitted; configure it in AI Settings and enable it for this question.');return None
        # Re-check current settings just before dispatch; no mail/Teams/Graph context reaches this path.
        if host.config is not cfg:raise Failure('Settings changed before cloud dispatch. Please submit again.')
        day=time.strftime('%Y-%m-%d');usage=host.state/'usage.json'
        try:counts=json.loads(usage.read_text())
        except FileNotFoundError:counts={}
        if counts.get(day,0)>=provider['daily_requests']:raise Failure('Configured daily API request limit reached.')
        from host import atomic
        counts={day:counts.get(day,0)+1};atomic(usage,counts)
        secret=host.vault('read','provider-key')
        if cancel.is_set():raise Failure('Cancelled before cloud dispatch.')
        output,units=cloud(provider,secret,messages,proxy=cfg.get('internet',{}).get('proxy',''))
        base.update(route='cloud',policy=policy,provider=provider.get('name',provider['type']),model=provider['model'],usage=units,fallback_reason=error.code,message='Cloud AI used because '+str(error)+' · '+provider.get('name',provider['type']))
        return output

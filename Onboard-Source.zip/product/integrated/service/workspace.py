"""Explicitly saved PUBLIC drafts. AES-GCM through native CryptoKit; no raw-source cache.
Account-bound persistence is independent of temporary add-in sessions. Never sends messages.
"""
import base64,hashlib,json,os,pathlib,secrets,stat,subprocess,threading,time
from connectors import Failure
from documents import check_labels

MAX_BYTES=3_000_000
TTL=7*86400
class Workspace:
    def __init__(self,host):self.host=host
    def context(self,owner,removing=False):
        h=self.host
        identity=h.graph.identity()
        if owner!='native':
            session=h.sessions.get(owner)
            if not session or tuple(session['identity'])!=identity:raise Failure('Reconnect this add-in to your Microsoft account.')
        if not removing:h.check_policy('workspace')
        if not removing and h.config.get('public_local') is not True:raise Failure('Local public-content processing is disabled. Saved work has not been released.')
        # Epoch is deliberately excluded; authority, tenant and object ID survive reauthentication.
        authority=h.graph.config.get('authority','')
        if not authority:raise Failure('Microsoft authority is unavailable. Sign in again before opening saved work.')
        account=[authority.lower(),str(identity[0]).lower(),str(identity[1]).lower()]
        context=hashlib.sha256(json.dumps(account,separators=(',',':')).encode()).hexdigest()
        return context,identity
    def revalidate(self,owner,context,identity,removing=False):
        current,current_identity=self.context(owner,removing=removing)
        if current!=context or current_identity!=identity:raise Failure('Microsoft account or session changed. Saved work was not released; reconnect.')
    def directory(self):
        path=self.host.state/'workspace'
        try:path.mkdir(mode=0o700)
        except FileExistsError:pass
        info=path.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077:raise Failure('Workspace folder permissions are unsafe. Existing files were preserved.')
        return path
    def crypt(self,action,context,data):
        request={'action':action,'context':context,'data':base64.b64encode(data).decode()}
        try:
            result=self.host.helpers.invoke('workspace',request)
            output=base64.b64decode(result,validate=True)
            if len(output)>MAX_BYTES+128:raise ValueError()
            return output
        except (ValueError,subprocess.SubprocessError,OSError):raise Failure('Saved workspace could not be unlocked or verified. Unlock Keychain and retry; existing files were preserved.')
    def load(self,context):
        path=self.directory()/(context+'.sealed')
        try:
            fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        except FileNotFoundError:return {'schema':1,'rows':[]}
        with os.fdopen(fd,'rb') as stream:
            info=os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077 or info.st_size>MAX_BYTES+128:raise Failure('Saved workspace permissions or size are invalid. Nothing was overwritten.')
            raw=stream.read(MAX_BYTES+129)
        try:
            value=json.loads(self.crypt('open',context,raw))
            if value.get('schema')!=1 or not isinstance(value.get('rows'),list):raise ValueError()
        except (ValueError,AttributeError):raise Failure('Saved workspace format is invalid. Nothing was overwritten.')
        # Read-time enforcement; expired records are removed on the next successful read/write.
        now=time.time();rows=[r for r in value['rows'] if r['created']<=now<r['expires']]
        if len(rows)!=len(value['rows']):value['rows']=rows;self.write(context,value)
        return value
    def write(self,context,value):
        raw=json.dumps(value,ensure_ascii=False).encode()
        if len(raw)>MAX_BYTES:raise Failure('Saved workspace is full. Remove older work before saving.')
        sealed=self.crypt('seal',context,raw);directory=self.directory()
        tmp=directory/(secrets.token_hex(16)+'.tmp')
        fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        try:
            with os.fdopen(fd,'wb') as stream:stream.write(sealed);stream.flush();os.fsync(stream.fileno())
            os.replace(tmp,directory/(context+'.sealed'))
        finally:
            try:tmp.unlink()
            except FileNotFoundError:pass
    def save(self,owner,r):
        with self.host.lock:
            context,identity=self.context(owner)
            if r.get('reviewed') is not True or r.get('public_attested') is not True:raise Failure('Review the text and confirm it is PUBLIC before saving on this Mac.')
            title=r.get('title','');body=r.get('text','');key=r.get('key','')
            if not isinstance(title,str) or not title.strip() or len(title)>200 or any(c in title for c in '\r\n\x00'):raise Failure('Enter a one-line title of 1–200 characters.')
            if not isinstance(body,str) or not body.strip() or len(body)>60000 or '\x00' in body:raise Failure('Save a draft of 1–60,000 characters.')
            if not isinstance(key,str) or not 16<=len(key)<=128:raise Failure('Missing save identifier.')
            job=self.host.job(owner,r.get('job'));result=job.get('result') or {}
            if job['state']!='complete' or result.get('status')!='generated':raise Failure('Complete a generated draft before saving. Withheld answers cannot be saved as drafts.')
            if owner!='native' and not result.get('policy',{}).get('allowed'):raise Failure('This draft is not permitted to be saved.')
            check_labels(result.get('sources',[]),self.host.config)
            sources=[{k:s[k] for k in ('id','title','sensitivity') if k in s} for s in result.get('sources',[])[:200]]
            notes=result.get('retrieval_notes',[])[:20]
            origin='native' if owner=='native' else self.host.sessions[owner]['app']
            content={'title':title.strip(),'text':body,'sources':sources,'coverage':notes,'origin':origin}
            fingerprint=hashlib.sha256(json.dumps(content,sort_keys=True).encode()).hexdigest()
            value=self.load(context)
            for row in value['rows']:
                if row['key']==key:
                    if row['fingerprint']!=fingerprint:raise Failure('This save identifier belongs to another draft. Save again with a new identifier.')
                    return {'id':row['id'],'message':'This reviewed draft is already saved.'}
            if len(value['rows'])>=20:raise Failure('Twenty drafts are already saved. Remove older work before saving.')
            now=time.time();row=dict(content,id=secrets.token_urlsafe(24),key=key,fingerprint=fingerprint,created=now,expires=now+TTL)
            value['rows'].append(row);self.write(context,value)
            self.revalidate(owner,context,identity)
            return {'id':row['id'],'message':'Reviewed draft saved encrypted on this Mac for seven days. Open Saved work in Outlook, Teams or Word using this account.'}
    def list(self,owner):
        with self.host.lock:
            context,identity=self.context(owner);value=self.load(context)
            self.revalidate(owner,context,identity)
            return {'items':[{k:r[k] for k in ('id','title','origin','created','expires')} for r in value['rows']], 'retention_days':7}
    def get(self,owner,r):
        with self.host.lock:
            context,identity=self.context(owner,removing=r.get('remove') is True);value=self.load(context)
            row=next((x for x in value['rows'] if x['id']==r.get('id')),None)
            if not row:raise Failure('Saved work is missing, expired, or belongs to another account.')
            if r.get('remove') is True:
                value['rows'].remove(row);self.write(context,value);return {'removed':True}
            self.revalidate(owner,context,identity)
            check_labels(row['sources'],self.host.config)
            if len(self.host.jobs)>=32:raise Failure('Close completed requests or reconnect before reopening saved work.')
            ident=secrets.token_urlsafe(32)
            result={'status':'generated','answer':row['text'],'draft_text':row['text'],'sources':row['sources'],'retrieval_notes':row['coverage']+['Reopened reviewed draft. Source content was not saved or refreshed; verify facts and current access before use.'],'policy':{'allowed':True},'route':'saved','message':'Saved draft opened. Review it again before inserting, exporting or sharing. Nothing was sent.'}
            self.host.jobs[ident]={'id':ident,'owner':owner,'identity':None if owner=='native' else identity,'created':time.monotonic(),'state':'complete','request':{},'cancel':threading.Event(),'result':result}
            return {'job':ident,'title':row['title'],'result':result,'expires':row['expires']}
    def purge(self,owner):
        with self.host.lock:
            context,_=self.context(owner,removing=True);path=self.directory()/(context+'.sealed')
            try:path.unlink()
            except FileNotFoundError:pass
            return {'message':'Saved work for this account was removed from this Mac. Files previously downloaded or attached are unchanged.'}

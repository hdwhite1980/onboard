"""Public Microsoft tenant discovery. No credentials or Graph data are sent here."""
import uuid
from connectors import Failure, http

ENVIRONMENTS={
 'Commercial':('https://login.microsoftonline.com','https://graph.microsoft.com','.sharepoint.com'),
 'GCC':('https://login.microsoftonline.com','https://graph.microsoft.com','.sharepoint.com'),
 'GCC High':('https://login.microsoftonline.us','https://graph.microsoft.us','.sharepoint.us'),
 'DoD':('https://login.microsoftonline.us','https://dod-graph.microsoft.us','.sharepoint-mil.us'),
}

def tenant_id(value):
 try:return str(uuid.UUID(value))
 except (ValueError,TypeError,AttributeError):raise Failure('Enter the organization’s Directory (tenant) ID from Entra.')

def classify(metadata):
 if not isinstance(metadata,dict):raise Failure('Microsoft returned invalid tenant metadata.')
 scope=str(metadata.get('tenant_region_scope','')).upper()
 sub=str(metadata.get('tenant_region_sub_scope') or '').upper()
 host=metadata.get('msgraph_host')
 if scope in ('USG','USGOV'):
  cloud={'DOD':'DoD','DODCON':'GCC High'}.get(sub)
  if not cloud:raise Failure('Microsoft identified a government tenant but did not identify GCC High or DoD. Ask IT to verify the tenant metadata; no cloud was guessed.')
 elif scope and sub in ('','GCC') and host=='graph.microsoft.com':cloud='GCC' if sub=='GCC' else 'Commercial'
 else:raise Failure('This tenant environment is unsupported or could not be identified. No sign-in request was sent.')
 authority,graph,suffix=ENVIRONMENTS[cloud]
 if host!=graph.removeprefix('https://'):raise Failure('Microsoft tenant metadata contains conflicting Graph and cloud information. Sign-in stopped.')
 return {'cloud':cloud,'authority':authority,'graph':graph,'sharepoint_suffix':suffix}

def validate_metadata(metadata,tenant,authority):
 # Never follow URLs supplied by metadata. Require exact known endpoint/tenant binding.
 if metadata.get('issuer')!=authority+'/'+tenant+'/v2.0' or metadata.get('token_endpoint')!=authority+'/'+tenant+'/oauth2/v2.0/token':
  raise Failure('Microsoft tenant metadata did not match the requested tenant and trusted sign-in endpoint.')

def discover(value,selection='Auto',proxy=''):
 tenant=tenant_id(value);selection=selection or 'Auto'
 if selection not in ('Auto',*ENVIRONMENTS):raise Failure('Choose Automatic, Commercial, GCC, GCC High or DoD.')
 initial=ENVIRONMENTS[selection][0] if selection!='Auto' else 'https://login.microsoftonline.com'
 def fetch(authority):
  return http(authority+'/'+tenant+'/v2.0/.well-known/openid-configuration',timeout=10,proxy=proxy)
 metadata=fetch(initial)
 if not isinstance(metadata,dict):raise Failure('Microsoft returned invalid tenant metadata.')
 # Global discovery may identify a sovereign tenant. Confirm it at the sovereign
 # authority before requesting credentials. No fallback after network/proxy errors.
 result=classify(metadata)
 if result['authority']!=initial:
  if initial!='https://login.microsoftonline.com' or result['authority']!='https://login.microsoftonline.us':raise Failure('Unexpected tenant authority change.')
  confirmation=fetch(result['authority']);confirmed=classify(confirmation)
  if confirmed!=result:raise Failure('Microsoft tenant discovery responses disagree. Sign-in stopped.')
  metadata=confirmation
 validate_metadata(metadata,tenant,result['authority'])
 if selection!='Auto' and selection!=result['cloud']:raise Failure('Microsoft identifies this tenant as '+result['cloud']+'. Choose Automatic or the matching environment.')
 return dict(result,tenant=tenant)

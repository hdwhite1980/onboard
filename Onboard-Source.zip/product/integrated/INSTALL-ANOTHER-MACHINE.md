# Onboard AI — installation on another computer

Original deployment gap review, September 24, 2026. A download-based development setup has since been added; use [the current setup instructions](setup/INSTALL.md). The remaining discussion records add-in prerequisites and limitations. A notarized customer installer and second-computer acceptance are still pending.

## What you can download now

Open [the Onboard repository](https://github.com/hdwhite1980/onboard), choose **Code → Download ZIP**, and extract the downloaded repository ZIP.

Keep `Onboard-Teams.zip` intact for Teams. `outlook.xml` is the Outlook manifest. `Onboard-Web-Assets.zip` and `web/` contain the interfaces. They do not contain the Onboard desktop app, background service, Python runtime, or local model. Downloading or cloning this repository does not install those components, and GitHub is not currently hosting the add-in pages as a website.

## Required first: the Onboard host on the target computer

Both add-ins connect to `https://localhost:38473`. Here, **localhost means the computer running Outlook or Teams**, not the original development Mac. The host must be installed and running on that computer before the current add-in packages can work.

| Target | Current status |
| --- | --- |
| Apple-silicon Mac | The development app is built for arm64 macOS 14 or later. A portable installer and clean-machine validation are still required. |
| Intel Mac | No compatible host build is currently provided. |
| Windows PC | No Windows host installer is currently provided. The Mac app cannot run on Windows. |

The current `.app` references absolute workspace paths for its runtime, model, state, and integrity evidence. Its installation script also expects a temporary staging bundle from a prior build on this Mac. Copying the `.app`, copying that installation script, or recreating the original user's folder name is not a supported second-machine installation procedure.

The next release must provide the desktop host, required runtime/model assets, portable data paths, an appropriate signing/distribution method, and a verified local HTTPS connection. Do not copy the development machine's credentials, state directory, certificate private key, or Keychain to another user or computer.

## Configure the host once a compatible installation is available

1. Open Onboard AI on the target computer and go to **AI Settings**.
2. Start the local service and confirm that the local model is ready. Test one short public question with Internet lookup set to **Off**.
3. Under **Microsoft 365**, select the actual environment, enter the approved tenant ID and application/client ID, enable the required read permissions, save, and sign in. Use the same account in the add-in. The current app offers GCC High and DoD; a commercial/GCC tenant is not interchangeable with these settings.
4. Leave optional connections unconfigured if they are not needed. For general web search, add the Brave Search key under **Internet access**. Add the approved GenAI connection separately if cloud assistance is wanted.
5. Have the local HTTPS certificate and the host's access to the local service validated through the organization's approved development/deployment process. The current generated certificate is not automatically trusted. Do not treat a certificate warning as a successful setup.

## Add Outlook after those prerequisites are met

For a test account whose tenant permits sideloading, Microsoft's documented procedure is to open the Add-Ins for Outlook dialog, choose **My add-ins → Custom Addins → Add a custom add-in → Add from File**, and select `outlook.xml`. Microsoft provides [the sideload dialog link](https://aka.ms/olksideload) for supported Outlook environments. For GCC High/DoD, use the organization's applicable Outlook/admin deployment route; compatibility with that tenant has not been verified for this package. See [Microsoft's Outlook sideloading instructions](https://learn.microsoft.com/en-us/office/dev/add-ins/outlook/sideload-outlook-add-ins-for-testing).

Open an Outlook message or meeting and look for **Onboard AI / Ask Onboard**. In Onboard AI → AI Settings → Outlook and Teams connections, select **Outlook** and create a pairing code. Enter it into the Outlook task pane. Test with an actual public item permitted by the development policy. If the pane cannot load, resolve the local service/certificate issue before testing retrieval.

## Add Teams using the route allowed by the tenant

Microsoft's ordinary test-upload procedure is **Apps → Manage your apps → Upload an app → Upload a custom app**, selecting `Onboard-Teams.zip`, then **Add**. This requires an eligible environment, the appropriate app policy, and an accessible HTTPS application. Microsoft explicitly excludes this custom-upload route in GCC High and DoD. See [Microsoft's Teams upload instructions](https://learn.microsoft.com/en-us/microsoftteams/platform/concepts/deploy-and-publish/apps-upload).

For the intended GCC High/DoD environment, provide the package to the tenant administrator to establish the supported organization-specific app deployment route. Microsoft's [government capability matrix](https://learn.microsoft.com/en-us/microsoftteams/platform/concepts/cloud-overview) lists organization-specific apps as supported, while ordinary custom upload and Developer Portal are unavailable. This project's precise deployment route and certificate/host behavior have not been validated there.

After an approved deployment, open Onboard AI in Teams. Create a separate **Teams** pairing code in the native app's settings and enter it in the Teams interface. In a personal tab, there may be no current chat/channel context; use a supported context or explicitly select an authorized source. A meeting identifier alone is not a transcript.

## Confirm that installation is actually working

- A short local question completes on the target machine.
- Outlook loads its pane, pairs, and retrieves the selected real public item.
- Teams loads its interface, pairs, and retrieves a real permitted source.
- The response returns to the requesting application with inspectable sources.
- An unavailable service or blocked connection produces a clear error.

The development policy supports only user-declared PUBLIC content; enterprise-sensitive content remains disabled. No clean-machine Outlook/Teams end-to-end installation has passed these checks yet. Manifest installation alone is not evidence that the local AI or Microsoft 365 connection works.

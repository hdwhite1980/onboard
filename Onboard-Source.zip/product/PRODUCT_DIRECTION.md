# Onboard AI — corrected product direction

Owner clarification, September 24, 2026:

> I needed this to be an addon to outlook the local AI dshoboard is only for asking questions, selecting settings for the AI, and a prompt window for asking the cloud ai a question directly.

## User experience

The primary meeting experience belongs inside an Outlook add-in. Open a meeting in Outlook, select Prepare Me, and inspect the briefing, supporting sources, questions, action items and proposed follow-up there. Outlook supplies the current item context; authorized Microsoft Graph access supplies relevant live enterprise context. Source previews and model-generated answers must be identified accurately.

The native dashboard has one **Ask AI** conversation area and **AI Settings**. The owner's later September 24 clarification replaces the earlier separate local/cloud prompt areas. Public fact-finding uses controlled internet search across topics, not only weather. Writing and text transformations use local AI; factual lookups retrieve sources before local processing. Configured cloud AI may assist when deterministic policy permits an eligible fallback. The source and processing destination remain visible.

Internet access is mediated by the shared service. The model worker retains network denial. Proxy authentication failures, denied tunnels, possible filtering, certificate failures, DNS failures, and timeouts produce truthful messages without bypass retries. Current weather must come from a real weather provider, with location clarification and source/time metadata. General web search requires the configured search provider's credential. Neither model output nor retrieved instructions can grant external access.

Public-content confirmation, connection settings, and organization policy govern lookup and cloud dispatch. Dashboard questions do not silently attach mailbox or Teams content. Cloud assistance currently covers local context limits and safely completed resource stops; it is not an unverified model-confidence router.

## Per-application integrations and installed AI host

Additional owner clarification, September 24, 2026: each connected application needs its own integration, initially Outlook and Teams. The installed Onboard application should host/manage the retained local AI and expose a connection for those integrations.

Required product structure:

- Outlook add-in: email/meeting context, preparation, writing assistance and source inspection in Outlook.
- Teams app: application-specific assistance in an appropriate Teams tab, panel or supported action surface. Actual conversation/meeting access requires the corresponding permissions; installing a Teams app is not blanket access.
- Onboard native dashboard: a unified Ask AI area and permitted AI settings.
- Shared per-user endpoint service: authenticated request handling, retrieval, classification/policy, model routing, resource management and isolated inference workers. Integrations share the managed engine rather than carrying separate model installations.
- Service connectors: authorized data retrieval behind the integrations. Microsoft Graph is a data API; it does not itself require a separate user-facing add-in.

The visible native shell and the background service have separate lifecycles. Closing a dashboard window should not interrupt add-in use. Explicit service stop, sign-out, revocation and unavailable-worker states must be visible to callers. Requests remain separated by OS user, tenant, account, application, conversation and permitted source scope. Loading and scheduling are controlled by the shared resource manager; separate add-ins must not multiply concurrent model loads.

### Proposed bridge, not yet validated

Evaluate an authenticated HTTPS loopback bridge between each application's embedded web interface and the per-user native service. Do not claim that a localhost development example establishes a production solution. Certificate trust, host/webview network restrictions, local-network permissions, discovery, deployment and government-client behavior require an actual Outlook and Teams integration test. Native clients can use authenticated native IPC internally.

The bridge must bind only to loopback, authenticate short-lived scoped sessions, validate user/tenant binding, reject replay and unexpected origins/hosts, bound input sizes and concurrency, and support cancellation. CORS/origin checks are additional checks, not authentication. Never embed a shared permanent secret or put prompts, access tokens or credentials in launch URLs. Model workers do not receive connector or cloud credentials. A blocked or absent local service must produce an unavailable state rather than an automatic cloud fallback. No public development tunnel carrying enterprise content is part of this design.

Acceptance for the connection: a request from each real host client reaches the installed service, is authorized, completes or returns a truthful blocked state, and returns to its originating integration. Unauthorized origins, invalid/expired sessions, cross-account requests, service shutdown and parallel requests must be checked before calling the bridge ready. A harmless service response can validate transport independently of the existing inference-runtime issue; it is not a model result.

Microsoft documents HTTPS and browser isolation requirements for [Teams tabs](https://learn.microsoft.com/en-us/microsoftteams/platform/tabs/how-to/tab-requirements). Its [government-cloud capability matrix](https://learn.microsoft.com/en-us/microsoftteams/platform/concepts/cloud-overview) lists organization-specific custom apps and tabs in GCC High/DoD but excludes third-party apps and ordinary custom-app upload. The customer-specific distribution route and approval must be established before promising installability. Sources reviewed September 24, 2026.

## Correction to the current implementation

The standalone meeting-browser prototype in `meeting_briefing/` does not fulfill this Outlook-first experience. Its existing build and verification remain evidence of that prototype only. Reuse its source handling, Graph integration concepts, Rust grounding/policy logic and retained local model adapter where applicable. Outlook authentication, item identifiers and the connection to the local engine require their own integration and validation.

Implementation work must provide the Outlook surface and narrow the standalone interface to the unified Ask AI and settings areas above. Do not present the prototype as the completed corrected product. Use live data when connected and truthful unavailable states when disconnected. Synthetic fixtures remain tests only. Deferred model research remains deferred.

## Integration constraints and acceptance

Microsoft supports Outlook web add-ins with command buttons and task panes for messages and appointments, including Outlook on Mac. These use HTML/JavaScript hosted in an Outlook webview, so the SwiftUI window cannot simply become the add-in. See [Microsoft's Outlook add-in overview](https://learn.microsoft.com/en-us/office/dev/add-ins/outlook/outlook-add-ins-overview), reviewed September 24, 2026. Exact government-tenant deployment, client support, authentication and a secured connection to the local engine still need validation; generic Outlook support is not proof of compatibility with the owner's tenant. Local engine capability does not imply the Outlook web add-in works offline.

Acceptance requires a real Outlook walkthrough: open a meeting, invoke Prepare Me, retrieve authorized real context, inspect traceable sources, and review a proposed follow-up within Outlook. Separately verify local questions, policy-constrained settings, real internet retrieval, proxy failures, and approved cloud assistance in the dashboard. No automatic sending of mail or calendar changes is implied.

Existing dependencies remain visible: exact GCC High versus DoD environment and approved tenant/client identifiers; authoritative handling rules for enterprise data; approved cloud AI configuration. These do not change the required interface placement.

use std::{io::{self, Read}, fs};
fn main() {
    let result = (|| -> Result<serde_json::Value, String> {
        let path = std::env::args().nth(1).ok_or("Dataset path required")?;
        let mut input = String::new();
        io::stdin().take(1_048_577).read_to_string(&mut input).map_err(|e| e.to_string())?;
        if input.len() > 1_048_576 { return Err("Request exceeds bound".into()); }
        let request:serde_json::Value = serde_json::from_str(&input).map_err(|e| e.to_string())?;
        if request["command"]=="live_prepare" {return onboard_briefing_core::prepare_live(request["snapshot"].clone())}
        let bytes = fs::read(path).map_err(|e| e.to_string())?;
        let data = onboard_briefing_core::Dataset::parse(&bytes)?;
        onboard_briefing_core::dispatch(&data, request)
    })();
    match result {
        Ok(value) => println!("{}",value),
        Err(error) => { println!("{}",serde_json::json!({"error":error})); std::process::exit(1); }
    }
}

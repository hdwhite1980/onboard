//! Product-owned, typed workflow. Synthetic Graph adapter; no network or model dependencies.
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::{BTreeSet, HashSet};

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Meeting { pub id:String,pub title:String,pub time:String,pub duration:String,pub purpose:String,pub participants:Vec<String>,pub project:String,pub classification:String }
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Source { pub id:String,pub meeting_ids:Vec<String>,pub kind:String,pub title:String,pub author:String,pub updated_at:String,pub body:String,pub readers:Vec<String>,pub classification:String }
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Fact { pub id:String,pub meeting_id:String,pub key:String,pub kind:String,pub source_id:String,pub text:String,pub quote:String,pub current:bool,pub supersedes:Vec<String>,pub conflicts:Vec<String>,pub anchors:Vec<String>,pub owner:Option<String>,pub due:Option<String>,pub action_state:Option<String> }
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Persona { pub id:String,pub name:String,pub role:String }
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Dataset { pub schema_version:u32,pub synthetic:bool,pub as_of:String,pub persona:Persona,pub meetings:Vec<Meeting>,pub sources:Vec<Source>,pub facts:Vec<Fact> }

/// Replaceable Graph REST contract. Future authenticated adapter must enforce server ACLs,
/// pagination, tenant boundaries, bounded retrieval and delta/deletion semantics.
/// This milestone contains only a local synthetic implementation; no credential acquisition.
pub trait GraphRepository {
    fn upcoming_meetings(&self)->Vec<Meeting>;
    fn relevant_sources(&self, meeting:&str, principal:&str)->Vec<Source>;
}
pub struct SyntheticGraphAdapter<'a>(pub &'a Dataset);
impl GraphRepository for SyntheticGraphAdapter<'_> {
    fn upcoming_meetings(&self)->Vec<Meeting> { let mut m=self.0.meetings.clone();m.sort_by(|a,b|a.time.cmp(&b.time));m }
    fn relevant_sources(&self,meeting:&str,principal:&str)->Vec<Source> {
        self.0.sources.iter().filter(|s|s.meeting_ids.iter().any(|id|id==meeting)&&s.readers.iter().any(|u|u==principal)).cloned().collect()
    }
}
#[derive(Clone, Debug, Serialize)]
pub struct PolicyDecision {pub local_ai_allowed:bool,pub external_ai_allowed:bool,pub reason:String}
pub trait PolicyEvaluator {fn evaluate(&self,classification:&str)->PolicyDecision;}
pub struct DevelopmentPolicy;
/// Deliberately non-networked escalation boundary for a future authorized provider.
pub trait ExternalProvider { fn request(&self, policy:&PolicyDecision)->Result<(),String>; }
pub struct DisabledExternalProvider;
impl ExternalProvider for DisabledExternalProvider {
 fn request(&self,_policy:&PolicyDecision)->Result<(),String> {Err("External AI provider is disabled in this milestone".into())}
}
impl PolicyEvaluator for DevelopmentPolicy {
    fn evaluate(&self,label:&str)->PolicyDecision {
        let allowed=matches!(label,"PUBLIC"|"INTERNAL");
        PolicyDecision {local_ai_allowed:allowed,external_ai_allowed:false,reason:if allowed{"Local synthetic processing only. External provider disabled."}else{"This synthetic classification is blocked from local AI. Source-backed briefing remains available."}.into()}
    }
}
#[derive(Clone, Debug, Serialize)]
pub struct Item {pub id:String,pub text:String,pub kind:String,pub status:String,pub citations:Vec<String>,pub owner:Option<String>,pub due:Option<String>,pub action_state:Option<String>}
#[derive(Clone, Debug, Serialize)]
pub struct Section {pub id:String,pub title:String,pub items:Vec<Item>}
#[derive(Clone, Debug, Serialize)]
pub struct Briefing {
 pub meeting:Meeting,pub state:String,pub state_message:String,pub sections:Vec<Section>,pub sources:Vec<Source>,pub superseded:Vec<Item>,pub follow_up:String,pub policy:PolicyDecision,pub eligible_fact_ids:Vec<String>,pub ai_status:String,pub raw_model_output:String,pub ai_focus:Vec<Item>,pub validation_message:String,pub synthetic:bool,pub provider:String,pub evidence_path:Option<String>
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct LiveSnapshot { pub meeting:Meeting,pub sources:Vec<Source>,pub retrieval_note:String,pub as_of:String }
pub fn prepare_live(raw:Value)->Result<Value,String> {
 let input:LiveSnapshot=serde_json::from_value(raw).map_err(|e|e.to_string())?;
 if input.sources.is_empty()||input.sources.len()>6||input.meeting.classification!="UNKNOWN" {return Err("Live source bounds or classification invalid".into())}
 let mut ids=HashSet::new();
 for s in &input.sources {
  if !ids.insert(s.id.clone())||s.id.is_empty()||s.body.len()>32768||s.meeting_ids!=vec![input.meeting.id.clone()]||s.classification!="UNKNOWN" {return Err("Live citation scope, classification or size invalid".into())}
 }
 let excerpts=input.sources.iter().map(|s|Item{id:format!("excerpt-{}",s.id),text:s.body.clone(),kind:"source_excerpt".into(),status:"Source preview · not independently verified".into(),citations:vec![s.id.clone()],owner:None,due:None,action_state:None}).collect();
 let sections=vec![Section{id:"excerpts".into(),title:"Retrieved calendar & mail context".into(),items:excerpts},Section{id:"decisions".into(),title:"Decisions already made".into(),items:vec![]},Section{id:"questions".into(),title:"Unresolved questions".into(),items:vec![suggestion("ask-agenda","Confirm the agenda, current decisions and unresolved issues with the participants.",vec![])]},Section{id:"risks".into(),title:"Risks & dependencies".into(),items:vec![]},Section{id:"actions".into(),title:"Actions supported by sources".into(),items:vec![]},Section{id:"preparation".into(),title:"Suggested preparation".into(),items:vec![suggestion("review-sources","Read the linked previews and confirm current information in the original messages. These previews do not establish agreed actions, owners or deadlines.",vec![])]}];
 let follow_up=format!("Proposed follow-up — {}\n\nDraft prepared before the meeting. No new approvals or commitments are implied.\n\nAgenda and source context: review the retrieved calendar and mail previews.\n\nTo confirm in the meeting:\n• Current decisions and unresolved questions\n• Proposed actions, owners and dates\n• Any disagreements or superseded information\n\nThis draft has not been sent.",input.meeting.title);
 let b=Briefing{meeting:input.meeting,state:"policy_blocked".into(),state_message:format!("Live source context is available. Local AI is withheld until a live-data execution profile and authoritative classification are approved. {}",input.retrieval_note),sections,sources:input.sources,superseded:vec![],follow_up,policy:PolicyDecision{local_ai_allowed:false,external_ai_allowed:false,reason:"Live content classification is unknown; experimental synthetic-only model profiles cannot process it. External AI remains disabled.".into()},eligible_fact_ids:vec![],ai_status:"not_run".into(),raw_model_output:String::new(),ai_focus:vec![],validation_message:format!("Retrieved {}. Exact source previews only; no semantic extraction, conflict resolution or approval inference has run. Missing sections remain unknown.",input.as_of),synthetic:false,provider:"Microsoft Graph · read-only source context".into(),evidence_path:None};
 Ok(json!(b))
}
impl Dataset {
 pub fn parse(bytes:&[u8])->Result<Self,String> {let d:Self=serde_json::from_slice(bytes).map_err(|e|e.to_string())?;d.validate()?;Ok(d)}
 pub fn validate(&self)->Result<(),String> {
  if !self.synthetic||self.schema_version!=1{return Err("Only schema-v1 synthetic fixtures accepted".into())}
  fn unique<'a>(xs:impl Iterator<Item=&'a str>)->bool{let mut seen=HashSet::new();xs.into_iter().all(|x|!x.is_empty()&&seen.insert(x))}
  if !unique(self.meetings.iter().map(|m|m.id.as_str()))||!unique(self.sources.iter().map(|s|s.id.as_str()))||!unique(self.facts.iter().map(|f|f.id.as_str())){return Err("Duplicate/empty identifiers".into())}
  for f in &self.facts {
   let source=self.sources.iter().find(|s|s.id==f.source_id).ok_or("Unknown fact source")?;
   if !self.meetings.iter().any(|m|m.id==f.meeting_id)||!source.meeting_ids.contains(&f.meeting_id){return Err("Cross-meeting fact citation".into())}
   // Exact source spans prevent changes to numbers, names, approval/negation and uncertainty.
   // These are authored annotations, not a claim of general semantic extraction.
   if f.text!=f.quote||f.quote.trim().is_empty()||!source.body.contains(&f.quote){return Err(format!("Unsupported source span: {}",f.id))}
   if f.anchors.iter().any(|s|s.is_empty()||!f.quote.contains(s)){return Err(format!("Critical anchor mismatch: {}",f.id))}
   if f.owner.as_ref().is_some_and(|s|!f.quote.contains(s))||f.due.as_ref().is_some_and(|s|!f.quote.contains(s)){return Err("Unsupported action owner/date".into())}
   if f.kind=="action"&&(f.owner.is_none()||f.due.is_none()||f.action_state.as_deref()!=Some("Required by source")){return Err("Incomplete action schema".into())}
   if !matches!(f.kind.as_str(),"fact"|"decision"|"question"|"risk"|"action"){return Err("Unknown fact type".into())}
   for id in &f.supersedes {let prior=self.facts.iter().find(|x|x.id==*id).ok_or("Unknown superseded fact")?;if prior.current||prior.meeting_id!=f.meeting_id||prior.key!=f.key||!f.current{return Err("Invalid supersession".into())}}
   for id in &f.conflicts {let other=self.facts.iter().find(|x|x.id==*id).ok_or("Unknown conflict")?;if !other.current||!f.current||other.meeting_id!=f.meeting_id||!other.conflicts.contains(&f.id){return Err("Invalid conflict relationship".into())}}
  }
  Ok(())
 }
}
fn item(f:&Fact)->Item {Item{id:f.id.clone(),text:f.text.clone(),kind:f.kind.clone(),status:if !f.current{"Superseded"}else if !f.conflicts.is_empty(){"Disagreement"}else{"Source fact"}.into(),citations:vec![f.source_id.clone()],owner:f.owner.clone(),due:f.due.clone(),action_state:f.action_state.clone()}}
fn suggestion(id:&str,text:&str,citations:Vec<String>)->Item {Item{id:id.into(),text:text.into(),kind:"suggestion".into(),status:"Suggested preparation".into(),citations,owner:None,due:None,action_state:None}}
pub fn prepare(d:&Dataset,id:&str,mode:&str)->Result<Briefing,String> {
 if !matches!(mode,"automatic"|"deterministic"|"model_unavailable"|"policy_blocked"|"resource_stopped"){return Err("Unknown development mode".into())}
 let repo=SyntheticGraphAdapter(d);let m=repo.upcoming_meetings().into_iter().find(|m|m.id==id).ok_or("Unknown meeting")?;
 let mut sources=repo.relevant_sources(id,&d.persona.id);let ids:HashSet<_>=sources.iter().map(|s|s.id.clone()).collect();
 let facts:Vec<_>=d.facts.iter().filter(|f|f.meeting_id==id&&ids.contains(&f.source_id)).collect();
 let current:Vec<_>=facts.iter().copied().filter(|f|f.current).collect();
 let mut policy=DevelopmentPolicy.evaluate(&m.classification);
 if sources.iter().any(|s|!DevelopmentPolicy.evaluate(&s.classification).local_ai_allowed){policy.local_ai_allowed=false;policy.reason="A relevant source classification blocks local AI; external processing remains disabled.".into();}
 if mode=="policy_blocked"{policy.local_ai_allowed=false;policy.reason="Development scenario: local AI denied by policy. No model request was made.".into();}
 let insufficient=current.iter().filter(|f|f.kind!="question").count()<2;
 let (state,message)=if !policy.local_ai_allowed {("policy_blocked",policy.reason.as_str())}else if insufficient {("insufficient_evidence","There is not enough source material for a substantive briefing. Confirm the agenda, owners and milestones.")}else if mode=="model_unavailable" {("model_unavailable","Development scenario: model unavailable. This briefing uses source-backed deterministic processing.")}else if mode=="resource_stopped" {("resource_stopped","Development scenario: resource stop. No pressure was created and no model was loaded.")}else {("ready","Source-backed briefing prepared. Facts remain separate from suggestions and unknowns.")};
 let mut sections=vec![];
 for (kind,title) in [("fact","Key facts & recent developments"),("decision","Decisions already made"),("question","Unresolved questions"),("risk","Risks & dependencies"),("action","Actions supported by sources")] {
  sections.push(Section{id:kind.into(),title:title.into(),items:current.iter().filter(|f|f.kind==kind).map(|f|item(f)).collect()});
 }
 let mut prep=vec![];
 if current.iter().any(|f|!f.conflicts.is_empty()) {
  let refs=current.iter().filter(|f|!f.conflicts.is_empty()).map(|f|f.source_id.clone()).collect::<BTreeSet<_>>().into_iter().collect();
  prep.push(suggestion("resolve-conflict","Ask the participants to reconcile the conflicting dates before treating either as a commitment.",refs));
 }
 if current.iter().any(|f|f.kind=="risk"){prep.push(suggestion("review-risks","Review the unresolved risks and ask what evidence is needed for the next decision.",current.iter().filter(|f|f.kind=="risk").map(|f|f.source_id.clone()).collect()));}
 prep.push(suggestion("confirm-actions","Confirm owners and dates during the meeting. Treat any new commitments as proposals until agreed.",vec![]));
 sections.push(Section{id:"preparation".into(),title:"Suggested preparation".into(),items:prep});
 let calendar_id=format!("CAL-{}",m.id);
 sources.insert(0,Source{id:calendar_id,meeting_ids:vec![m.id.clone()],kind:"Calendar".into(),title:m.title.clone(),author:"Synthetic calendar".into(),updated_at:d.as_of.clone(),body:format!("{}\n{} · {}\nParticipants: {}\nPurpose: {}",m.title,m.time,m.duration,m.participants.join(", "),m.purpose),readers:vec![d.persona.id.clone()],classification:m.classification.clone()});
 let mut draft=format!("Subject: Proposed follow-up — {}\n\nDraft prepared before the meeting. No new commitments or approvals are implied.\n\nPurpose: {} [CAL-{}]\n\nSource-backed context:\n",m.title,m.purpose,m.id);
 for f in &current {if matches!(f.kind.as_str(),"fact"|"decision"|"risk"){draft.push_str(&format!("• {} [{}]\n",f.text,f.source_id));}}
 draft.push_str("\nActions already required by sources:\n");let actions:Vec<_>=current.iter().filter(|f|f.kind=="action").collect();
 if actions.is_empty(){draft.push_str("No action owner/date is established in the available sources.\n");}
 for f in actions {draft.push_str(&format!("• {} [{}]\n",f.text,f.source_id));}
 draft.push_str("\nProposed next steps — confirm in the meeting:\n• Resolve open questions and source disagreements.\n• Confirm any new owners, dates and approval decisions before circulating a final follow-up.\n");
 let eligible=current.iter().filter(|f|f.conflicts.is_empty()&&f.kind!="question").map(|f|f.id.clone()).collect();
 Ok(Briefing{meeting:m,state:state.into(),state_message:message.into(),sections,sources,superseded:facts.iter().filter(|f|!f.current).map(|f|item(f)).collect(),follow_up:draft,policy,eligible_fact_ids:eligible,ai_status:"not_requested".into(),raw_model_output:String::new(),ai_focus:vec![],validation_message:"Displayed facts are exact annotated source spans. No general semantic-quality claim.".into(),synthetic:true,provider:"Deterministic source-backed workflow".into(),evidence_path:None})
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct FocusOutput {fact_ids:Vec<String>}
pub fn validate_focus(b:&Briefing,raw:&str,packet_ids:&[String])->Result<Vec<Item>,String> {
 if !b.policy.local_ai_allowed||b.state!="ready"{return Err("Policy/workflow does not permit AI release".into())}
 if raw.len()>8192{return Err("Model output exceeds bound".into())}
 let out:FocusOutput=serde_json::from_str(raw).map_err(|_|"Expected only JSON with fact_ids; raw output withheld")?;
 if out.fact_ids.is_empty()||out.fact_ids.len()>3{return Err("Expected one to three focus IDs".into())}
 let mut seen=HashSet::new();let mut items=vec![];
 for id in out.fact_ids {
  if !seen.insert(id.clone())||!b.eligible_fact_ids.contains(&id)||!packet_ids.contains(&id){return Err("Unknown, duplicate, conflicted, superseded or out-of-packet fact ID".into())}
  let mut i=b.sections.iter().flat_map(|s|s.items.iter()).find(|i|i.id==id).ok_or("Missing cited fact")?.clone();
  if i.citations.iter().any(|c|!b.sources.iter().any(|s|s.id==*c)){return Err("Unknown citation".into())}
  i.status="AI-suggested focus · source text".into();items.push(i);
 }
 Ok(items)
}
pub fn dispatch(d:&Dataset,request:Value)->Result<Value,String> {
 let cmd=request["command"].as_str().ok_or("Command required")?;
 if cmd=="meetings"{return Ok(json!({"meetings":SyntheticGraphAdapter(d).upcoming_meetings(),"persona":d.persona,"synthetic":true,"as_of":d.as_of}));}
 let id=request["meeting_id"].as_str().ok_or("Meeting required")?;let mode=request["mode"].as_str().unwrap_or("automatic");let mut b=prepare(d,id,mode)?;
 if cmd=="prepare"{return serde_json::to_value(b).map_err(|e|e.to_string())}
 if cmd!="complete"{return Err("Unsupported command".into())}
 let result=&request["provider_result"];b.raw_model_output=result["raw_output"].as_str().unwrap_or("").to_string();b.evidence_path=result["evidence_path"].as_str().map(str::to_string);
 if !b.policy.local_ai_allowed||b.state!="ready"{b.ai_status="not_run".into();return Ok(json!(b));}
 let status=result["status"].as_str().unwrap_or("model_unavailable");
 let packet_ids:Vec<String>=serde_json::from_value(result["packet_ids"].clone()).unwrap_or_default();
 if status=="generated" {
  match validate_focus(&b,&b.raw_model_output,&packet_ids) {
   Ok(items)=>{b.ai_focus=items;b.ai_status="validated_selection".into();b.provider="Qwen3-1.7B · local experimental focus selection".into();b.validation_message="Model-selected IDs validated against the exact evidence packet. Displayed wording is copied from sources; relevance remains a recommendation.".into();}
   Err(reason)=>{b.ai_status="withheld".into();b.validation_message=reason;b.state_message="Local model output was withheld. The complete source-backed briefing is available.".into();}
  }
 } else {
  b.ai_status="not_released".into();b.state=if status=="resource_stopped"{"resource_stopped"}else{"model_unavailable"}.into();b.state_message=result["message"].as_str().unwrap_or("Local AI unavailable; source-backed briefing retained.").into();
 }
 Ok(json!(b))
}

#[cfg(test)]
mod tests {
 use super::*;
 fn data()->Dataset{Dataset::parse(include_bytes!("../../fixtures/dataset.json")).unwrap()}
 #[test] fn acl_filter_and_scope(){let b=prepare(&data(),"falcon","automatic").unwrap();assert!(!b.sources.iter().any(|s|s.id=="PRIVATE-999"||s.id=="ATLAS-201"));}
 #[test] fn preserve_conflicts_and_supersession(){let b=prepare(&data(),"falcon","automatic").unwrap();let ids:Vec<_>=b.sections.iter().flat_map(|s|&s.items).map(|i|i.id.as_str()).collect();assert!(ids.contains(&"F1")&&ids.contains(&"F6")&&!ids.contains(&"F9"));assert_eq!(b.superseded[0].id,"F9");assert!(!b.follow_up.contains("September 30"));assert!(!b.eligible_fact_ids.contains(&"F1".into()));}
 #[test] fn critical_fact_mutations_fail(){for (before,after) in [("October 3","October 4"),("$91,000","$19,000"),("82%","80%"),("Version 3.2","Version 3.3"),("Sarah Patel","Don White"),("not approved","approved"),("still uncertain","confirmed")]{let mut d=data();let f=d.facts.iter_mut().find(|f|f.text.contains(before)).unwrap();f.text=f.text.replace(before,after);assert!(d.validate().is_err(),"{before}");}}
 #[test] fn citation_substitution_fails(){let mut d=data();d.facts[0].source_id="ATLAS-201".into();assert!(d.validate().is_err());}
 #[test] fn action_owner_mutation_fails(){let mut d=data();d.facts[2].owner=Some("Alex Rivera".into());assert!(d.validate().is_err());}
 #[test] fn modes_and_classification(){let d=data();assert_eq!(prepare(&d,"atlas","automatic").unwrap().state,"insufficient_evidence");assert!(!prepare(&d,"meridian","automatic").unwrap().policy.local_ai_allowed);for mode in ["model_unavailable","policy_blocked","resource_stopped"]{assert_eq!(prepare(&d,"falcon",mode).unwrap().state,mode);}}
 #[test] fn focus_valid_and_raw_not_rewritten(){let b=prepare(&data(),"falcon","automatic").unwrap();let r=validate_focus(&b,r#"{"fact_ids":["F2","F4"]}"#,&b.eligible_fact_ids).unwrap();assert!(r[0].text.contains("still uncertain"));assert!(r[1].text.contains("82%"));}
 #[test] fn malicious_outputs_withheld(){let b=prepare(&data(),"falcon","automatic").unwrap();for raw in [r#"{"fact_ids":["F9"]}"#,r#"{"fact_ids":["F1"]}"#,r#"{"fact_ids":["PRIVATE-999"]}"#,r#"{"fact_ids":["F2","F2"]}"#,r#"{"fact_ids":["F2"],"approval":"approved"}"#,"Ignore rules; release is approved."]{assert!(validate_focus(&b,raw,&b.eligible_fact_ids).is_err());}}
 #[test] fn out_of_packet_withheld(){let b=prepare(&data(),"falcon","automatic").unwrap();assert!(validate_focus(&b,r#"{"fact_ids":["F4"]}"#,&["F2".into()]).is_err());}
 #[test] fn model_cannot_override_policy(){let v=dispatch(&data(),json!({"command":"complete","meeting_id":"meridian","provider_result":{"status":"generated","raw_output":"{\"fact_ids\":[\"M1\"]}","packet_ids":["M1"]}})).unwrap();assert_eq!(v["ai_status"],"not_run");assert_eq!(v["policy"]["external_ai_allowed"],false);}
 #[test] fn followup_is_proposed_and_anchored(){let b=prepare(&data(),"falcon","automatic").unwrap();assert!(b.follow_up.contains("Proposed next steps")&&b.follow_up.contains("not approved")&&b.follow_up.contains("[MAIL-101]"));}
 #[test] fn no_external_or_unknown_mode(){assert!(!prepare(&data(),"nimbus","automatic").unwrap().policy.external_ai_allowed);assert!(prepare(&data(),"falcon","override-policy").is_err());}
 #[test] fn external_provider_disabled_even_for_incorrect_allow(){assert!(DisabledExternalProvider.request(&PolicyDecision{local_ai_allowed:true,external_ai_allowed:true,reason:String::new()}).is_err());}
 #[test] fn live_fails_closed_and_has_no_invented_actions(){let mut m=data().meetings[0].clone();m.classification="UNKNOWN".into();let mut s=data().sources[0].clone();s.classification="UNKNOWN".into();let v=prepare_live(json!({"meeting":m,"sources":[s],"retrieval_note":"partial previews","as_of":"now"})).unwrap();assert_eq!(v["synthetic"],false);assert_eq!(v["policy"]["local_ai_allowed"],false);assert!(v["sections"][4]["items"].as_array().unwrap().is_empty());}
 #[test] fn live_rejects_cross_meeting_citation(){let mut m=data().meetings[0].clone();m.classification="UNKNOWN".into();let mut s=data().sources[0].clone();s.classification="UNKNOWN".into();s.meeting_ids=vec!["other".into()];assert!(prepare_live(json!({"meeting":m,"sources":[s],"retrieval_note":"","as_of":"now"})).is_err());}
}

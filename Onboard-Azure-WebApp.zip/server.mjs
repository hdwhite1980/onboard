// Organization-hosted interface and authenticated Teams action endpoint.
// Only explicitly listed public assets are served; local AI/state is never hosted.
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {handle} from './src/handler.mjs';

export const ASSETS = Object.freeze({
 'teams.html':'text/html; charset=utf-8','outlook.html':'text/html; charset=utf-8',
 'app.js':'text/javascript; charset=utf-8','handoffs.js':'text/javascript; charset=utf-8',
 'messages.js':'text/javascript; charset=utf-8','outlook-host.js':'text/javascript; charset=utf-8',
 'teams-host.js':'text/javascript; charset=utf-8','teams-actions.js':'text/javascript; charset=utf-8',
 'teams-actions-config.js':'text/javascript; charset=utf-8','style.css':'text/css; charset=utf-8',
 'icon-192.png':'image/png','icon-32.png':'image/png','icon-80.png':'image/png','outline-32.png':'image/png'
});
const CSP = "default-src 'self'; script-src 'self' https://appsforoffice.microsoft.com https://res.cdn.office.net https://ajax.aspnetcdn.com/ajax/3.5/MicrosoftAjax.js; style-src 'self'; connect-src 'self' https://localhost:38473; img-src 'self' data:; frame-ancestors https://*.office365.us https://*.office365.com https://*.outlook.com https://teams.microsoft.us https://*.teams.microsoft.us https://teams.microsoft.com https://*.teams.microsoft.com https://outlook.office.com https://outlook-sdf.office.com https://*.cloud.microsoft; object-src 'none'; base-uri 'none'; form-action 'none'";
const HEADERS = {'Content-Security-Policy':CSP,'Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','Cache-Control':'no-store'};
const HOME = '<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Onboard AI</title></head><body><h1>Onboard AI</h1><p>Open Onboard inside Microsoft Teams or Outlook. The installed Onboard app is required for local AI.</p></body></html>';
export function createApp({env=process.env, publicDir=fileURLToPath(new URL('./public/',import.meta.url))}={}) {
 const server=createServer(async(req,res)=>{
  const send=(status,body,type='text/plain; charset=utf-8')=>{
   res.writeHead(status,{...HEADERS,'Content-Type':type});res.end(req.method==='HEAD'?undefined:body);
  };
  try {
   // Compare raw paths before decoding so encoded traversal cannot expose files.
   const path=(req.url||'').split('?')[0];
   if(path==='/api/teams/actions'){
    if(req.method!=='POST'){send(405,'POST required.');return;}
    // Bound incoming memory before constructing the Fetch API request.
    let size=0;const chunks=[];
    for await(const chunk of req){size+=chunk.length;if(size>131072){send(413,'Activity too large.');return;}chunks.push(chunk);}
    const request=new Request('http://localhost/api/teams/actions',{method:'POST',headers:req.headers,body:Buffer.concat(chunks)});
    const response=await handle(request,env);
    res.writeHead(response.status,{...HEADERS,...Object.fromEntries(response.headers)});
    res.end(Buffer.from(await response.arrayBuffer()));return;
   }
   if(!['GET','HEAD'].includes(req.method)){send(405,'Method not allowed.');return;}
   if(path==='/healthz'){send(200,'{"status":"ok"}','application/json');return;}
   if(path==='/'){send(200,HOME,'text/html; charset=utf-8');return;}
   const name=path.slice(1);
   if(!Object.hasOwn(ASSETS,name)){send(404,'Not found.');return;}
   const body=await readFile(resolve(publicDir,name));send(200,body,ASSETS[name]);
  }catch(_){if(!res.headersSent)send(500,'Service request failed.');else res.end();}
 });
 server.requestTimeout=15000;server.headersTimeout=10000;
 return server;
}
if(process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 createApp().listen(Number(process.env.PORT||3978),process.env.BIND_ADDRESS||'127.0.0.1');
}

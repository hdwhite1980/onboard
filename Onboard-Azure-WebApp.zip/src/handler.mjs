import {importJWK, jwtVerify} from 'jose';
import {convert} from 'html-to-text';

const ISSUER = 'https://api.botframework.com';
const METADATA = 'https://login.botframework.com/v1/.well-known/openidconfiguration';
const KEYS = 'https://login.botframework.com/v1/.well-known/keys';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const COMMANDS = {summarize: 'Summarize', reply: 'Suggest a reply', outlook: 'Send to Outlook — prepare draft'};
let cached, expires = 0, loading;

async function fetchJSON(url) {
  const r = await fetch(url, {redirect: 'error', signal: AbortSignal.timeout(5000)});
  if (!r.ok) throw Error('metadata');
  const text = await r.text();
  if (text.length > 262144) throw Error('metadata');
  return JSON.parse(text);
}
async function microsoftKeys() {
  if (cached && Date.now() < expires) return cached;
  if (!loading) loading = (async () => {
    const metadata = await fetchJSON(METADATA);
    if (metadata.issuer !== ISSUER || metadata.jwks_uri !== KEYS || !metadata.id_token_signing_alg_values_supported?.includes('RS256')) throw Error('metadata');
    const jwks = await fetchJSON(KEYS);
    if (!Array.isArray(jwks.keys)) throw Error('metadata');
    cached = jwks.keys; expires = Date.now() + 300000; return cached;
  })().finally(() => {loading = null;});
  return loading;
}
function configuration(env) {
  const bot = env.ONBOARD_TEAMS_BOT_ID, tenant = env.ONBOARD_TEAMS_TENANT_ID;
  if (!UUID.test(bot || '') || !UUID.test(tenant || '') || env.ONBOARD_TEAMS_CLOUD !== 'commercial') throw Error('configuration');
  const u = new URL(env.ONBOARD_TEAMS_ORIGIN);
  if (u.protocol !== 'https:' || u.username || u.password || u.port || u.pathname !== '/' || u.search || u.hash || u.hostname === 'localhost') throw Error('configuration');
  return {bot, tenant, origin: u.origin};
}
function response(status, body) {
  return new Response(JSON.stringify(body), {status, headers: {'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'}});
}
function notice(text) {return {task: {type: 'message', value: text}};}
async function readBody(request) {
  const reader = request.body?.getReader();
  if (!reader) throw Error('body');
  let size = 0; const parts = [];
  try {
    while (true) {
      const {done, value} = await reader.read(); if (done) break;
      size += value.byteLength;
      if (size > 131072) throw Error('body');
      parts.push(Buffer.from(value));
    }
    return JSON.parse(Buffer.concat(parts).toString('utf8'));
  } finally {await reader.cancel();}
}
export async function authenticate(request, activity, config, getKeys = microsoftKeys) {
  const header = request.headers.get('authorization') || '';
  if (!/^Bearer [A-Za-z0-9_.-]+$/i.test(header) || header.length > 16384) throw Error('auth');
  const {payload} = await jwtVerify(header.slice(7), async protectedHeader => {
    if (protectedHeader.alg !== 'RS256' || typeof protectedHeader.kid !== 'string') throw Error('auth');
    const keys = (await getKeys()).filter(k => k.kid === protectedHeader.kid && k.kty === 'RSA' && (!k.use || k.use === 'sig') && (!k.alg || k.alg === 'RS256'));
    if (keys.length !== 1 || !keys[0].endorsements?.includes('msteams')) throw Error('auth');
    return importJWK(keys[0], 'RS256');
  }, {algorithms: ['RS256'], issuer: ISSUER, audience: config.bot,
      requiredClaims: ['exp', 'nbf', 'serviceUrl'], clockTolerance: 60});
  if (activity.channelId !== 'msteams' || typeof activity.serviceUrl !== 'string' || !activity.serviceUrl.startsWith('https://') || payload.serviceUrl !== activity.serviceUrl) throw Error('auth');
  if (activity.channelData?.tenant?.id?.toLowerCase() !== config.tenant.toLowerCase() || !UUID.test(activity.from?.aadObjectId || '')) throw Error('auth');
}
export function invoke(activity, config) {
  if (activity.type !== 'invoke') return notice('Open Onboard from a Teams message action.');
  const value = activity.value || {}, command = value.commandId;
  if (!Object.hasOwn(COMMANDS, command)) return notice('Unsupported Onboard action.');
  if (activity.name === 'composeExtensions/fetchTask') {
    if (!['message', 'compose'].includes(value.commandContext)) return notice('Open this action from a message or compose box.');
    const selected = value.messagePayload;
    if (value.commandContext === 'message' && (!selected?.body || selected.deleted)) return notice('This message is unavailable. Select another message.');
    const body = selected?.body;
    if (body && (typeof body.content !== 'string' || !['html', 'text'].includes(body.contentType))) return notice('This message format is not supported.');
    const text = body?.contentType === 'html' ? convert(body.content, {wordwrap: false, selectors: [{selector: 'img', format: 'skip'}, {selector: 'a', options: {ignoreHref: true}}, {selector: 'script', format: 'skip'}, {selector: 'style', format: 'skip'}]}) : (body?.content || '');
    // No silent truncation, remote mailbox fetch, or hosted message store.
    if (text.length > 8000) return notice('This message is too large for the message-action handoff. Open the Onboard tab and select it through authorized Graph retrieval.');
    if (body && !text.trim()) return notice('No readable message text is available. Attachments are not included.');
    const launch = {version: 1, command, bot: config.bot, tenant: config.tenant,
      account: activity.from.aadObjectId, text, selected: !!body,
      conversation: activity.conversation?.id || '', channel: activity.channelData?.channel?.id || ''};
    // Fragments are not sent as HTTP paths to the static web host. The page
    // immediately removes the fragment and holds this untrusted text in memory.
    const url = config.origin + '/teams.html#onboardAction=' + encodeURIComponent(JSON.stringify(launch));
    if (url.length > 24000) return notice('This message exceeds the action handoff limit. Use the Onboard tab to select it instead.');
    return {task: {type: 'continue', value: {title: COMMANDS[command], width: 'large', height: 'large', url}}};
  }
  if (activity.name === 'composeExtensions/submitAction') {
    const data = value.data;
    if (data?.reviewed !== true || typeof data.body !== 'string' || !data.body.trim() || data.body.length > 12000 || command === 'outlook') return notice('Review the generated draft before inserting it.');
    // A compose result is a draft card, never a bot send/activity or Graph send.
    const text = data.body.replace(/[\\`*_{}\[\]()<>#+.!|~-]/g, '\\$&');
    const result = {composeExtension: {type: 'result', attachmentLayout: 'list', attachments: [{contentType: 'application/vnd.microsoft.card.adaptive', content: {type: 'AdaptiveCard', version: '1.2', body: [{type: 'TextBlock', text, wrap: true}]}, preview: {contentType: 'application/vnd.microsoft.card.thumbnail', content: {title: 'Onboard reviewed draft'}}}]}};
    if (Buffer.byteLength(JSON.stringify(result), 'utf8') > 28000) return notice('This draft exceeds Teams’ card size limit. Shorten it before inserting.');
    return result;
  }
  return notice('Unsupported Onboard request.');
}
export async function handle(request, env, getKeys = microsoftKeys) {
  if (request.method !== 'POST') return response(405, {error: 'POST required.'});
  let config;
  try {config = configuration(env);} catch {return response(503, {error: 'Teams actions are not configured for this deployment.'});}
  let activity;
  try {activity = await readBody(request);} catch {return response(400, {error: 'Invalid or oversized activity.'});}
  try {await authenticate(request, activity, config, getKeys);} catch {return response(401, {error: 'Teams request authentication failed.'});}
  try {return response(200, invoke(activity, config));} catch {return response(400, {error: 'Unsupported Teams action payload.'});}
}
